import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/NotFound.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/pages/NotFound.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=e72f996b";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { Home, Plane } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import SEO from "/src/components/seo/SEO.tsx";
import Navigation from "/src/components/layout/Navigation.tsx";
import Atmosphere from "/src/components/atmosphere/Atmosphere.tsx";
import PreloadLink from "/src/components/ui/preload-link.tsx";
const ALTITUDE_404 = [
    '  ____    _   _   ____   _____  ',
    ' |  _ \\  / \\ | |/ ___| |  ___| ',
    ' | | | |/ _ \\| | |  _  | |_    ',
    ' | |_| / ___ \\ | |_| | |  _|   ',
    ' |____/_/   \\_|\\____|  |_|     '
];
const NotFound = ()=>{
    _s();
    const location = useLocation();
    useEffect(()=>{
        console.error('404 Error: User attempted to access non-existent route:', location.pathname);
    }, [
        location.pathname
    ]);
    const seoProps = {
        title: '404 - Page Not Found',
        description: "The page you're looking for doesn't exist. Return to the homepage to explore the portfolio.",
        noIndex: true,
        noFollow: true
    };
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "min-h-screen bg-background relative overflow-hidden",
        children: [
            /*#__PURE__*/ _jsxDEV(Atmosphere, {
                variant: "mist"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(SEO, {
                ...seoProps
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(Navigation, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "relative z-10 min-h-screen flex items-center justify-center px-4",
                children: /*#__PURE__*/ _jsxDEV("div", {
                    className: "text-center",
                    children: [
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                scale: 0.9
                            },
                            animate: {
                                opacity: 1,
                                scale: 1
                            },
                            transition: {
                                duration: 0.6
                            },
                            className: "mb-8",
                            children: /*#__PURE__*/ _jsxDEV("pre", {
                                className: "font-mono gold-text/80 leading-tight text-xs sm:text-sm md:text-base overflow-x-auto",
                                children: ALTITUDE_404.join('\n')
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                                lineNumber: 50,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                            lineNumber: 44,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.h1, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.2,
                                duration: 0.5
                            },
                            className: "text-3xl md:text-4xl font-bold font-heading mb-4",
                            children: "Lost above the clouds"
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.p, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.4,
                                duration: 0.5
                            },
                            className: "text-xl text-mist-soft max-w-xl mx-auto mb-8 font-light",
                            children: [
                                /*#__PURE__*/ _jsxDEV(Plane, {
                                    className: "inline h-5 w-5 gold-text mr-2"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("span", {
                                    className: "font-mono text-sm",
                                    children: [
                                        "no route found at `",
                                        location.pathname,
                                        "`"
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                                    lineNumber: 71,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.6,
                                duration: 0.5
                            },
                            children: /*#__PURE__*/ _jsxDEV(PreloadLink, {
                                to: "/",
                                children: /*#__PURE__*/ _jsxDEV("span", {
                                    className: "inline-flex items-center px-8 py-3.5 rounded-lg bg-mist text-storm-deep text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 hover:shadow-glow-strong",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV(Home, {
                                            className: "mr-2 h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                                            lineNumber: 83,
                                            columnNumber: 17
                                        }, this),
                                        "Back to Home"
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                                    lineNumber: 82,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                                lineNumber: 81,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                            lineNumber: 76,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                    lineNumber: 42,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/NotFound.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
};
_s(NotFound, "BXcZrDMM76mmm4zA8/QV5UbMNXE=", false, function() {
    return [
        useLocation
    ];
});
_c = NotFound;
export default NotFound;
var _c;
$RefreshReg$(_c, "NotFound");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/pages/NotFound.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/pages/NotFound.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk5vdEZvdW5kLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uIH0gZnJvbSAnZnJhbWVyLW1vdGlvbic7XG5pbXBvcnQgeyBIb21lLCBQbGFuZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgU0VPIGZyb20gJ0AvY29tcG9uZW50cy9zZW8vU0VPJztcbmltcG9ydCBOYXZpZ2F0aW9uIGZyb20gJ0AvY29tcG9uZW50cy9sYXlvdXQvTmF2aWdhdGlvbic7XG5pbXBvcnQgQXRtb3NwaGVyZSBmcm9tICdAL2NvbXBvbmVudHMvYXRtb3NwaGVyZS9BdG1vc3BoZXJlJztcbmltcG9ydCBQcmVsb2FkTGluayBmcm9tICdAL2NvbXBvbmVudHMvdWkvcHJlbG9hZC1saW5rJztcblxuY29uc3QgQUxUSVRVREVfNDA0ID0gW1xuICAnICBfX19fICAgIF8gICBfICAgX19fXyAgIF9fX19fICAnLFxuICAnIHwgIF8gXFxcXCAgLyBcXFxcIHwgfC8gX19ffCB8ICBfX198ICcsXG4gICcgfCB8IHwgfC8gXyBcXFxcfCB8IHwgIF8gIHwgfF8gICAgJyxcbiAgJyB8IHxffCAvIF9fXyBcXFxcIHwgfF98IHwgfCAgX3wgICAnLFxuICAnIHxfX19fL18vICAgXFxcXF98XFxcXF9fX198ICB8X3wgICAgICcsXG5dO1xuXG5jb25zdCBOb3RGb3VuZCA9ICgpID0+IHtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc29sZS5lcnJvcihcbiAgICAgICc0MDQgRXJyb3I6IFVzZXIgYXR0ZW1wdGVkIHRvIGFjY2VzcyBub24tZXhpc3RlbnQgcm91dGU6JyxcbiAgICAgIGxvY2F0aW9uLnBhdGhuYW1lXG4gICAgKTtcbiAgfSwgW2xvY2F0aW9uLnBhdGhuYW1lXSk7XG5cbiAgY29uc3Qgc2VvUHJvcHMgPSB7XG4gICAgdGl0bGU6ICc0MDQgLSBQYWdlIE5vdCBGb3VuZCcsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICBcIlRoZSBwYWdlIHlvdSdyZSBsb29raW5nIGZvciBkb2Vzbid0IGV4aXN0LiBSZXR1cm4gdG8gdGhlIGhvbWVwYWdlIHRvIGV4cGxvcmUgdGhlIHBvcnRmb2xpby5cIixcbiAgICBub0luZGV4OiB0cnVlLFxuICAgIG5vRm9sbG93OiB0cnVlLFxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9J21pbi1oLXNjcmVlbiBiZy1iYWNrZ3JvdW5kIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbic+XG4gICAgICA8QXRtb3NwaGVyZSB2YXJpYW50PSdtaXN0JyAvPlxuICAgICAgPFNFTyB7Li4uc2VvUHJvcHN9IC8+XG4gICAgICA8TmF2aWdhdGlvbiAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9J3JlbGF0aXZlIHotMTAgbWluLWgtc2NyZWVuIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB4LTQnPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ndGV4dC1jZW50ZXInPlxuICAgICAgICAgIHsvKiBBbHRpdHVkZSBhcnQgKi99XG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgc2NhbGU6IDAuOSB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCBzY2FsZTogMSB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC42IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J21iLTgnXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9J2ZvbnQtbW9ubyBnb2xkLXRleHQvODAgbGVhZGluZy10aWdodCB0ZXh0LXhzIHNtOnRleHQtc20gbWQ6dGV4dC1iYXNlIG92ZXJmbG93LXgtYXV0byc+XG4gICAgICAgICAgICAgIHtBTFRJVFVERV80MDQuam9pbignXFxuJyl9XG4gICAgICAgICAgICA8L3ByZT5cbiAgICAgICAgICA8L21vdGlvbi5kaXY+XG5cbiAgICAgICAgICA8bW90aW9uLmgxXG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuMiwgZHVyYXRpb246IDAuNSB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPSd0ZXh0LTN4bCBtZDp0ZXh0LTR4bCBmb250LWJvbGQgZm9udC1oZWFkaW5nIG1iLTQnXG4gICAgICAgICAgPlxuICAgICAgICAgICAgTG9zdCBhYm92ZSB0aGUgY2xvdWRzXG4gICAgICAgICAgPC9tb3Rpb24uaDE+XG5cbiAgICAgICAgICA8bW90aW9uLnBcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMjAgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC40LCBkdXJhdGlvbjogMC41IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J3RleHQteGwgdGV4dC1taXN0LXNvZnQgbWF4LXcteGwgbXgtYXV0byBtYi04IGZvbnQtbGlnaHQnXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFBsYW5lIGNsYXNzTmFtZT0naW5saW5lIGgtNSB3LTUgZ29sZC10ZXh0IG1yLTInIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXNtJz5cbiAgICAgICAgICAgICAgbm8gcm91dGUgZm91bmQgYXQgYHtsb2NhdGlvbi5wYXRobmFtZX1gXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9tb3Rpb24ucD5cblxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuNiwgZHVyYXRpb246IDAuNSB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxQcmVsb2FkTGluayB0bz0nLyc+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0naW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTggcHktMy41IHJvdW5kZWQtbGcgYmctbWlzdCB0ZXh0LXN0b3JtLWRlZXAgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBob3ZlcjotdHJhbnNsYXRlLXktMC41IGhvdmVyOnNoYWRvdy1nbG93LXN0cm9uZyc+XG4gICAgICAgICAgICAgICAgPEhvbWUgY2xhc3NOYW1lPSdtci0yIGgtNCB3LTQnIC8+XG4gICAgICAgICAgICAgICAgQmFjayB0byBIb21lXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvUHJlbG9hZExpbms+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTm90Rm91bmQ7XG4iXSwibmFtZXMiOlsidXNlTG9jYXRpb24iLCJ1c2VFZmZlY3QiLCJtb3Rpb24iLCJIb21lIiwiUGxhbmUiLCJTRU8iLCJOYXZpZ2F0aW9uIiwiQXRtb3NwaGVyZSIsIlByZWxvYWRMaW5rIiwiQUxUSVRVREVfNDA0IiwiTm90Rm91bmQiLCJsb2NhdGlvbiIsImNvbnNvbGUiLCJlcnJvciIsInBhdGhuYW1lIiwic2VvUHJvcHMiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwibm9JbmRleCIsIm5vRm9sbG93IiwiZGl2IiwiY2xhc3NOYW1lIiwidmFyaWFudCIsImluaXRpYWwiLCJvcGFjaXR5Iiwic2NhbGUiLCJhbmltYXRlIiwidHJhbnNpdGlvbiIsImR1cmF0aW9uIiwicHJlIiwiam9pbiIsImgxIiwieSIsImRlbGF5IiwicCIsInNwYW4iLCJ0byJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLFNBQVNBLFdBQVcsUUFBUSxtQkFBbUI7QUFDL0MsU0FBU0MsU0FBUyxRQUFRLFFBQVE7QUFDbEMsU0FBU0MsTUFBTSxRQUFRLGdCQUFnQjtBQUN2QyxTQUFTQyxJQUFJLEVBQUVDLEtBQUssUUFBUSxlQUFlO0FBQzNDLE9BQU9DLFNBQVMsdUJBQXVCO0FBQ3ZDLE9BQU9DLGdCQUFnQixpQ0FBaUM7QUFDeEQsT0FBT0MsZ0JBQWdCLHFDQUFxQztBQUM1RCxPQUFPQyxpQkFBaUIsK0JBQStCO0FBRXZELE1BQU1DLGVBQWU7SUFDbkI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtDQUNEO0FBRUQsTUFBTUMsV0FBVzs7SUFDZixNQUFNQyxXQUFXWDtJQUVqQkMsVUFBVTtRQUNSVyxRQUFRQyxLQUFLLENBQ1gsMkRBQ0FGLFNBQVNHLFFBQVE7SUFFckIsR0FBRztRQUFDSCxTQUFTRyxRQUFRO0tBQUM7SUFFdEIsTUFBTUMsV0FBVztRQUNmQyxPQUFPO1FBQ1BDLGFBQ0U7UUFDRkMsU0FBUztRQUNUQyxVQUFVO0lBQ1o7SUFFQSxxQkFDRSxRQUFDQztRQUFJQyxXQUFVOzswQkFDYixRQUFDZDtnQkFBV2UsU0FBUTs7Ozs7OzBCQUNwQixRQUFDakI7Z0JBQUssR0FBR1UsUUFBUTs7Ozs7OzBCQUNqQixRQUFDVDs7Ozs7MEJBQ0QsUUFBQ2M7Z0JBQUlDLFdBQVU7MEJBQ2IsY0FBQSxRQUFDRDtvQkFBSUMsV0FBVTs7c0NBRWIsUUFBQ25CLE9BQU9rQixHQUFHOzRCQUNURyxTQUFTO2dDQUFFQyxTQUFTO2dDQUFHQyxPQUFPOzRCQUFJOzRCQUNsQ0MsU0FBUztnQ0FBRUYsU0FBUztnQ0FBR0MsT0FBTzs0QkFBRTs0QkFDaENFLFlBQVk7Z0NBQUVDLFVBQVU7NEJBQUk7NEJBQzVCUCxXQUFVO3NDQUVWLGNBQUEsUUFBQ1E7Z0NBQUlSLFdBQVU7MENBQ1paLGFBQWFxQixJQUFJLENBQUM7Ozs7Ozs7Ozs7O3NDQUl2QixRQUFDNUIsT0FBTzZCLEVBQUU7NEJBQ1JSLFNBQVM7Z0NBQUVDLFNBQVM7Z0NBQUdRLEdBQUc7NEJBQUc7NEJBQzdCTixTQUFTO2dDQUFFRixTQUFTO2dDQUFHUSxHQUFHOzRCQUFFOzRCQUM1QkwsWUFBWTtnQ0FBRU0sT0FBTztnQ0FBS0wsVUFBVTs0QkFBSTs0QkFDeENQLFdBQVU7c0NBQ1g7Ozs7OztzQ0FJRCxRQUFDbkIsT0FBT2dDLENBQUM7NEJBQ1BYLFNBQVM7Z0NBQUVDLFNBQVM7Z0NBQUdRLEdBQUc7NEJBQUc7NEJBQzdCTixTQUFTO2dDQUFFRixTQUFTO2dDQUFHUSxHQUFHOzRCQUFFOzRCQUM1QkwsWUFBWTtnQ0FBRU0sT0FBTztnQ0FBS0wsVUFBVTs0QkFBSTs0QkFDeENQLFdBQVU7OzhDQUVWLFFBQUNqQjtvQ0FBTWlCLFdBQVU7Ozs7Ozs4Q0FDakIsUUFBQ2M7b0NBQUtkLFdBQVU7O3dDQUFvQjt3Q0FDZFYsU0FBU0csUUFBUTt3Q0FBQzs7Ozs7Ozs7Ozs7OztzQ0FJMUMsUUFBQ1osT0FBT2tCLEdBQUc7NEJBQ1RHLFNBQVM7Z0NBQUVDLFNBQVM7Z0NBQUdRLEdBQUc7NEJBQUc7NEJBQzdCTixTQUFTO2dDQUFFRixTQUFTO2dDQUFHUSxHQUFHOzRCQUFFOzRCQUM1QkwsWUFBWTtnQ0FBRU0sT0FBTztnQ0FBS0wsVUFBVTs0QkFBSTtzQ0FFeEMsY0FBQSxRQUFDcEI7Z0NBQVk0QixJQUFHOzBDQUNkLGNBQUEsUUFBQ0Q7b0NBQUtkLFdBQVU7O3NEQUNkLFFBQUNsQjs0Q0FBS2tCLFdBQVU7Ozs7Ozt3Q0FBaUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFTakQ7R0ExRU1YOztRQUNhVjs7O0tBRGJVO0FBNEVOLGVBQWVBLFNBQVMifQ==