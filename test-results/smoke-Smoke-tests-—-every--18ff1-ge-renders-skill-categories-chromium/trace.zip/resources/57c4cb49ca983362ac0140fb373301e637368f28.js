import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Footer.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { Github, Mail, Send } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import PreloadLink from "/src/components/ui/preload-link.tsx";
const TELEMETRY = [
    'HEADING 045',
    'G/S 320 KTS',
    'FL380',
    'WIND 12 KT',
    'FUEL 45%',
    'PAX 0 · RELIABLE',
    'TICKETS RESOLVED 1000+',
    'SYSTEMS KEPT RUNNING 500+',
    'EST ARRIVAL · CLOUD-9'
];
const Footer = ()=>{
    const links = [
        {
            icon: Github,
            href: 'https://github.com/jaHxii',
            label: 'GitHub'
        },
        {
            icon: Send,
            href: 'https://t.me/cloudx69',
            label: 'LinkedIn/Telegram'
        },
        {
            icon: Mail,
            href: 'mailto:ermias.xii@gmail.com',
            label: 'Email'
        }
    ];
    return /*#__PURE__*/ _jsxDEV("footer", {
        className: "relative border-t border-white/5 bg-background overflow-hidden",
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                "aria-hidden": "true",
                className: "absolute inset-x-0 top-0 h-40 opacity-40 pointer-events-none",
                style: {
                    background: 'linear-gradient(180deg, transparent, hsl(42 58% 64% / 0.06))'
                }
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                "aria-hidden": "true",
                className: "group relative z-10 overflow-hidden border-b border-white/5 bg-white/[0.02]",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-background to-transparent z-10"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-background to-transparent z-10"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                        lineNumber: 41,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex whitespace-nowrap motion-safe:animate-marquee-reverse [animation-duration:80s] group-hover:[animation-play-state:paused]",
                        children: [
                            0,
                            1
                        ].map((duplicate)=>/*#__PURE__*/ _jsxDEV("div", {
                                className: "flex shrink-0 items-center py-3 font-mono text-[11px] tracking-[0.25em] text-mist-soft/70",
                                children: TELEMETRY.map((item)=>/*#__PURE__*/ _jsxDEV("span", {
                                        className: "inline-flex items-center px-8",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "mr-3 h-1.5 w-1.5 rounded-full bg-gold/70"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                                lineNumber: 50,
                                                columnNumber: 19
                                            }, this),
                                            item
                                        ]
                                    }, item, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                        lineNumber: 49,
                                        columnNumber: 17
                                    }, this))
                            }, duplicate, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                lineNumber: 44,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "relative z-10 container mx-auto px-4 py-14",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex flex-col md:flex-row items-center justify-between gap-8",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                children: [
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        className: "font-heading font-semibold text-lg tracking-tight",
                                        children: "Ermias Lemesa"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                        lineNumber: 62,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        className: "text-sm text-mist-soft mt-1",
                                        children: "Computer Engineer"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                        lineNumber: 65,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                lineNumber: 61,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "flex items-center gap-5",
                                children: [
                                    links.map((link)=>/*#__PURE__*/ _jsxDEV("a", {
                                            href: link.href,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            "aria-label": link.label,
                                            className: "glass flex h-10 w-10 items-center justify-center rounded-full text-mist-soft transition-all duration-300 hover:text-gold hover:border-gold/60",
                                            children: /*#__PURE__*/ _jsxDEV(link.icon, {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                                lineNumber: 78,
                                                columnNumber: 17
                                            }, this)
                                        }, link.label, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                            lineNumber: 70,
                                            columnNumber: 15
                                        }, this)),
                                    /*#__PURE__*/ _jsxDEV(PreloadLink, {
                                        to: "/resume",
                                        className: "text-sm text-mist-soft hover:text-gold transition-colors",
                                        children: "CV"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                lineNumber: 68,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                        lineNumber: 60,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "mt-10 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3",
                        children: [
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "font-mono text-[11px] tracking-[0.3em] text-mist-soft/60",
                                children: "SYSTEMS ONLINE"
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                lineNumber: 91,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "font-mono text-[11px] tracking-[0.2em] text-mist-soft/60",
                                children: "© 2026 ERMIAS LEMESA"
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                                lineNumber: 94,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
};
_c = Footer;
export default Footer;
var _c;
$RefreshReg$(_c, "Footer");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/layout/Footer.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkZvb3Rlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEdpdGh1YiwgTWFpbCwgU2VuZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgUHJlbG9hZExpbmsgZnJvbSAnQC9jb21wb25lbnRzL3VpL3ByZWxvYWQtbGluayc7XG5cbmNvbnN0IFRFTEVNRVRSWSA9IFtcbiAgJ0hFQURJTkcgMDQ1JyxcbiAgJ0cvUyAzMjAgS1RTJyxcbiAgJ0ZMMzgwJyxcbiAgJ1dJTkQgMTIgS1QnLFxuICAnRlVFTCA0NSUnLFxuICAnUEFYIDAgwrcgUkVMSUFCTEUnLFxuICAnVElDS0VUUyBSRVNPTFZFRCAxMDAwKycsXG4gICdTWVNURU1TIEtFUFQgUlVOTklORyA1MDArJyxcbiAgJ0VTVCBBUlJJVkFMIMK3IENMT1VELTknLFxuXTtcblxuY29uc3QgRm9vdGVyID0gKCkgPT4ge1xuICBjb25zdCBsaW5rcyA9IFtcbiAgICB7IGljb246IEdpdGh1YiwgaHJlZjogJ2h0dHBzOi8vZ2l0aHViLmNvbS9qYUh4aWknLCBsYWJlbDogJ0dpdEh1YicgfSxcbiAgICB7IGljb246IFNlbmQsIGhyZWY6ICdodHRwczovL3QubWUvY2xvdWR4NjknLCBsYWJlbDogJ0xpbmtlZEluL1RlbGVncmFtJyB9LFxuICAgIHsgaWNvbjogTWFpbCwgaHJlZjogJ21haWx0bzplcm1pYXMueGlpQGdtYWlsLmNvbScsIGxhYmVsOiAnRW1haWwnIH0sXG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8Zm9vdGVyIGNsYXNzTmFtZT0ncmVsYXRpdmUgYm9yZGVyLXQgYm9yZGVyLXdoaXRlLzUgYmctYmFja2dyb3VuZCBvdmVyZmxvdy1oaWRkZW4nPlxuICAgICAgPGRpdlxuICAgICAgICBhcmlhLWhpZGRlbj0ndHJ1ZSdcbiAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSBpbnNldC14LTAgdG9wLTAgaC00MCBvcGFjaXR5LTQwIHBvaW50ZXItZXZlbnRzLW5vbmUnXG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgYmFja2dyb3VuZDpcbiAgICAgICAgICAgICdsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCB0cmFuc3BhcmVudCwgaHNsKDQyIDU4JSA2NCUgLyAwLjA2KSknLFxuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAgey8qIFRlbGVtZXRyeSB0aWNrZXIgKi99XG4gICAgICA8ZGl2XG4gICAgICAgIGFyaWEtaGlkZGVuPSd0cnVlJ1xuICAgICAgICBjbGFzc05hbWU9J2dyb3VwIHJlbGF0aXZlIHotMTAgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlci1iIGJvcmRlci13aGl0ZS81IGJnLXdoaXRlL1swLjAyXSdcbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Fic29sdXRlIGxlZnQtMCB0b3AtMCBib3R0b20tMCB3LTI0IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1iYWNrZ3JvdW5kIHRvLXRyYW5zcGFyZW50IHotMTAnIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdhYnNvbHV0ZSByaWdodC0wIHRvcC0wIGJvdHRvbS0wIHctMjQgYmctZ3JhZGllbnQtdG8tbCBmcm9tLWJhY2tncm91bmQgdG8tdHJhbnNwYXJlbnQgei0xMCcgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggd2hpdGVzcGFjZS1ub3dyYXAgbW90aW9uLXNhZmU6YW5pbWF0ZS1tYXJxdWVlLXJldmVyc2UgW2FuaW1hdGlvbi1kdXJhdGlvbjo4MHNdIGdyb3VwLWhvdmVyOlthbmltYXRpb24tcGxheS1zdGF0ZTpwYXVzZWRdJz5cbiAgICAgICAgICB7WzAsIDFdLm1hcChkdXBsaWNhdGUgPT4gKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBrZXk9e2R1cGxpY2F0ZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSdmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBweS0zIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XSB0cmFja2luZy1bMC4yNWVtXSB0ZXh0LW1pc3Qtc29mdC83MCdcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge1RFTEVNRVRSWS5tYXAoaXRlbSA9PiAoXG4gICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpdGVtfSBjbGFzc05hbWU9J2lubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC04Jz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nbXItMyBoLTEuNSB3LTEuNSByb3VuZGVkLWZ1bGwgYmctZ29sZC83MCcgLz5cbiAgICAgICAgICAgICAgICAgIHtpdGVtfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9J3JlbGF0aXZlIHotMTAgY29udGFpbmVyIG14LWF1dG8gcHgtNCBweS0xNCc+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTgnPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9J2ZvbnQtaGVhZGluZyBmb250LXNlbWlib2xkIHRleHQtbGcgdHJhY2tpbmctdGlnaHQnPlxuICAgICAgICAgICAgICBFcm1pYXMgTGVtZXNhXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtc20gdGV4dC1taXN0LXNvZnQgbXQtMSc+Q29tcHV0ZXIgRW5naW5lZXI8L3A+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTUnPlxuICAgICAgICAgICAge2xpbmtzLm1hcChsaW5rID0+IChcbiAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICBrZXk9e2xpbmsubGFiZWx9XG4gICAgICAgICAgICAgICAgaHJlZj17bGluay5ocmVmfVxuICAgICAgICAgICAgICAgIHRhcmdldD0nX2JsYW5rJ1xuICAgICAgICAgICAgICAgIHJlbD0nbm9vcGVuZXIgbm9yZWZlcnJlcidcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtsaW5rLmxhYmVsfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZ2xhc3MgZmxleCBoLTEwIHctMTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCB0ZXh0LW1pc3Qtc29mdCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgaG92ZXI6dGV4dC1nb2xkIGhvdmVyOmJvcmRlci1nb2xkLzYwJ1xuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGxpbmsuaWNvbiBjbGFzc05hbWU9J2gtNCB3LTQnIC8+XG4gICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPFByZWxvYWRMaW5rXG4gICAgICAgICAgICAgIHRvPScvcmVzdW1lJ1xuICAgICAgICAgICAgICBjbGFzc05hbWU9J3RleHQtc20gdGV4dC1taXN0LXNvZnQgaG92ZXI6dGV4dC1nb2xkIHRyYW5zaXRpb24tY29sb3JzJ1xuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBDVlxuICAgICAgICAgICAgPC9QcmVsb2FkTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J210LTEwIHB0LTYgYm9yZGVyLXQgYm9yZGVyLXdoaXRlLzUgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zJz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LVsxMXB4XSB0cmFja2luZy1bMC4zZW1dIHRleHQtbWlzdC1zb2Z0LzYwJz5cbiAgICAgICAgICAgIFNZU1RFTVMgT05MSU5FXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQtWzExcHhdIHRyYWNraW5nLVswLjJlbV0gdGV4dC1taXN0LXNvZnQvNjAnPlxuICAgICAgICAgICAgwqkgMjAyNiBFUk1JQVMgTEVNRVNBXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZm9vdGVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgRm9vdGVyO1xuIl0sIm5hbWVzIjpbIlJlYWN0IiwiR2l0aHViIiwiTWFpbCIsIlNlbmQiLCJQcmVsb2FkTGluayIsIlRFTEVNRVRSWSIsIkZvb3RlciIsImxpbmtzIiwiaWNvbiIsImhyZWYiLCJsYWJlbCIsImZvb3RlciIsImNsYXNzTmFtZSIsImRpdiIsImFyaWEtaGlkZGVuIiwic3R5bGUiLCJiYWNrZ3JvdW5kIiwibWFwIiwiZHVwbGljYXRlIiwiaXRlbSIsInNwYW4iLCJwIiwibGluayIsImEiLCJ0YXJnZXQiLCJyZWwiLCJhcmlhLWxhYmVsIiwidG8iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLE9BQU9BLFdBQVcsUUFBUTtBQUMxQixTQUFTQyxNQUFNLEVBQUVDLElBQUksRUFBRUMsSUFBSSxRQUFRLGVBQWU7QUFDbEQsT0FBT0MsaUJBQWlCLCtCQUErQjtBQUV2RCxNQUFNQyxZQUFZO0lBQ2hCO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtDQUNEO0FBRUQsTUFBTUMsU0FBUztJQUNiLE1BQU1DLFFBQVE7UUFDWjtZQUFFQyxNQUFNUDtZQUFRUSxNQUFNO1lBQTZCQyxPQUFPO1FBQVM7UUFDbkU7WUFBRUYsTUFBTUw7WUFBTU0sTUFBTTtZQUF5QkMsT0FBTztRQUFvQjtRQUN4RTtZQUFFRixNQUFNTjtZQUFNTyxNQUFNO1lBQStCQyxPQUFPO1FBQVE7S0FDbkU7SUFFRCxxQkFDRSxRQUFDQztRQUFPQyxXQUFVOzswQkFDaEIsUUFBQ0M7Z0JBQ0NDLGVBQVk7Z0JBQ1pGLFdBQVU7Z0JBQ1ZHLE9BQU87b0JBQ0xDLFlBQ0U7Z0JBQ0o7Ozs7OzswQkFJRixRQUFDSDtnQkFDQ0MsZUFBWTtnQkFDWkYsV0FBVTs7a0NBRVYsUUFBQ0M7d0JBQUlELFdBQVU7Ozs7OztrQ0FDZixRQUFDQzt3QkFBSUQsV0FBVTs7Ozs7O2tDQUNmLFFBQUNDO3dCQUFJRCxXQUFVO2tDQUNaOzRCQUFDOzRCQUFHO3lCQUFFLENBQUNLLEdBQUcsQ0FBQ0MsQ0FBQUEsMEJBQ1YsUUFBQ0w7Z0NBRUNELFdBQVU7MENBRVRQLFVBQVVZLEdBQUcsQ0FBQ0UsQ0FBQUEscUJBQ2IsUUFBQ0M7d0NBQWdCUixXQUFVOzswREFDekIsUUFBQ1E7Z0RBQUtSLFdBQVU7Ozs7Ozs0Q0FDZk87O3VDQUZRQTs7Ozs7K0JBSlJEOzs7Ozs7Ozs7Ozs7Ozs7OzBCQWNiLFFBQUNMO2dCQUFJRCxXQUFVOztrQ0FDYixRQUFDQzt3QkFBSUQsV0FBVTs7MENBQ2IsUUFBQ0M7O2tEQUNDLFFBQUNRO3dDQUFFVCxXQUFVO2tEQUFvRDs7Ozs7O2tEQUdqRSxRQUFDUzt3Q0FBRVQsV0FBVTtrREFBOEI7Ozs7Ozs7Ozs7OzswQ0FHN0MsUUFBQ0M7Z0NBQUlELFdBQVU7O29DQUNaTCxNQUFNVSxHQUFHLENBQUNLLENBQUFBLHFCQUNULFFBQUNDOzRDQUVDZCxNQUFNYSxLQUFLYixJQUFJOzRDQUNmZSxRQUFPOzRDQUNQQyxLQUFJOzRDQUNKQyxjQUFZSixLQUFLWixLQUFLOzRDQUN0QkUsV0FBVTtzREFFVixjQUFBLFFBQUNVLEtBQUtkLElBQUk7Z0RBQUNJLFdBQVU7Ozs7OzsyQ0FQaEJVLEtBQUtaLEtBQUs7Ozs7O2tEQVVuQixRQUFDTjt3Q0FDQ3VCLElBQUc7d0NBQ0hmLFdBQVU7a0RBQ1g7Ozs7Ozs7Ozs7Ozs7Ozs7OztrQ0FNTCxRQUFDQzt3QkFBSUQsV0FBVTs7MENBQ2IsUUFBQ1E7Z0NBQUtSLFdBQVU7MENBQTJEOzs7Ozs7MENBRzNFLFFBQUNRO2dDQUFLUixXQUFVOzBDQUEyRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBT3JGO0tBcEZNTjtBQXNGTixlQUFlQSxPQUFPIn0=