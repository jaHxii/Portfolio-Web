import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/tooltip.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/tooltip.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport2_react);
import * as TooltipPrimitive from "/node_modules/.vite/deps/@radix-ui_react-tooltip.js?v=e72f996b";
import { cn } from "/src/lib/utils.ts";
const TooltipProvider = TooltipPrimitive.Provider;
const Tooltip = TooltipPrimitive.Root;
const TooltipTrigger = TooltipPrimitive.Trigger;
const TooltipContent = /*#__PURE__*/ React.forwardRef(_c = ({ className, sideOffset = 4, ...props }, ref)=>/*#__PURE__*/ _jsxDEV(TooltipPrimitive.Content, {
        ref: ref,
        sideOffset: sideOffset,
        className: cn("z-50 overflow-hidden rounded-md border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", className),
        ...props
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/tooltip.tsx",
        lineNumber: 16,
        columnNumber: 3
    }, this));
_c1 = TooltipContent;
TooltipContent.displayName = TooltipPrimitive.Content.displayName;
export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };
var _c, _c1;
$RefreshReg$(_c, "TooltipContent$React.forwardRef");
$RefreshReg$(_c1, "TooltipContent");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/tooltip.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/tooltip.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRvb2x0aXAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgKiBhcyBUb29sdGlwUHJpbWl0aXZlIGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtdG9vbHRpcFwiXG5cbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCJcblxuY29uc3QgVG9vbHRpcFByb3ZpZGVyID0gVG9vbHRpcFByaW1pdGl2ZS5Qcm92aWRlclxuXG5jb25zdCBUb29sdGlwID0gVG9vbHRpcFByaW1pdGl2ZS5Sb290XG5cbmNvbnN0IFRvb2x0aXBUcmlnZ2VyID0gVG9vbHRpcFByaW1pdGl2ZS5UcmlnZ2VyXG5cbmNvbnN0IFRvb2x0aXBDb250ZW50ID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgVG9vbHRpcFByaW1pdGl2ZS5Db250ZW50PixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBUb29sdGlwUHJpbWl0aXZlLkNvbnRlbnQ+XG4+KCh7IGNsYXNzTmFtZSwgc2lkZU9mZnNldCA9IDQsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8VG9vbHRpcFByaW1pdGl2ZS5Db250ZW50XG4gICAgcmVmPXtyZWZ9XG4gICAgc2lkZU9mZnNldD17c2lkZU9mZnNldH1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJ6LTUwIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLW1kIGJvcmRlciBiZy1wb3BvdmVyIHB4LTMgcHktMS41IHRleHQtc20gdGV4dC1wb3BvdmVyLWZvcmVncm91bmQgc2hhZG93LW1kIGFuaW1hdGUtaW4gZmFkZS1pbi0wIHpvb20taW4tOTUgZGF0YS1bc3RhdGU9Y2xvc2VkXTphbmltYXRlLW91dCBkYXRhLVtzdGF0ZT1jbG9zZWRdOmZhZGUtb3V0LTAgZGF0YS1bc3RhdGU9Y2xvc2VkXTp6b29tLW91dC05NSBkYXRhLVtzaWRlPWJvdHRvbV06c2xpZGUtaW4tZnJvbS10b3AtMiBkYXRhLVtzaWRlPWxlZnRdOnNsaWRlLWluLWZyb20tcmlnaHQtMiBkYXRhLVtzaWRlPXJpZ2h0XTpzbGlkZS1pbi1mcm9tLWxlZnQtMiBkYXRhLVtzaWRlPXRvcF06c2xpZGUtaW4tZnJvbS1ib3R0b20tMlwiLFxuICAgICAgY2xhc3NOYW1lXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKVxuVG9vbHRpcENvbnRlbnQuZGlzcGxheU5hbWUgPSBUb29sdGlwUHJpbWl0aXZlLkNvbnRlbnQuZGlzcGxheU5hbWVcblxuZXhwb3J0IHsgVG9vbHRpcCwgVG9vbHRpcFRyaWdnZXIsIFRvb2x0aXBDb250ZW50LCBUb29sdGlwUHJvdmlkZXIgfVxuIl0sIm5hbWVzIjpbIlJlYWN0IiwiVG9vbHRpcFByaW1pdGl2ZSIsImNuIiwiVG9vbHRpcFByb3ZpZGVyIiwiUHJvdmlkZXIiLCJUb29sdGlwIiwiUm9vdCIsIlRvb2x0aXBUcmlnZ2VyIiwiVHJpZ2dlciIsIlRvb2x0aXBDb250ZW50IiwiZm9yd2FyZFJlZiIsImNsYXNzTmFtZSIsInNpZGVPZmZzZXQiLCJwcm9wcyIsInJlZiIsIkNvbnRlbnQiLCJkaXNwbGF5TmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsWUFBWUEsV0FBVyxRQUFPO0FBQzlCLFlBQVlDLHNCQUFzQiwwQkFBeUI7QUFFM0QsU0FBU0MsRUFBRSxRQUFRLGNBQWE7QUFFaEMsTUFBTUMsa0JBQWtCRixpQkFBaUJHLFFBQVE7QUFFakQsTUFBTUMsVUFBVUosaUJBQWlCSyxJQUFJO0FBRXJDLE1BQU1DLGlCQUFpQk4saUJBQWlCTyxPQUFPO0FBRS9DLE1BQU1DLCtCQUFpQlQsTUFBTVUsVUFBVSxNQUdyQyxDQUFDLEVBQUVDLFNBQVMsRUFBRUMsYUFBYSxDQUFDLEVBQUUsR0FBR0MsT0FBTyxFQUFFQyxvQkFDMUMsUUFBQ2IsaUJBQWlCYyxPQUFPO1FBQ3ZCRCxLQUFLQTtRQUNMRixZQUFZQTtRQUNaRCxXQUFXVCxHQUNULHNZQUNBUztRQUVELEdBQUdFLEtBQUs7Ozs7Ozs7QUFHYkosZUFBZU8sV0FBVyxHQUFHZixpQkFBaUJjLE9BQU8sQ0FBQ0MsV0FBVztBQUVqRSxTQUFTWCxPQUFPLEVBQUVFLGNBQWMsRUFBRUUsY0FBYyxFQUFFTixlQUFlLEdBQUUifQ==