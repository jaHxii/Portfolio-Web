import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/flight-log.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/flight-log.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useEffect = __vite__cjsImport2_react["useEffect"]; const useState = __vite__cjsImport2_react["useState"];
const FlightLog = ({ entries })=>{
    _s();
    const [index, setIndex] = useState(0);
    useEffect(()=>{
        if (typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            return;
        }
        const timer = setInterval(()=>setIndex((prev)=>(prev + 1) % entries.length), 2800);
        return ()=>clearInterval(timer);
    }, [
        entries.length
    ]);
    const text = entries[index % entries.length] ?? entries[0] ?? '';
    return /*#__PURE__*/ _jsxDEV("span", {
        className: "glass inline-flex items-center gap-2.5 rounded-full px-5 py-2 font-mono text-[11px] tracking-[0.25em] text-mist-soft",
        children: [
            /*#__PURE__*/ _jsxDEV("span", {
                className: "relative flex h-2 w-2",
                "aria-hidden": "true",
                children: [
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "absolute inline-flex h-full w-full rounded-full bg-gold/50 motion-safe:animate-ping"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/flight-log.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "relative inline-flex h-2 w-2 rounded-full bg-gold"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/flight-log.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/flight-log.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            text
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/flight-log.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
};
_s(FlightLog, "c3fuAdVwNN91t4bNS1qBXl5hAWY=");
_c = FlightLog;
export default FlightLog;
var _c;
$RefreshReg$(_c, "FlightLog");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/flight-log.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/flight-log.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZsaWdodC1sb2cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5jb25zdCBGbGlnaHRMb2cgPSAoeyBlbnRyaWVzIH06IHsgZW50cmllczogc3RyaW5nW10gfSkgPT4ge1xuICBjb25zdCBbaW5kZXgsIHNldEluZGV4XSA9IHVzZVN0YXRlKDApO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKFxuICAgICAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAgIHdpbmRvdy5tYXRjaE1lZGlhKCcocHJlZmVycy1yZWR1Y2VkLW1vdGlvbjogcmVkdWNlKScpLm1hdGNoZXNcbiAgICApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgdGltZXIgPSBzZXRJbnRlcnZhbChcbiAgICAgICgpID0+IHNldEluZGV4KHByZXYgPT4gKHByZXYgKyAxKSAlIGVudHJpZXMubGVuZ3RoKSxcbiAgICAgIDI4MDBcbiAgICApO1xuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKHRpbWVyKTtcbiAgfSwgW2VudHJpZXMubGVuZ3RoXSk7XG5cbiAgY29uc3QgdGV4dCA9IGVudHJpZXNbaW5kZXggJSBlbnRyaWVzLmxlbmd0aF0gPz8gZW50cmllc1swXSA/PyAnJztcblxuICByZXR1cm4gKFxuICAgIDxzcGFuIGNsYXNzTmFtZT0nZ2xhc3MgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcm91bmRlZC1mdWxsIHB4LTUgcHktMiBmb250LW1vbm8gdGV4dC1bMTFweF0gdHJhY2tpbmctWzAuMjVlbV0gdGV4dC1taXN0LXNvZnQnPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPSdyZWxhdGl2ZSBmbGV4IGgtMiB3LTInIGFyaWEtaGlkZGVuPSd0cnVlJz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdhYnNvbHV0ZSBpbmxpbmUtZmxleCBoLWZ1bGwgdy1mdWxsIHJvdW5kZWQtZnVsbCBiZy1nb2xkLzUwIG1vdGlvbi1zYWZlOmFuaW1hdGUtcGluZycgLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdyZWxhdGl2ZSBpbmxpbmUtZmxleCBoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1nb2xkJyAvPlxuICAgICAgPC9zcGFuPlxuICAgICAge3RleHR9XG4gICAgPC9zcGFuPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgRmxpZ2h0TG9nO1xuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJGbGlnaHRMb2ciLCJlbnRyaWVzIiwiaW5kZXgiLCJzZXRJbmRleCIsIndpbmRvdyIsIm1hdGNoTWVkaWEiLCJtYXRjaGVzIiwidGltZXIiLCJzZXRJbnRlcnZhbCIsInByZXYiLCJsZW5ndGgiLCJjbGVhckludGVydmFsIiwidGV4dCIsInNwYW4iLCJjbGFzc05hbWUiLCJhcmlhLWhpZGRlbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFNBQVMsRUFBRUMsUUFBUSxRQUFRLFFBQVE7QUFFbkQsTUFBTUMsWUFBWSxDQUFDLEVBQUVDLE9BQU8sRUFBeUI7O0lBQ25ELE1BQU0sQ0FBQ0MsT0FBT0MsU0FBUyxHQUFHSixTQUFTO0lBRW5DRCxVQUFVO1FBQ1IsSUFDRSxPQUFPTSxXQUFXLGVBQ2xCQSxPQUFPQyxVQUFVLENBQUMsb0NBQW9DQyxPQUFPLEVBQzdEO1lBQ0E7UUFDRjtRQUNBLE1BQU1DLFFBQVFDLFlBQ1osSUFBTUwsU0FBU00sQ0FBQUEsT0FBUSxBQUFDQSxDQUFBQSxPQUFPLENBQUEsSUFBS1IsUUFBUVMsTUFBTSxHQUNsRDtRQUVGLE9BQU8sSUFBTUMsY0FBY0o7SUFDN0IsR0FBRztRQUFDTixRQUFRUyxNQUFNO0tBQUM7SUFFbkIsTUFBTUUsT0FBT1gsT0FBTyxDQUFDQyxRQUFRRCxRQUFRUyxNQUFNLENBQUMsSUFBSVQsT0FBTyxDQUFDLEVBQUUsSUFBSTtJQUU5RCxxQkFDRSxRQUFDWTtRQUFLQyxXQUFVOzswQkFDZCxRQUFDRDtnQkFBS0MsV0FBVTtnQkFBd0JDLGVBQVk7O2tDQUNsRCxRQUFDRjt3QkFBS0MsV0FBVTs7Ozs7O2tDQUNoQixRQUFDRDt3QkFBS0MsV0FBVTs7Ozs7Ozs7Ozs7O1lBRWpCRjs7Ozs7OztBQUdQO0dBNUJNWjtLQUFBQTtBQThCTixlQUFlQSxVQUFVIn0=