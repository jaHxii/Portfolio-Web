// Structured Data (JSON-LD) utilities for SEO
// Default person schema for the portfolio owner
export const createPersonSchema = (overrides)=>({
        '@context': 'https://schema.org',
        '@type': 'Person',
        name: 'Ermias Lemesa',
        jobTitle: 'Computer Engineer | IT Support Specialist | Hardware Engineer',
        description: 'Computer Engineer and Senior IT Support Specialist with hands-on experience in hardware, networking, helpdesk, and AI/ML.',
        url: typeof window !== 'undefined' ? window.location.origin : 'https://portfolio.example.com',
        image: '/portfolio.png',
        email: 'ermias.xii@gmail.com',
        address: {
            '@type': 'PostalAddress',
            addressLocality: 'Addis Ababa',
            addressCountry: 'Ethiopia'
        },
        sameAs: [
            'https://github.com/jaHxii',
            'https://t.me/cloudx69'
        ],
        knowsAbout: [
            'IT Support',
            'Hardware Engineering',
            'Networking',
            'Python',
            'Machine Learning',
            'Web Development',
            'Database Design'
        ],
        alumniOf: {
            '@type': 'EducationalOrganization',
            name: 'University of Gondar',
            url: 'https://www.uog.edu.et'
        },
        ...overrides
    });
// Create work schema for projects
export const createWorkSchema = (project)=>({
        '@context': 'https://schema.org',
        '@type': 'CreativeWork',
        name: project.name,
        description: project.description,
        url: project.url,
        image: project.image,
        dateCreated: project.dateCreated,
        dateModified: project.dateModified,
        creator: {
            '@type': 'Person',
            name: 'Ermias Lemesa'
        },
        keywords: project.keywords,
        genre: 'Software Application',
        programmingLanguage: project.programmingLanguage,
        codeRepository: project.codeRepository,
        runtimePlatform: project.runtimePlatform
    });
// Create organization schema for work experience
export const createOrganizationSchema = (organization)=>({
        '@context': 'https://schema.org',
        '@type': 'Organization',
        name: organization.name,
        description: organization.description,
        url: organization.url,
        logo: organization.logo,
        foundingDate: organization.foundingDate,
        address: organization.address ? {
            '@type': 'PostalAddress',
            addressLocality: organization.address.locality,
            addressCountry: organization.address.country
        } : undefined,
        employee: organization.employees?.map((emp)=>({
                '@type': 'Person',
                name: emp.name,
                jobTitle: emp.jobTitle,
                startDate: emp.startDate,
                endDate: emp.endDate
            }))
    });
// Create breadcrumb schema for navigation
export const createBreadcrumbSchema = (breadcrumbs)=>({
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: breadcrumbs.map((crumb, index)=>({
                '@type': 'ListItem',
                position: index + 1,
                name: crumb.name,
                item: crumb.url
            }))
    });
// Create website schema
export const createWebSiteSchema = (overrides)=>({
        '@context': 'https://schema.org',
        '@type': 'WebSite',
        name: 'Ermias Lemesa - Portfolio',
        description: 'Portfolio of Ermias Lemesa - Computer Engineer and Senior IT Support Specialist based in Addis Ababa, Ethiopia.',
        url: typeof window !== 'undefined' ? window.location.origin : 'https://portfolio.example.com',
        author: {
            '@type': 'Person',
            name: 'Ermias Lemesa'
        },
        potentialAction: {
            '@type': 'SearchAction',
            target: {
                '@type': 'EntryPoint',
                urlTemplate: `${typeof window !== 'undefined' ? window.location.origin : 'https://portfolio.example.com'}/search?q={search_term_string}`
            },
            'query-input': 'required name=search_term_string'
        },
        ...overrides
    });
// Utility function to generate JSON-LD script tag content
export const generateJSONLD = (schema)=>{
    return JSON.stringify(schema, null, 2);
};
// Validate JSON-LD schema
export const validateSchema = (schema)=>{
    try {
        // Basic validation - check required fields
        if (!schema['@context'] || !schema['@type']) {
            console.error('Schema missing required @context or @type');
            return false;
        }
        // Validate context
        if (schema['@context'] !== 'https://schema.org') {
            console.error('Invalid @context, should be https://schema.org');
            return false;
        }
        // Additional type-specific validation
        switch(schema['@type']){
            case 'Person':
                if (!schema.name) {
                    console.error('Person schema missing required name field');
                    return false;
                }
                break;
            case 'CreativeWork':
                if (!schema.name || !schema.description) {
                    console.error('CreativeWork schema missing required name or description');
                    return false;
                }
                break;
            case 'Organization':
                if (!schema.name) {
                    console.error('Organization schema missing required name field');
                    return false;
                }
                break;
            case 'BreadcrumbList':
                if (!schema.itemListElement || !Array.isArray(schema.itemListElement)) {
                    console.error('BreadcrumbList schema missing or invalid itemListElement');
                    return false;
                }
                break;
            case 'WebSite':
                if (!schema.name || !schema.url) {
                    console.error('WebSite schema missing required name or url');
                    return false;
                }
                break;
        }
        return true;
    } catch (error) {
        console.error('Schema validation error:', error);
        return false;
    }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0cnVjdHVyZWQtZGF0YS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBTdHJ1Y3R1cmVkIERhdGEgKEpTT04tTEQpIHV0aWxpdGllcyBmb3IgU0VPXG5cbmV4cG9ydCBpbnRlcmZhY2UgUGVyc29uU2NoZW1hIHtcbiAgJ0Bjb250ZXh0JzogJ2h0dHBzOi8vc2NoZW1hLm9yZyc7XG4gICdAdHlwZSc6ICdQZXJzb24nO1xuICBuYW1lOiBzdHJpbmc7XG4gIGpvYlRpdGxlOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICB1cmw/OiBzdHJpbmc7XG4gIGltYWdlPzogc3RyaW5nO1xuICBlbWFpbD86IHN0cmluZztcbiAgdGVsZXBob25lPzogc3RyaW5nO1xuICBhZGRyZXNzPzoge1xuICAgICdAdHlwZSc6ICdQb3N0YWxBZGRyZXNzJztcbiAgICBhZGRyZXNzTG9jYWxpdHk6IHN0cmluZztcbiAgICBhZGRyZXNzQ291bnRyeTogc3RyaW5nO1xuICB9O1xuICBzYW1lQXM/OiBzdHJpbmdbXTtcbiAga25vd3NBYm91dD86IHN0cmluZ1tdO1xuICBhbHVtbmlPZj86IHtcbiAgICAnQHR5cGUnOiAnRWR1Y2F0aW9uYWxPcmdhbml6YXRpb24nO1xuICAgIG5hbWU6IHN0cmluZztcbiAgICB1cmw/OiBzdHJpbmc7XG4gIH07XG4gIHdvcmtzRm9yPzoge1xuICAgICdAdHlwZSc6ICdPcmdhbml6YXRpb24nO1xuICAgIG5hbWU6IHN0cmluZztcbiAgICB1cmw/OiBzdHJpbmc7XG4gIH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgV29ya1NjaGVtYSB7XG4gICdAY29udGV4dCc6ICdodHRwczovL3NjaGVtYS5vcmcnO1xuICAnQHR5cGUnOiAnQ3JlYXRpdmVXb3JrJztcbiAgbmFtZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICB1cmw/OiBzdHJpbmc7XG4gIGltYWdlPzogc3RyaW5nO1xuICBkYXRlQ3JlYXRlZD86IHN0cmluZztcbiAgZGF0ZU1vZGlmaWVkPzogc3RyaW5nO1xuICBjcmVhdG9yOiB7XG4gICAgJ0B0eXBlJzogJ1BlcnNvbic7XG4gICAgbmFtZTogc3RyaW5nO1xuICB9O1xuICBrZXl3b3Jkcz86IHN0cmluZ1tdO1xuICBnZW5yZT86IHN0cmluZztcbiAgcHJvZ3JhbW1pbmdMYW5ndWFnZT86IHN0cmluZ1tdO1xuICBjb2RlUmVwb3NpdG9yeT86IHN0cmluZztcbiAgcnVudGltZVBsYXRmb3JtPzogc3RyaW5nW107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JnYW5pemF0aW9uU2NoZW1hIHtcbiAgJ0Bjb250ZXh0JzogJ2h0dHBzOi8vc2NoZW1hLm9yZyc7XG4gICdAdHlwZSc6ICdPcmdhbml6YXRpb24nO1xuICBuYW1lOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICB1cmw/OiBzdHJpbmc7XG4gIGxvZ28/OiBzdHJpbmc7XG4gIGFkZHJlc3M/OiB7XG4gICAgJ0B0eXBlJzogJ1Bvc3RhbEFkZHJlc3MnO1xuICAgIGFkZHJlc3NMb2NhbGl0eTogc3RyaW5nO1xuICAgIGFkZHJlc3NDb3VudHJ5OiBzdHJpbmc7XG4gIH07XG4gIGZvdW5kaW5nRGF0ZT86IHN0cmluZztcbiAgZW1wbG95ZWU/OiB7XG4gICAgJ0B0eXBlJzogJ1BlcnNvbic7XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIGpvYlRpdGxlOiBzdHJpbmc7XG4gICAgc3RhcnREYXRlOiBzdHJpbmc7XG4gICAgZW5kRGF0ZT86IHN0cmluZztcbiAgfVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJyZWFkY3J1bWJMaXN0U2NoZW1hIHtcbiAgJ0Bjb250ZXh0JzogJ2h0dHBzOi8vc2NoZW1hLm9yZyc7XG4gICdAdHlwZSc6ICdCcmVhZGNydW1iTGlzdCc7XG4gIGl0ZW1MaXN0RWxlbWVudDoge1xuICAgICdAdHlwZSc6ICdMaXN0SXRlbSc7XG4gICAgcG9zaXRpb246IG51bWJlcjtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgaXRlbTogc3RyaW5nO1xuICB9W107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgV2ViU2l0ZVNjaGVtYSB7XG4gICdAY29udGV4dCc6ICdodHRwczovL3NjaGVtYS5vcmcnO1xuICAnQHR5cGUnOiAnV2ViU2l0ZSc7XG4gIG5hbWU6IHN0cmluZztcbiAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgdXJsOiBzdHJpbmc7XG4gIGF1dGhvcjoge1xuICAgICdAdHlwZSc6ICdQZXJzb24nO1xuICAgIG5hbWU6IHN0cmluZztcbiAgfTtcbiAgcG90ZW50aWFsQWN0aW9uPzoge1xuICAgICdAdHlwZSc6ICdTZWFyY2hBY3Rpb24nO1xuICAgIHRhcmdldDoge1xuICAgICAgJ0B0eXBlJzogJ0VudHJ5UG9pbnQnO1xuICAgICAgdXJsVGVtcGxhdGU6IHN0cmluZztcbiAgICB9O1xuICAgICdxdWVyeS1pbnB1dCc6IHN0cmluZztcbiAgfTtcbn1cblxuLy8gRGVmYXVsdCBwZXJzb24gc2NoZW1hIGZvciB0aGUgcG9ydGZvbGlvIG93bmVyXG5leHBvcnQgY29uc3QgY3JlYXRlUGVyc29uU2NoZW1hID0gKFxuICBvdmVycmlkZXM/OiBQYXJ0aWFsPFBlcnNvblNjaGVtYT5cbik6IFBlcnNvblNjaGVtYSA9PiAoe1xuICAnQGNvbnRleHQnOiAnaHR0cHM6Ly9zY2hlbWEub3JnJyxcbiAgJ0B0eXBlJzogJ1BlcnNvbicsXG4gIG5hbWU6ICdFcm1pYXMgTGVtZXNhJyxcbiAgam9iVGl0bGU6ICdDb21wdXRlciBFbmdpbmVlciB8IElUIFN1cHBvcnQgU3BlY2lhbGlzdCB8IEhhcmR3YXJlIEVuZ2luZWVyJyxcbiAgZGVzY3JpcHRpb246XG4gICAgJ0NvbXB1dGVyIEVuZ2luZWVyIGFuZCBTZW5pb3IgSVQgU3VwcG9ydCBTcGVjaWFsaXN0IHdpdGggaGFuZHMtb24gZXhwZXJpZW5jZSBpbiBoYXJkd2FyZSwgbmV0d29ya2luZywgaGVscGRlc2ssIGFuZCBBSS9NTC4nLFxuICB1cmw6XG4gICAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgID8gd2luZG93LmxvY2F0aW9uLm9yaWdpblxuICAgICAgOiAnaHR0cHM6Ly9wb3J0Zm9saW8uZXhhbXBsZS5jb20nLFxuICBpbWFnZTogJy9wb3J0Zm9saW8ucG5nJyxcbiAgZW1haWw6ICdlcm1pYXMueGlpQGdtYWlsLmNvbScsXG4gIGFkZHJlc3M6IHtcbiAgICAnQHR5cGUnOiAnUG9zdGFsQWRkcmVzcycsXG4gICAgYWRkcmVzc0xvY2FsaXR5OiAnQWRkaXMgQWJhYmEnLFxuICAgIGFkZHJlc3NDb3VudHJ5OiAnRXRoaW9waWEnLFxuICB9LFxuICBzYW1lQXM6IFsnaHR0cHM6Ly9naXRodWIuY29tL2phSHhpaScsICdodHRwczovL3QubWUvY2xvdWR4NjknXSxcbiAga25vd3NBYm91dDogW1xuICAgICdJVCBTdXBwb3J0JyxcbiAgICAnSGFyZHdhcmUgRW5naW5lZXJpbmcnLFxuICAgICdOZXR3b3JraW5nJyxcbiAgICAnUHl0aG9uJyxcbiAgICAnTWFjaGluZSBMZWFybmluZycsXG4gICAgJ1dlYiBEZXZlbG9wbWVudCcsXG4gICAgJ0RhdGFiYXNlIERlc2lnbicsXG4gIF0sXG4gIGFsdW1uaU9mOiB7XG4gICAgJ0B0eXBlJzogJ0VkdWNhdGlvbmFsT3JnYW5pemF0aW9uJyxcbiAgICBuYW1lOiAnVW5pdmVyc2l0eSBvZiBHb25kYXInLFxuICAgIHVybDogJ2h0dHBzOi8vd3d3LnVvZy5lZHUuZXQnLFxuICB9LFxuICAuLi5vdmVycmlkZXMsXG59KTtcblxuLy8gQ3JlYXRlIHdvcmsgc2NoZW1hIGZvciBwcm9qZWN0c1xuZXhwb3J0IGNvbnN0IGNyZWF0ZVdvcmtTY2hlbWEgPSAocHJvamVjdDoge1xuICBuYW1lOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIHVybD86IHN0cmluZztcbiAgaW1hZ2U/OiBzdHJpbmc7XG4gIGRhdGVDcmVhdGVkPzogc3RyaW5nO1xuICBkYXRlTW9kaWZpZWQ/OiBzdHJpbmc7XG4gIGtleXdvcmRzPzogc3RyaW5nW107XG4gIHByb2dyYW1taW5nTGFuZ3VhZ2U/OiBzdHJpbmdbXTtcbiAgY29kZVJlcG9zaXRvcnk/OiBzdHJpbmc7XG4gIHJ1bnRpbWVQbGF0Zm9ybT86IHN0cmluZ1tdO1xufSk6IFdvcmtTY2hlbWEgPT4gKHtcbiAgJ0Bjb250ZXh0JzogJ2h0dHBzOi8vc2NoZW1hLm9yZycsXG4gICdAdHlwZSc6ICdDcmVhdGl2ZVdvcmsnLFxuICBuYW1lOiBwcm9qZWN0Lm5hbWUsXG4gIGRlc2NyaXB0aW9uOiBwcm9qZWN0LmRlc2NyaXB0aW9uLFxuICB1cmw6IHByb2plY3QudXJsLFxuICBpbWFnZTogcHJvamVjdC5pbWFnZSxcbiAgZGF0ZUNyZWF0ZWQ6IHByb2plY3QuZGF0ZUNyZWF0ZWQsXG4gIGRhdGVNb2RpZmllZDogcHJvamVjdC5kYXRlTW9kaWZpZWQsXG4gIGNyZWF0b3I6IHtcbiAgICAnQHR5cGUnOiAnUGVyc29uJyxcbiAgICBuYW1lOiAnRXJtaWFzIExlbWVzYScsXG4gIH0sXG4gIGtleXdvcmRzOiBwcm9qZWN0LmtleXdvcmRzLFxuICBnZW5yZTogJ1NvZnR3YXJlIEFwcGxpY2F0aW9uJyxcbiAgcHJvZ3JhbW1pbmdMYW5ndWFnZTogcHJvamVjdC5wcm9ncmFtbWluZ0xhbmd1YWdlLFxuICBjb2RlUmVwb3NpdG9yeTogcHJvamVjdC5jb2RlUmVwb3NpdG9yeSxcbiAgcnVudGltZVBsYXRmb3JtOiBwcm9qZWN0LnJ1bnRpbWVQbGF0Zm9ybSxcbn0pO1xuXG4vLyBDcmVhdGUgb3JnYW5pemF0aW9uIHNjaGVtYSBmb3Igd29yayBleHBlcmllbmNlXG5leHBvcnQgY29uc3QgY3JlYXRlT3JnYW5pemF0aW9uU2NoZW1hID0gKG9yZ2FuaXphdGlvbjoge1xuICBuYW1lOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICB1cmw/OiBzdHJpbmc7XG4gIGxvZ28/OiBzdHJpbmc7XG4gIGZvdW5kaW5nRGF0ZT86IHN0cmluZztcbiAgYWRkcmVzcz86IHtcbiAgICBsb2NhbGl0eTogc3RyaW5nO1xuICAgIGNvdW50cnk6IHN0cmluZztcbiAgfTtcbiAgZW1wbG95ZWVzPzoge1xuICAgIG5hbWU6IHN0cmluZztcbiAgICBqb2JUaXRsZTogc3RyaW5nO1xuICAgIHN0YXJ0RGF0ZTogc3RyaW5nO1xuICAgIGVuZERhdGU/OiBzdHJpbmc7XG4gIH1bXTtcbn0pOiBPcmdhbml6YXRpb25TY2hlbWEgPT4gKHtcbiAgJ0Bjb250ZXh0JzogJ2h0dHBzOi8vc2NoZW1hLm9yZycsXG4gICdAdHlwZSc6ICdPcmdhbml6YXRpb24nLFxuICBuYW1lOiBvcmdhbml6YXRpb24ubmFtZSxcbiAgZGVzY3JpcHRpb246IG9yZ2FuaXphdGlvbi5kZXNjcmlwdGlvbixcbiAgdXJsOiBvcmdhbml6YXRpb24udXJsLFxuICBsb2dvOiBvcmdhbml6YXRpb24ubG9nbyxcbiAgZm91bmRpbmdEYXRlOiBvcmdhbml6YXRpb24uZm91bmRpbmdEYXRlLFxuICBhZGRyZXNzOiBvcmdhbml6YXRpb24uYWRkcmVzc1xuICAgID8ge1xuICAgICAgICAnQHR5cGUnOiAnUG9zdGFsQWRkcmVzcycsXG4gICAgICAgIGFkZHJlc3NMb2NhbGl0eTogb3JnYW5pemF0aW9uLmFkZHJlc3MubG9jYWxpdHksXG4gICAgICAgIGFkZHJlc3NDb3VudHJ5OiBvcmdhbml6YXRpb24uYWRkcmVzcy5jb3VudHJ5LFxuICAgICAgfVxuICAgIDogdW5kZWZpbmVkLFxuICBlbXBsb3llZTogb3JnYW5pemF0aW9uLmVtcGxveWVlcz8ubWFwKGVtcCA9PiAoe1xuICAgICdAdHlwZSc6ICdQZXJzb24nLFxuICAgIG5hbWU6IGVtcC5uYW1lLFxuICAgIGpvYlRpdGxlOiBlbXAuam9iVGl0bGUsXG4gICAgc3RhcnREYXRlOiBlbXAuc3RhcnREYXRlLFxuICAgIGVuZERhdGU6IGVtcC5lbmREYXRlLFxuICB9KSksXG59KTtcblxuLy8gQ3JlYXRlIGJyZWFkY3J1bWIgc2NoZW1hIGZvciBuYXZpZ2F0aW9uXG5leHBvcnQgY29uc3QgY3JlYXRlQnJlYWRjcnVtYlNjaGVtYSA9IChcbiAgYnJlYWRjcnVtYnM6IHsgbmFtZTogc3RyaW5nOyB1cmw6IHN0cmluZyB9W11cbik6IEJyZWFkY3J1bWJMaXN0U2NoZW1hID0+ICh7XG4gICdAY29udGV4dCc6ICdodHRwczovL3NjaGVtYS5vcmcnLFxuICAnQHR5cGUnOiAnQnJlYWRjcnVtYkxpc3QnLFxuICBpdGVtTGlzdEVsZW1lbnQ6IGJyZWFkY3J1bWJzLm1hcCgoY3J1bWIsIGluZGV4KSA9PiAoe1xuICAgICdAdHlwZSc6ICdMaXN0SXRlbScsXG4gICAgcG9zaXRpb246IGluZGV4ICsgMSxcbiAgICBuYW1lOiBjcnVtYi5uYW1lLFxuICAgIGl0ZW06IGNydW1iLnVybCxcbiAgfSkpLFxufSk7XG5cbi8vIENyZWF0ZSB3ZWJzaXRlIHNjaGVtYVxuZXhwb3J0IGNvbnN0IGNyZWF0ZVdlYlNpdGVTY2hlbWEgPSAoXG4gIG92ZXJyaWRlcz86IFBhcnRpYWw8V2ViU2l0ZVNjaGVtYT5cbik6IFdlYlNpdGVTY2hlbWEgPT4gKHtcbiAgJ0Bjb250ZXh0JzogJ2h0dHBzOi8vc2NoZW1hLm9yZycsXG4gICdAdHlwZSc6ICdXZWJTaXRlJyxcbiAgbmFtZTogJ0VybWlhcyBMZW1lc2EgLSBQb3J0Zm9saW8nLFxuICBkZXNjcmlwdGlvbjpcbiAgICAnUG9ydGZvbGlvIG9mIEVybWlhcyBMZW1lc2EgLSBDb21wdXRlciBFbmdpbmVlciBhbmQgU2VuaW9yIElUIFN1cHBvcnQgU3BlY2lhbGlzdCBiYXNlZCBpbiBBZGRpcyBBYmFiYSwgRXRoaW9waWEuJyxcbiAgdXJsOlxuICAgIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnXG4gICAgICA/IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW5cbiAgICAgIDogJ2h0dHBzOi8vcG9ydGZvbGlvLmV4YW1wbGUuY29tJyxcbiAgYXV0aG9yOiB7XG4gICAgJ0B0eXBlJzogJ1BlcnNvbicsXG4gICAgbmFtZTogJ0VybWlhcyBMZW1lc2EnLFxuICB9LFxuICBwb3RlbnRpYWxBY3Rpb246IHtcbiAgICAnQHR5cGUnOiAnU2VhcmNoQWN0aW9uJyxcbiAgICB0YXJnZXQ6IHtcbiAgICAgICdAdHlwZSc6ICdFbnRyeVBvaW50JyxcbiAgICAgIHVybFRlbXBsYXRlOiBgJHt0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gOiAnaHR0cHM6Ly9wb3J0Zm9saW8uZXhhbXBsZS5jb20nfS9zZWFyY2g/cT17c2VhcmNoX3Rlcm1fc3RyaW5nfWAsXG4gICAgfSxcbiAgICAncXVlcnktaW5wdXQnOiAncmVxdWlyZWQgbmFtZT1zZWFyY2hfdGVybV9zdHJpbmcnLFxuICB9LFxuICAuLi5vdmVycmlkZXMsXG59KTtcblxuLy8gVXRpbGl0eSBmdW5jdGlvbiB0byBnZW5lcmF0ZSBKU09OLUxEIHNjcmlwdCB0YWcgY29udGVudFxuZXhwb3J0IGNvbnN0IGdlbmVyYXRlSlNPTkxEID0gKHNjaGVtYTogYW55KTogc3RyaW5nID0+IHtcbiAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHNjaGVtYSwgbnVsbCwgMik7XG59O1xuXG4vLyBWYWxpZGF0ZSBKU09OLUxEIHNjaGVtYVxuZXhwb3J0IGNvbnN0IHZhbGlkYXRlU2NoZW1hID0gKHNjaGVtYTogYW55KTogYm9vbGVhbiA9PiB7XG4gIHRyeSB7XG4gICAgLy8gQmFzaWMgdmFsaWRhdGlvbiAtIGNoZWNrIHJlcXVpcmVkIGZpZWxkc1xuICAgIGlmICghc2NoZW1hWydAY29udGV4dCddIHx8ICFzY2hlbWFbJ0B0eXBlJ10pIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1NjaGVtYSBtaXNzaW5nIHJlcXVpcmVkIEBjb250ZXh0IG9yIEB0eXBlJyk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgY29udGV4dFxuICAgIGlmIChzY2hlbWFbJ0Bjb250ZXh0J10gIT09ICdodHRwczovL3NjaGVtYS5vcmcnKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdJbnZhbGlkIEBjb250ZXh0LCBzaG91bGQgYmUgaHR0cHM6Ly9zY2hlbWEub3JnJyk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgLy8gQWRkaXRpb25hbCB0eXBlLXNwZWNpZmljIHZhbGlkYXRpb25cbiAgICBzd2l0Y2ggKHNjaGVtYVsnQHR5cGUnXSkge1xuICAgICAgY2FzZSAnUGVyc29uJzpcbiAgICAgICAgaWYgKCFzY2hlbWEubmFtZSkge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1BlcnNvbiBzY2hlbWEgbWlzc2luZyByZXF1aXJlZCBuYW1lIGZpZWxkJyk7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnQ3JlYXRpdmVXb3JrJzpcbiAgICAgICAgaWYgKCFzY2hlbWEubmFtZSB8fCAhc2NoZW1hLmRlc2NyaXB0aW9uKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICAgICdDcmVhdGl2ZVdvcmsgc2NoZW1hIG1pc3NpbmcgcmVxdWlyZWQgbmFtZSBvciBkZXNjcmlwdGlvbidcbiAgICAgICAgICApO1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ09yZ2FuaXphdGlvbic6XG4gICAgICAgIGlmICghc2NoZW1hLm5hbWUpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdPcmdhbml6YXRpb24gc2NoZW1hIG1pc3NpbmcgcmVxdWlyZWQgbmFtZSBmaWVsZCcpO1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ0JyZWFkY3J1bWJMaXN0JzpcbiAgICAgICAgaWYgKCFzY2hlbWEuaXRlbUxpc3RFbGVtZW50IHx8ICFBcnJheS5pc0FycmF5KHNjaGVtYS5pdGVtTGlzdEVsZW1lbnQpKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICAgICdCcmVhZGNydW1iTGlzdCBzY2hlbWEgbWlzc2luZyBvciBpbnZhbGlkIGl0ZW1MaXN0RWxlbWVudCdcbiAgICAgICAgICApO1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ1dlYlNpdGUnOlxuICAgICAgICBpZiAoIXNjaGVtYS5uYW1lIHx8ICFzY2hlbWEudXJsKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcignV2ViU2l0ZSBzY2hlbWEgbWlzc2luZyByZXF1aXJlZCBuYW1lIG9yIHVybCcpO1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdTY2hlbWEgdmFsaWRhdGlvbiBlcnJvcjonLCBlcnJvcik7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59O1xuIl0sIm5hbWVzIjpbImNyZWF0ZVBlcnNvblNjaGVtYSIsIm92ZXJyaWRlcyIsIm5hbWUiLCJqb2JUaXRsZSIsImRlc2NyaXB0aW9uIiwidXJsIiwid2luZG93IiwibG9jYXRpb24iLCJvcmlnaW4iLCJpbWFnZSIsImVtYWlsIiwiYWRkcmVzcyIsImFkZHJlc3NMb2NhbGl0eSIsImFkZHJlc3NDb3VudHJ5Iiwic2FtZUFzIiwia25vd3NBYm91dCIsImFsdW1uaU9mIiwiY3JlYXRlV29ya1NjaGVtYSIsInByb2plY3QiLCJkYXRlQ3JlYXRlZCIsImRhdGVNb2RpZmllZCIsImNyZWF0b3IiLCJrZXl3b3JkcyIsImdlbnJlIiwicHJvZ3JhbW1pbmdMYW5ndWFnZSIsImNvZGVSZXBvc2l0b3J5IiwicnVudGltZVBsYXRmb3JtIiwiY3JlYXRlT3JnYW5pemF0aW9uU2NoZW1hIiwib3JnYW5pemF0aW9uIiwibG9nbyIsImZvdW5kaW5nRGF0ZSIsImxvY2FsaXR5IiwiY291bnRyeSIsInVuZGVmaW5lZCIsImVtcGxveWVlIiwiZW1wbG95ZWVzIiwibWFwIiwiZW1wIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsImNyZWF0ZUJyZWFkY3J1bWJTY2hlbWEiLCJicmVhZGNydW1icyIsIml0ZW1MaXN0RWxlbWVudCIsImNydW1iIiwiaW5kZXgiLCJwb3NpdGlvbiIsIml0ZW0iLCJjcmVhdGVXZWJTaXRlU2NoZW1hIiwiYXV0aG9yIiwicG90ZW50aWFsQWN0aW9uIiwidGFyZ2V0IiwidXJsVGVtcGxhdGUiLCJnZW5lcmF0ZUpTT05MRCIsInNjaGVtYSIsIkpTT04iLCJzdHJpbmdpZnkiLCJ2YWxpZGF0ZVNjaGVtYSIsImNvbnNvbGUiLCJlcnJvciIsIkFycmF5IiwiaXNBcnJheSJdLCJtYXBwaW5ncyI6IkFBQUEsOENBQThDO0FBd0c5QyxnREFBZ0Q7QUFDaEQsT0FBTyxNQUFNQSxxQkFBcUIsQ0FDaENDLFlBQ2tCLENBQUE7UUFDbEIsWUFBWTtRQUNaLFNBQVM7UUFDVEMsTUFBTTtRQUNOQyxVQUFVO1FBQ1ZDLGFBQ0U7UUFDRkMsS0FDRSxPQUFPQyxXQUFXLGNBQ2RBLE9BQU9DLFFBQVEsQ0FBQ0MsTUFBTSxHQUN0QjtRQUNOQyxPQUFPO1FBQ1BDLE9BQU87UUFDUEMsU0FBUztZQUNQLFNBQVM7WUFDVEMsaUJBQWlCO1lBQ2pCQyxnQkFBZ0I7UUFDbEI7UUFDQUMsUUFBUTtZQUFDO1lBQTZCO1NBQXdCO1FBQzlEQyxZQUFZO1lBQ1Y7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7U0FDRDtRQUNEQyxVQUFVO1lBQ1IsU0FBUztZQUNUZCxNQUFNO1lBQ05HLEtBQUs7UUFDUDtRQUNBLEdBQUdKLFNBQVM7SUFDZCxDQUFBLEVBQUc7QUFFSCxrQ0FBa0M7QUFDbEMsT0FBTyxNQUFNZ0IsbUJBQW1CLENBQUNDLFVBV2QsQ0FBQTtRQUNqQixZQUFZO1FBQ1osU0FBUztRQUNUaEIsTUFBTWdCLFFBQVFoQixJQUFJO1FBQ2xCRSxhQUFhYyxRQUFRZCxXQUFXO1FBQ2hDQyxLQUFLYSxRQUFRYixHQUFHO1FBQ2hCSSxPQUFPUyxRQUFRVCxLQUFLO1FBQ3BCVSxhQUFhRCxRQUFRQyxXQUFXO1FBQ2hDQyxjQUFjRixRQUFRRSxZQUFZO1FBQ2xDQyxTQUFTO1lBQ1AsU0FBUztZQUNUbkIsTUFBTTtRQUNSO1FBQ0FvQixVQUFVSixRQUFRSSxRQUFRO1FBQzFCQyxPQUFPO1FBQ1BDLHFCQUFxQk4sUUFBUU0sbUJBQW1CO1FBQ2hEQyxnQkFBZ0JQLFFBQVFPLGNBQWM7UUFDdENDLGlCQUFpQlIsUUFBUVEsZUFBZTtJQUMxQyxDQUFBLEVBQUc7QUFFSCxpREFBaUQ7QUFDakQsT0FBTyxNQUFNQywyQkFBMkIsQ0FBQ0MsZUFnQmQsQ0FBQTtRQUN6QixZQUFZO1FBQ1osU0FBUztRQUNUMUIsTUFBTTBCLGFBQWExQixJQUFJO1FBQ3ZCRSxhQUFhd0IsYUFBYXhCLFdBQVc7UUFDckNDLEtBQUt1QixhQUFhdkIsR0FBRztRQUNyQndCLE1BQU1ELGFBQWFDLElBQUk7UUFDdkJDLGNBQWNGLGFBQWFFLFlBQVk7UUFDdkNuQixTQUFTaUIsYUFBYWpCLE9BQU8sR0FDekI7WUFDRSxTQUFTO1lBQ1RDLGlCQUFpQmdCLGFBQWFqQixPQUFPLENBQUNvQixRQUFRO1lBQzlDbEIsZ0JBQWdCZSxhQUFhakIsT0FBTyxDQUFDcUIsT0FBTztRQUM5QyxJQUNBQztRQUNKQyxVQUFVTixhQUFhTyxTQUFTLEVBQUVDLElBQUlDLENBQUFBLE1BQVEsQ0FBQTtnQkFDNUMsU0FBUztnQkFDVG5DLE1BQU1tQyxJQUFJbkMsSUFBSTtnQkFDZEMsVUFBVWtDLElBQUlsQyxRQUFRO2dCQUN0Qm1DLFdBQVdELElBQUlDLFNBQVM7Z0JBQ3hCQyxTQUFTRixJQUFJRSxPQUFPO1lBQ3RCLENBQUE7SUFDRixDQUFBLEVBQUc7QUFFSCwwQ0FBMEM7QUFDMUMsT0FBTyxNQUFNQyx5QkFBeUIsQ0FDcENDLGNBQzBCLENBQUE7UUFDMUIsWUFBWTtRQUNaLFNBQVM7UUFDVEMsaUJBQWlCRCxZQUFZTCxHQUFHLENBQUMsQ0FBQ08sT0FBT0MsUUFBVyxDQUFBO2dCQUNsRCxTQUFTO2dCQUNUQyxVQUFVRCxRQUFRO2dCQUNsQjFDLE1BQU15QyxNQUFNekMsSUFBSTtnQkFDaEI0QyxNQUFNSCxNQUFNdEMsR0FBRztZQUNqQixDQUFBO0lBQ0YsQ0FBQSxFQUFHO0FBRUgsd0JBQXdCO0FBQ3hCLE9BQU8sTUFBTTBDLHNCQUFzQixDQUNqQzlDLFlBQ21CLENBQUE7UUFDbkIsWUFBWTtRQUNaLFNBQVM7UUFDVEMsTUFBTTtRQUNORSxhQUNFO1FBQ0ZDLEtBQ0UsT0FBT0MsV0FBVyxjQUNkQSxPQUFPQyxRQUFRLENBQUNDLE1BQU0sR0FDdEI7UUFDTndDLFFBQVE7WUFDTixTQUFTO1lBQ1Q5QyxNQUFNO1FBQ1I7UUFDQStDLGlCQUFpQjtZQUNmLFNBQVM7WUFDVEMsUUFBUTtnQkFDTixTQUFTO2dCQUNUQyxhQUFhLEdBQUcsT0FBTzdDLFdBQVcsY0FBY0EsT0FBT0MsUUFBUSxDQUFDQyxNQUFNLEdBQUcsZ0NBQWdDLDhCQUE4QixDQUFDO1lBQzFJO1lBQ0EsZUFBZTtRQUNqQjtRQUNBLEdBQUdQLFNBQVM7SUFDZCxDQUFBLEVBQUc7QUFFSCwwREFBMEQ7QUFDMUQsT0FBTyxNQUFNbUQsaUJBQWlCLENBQUNDO0lBQzdCLE9BQU9DLEtBQUtDLFNBQVMsQ0FBQ0YsUUFBUSxNQUFNO0FBQ3RDLEVBQUU7QUFFRiwwQkFBMEI7QUFDMUIsT0FBTyxNQUFNRyxpQkFBaUIsQ0FBQ0g7SUFDN0IsSUFBSTtRQUNGLDJDQUEyQztRQUMzQyxJQUFJLENBQUNBLE1BQU0sQ0FBQyxXQUFXLElBQUksQ0FBQ0EsTUFBTSxDQUFDLFFBQVEsRUFBRTtZQUMzQ0ksUUFBUUMsS0FBSyxDQUFDO1lBQ2QsT0FBTztRQUNUO1FBRUEsbUJBQW1CO1FBQ25CLElBQUlMLE1BQU0sQ0FBQyxXQUFXLEtBQUssc0JBQXNCO1lBQy9DSSxRQUFRQyxLQUFLLENBQUM7WUFDZCxPQUFPO1FBQ1Q7UUFFQSxzQ0FBc0M7UUFDdEMsT0FBUUwsTUFBTSxDQUFDLFFBQVE7WUFDckIsS0FBSztnQkFDSCxJQUFJLENBQUNBLE9BQU9uRCxJQUFJLEVBQUU7b0JBQ2hCdUQsUUFBUUMsS0FBSyxDQUFDO29CQUNkLE9BQU87Z0JBQ1Q7Z0JBQ0E7WUFDRixLQUFLO2dCQUNILElBQUksQ0FBQ0wsT0FBT25ELElBQUksSUFBSSxDQUFDbUQsT0FBT2pELFdBQVcsRUFBRTtvQkFDdkNxRCxRQUFRQyxLQUFLLENBQ1g7b0JBRUYsT0FBTztnQkFDVDtnQkFDQTtZQUNGLEtBQUs7Z0JBQ0gsSUFBSSxDQUFDTCxPQUFPbkQsSUFBSSxFQUFFO29CQUNoQnVELFFBQVFDLEtBQUssQ0FBQztvQkFDZCxPQUFPO2dCQUNUO2dCQUNBO1lBQ0YsS0FBSztnQkFDSCxJQUFJLENBQUNMLE9BQU9YLGVBQWUsSUFBSSxDQUFDaUIsTUFBTUMsT0FBTyxDQUFDUCxPQUFPWCxlQUFlLEdBQUc7b0JBQ3JFZSxRQUFRQyxLQUFLLENBQ1g7b0JBRUYsT0FBTztnQkFDVDtnQkFDQTtZQUNGLEtBQUs7Z0JBQ0gsSUFBSSxDQUFDTCxPQUFPbkQsSUFBSSxJQUFJLENBQUNtRCxPQUFPaEQsR0FBRyxFQUFFO29CQUMvQm9ELFFBQVFDLEtBQUssQ0FBQztvQkFDZCxPQUFPO2dCQUNUO2dCQUNBO1FBQ0o7UUFFQSxPQUFPO0lBQ1QsRUFBRSxPQUFPQSxPQUFPO1FBQ2RELFFBQVFDLEtBQUssQ0FBQyw0QkFBNEJBO1FBQzFDLE9BQU87SUFDVDtBQUNGLEVBQUUifQ==