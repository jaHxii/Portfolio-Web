import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/altitude-counter.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/altitude-counter.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const useEffect = __vite__cjsImport2_react["useEffect"]; const useState = __vite__cjsImport2_react["useState"];
import { useScroll, useMotionValueEvent } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
const BASE_ALTITUDE = 8400;
const CRUISE_ALTITUDE = 38000;
export default function AltitudeCounter() {
    _s();
    const { scrollY } = useScroll();
    const [altitude, setAltitude] = useState(BASE_ALTITUDE);
    useMotionValueEvent(scrollY, 'change', (y)=>{
        const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
        const progress = maxScroll > 0 ? Math.min(y / maxScroll, 1) : 0;
        const current = Math.round(BASE_ALTITUDE + progress * (CRUISE_ALTITUDE - BASE_ALTITUDE));
        setAltitude((prev)=>prev === current ? prev : current);
    });
    const reduced = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    useEffect(()=>{
        if (!reduced) return;
        setAltitude(CRUISE_ALTITUDE);
    }, [
        reduced
    ]);
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "fixed bottom-5 right-5 z-40 hidden select-none pointer-events-none md:block font-mono text-[10px] leading-4 tracking-[0.3em] text-mist-soft/50",
        "aria-hidden": "true",
        children: [
            "ALT ",
            altitude.toLocaleString('en-US'),
            " FT",
            /*#__PURE__*/ _jsxDEV("div", {
                className: "mt-1 ml-auto h-px w-10 bg-gradient-to-r from-transparent to-gold/60"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/altitude-counter.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/altitude-counter.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(AltitudeCounter, "1NsFd/Z6bOVXhLbir7hFqHYHS5I=", false, function() {
    return [
        useScroll,
        useMotionValueEvent
    ];
});
_c = AltitudeCounter;
var _c;
$RefreshReg$(_c, "AltitudeCounter");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/altitude-counter.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/altitude-counter.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFsdGl0dWRlLWNvdW50ZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VTY3JvbGwsIHVzZU1vdGlvblZhbHVlRXZlbnQgfSBmcm9tICdmcmFtZXItbW90aW9uJztcblxuY29uc3QgQkFTRV9BTFRJVFVERSA9IDg0MDA7XG5jb25zdCBDUlVJU0VfQUxUSVRVREUgPSAzODAwMDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQWx0aXR1ZGVDb3VudGVyKCkge1xuICBjb25zdCB7IHNjcm9sbFkgfSA9IHVzZVNjcm9sbCgpO1xuICBjb25zdCBbYWx0aXR1ZGUsIHNldEFsdGl0dWRlXSA9IHVzZVN0YXRlKEJBU0VfQUxUSVRVREUpO1xuXG4gIHVzZU1vdGlvblZhbHVlRXZlbnQoc2Nyb2xsWSwgJ2NoYW5nZScsIHkgPT4ge1xuICAgIGNvbnN0IG1heFNjcm9sbCA9XG4gICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsSGVpZ2h0IC0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgIGNvbnN0IHByb2dyZXNzID0gbWF4U2Nyb2xsID4gMCA/IE1hdGgubWluKHkgLyBtYXhTY3JvbGwsIDEpIDogMDtcbiAgICBjb25zdCBjdXJyZW50ID0gTWF0aC5yb3VuZChcbiAgICAgIEJBU0VfQUxUSVRVREUgKyBwcm9ncmVzcyAqIChDUlVJU0VfQUxUSVRVREUgLSBCQVNFX0FMVElUVURFKVxuICAgICk7XG4gICAgc2V0QWx0aXR1ZGUocHJldiA9PiAocHJldiA9PT0gY3VycmVudCA/IHByZXYgOiBjdXJyZW50KSk7XG4gIH0pO1xuXG4gIGNvbnN0IHJlZHVjZWQgPVxuICAgIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXG4gICAgd2luZG93Lm1hdGNoTWVkaWEoJyhwcmVmZXJzLXJlZHVjZWQtbW90aW9uOiByZWR1Y2UpJykubWF0Y2hlcztcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghcmVkdWNlZCkgcmV0dXJuO1xuICAgIHNldEFsdGl0dWRlKENSVUlTRV9BTFRJVFVERSk7XG4gIH0sIFtyZWR1Y2VkXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBjbGFzc05hbWU9J2ZpeGVkIGJvdHRvbS01IHJpZ2h0LTUgei00MCBoaWRkZW4gc2VsZWN0LW5vbmUgcG9pbnRlci1ldmVudHMtbm9uZSBtZDpibG9jayBmb250LW1vbm8gdGV4dC1bMTBweF0gbGVhZGluZy00IHRyYWNraW5nLVswLjNlbV0gdGV4dC1taXN0LXNvZnQvNTAnXG4gICAgICBhcmlhLWhpZGRlbj0ndHJ1ZSdcbiAgICA+XG4gICAgICBBTFQge2FsdGl0dWRlLnRvTG9jYWxlU3RyaW5nKCdlbi1VUycpfSBGVFxuICAgICAgPGRpdiBjbGFzc05hbWU9J210LTEgbWwtYXV0byBoLXB4IHctMTAgYmctZ3JhZGllbnQtdG8tciBmcm9tLXRyYW5zcGFyZW50IHRvLWdvbGQvNjAnIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VTY3JvbGwiLCJ1c2VNb3Rpb25WYWx1ZUV2ZW50IiwiQkFTRV9BTFRJVFVERSIsIkNSVUlTRV9BTFRJVFVERSIsIkFsdGl0dWRlQ291bnRlciIsInNjcm9sbFkiLCJhbHRpdHVkZSIsInNldEFsdGl0dWRlIiwieSIsIm1heFNjcm9sbCIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50Iiwic2Nyb2xsSGVpZ2h0Iiwid2luZG93IiwiaW5uZXJIZWlnaHQiLCJwcm9ncmVzcyIsIk1hdGgiLCJtaW4iLCJjdXJyZW50Iiwicm91bmQiLCJwcmV2IiwicmVkdWNlZCIsIm1hdGNoTWVkaWEiLCJtYXRjaGVzIiwiZGl2IiwiY2xhc3NOYW1lIiwiYXJpYS1oaWRkZW4iLCJ0b0xvY2FsZVN0cmluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLFNBQVNBLFNBQVMsRUFBRUMsUUFBUSxRQUFRLFFBQVE7QUFDNUMsU0FBU0MsU0FBUyxFQUFFQyxtQkFBbUIsUUFBUSxnQkFBZ0I7QUFFL0QsTUFBTUMsZ0JBQWdCO0FBQ3RCLE1BQU1DLGtCQUFrQjtBQUV4QixlQUFlLFNBQVNDOztJQUN0QixNQUFNLEVBQUVDLE9BQU8sRUFBRSxHQUFHTDtJQUNwQixNQUFNLENBQUNNLFVBQVVDLFlBQVksR0FBR1IsU0FBU0c7SUFFekNELG9CQUFvQkksU0FBUyxVQUFVRyxDQUFBQTtRQUNyQyxNQUFNQyxZQUNKQyxTQUFTQyxlQUFlLENBQUNDLFlBQVksR0FBR0MsT0FBT0MsV0FBVztRQUM1RCxNQUFNQyxXQUFXTixZQUFZLElBQUlPLEtBQUtDLEdBQUcsQ0FBQ1QsSUFBSUMsV0FBVyxLQUFLO1FBQzlELE1BQU1TLFVBQVVGLEtBQUtHLEtBQUssQ0FDeEJqQixnQkFBZ0JhLFdBQVlaLENBQUFBLGtCQUFrQkQsYUFBWTtRQUU1REssWUFBWWEsQ0FBQUEsT0FBU0EsU0FBU0YsVUFBVUUsT0FBT0Y7SUFDakQ7SUFFQSxNQUFNRyxVQUNKLE9BQU9SLFdBQVcsZUFDbEJBLE9BQU9TLFVBQVUsQ0FBQyxvQ0FBb0NDLE9BQU87SUFFL0R6QixVQUFVO1FBQ1IsSUFBSSxDQUFDdUIsU0FBUztRQUNkZCxZQUFZSjtJQUNkLEdBQUc7UUFBQ2tCO0tBQVE7SUFFWixxQkFDRSxRQUFDRztRQUNDQyxXQUFVO1FBQ1ZDLGVBQVk7O1lBQ2I7WUFDTXBCLFNBQVNxQixjQUFjLENBQUM7WUFBUzswQkFDdEMsUUFBQ0g7Z0JBQUlDLFdBQVU7Ozs7Ozs7Ozs7OztBQUdyQjtHQWhDd0JyQjs7UUFDRko7UUFHcEJDOzs7S0FKc0JHIn0=