/**
 * Route preloading utilities for code-split routes
 */ // Cache for preloaded routes
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
const preloadedRoutes = new Set();
// Route component loaders
export const routeLoaders = {
    '/': ()=>import("/src/pages/Index.tsx"),
    '/projects': ()=>import("/src/pages/Projects.tsx"),
    '/skills': ()=>import("/src/pages/Skills.tsx"),
    '/experience': ()=>import("/src/pages/Experience.tsx"),
    '/contact': ()=>import("/src/pages/Contact.tsx"),
    '/resume': ()=>import("/src/pages/Resume.tsx")
};
/**
 * Preload a route component
 */ export async function preloadRoute(path) {
    // Normalize path
    const normalizedPath = path === '' ? '/' : path;
    if (preloadedRoutes.has(normalizedPath)) {
        return; // Already preloaded
    }
    const loader = routeLoaders[normalizedPath];
    if (!loader) {
        console.warn(`No loader found for route: ${normalizedPath}`);
        return;
    }
    try {
        await loader();
        preloadedRoutes.add(normalizedPath);
        console.log(`Preloaded route: ${normalizedPath}`);
    } catch (error) {
        console.error(`Failed to preload route ${normalizedPath}:`, error);
    }
}
/**
 * Preload multiple routes
 */ export async function preloadRoutes(paths) {
    const promises = paths.map((path)=>preloadRoute(path));
    await Promise.allSettled(promises);
}
/**
 * Get preloaded routes
 */ export function getPreloadedRoutes() {
    return Array.from(preloadedRoutes);
}
/**
 * Clear preload cache
 */ export function clearPreloadCache() {
    preloadedRoutes.clear();
}
/**
 * Check if route is preloaded
 */ export function isRoutePreloaded(path) {
    const normalizedPath = path === '' ? '/' : path;
    return preloadedRoutes.has(normalizedPath);
}
/**
 * Preload route on hover/focus with debouncing
 */ const preloadTimeouts = new Map();
export function scheduleRoutePreload(path, delay = 100) {
    // Cancel any existing timeout for this specific path
    const existing = preloadTimeouts.get(path);
    if (existing) clearTimeout(existing);
    const timeout = setTimeout(()=>{
        preloadTimeouts.delete(path);
        preloadRoute(path);
    }, delay);
    preloadTimeouts.set(path, timeout);
}
/**
 * Cancel scheduled preload for a specific path (or all if omitted)
 */ export function cancelScheduledPreload(path) {
    if (path) {
        const timeout = preloadTimeouts.get(path);
        if (timeout) {
            clearTimeout(timeout);
            preloadTimeouts.delete(path);
        }
    } else {
        preloadTimeouts.forEach((timeout)=>clearTimeout(timeout));
        preloadTimeouts.clear();
    }
}
/**
 * Hook for route preloading
 */ export function useRoutePreloader() {
    const preload = (path)=>preloadRoute(path);
    const schedulePreload = (path, delay)=>scheduleRoutePreload(path, delay);
    const cancelPreload = ()=>cancelScheduledPreload();
    return {
        preload,
        schedulePreload,
        cancelPreload,
        isPreloaded: isRoutePreloaded,
        preloadedRoutes: getPreloadedRoutes()
    };
}
/**
 * Preload critical routes on app initialization
 */ export function preloadCriticalRoutes() {
    // Preload the most important routes (skip '/' since it's already loaded)
    const criticalRoutes = [
        '/projects',
        '/skills'
    ];
    // Use requestIdleCallback if available, otherwise setTimeout
    if ('requestIdleCallback' in window) {
        requestIdleCallback(()=>{
            preloadRoutes(criticalRoutes);
        });
    } else {
        setTimeout(()=>{
            preloadRoutes(criticalRoutes);
        }, 1000);
    }
}
/**
 * Intelligent route preloading based on user behavior
 */ export class RoutePreloadManager {
    static getInstance() {
        if (!RoutePreloadManager.instance) {
            RoutePreloadManager.instance = new RoutePreloadManager();
        }
        return RoutePreloadManager.instance;
    }
    /**
   * Add route to preload queue
   */ queuePreload(path) {
        if (!this.preloadQueue.includes(path) && !isRoutePreloaded(path)) {
            this.preloadQueue.push(path);
            this.processQueue();
        }
    }
    /**
   * Process preload queue
   */ async processQueue() {
        if (this.isProcessing || this.preloadQueue.length === 0) {
            return;
        }
        this.isProcessing = true;
        while(this.preloadQueue.length > 0){
            const path = this.preloadQueue.shift();
            if (path) {
                try {
                    await preloadRoute(path);
                    // Add small delay between preloads to avoid blocking
                    await new Promise((resolve)=>setTimeout(resolve, 50));
                } catch (error) {
                    console.error(`Failed to preload route ${path}:`, error);
                }
            }
        }
        this.isProcessing = false;
    }
    /**
   * Preload based on current route
   */ preloadRelatedRoutes(currentPath) {
        const relatedRoutes = {
            '/': [
                '/projects',
                '/skills'
            ],
            '/projects': [
                '/skills',
                '/experience'
            ],
            '/skills': [
                '/experience',
                '/contact'
            ],
            '/experience': [
                '/contact',
                '/projects'
            ],
            '/contact': [
                '/',
                '/projects'
            ],
            '/resume': [
                '/contact',
                '/projects'
            ]
        };
        const related = relatedRoutes[currentPath] || [];
        related.forEach((route)=>this.queuePreload(route));
    }
    constructor(){
        _define_property(this, "preloadQueue", []);
        _define_property(this, "isProcessing", false);
    }
}
_define_property(RoutePreloadManager, "instance", void 0);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJvdXRlLXByZWxvYWRlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFJvdXRlIHByZWxvYWRpbmcgdXRpbGl0aWVzIGZvciBjb2RlLXNwbGl0IHJvdXRlc1xuICovXG5cbi8vIENhY2hlIGZvciBwcmVsb2FkZWQgcm91dGVzXG5jb25zdCBwcmVsb2FkZWRSb3V0ZXMgPSBuZXcgU2V0PHN0cmluZz4oKTtcblxuLy8gUm91dGUgY29tcG9uZW50IGxvYWRlcnNcbmV4cG9ydCBjb25zdCByb3V0ZUxvYWRlcnMgPSB7XG4gICcvJzogKCkgPT4gaW1wb3J0KCcuLi9wYWdlcy9JbmRleCcpLFxuICAnL3Byb2plY3RzJzogKCkgPT4gaW1wb3J0KCcuLi9wYWdlcy9Qcm9qZWN0cycpLFxuICAnL3NraWxscyc6ICgpID0+IGltcG9ydCgnLi4vcGFnZXMvU2tpbGxzJyksXG4gICcvZXhwZXJpZW5jZSc6ICgpID0+IGltcG9ydCgnLi4vcGFnZXMvRXhwZXJpZW5jZScpLFxuICAnL2NvbnRhY3QnOiAoKSA9PiBpbXBvcnQoJy4uL3BhZ2VzL0NvbnRhY3QnKSxcbiAgJy9yZXN1bWUnOiAoKSA9PiBpbXBvcnQoJy4uL3BhZ2VzL1Jlc3VtZScpLFxufSBhcyBjb25zdDtcblxuZXhwb3J0IHR5cGUgUm91dGVLZXkgPSBrZXlvZiB0eXBlb2Ygcm91dGVMb2FkZXJzO1xuXG4vKipcbiAqIFByZWxvYWQgYSByb3V0ZSBjb21wb25lbnRcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByZWxvYWRSb3V0ZShwYXRoOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gTm9ybWFsaXplIHBhdGhcbiAgY29uc3Qgbm9ybWFsaXplZFBhdGggPSBwYXRoID09PSAnJyA/ICcvJyA6IHBhdGg7XG5cbiAgaWYgKHByZWxvYWRlZFJvdXRlcy5oYXMobm9ybWFsaXplZFBhdGgpKSB7XG4gICAgcmV0dXJuOyAvLyBBbHJlYWR5IHByZWxvYWRlZFxuICB9XG5cbiAgY29uc3QgbG9hZGVyID0gcm91dGVMb2FkZXJzW25vcm1hbGl6ZWRQYXRoIGFzIFJvdXRlS2V5XTtcbiAgaWYgKCFsb2FkZXIpIHtcbiAgICBjb25zb2xlLndhcm4oYE5vIGxvYWRlciBmb3VuZCBmb3Igcm91dGU6ICR7bm9ybWFsaXplZFBhdGh9YCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBhd2FpdCBsb2FkZXIoKTtcbiAgICBwcmVsb2FkZWRSb3V0ZXMuYWRkKG5vcm1hbGl6ZWRQYXRoKTtcbiAgICBjb25zb2xlLmxvZyhgUHJlbG9hZGVkIHJvdXRlOiAke25vcm1hbGl6ZWRQYXRofWApO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBwcmVsb2FkIHJvdXRlICR7bm9ybWFsaXplZFBhdGh9OmAsIGVycm9yKTtcbiAgfVxufVxuXG4vKipcbiAqIFByZWxvYWQgbXVsdGlwbGUgcm91dGVzXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVsb2FkUm91dGVzKHBhdGhzOiBzdHJpbmdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBwcm9taXNlcyA9IHBhdGhzLm1hcChwYXRoID0+IHByZWxvYWRSb3V0ZShwYXRoKSk7XG4gIGF3YWl0IFByb21pc2UuYWxsU2V0dGxlZChwcm9taXNlcyk7XG59XG5cbi8qKlxuICogR2V0IHByZWxvYWRlZCByb3V0ZXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFByZWxvYWRlZFJvdXRlcygpOiBzdHJpbmdbXSB7XG4gIHJldHVybiBBcnJheS5mcm9tKHByZWxvYWRlZFJvdXRlcyk7XG59XG5cbi8qKlxuICogQ2xlYXIgcHJlbG9hZCBjYWNoZVxuICovXG5leHBvcnQgZnVuY3Rpb24gY2xlYXJQcmVsb2FkQ2FjaGUoKTogdm9pZCB7XG4gIHByZWxvYWRlZFJvdXRlcy5jbGVhcigpO1xufVxuXG4vKipcbiAqIENoZWNrIGlmIHJvdXRlIGlzIHByZWxvYWRlZFxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNSb3V0ZVByZWxvYWRlZChwYXRoOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3Qgbm9ybWFsaXplZFBhdGggPSBwYXRoID09PSAnJyA/ICcvJyA6IHBhdGg7XG4gIHJldHVybiBwcmVsb2FkZWRSb3V0ZXMuaGFzKG5vcm1hbGl6ZWRQYXRoKTtcbn1cblxuLyoqXG4gKiBQcmVsb2FkIHJvdXRlIG9uIGhvdmVyL2ZvY3VzIHdpdGggZGVib3VuY2luZ1xuICovXG5jb25zdCBwcmVsb2FkVGltZW91dHMgPSBuZXcgTWFwPHN0cmluZywgTm9kZUpTLlRpbWVvdXQ+KCk7XG5cbmV4cG9ydCBmdW5jdGlvbiBzY2hlZHVsZVJvdXRlUHJlbG9hZChwYXRoOiBzdHJpbmcsIGRlbGF5OiBudW1iZXIgPSAxMDApOiB2b2lkIHtcbiAgLy8gQ2FuY2VsIGFueSBleGlzdGluZyB0aW1lb3V0IGZvciB0aGlzIHNwZWNpZmljIHBhdGhcbiAgY29uc3QgZXhpc3RpbmcgPSBwcmVsb2FkVGltZW91dHMuZ2V0KHBhdGgpO1xuICBpZiAoZXhpc3RpbmcpIGNsZWFyVGltZW91dChleGlzdGluZyk7XG5cbiAgY29uc3QgdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgIHByZWxvYWRUaW1lb3V0cy5kZWxldGUocGF0aCk7XG4gICAgcHJlbG9hZFJvdXRlKHBhdGgpO1xuICB9LCBkZWxheSk7XG4gIHByZWxvYWRUaW1lb3V0cy5zZXQocGF0aCwgdGltZW91dCk7XG59XG5cbi8qKlxuICogQ2FuY2VsIHNjaGVkdWxlZCBwcmVsb2FkIGZvciBhIHNwZWNpZmljIHBhdGggKG9yIGFsbCBpZiBvbWl0dGVkKVxuICovXG5leHBvcnQgZnVuY3Rpb24gY2FuY2VsU2NoZWR1bGVkUHJlbG9hZChwYXRoPzogc3RyaW5nKTogdm9pZCB7XG4gIGlmIChwYXRoKSB7XG4gICAgY29uc3QgdGltZW91dCA9IHByZWxvYWRUaW1lb3V0cy5nZXQocGF0aCk7XG4gICAgaWYgKHRpbWVvdXQpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcbiAgICAgIHByZWxvYWRUaW1lb3V0cy5kZWxldGUocGF0aCk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHByZWxvYWRUaW1lb3V0cy5mb3JFYWNoKHRpbWVvdXQgPT4gY2xlYXJUaW1lb3V0KHRpbWVvdXQpKTtcbiAgICBwcmVsb2FkVGltZW91dHMuY2xlYXIoKTtcbiAgfVxufVxuXG4vKipcbiAqIEVuaGFuY2VkIExpbmsgY29tcG9uZW50IHdpdGggcHJlbG9hZGluZ1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFByZWxvYWRMaW5rUHJvcHMge1xuICB0bzogc3RyaW5nO1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIHByZWxvYWRPbkhvdmVyPzogYm9vbGVhbjtcbiAgcHJlbG9hZE9uRm9jdXM/OiBib29sZWFuO1xuICBwcmVsb2FkRGVsYXk/OiBudW1iZXI7XG59XG5cbi8qKlxuICogSG9vayBmb3Igcm91dGUgcHJlbG9hZGluZ1xuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlUm91dGVQcmVsb2FkZXIoKSB7XG4gIGNvbnN0IHByZWxvYWQgPSAocGF0aDogc3RyaW5nKSA9PiBwcmVsb2FkUm91dGUocGF0aCk7XG4gIGNvbnN0IHNjaGVkdWxlUHJlbG9hZCA9IChwYXRoOiBzdHJpbmcsIGRlbGF5PzogbnVtYmVyKSA9PlxuICAgIHNjaGVkdWxlUm91dGVQcmVsb2FkKHBhdGgsIGRlbGF5KTtcbiAgY29uc3QgY2FuY2VsUHJlbG9hZCA9ICgpID0+IGNhbmNlbFNjaGVkdWxlZFByZWxvYWQoKTtcblxuICByZXR1cm4ge1xuICAgIHByZWxvYWQsXG4gICAgc2NoZWR1bGVQcmVsb2FkLFxuICAgIGNhbmNlbFByZWxvYWQsXG4gICAgaXNQcmVsb2FkZWQ6IGlzUm91dGVQcmVsb2FkZWQsXG4gICAgcHJlbG9hZGVkUm91dGVzOiBnZXRQcmVsb2FkZWRSb3V0ZXMoKSxcbiAgfTtcbn1cblxuLyoqXG4gKiBQcmVsb2FkIGNyaXRpY2FsIHJvdXRlcyBvbiBhcHAgaW5pdGlhbGl6YXRpb25cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHByZWxvYWRDcml0aWNhbFJvdXRlcygpOiB2b2lkIHtcbiAgLy8gUHJlbG9hZCB0aGUgbW9zdCBpbXBvcnRhbnQgcm91dGVzIChza2lwICcvJyBzaW5jZSBpdCdzIGFscmVhZHkgbG9hZGVkKVxuICBjb25zdCBjcml0aWNhbFJvdXRlcyA9IFsnL3Byb2plY3RzJywgJy9za2lsbHMnXTtcblxuICAvLyBVc2UgcmVxdWVzdElkbGVDYWxsYmFjayBpZiBhdmFpbGFibGUsIG90aGVyd2lzZSBzZXRUaW1lb3V0XG4gIGlmICgncmVxdWVzdElkbGVDYWxsYmFjaycgaW4gd2luZG93KSB7XG4gICAgcmVxdWVzdElkbGVDYWxsYmFjaygoKSA9PiB7XG4gICAgICBwcmVsb2FkUm91dGVzKGNyaXRpY2FsUm91dGVzKTtcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHByZWxvYWRSb3V0ZXMoY3JpdGljYWxSb3V0ZXMpO1xuICAgIH0sIDEwMDApO1xuICB9XG59XG5cbi8qKlxuICogSW50ZWxsaWdlbnQgcm91dGUgcHJlbG9hZGluZyBiYXNlZCBvbiB1c2VyIGJlaGF2aW9yXG4gKi9cbmV4cG9ydCBjbGFzcyBSb3V0ZVByZWxvYWRNYW5hZ2VyIHtcbiAgcHJpdmF0ZSBzdGF0aWMgaW5zdGFuY2U6IFJvdXRlUHJlbG9hZE1hbmFnZXI7XG4gIHByaXZhdGUgcHJlbG9hZFF1ZXVlOiBzdHJpbmdbXSA9IFtdO1xuICBwcml2YXRlIGlzUHJvY2Vzc2luZyA9IGZhbHNlO1xuXG4gIHN0YXRpYyBnZXRJbnN0YW5jZSgpOiBSb3V0ZVByZWxvYWRNYW5hZ2VyIHtcbiAgICBpZiAoIVJvdXRlUHJlbG9hZE1hbmFnZXIuaW5zdGFuY2UpIHtcbiAgICAgIFJvdXRlUHJlbG9hZE1hbmFnZXIuaW5zdGFuY2UgPSBuZXcgUm91dGVQcmVsb2FkTWFuYWdlcigpO1xuICAgIH1cbiAgICByZXR1cm4gUm91dGVQcmVsb2FkTWFuYWdlci5pbnN0YW5jZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgcm91dGUgdG8gcHJlbG9hZCBxdWV1ZVxuICAgKi9cbiAgcXVldWVQcmVsb2FkKHBhdGg6IHN0cmluZyk6IHZvaWQge1xuICAgIGlmICghdGhpcy5wcmVsb2FkUXVldWUuaW5jbHVkZXMocGF0aCkgJiYgIWlzUm91dGVQcmVsb2FkZWQocGF0aCkpIHtcbiAgICAgIHRoaXMucHJlbG9hZFF1ZXVlLnB1c2gocGF0aCk7XG4gICAgICB0aGlzLnByb2Nlc3NRdWV1ZSgpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQcm9jZXNzIHByZWxvYWQgcXVldWVcbiAgICovXG4gIHByaXZhdGUgYXN5bmMgcHJvY2Vzc1F1ZXVlKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGlmICh0aGlzLmlzUHJvY2Vzc2luZyB8fCB0aGlzLnByZWxvYWRRdWV1ZS5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLmlzUHJvY2Vzc2luZyA9IHRydWU7XG5cbiAgICB3aGlsZSAodGhpcy5wcmVsb2FkUXVldWUubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgcGF0aCA9IHRoaXMucHJlbG9hZFF1ZXVlLnNoaWZ0KCk7XG4gICAgICBpZiAocGF0aCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IHByZWxvYWRSb3V0ZShwYXRoKTtcbiAgICAgICAgICAvLyBBZGQgc21hbGwgZGVsYXkgYmV0d2VlbiBwcmVsb2FkcyB0byBhdm9pZCBibG9ja2luZ1xuICAgICAgICAgIGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCA1MCkpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBwcmVsb2FkIHJvdXRlICR7cGF0aH06YCwgZXJyb3IpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgdGhpcy5pc1Byb2Nlc3NpbmcgPSBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQcmVsb2FkIGJhc2VkIG9uIGN1cnJlbnQgcm91dGVcbiAgICovXG4gIHByZWxvYWRSZWxhdGVkUm91dGVzKGN1cnJlbnRQYXRoOiBzdHJpbmcpOiB2b2lkIHtcbiAgICBjb25zdCByZWxhdGVkUm91dGVzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gPSB7XG4gICAgICAnLyc6IFsnL3Byb2plY3RzJywgJy9za2lsbHMnXSxcbiAgICAgICcvcHJvamVjdHMnOiBbJy9za2lsbHMnLCAnL2V4cGVyaWVuY2UnXSxcbiAgICAgICcvc2tpbGxzJzogWycvZXhwZXJpZW5jZScsICcvY29udGFjdCddLFxuICAgICAgJy9leHBlcmllbmNlJzogWycvY29udGFjdCcsICcvcHJvamVjdHMnXSxcbiAgICAgICcvY29udGFjdCc6IFsnLycsICcvcHJvamVjdHMnXSxcbiAgICAgICcvcmVzdW1lJzogWycvY29udGFjdCcsICcvcHJvamVjdHMnXSxcbiAgICB9O1xuXG4gICAgY29uc3QgcmVsYXRlZCA9IHJlbGF0ZWRSb3V0ZXNbY3VycmVudFBhdGhdIHx8IFtdO1xuICAgIHJlbGF0ZWQuZm9yRWFjaChyb3V0ZSA9PiB0aGlzLnF1ZXVlUHJlbG9hZChyb3V0ZSkpO1xuICB9XG59XG4iXSwibmFtZXMiOlsicHJlbG9hZGVkUm91dGVzIiwiU2V0Iiwicm91dGVMb2FkZXJzIiwicHJlbG9hZFJvdXRlIiwicGF0aCIsIm5vcm1hbGl6ZWRQYXRoIiwiaGFzIiwibG9hZGVyIiwiY29uc29sZSIsIndhcm4iLCJhZGQiLCJsb2ciLCJlcnJvciIsInByZWxvYWRSb3V0ZXMiLCJwYXRocyIsInByb21pc2VzIiwibWFwIiwiUHJvbWlzZSIsImFsbFNldHRsZWQiLCJnZXRQcmVsb2FkZWRSb3V0ZXMiLCJBcnJheSIsImZyb20iLCJjbGVhclByZWxvYWRDYWNoZSIsImNsZWFyIiwiaXNSb3V0ZVByZWxvYWRlZCIsInByZWxvYWRUaW1lb3V0cyIsIk1hcCIsInNjaGVkdWxlUm91dGVQcmVsb2FkIiwiZGVsYXkiLCJleGlzdGluZyIsImdldCIsImNsZWFyVGltZW91dCIsInRpbWVvdXQiLCJzZXRUaW1lb3V0IiwiZGVsZXRlIiwic2V0IiwiY2FuY2VsU2NoZWR1bGVkUHJlbG9hZCIsImZvckVhY2giLCJ1c2VSb3V0ZVByZWxvYWRlciIsInByZWxvYWQiLCJzY2hlZHVsZVByZWxvYWQiLCJjYW5jZWxQcmVsb2FkIiwiaXNQcmVsb2FkZWQiLCJwcmVsb2FkQ3JpdGljYWxSb3V0ZXMiLCJjcml0aWNhbFJvdXRlcyIsIndpbmRvdyIsInJlcXVlc3RJZGxlQ2FsbGJhY2siLCJSb3V0ZVByZWxvYWRNYW5hZ2VyIiwiZ2V0SW5zdGFuY2UiLCJpbnN0YW5jZSIsInF1ZXVlUHJlbG9hZCIsInByZWxvYWRRdWV1ZSIsImluY2x1ZGVzIiwicHVzaCIsInByb2Nlc3NRdWV1ZSIsImlzUHJvY2Vzc2luZyIsImxlbmd0aCIsInNoaWZ0IiwicmVzb2x2ZSIsInByZWxvYWRSZWxhdGVkUm91dGVzIiwiY3VycmVudFBhdGgiLCJyZWxhdGVkUm91dGVzIiwicmVsYXRlZCIsInJvdXRlIl0sIm1hcHBpbmdzIjoiQUFBQTs7Q0FFQyxHQUVELDZCQUE2Qjs7Ozs7Ozs7Ozs7Ozs7QUFDN0IsTUFBTUEsa0JBQWtCLElBQUlDO0FBRTVCLDBCQUEwQjtBQUMxQixPQUFPLE1BQU1DLGVBQWU7SUFDMUIsS0FBSyxJQUFNLE1BQU0sQ0FBQztJQUNsQixhQUFhLElBQU0sTUFBTSxDQUFDO0lBQzFCLFdBQVcsSUFBTSxNQUFNLENBQUM7SUFDeEIsZUFBZSxJQUFNLE1BQU0sQ0FBQztJQUM1QixZQUFZLElBQU0sTUFBTSxDQUFDO0lBQ3pCLFdBQVcsSUFBTSxNQUFNLENBQUM7QUFDMUIsRUFBVztBQUlYOztDQUVDLEdBQ0QsT0FBTyxlQUFlQyxhQUFhQyxJQUFZO0lBQzdDLGlCQUFpQjtJQUNqQixNQUFNQyxpQkFBaUJELFNBQVMsS0FBSyxNQUFNQTtJQUUzQyxJQUFJSixnQkFBZ0JNLEdBQUcsQ0FBQ0QsaUJBQWlCO1FBQ3ZDLFFBQVEsb0JBQW9CO0lBQzlCO0lBRUEsTUFBTUUsU0FBU0wsWUFBWSxDQUFDRyxlQUEyQjtJQUN2RCxJQUFJLENBQUNFLFFBQVE7UUFDWEMsUUFBUUMsSUFBSSxDQUFDLENBQUMsMkJBQTJCLEVBQUVKLGdCQUFnQjtRQUMzRDtJQUNGO0lBRUEsSUFBSTtRQUNGLE1BQU1FO1FBQ05QLGdCQUFnQlUsR0FBRyxDQUFDTDtRQUNwQkcsUUFBUUcsR0FBRyxDQUFDLENBQUMsaUJBQWlCLEVBQUVOLGdCQUFnQjtJQUNsRCxFQUFFLE9BQU9PLE9BQU87UUFDZEosUUFBUUksS0FBSyxDQUFDLENBQUMsd0JBQXdCLEVBQUVQLGVBQWUsQ0FBQyxDQUFDLEVBQUVPO0lBQzlEO0FBQ0Y7QUFFQTs7Q0FFQyxHQUNELE9BQU8sZUFBZUMsY0FBY0MsS0FBZTtJQUNqRCxNQUFNQyxXQUFXRCxNQUFNRSxHQUFHLENBQUNaLENBQUFBLE9BQVFELGFBQWFDO0lBQ2hELE1BQU1hLFFBQVFDLFVBQVUsQ0FBQ0g7QUFDM0I7QUFFQTs7Q0FFQyxHQUNELE9BQU8sU0FBU0k7SUFDZCxPQUFPQyxNQUFNQyxJQUFJLENBQUNyQjtBQUNwQjtBQUVBOztDQUVDLEdBQ0QsT0FBTyxTQUFTc0I7SUFDZHRCLGdCQUFnQnVCLEtBQUs7QUFDdkI7QUFFQTs7Q0FFQyxHQUNELE9BQU8sU0FBU0MsaUJBQWlCcEIsSUFBWTtJQUMzQyxNQUFNQyxpQkFBaUJELFNBQVMsS0FBSyxNQUFNQTtJQUMzQyxPQUFPSixnQkFBZ0JNLEdBQUcsQ0FBQ0Q7QUFDN0I7QUFFQTs7Q0FFQyxHQUNELE1BQU1vQixrQkFBa0IsSUFBSUM7QUFFNUIsT0FBTyxTQUFTQyxxQkFBcUJ2QixJQUFZLEVBQUV3QixRQUFnQixHQUFHO0lBQ3BFLHFEQUFxRDtJQUNyRCxNQUFNQyxXQUFXSixnQkFBZ0JLLEdBQUcsQ0FBQzFCO0lBQ3JDLElBQUl5QixVQUFVRSxhQUFhRjtJQUUzQixNQUFNRyxVQUFVQyxXQUFXO1FBQ3pCUixnQkFBZ0JTLE1BQU0sQ0FBQzlCO1FBQ3ZCRCxhQUFhQztJQUNmLEdBQUd3QjtJQUNISCxnQkFBZ0JVLEdBQUcsQ0FBQy9CLE1BQU00QjtBQUM1QjtBQUVBOztDQUVDLEdBQ0QsT0FBTyxTQUFTSSx1QkFBdUJoQyxJQUFhO0lBQ2xELElBQUlBLE1BQU07UUFDUixNQUFNNEIsVUFBVVAsZ0JBQWdCSyxHQUFHLENBQUMxQjtRQUNwQyxJQUFJNEIsU0FBUztZQUNYRCxhQUFhQztZQUNiUCxnQkFBZ0JTLE1BQU0sQ0FBQzlCO1FBQ3pCO0lBQ0YsT0FBTztRQUNMcUIsZ0JBQWdCWSxPQUFPLENBQUNMLENBQUFBLFVBQVdELGFBQWFDO1FBQ2hEUCxnQkFBZ0JGLEtBQUs7SUFDdkI7QUFDRjtBQWNBOztDQUVDLEdBQ0QsT0FBTyxTQUFTZTtJQUNkLE1BQU1DLFVBQVUsQ0FBQ25DLE9BQWlCRCxhQUFhQztJQUMvQyxNQUFNb0Msa0JBQWtCLENBQUNwQyxNQUFjd0IsUUFDckNELHFCQUFxQnZCLE1BQU13QjtJQUM3QixNQUFNYSxnQkFBZ0IsSUFBTUw7SUFFNUIsT0FBTztRQUNMRztRQUNBQztRQUNBQztRQUNBQyxhQUFhbEI7UUFDYnhCLGlCQUFpQm1CO0lBQ25CO0FBQ0Y7QUFFQTs7Q0FFQyxHQUNELE9BQU8sU0FBU3dCO0lBQ2QseUVBQXlFO0lBQ3pFLE1BQU1DLGlCQUFpQjtRQUFDO1FBQWE7S0FBVTtJQUUvQyw2REFBNkQ7SUFDN0QsSUFBSSx5QkFBeUJDLFFBQVE7UUFDbkNDLG9CQUFvQjtZQUNsQmpDLGNBQWMrQjtRQUNoQjtJQUNGLE9BQU87UUFDTFgsV0FBVztZQUNUcEIsY0FBYytCO1FBQ2hCLEdBQUc7SUFDTDtBQUNGO0FBRUE7O0NBRUMsR0FDRCxPQUFPLE1BQU1HO0lBS1gsT0FBT0MsY0FBbUM7UUFDeEMsSUFBSSxDQUFDRCxvQkFBb0JFLFFBQVEsRUFBRTtZQUNqQ0Ysb0JBQW9CRSxRQUFRLEdBQUcsSUFBSUY7UUFDckM7UUFDQSxPQUFPQSxvQkFBb0JFLFFBQVE7SUFDckM7SUFFQTs7R0FFQyxHQUNEQyxhQUFhOUMsSUFBWSxFQUFRO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMrQyxZQUFZLENBQUNDLFFBQVEsQ0FBQ2hELFNBQVMsQ0FBQ29CLGlCQUFpQnBCLE9BQU87WUFDaEUsSUFBSSxDQUFDK0MsWUFBWSxDQUFDRSxJQUFJLENBQUNqRDtZQUN2QixJQUFJLENBQUNrRCxZQUFZO1FBQ25CO0lBQ0Y7SUFFQTs7R0FFQyxHQUNELE1BQWNBLGVBQThCO1FBQzFDLElBQUksSUFBSSxDQUFDQyxZQUFZLElBQUksSUFBSSxDQUFDSixZQUFZLENBQUNLLE1BQU0sS0FBSyxHQUFHO1lBQ3ZEO1FBQ0Y7UUFFQSxJQUFJLENBQUNELFlBQVksR0FBRztRQUVwQixNQUFPLElBQUksQ0FBQ0osWUFBWSxDQUFDSyxNQUFNLEdBQUcsRUFBRztZQUNuQyxNQUFNcEQsT0FBTyxJQUFJLENBQUMrQyxZQUFZLENBQUNNLEtBQUs7WUFDcEMsSUFBSXJELE1BQU07Z0JBQ1IsSUFBSTtvQkFDRixNQUFNRCxhQUFhQztvQkFDbkIscURBQXFEO29CQUNyRCxNQUFNLElBQUlhLFFBQVF5QyxDQUFBQSxVQUFXekIsV0FBV3lCLFNBQVM7Z0JBQ25ELEVBQUUsT0FBTzlDLE9BQU87b0JBQ2RKLFFBQVFJLEtBQUssQ0FBQyxDQUFDLHdCQUF3QixFQUFFUixLQUFLLENBQUMsQ0FBQyxFQUFFUTtnQkFDcEQ7WUFDRjtRQUNGO1FBRUEsSUFBSSxDQUFDMkMsWUFBWSxHQUFHO0lBQ3RCO0lBRUE7O0dBRUMsR0FDREkscUJBQXFCQyxXQUFtQixFQUFRO1FBQzlDLE1BQU1DLGdCQUEwQztZQUM5QyxLQUFLO2dCQUFDO2dCQUFhO2FBQVU7WUFDN0IsYUFBYTtnQkFBQztnQkFBVzthQUFjO1lBQ3ZDLFdBQVc7Z0JBQUM7Z0JBQWU7YUFBVztZQUN0QyxlQUFlO2dCQUFDO2dCQUFZO2FBQVk7WUFDeEMsWUFBWTtnQkFBQztnQkFBSzthQUFZO1lBQzlCLFdBQVc7Z0JBQUM7Z0JBQVk7YUFBWTtRQUN0QztRQUVBLE1BQU1DLFVBQVVELGFBQWEsQ0FBQ0QsWUFBWSxJQUFJLEVBQUU7UUFDaERFLFFBQVF6QixPQUFPLENBQUMwQixDQUFBQSxRQUFTLElBQUksQ0FBQ2IsWUFBWSxDQUFDYTtJQUM3Qzs7UUE3REEsdUJBQVFaLGdCQUF5QixFQUFFO1FBQ25DLHVCQUFRSSxnQkFBZTs7QUE2RHpCO0FBL0RFLGlCQURXUixxQkFDSUUsWUFBZixLQUFBIn0=