import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/performance-dashboard.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
import * as RefreshRuntime from "/@react-refresh";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useState = __vite__cjsImport2_react["useState"]; const useEffect = __vite__cjsImport2_react["useEffect"];
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { Activity, AlertTriangle, CheckCircle, Clock, Eye, EyeOff } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Button } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { usePerformanceMonitor, PERFORMANCE_THRESHOLDS } from "/src/lib/performance-monitor.ts";
import { cn } from "/src/lib/utils.ts";
const PerformanceDashboard = ({ className, showInProduction = false }) => {
  _s();
  const [isVisible, setIsVisible] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const { report, metrics, isComplete } = usePerformanceMonitor();
  const shouldShow = true;
  useEffect(() => {
    if (isComplete && shouldShow) {
      setIsVisible(true);
    }
  }, [
    isComplete,
    shouldShow
  ]);
  if (!shouldShow) {
    return null;
  }
  const getRatingColor = (rating) => {
    switch (rating) {
      case "good":
        return "text-green-600 bg-green-50 border-green-200";
      case "needs-improvement":
        return "text-yellow-600 bg-yellow-50 border-yellow-200";
      case "poor":
        return "text-red-600 bg-red-50 border-red-200";
      default:
        return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };
  const getRatingIcon = (rating) => {
    switch (rating) {
      case "good":
        return /* @__PURE__ */ _jsxDEV(CheckCircle, {
          className: "w-4 h-4"
        }, void 0, false, {
          fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
          lineNumber: 65,
          columnNumber: 16
        }, void 0);
      case "needs-improvement":
        return /* @__PURE__ */ _jsxDEV(Clock, {
          className: "w-4 h-4"
        }, void 0, false, {
          fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
          lineNumber: 67,
          columnNumber: 16
        }, void 0);
      case "poor":
        return /* @__PURE__ */ _jsxDEV(AlertTriangle, {
          className: "w-4 h-4"
        }, void 0, false, {
          fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
          lineNumber: 69,
          columnNumber: 16
        }, void 0);
      default:
        return /* @__PURE__ */ _jsxDEV(Activity, {
          className: "w-4 h-4"
        }, void 0, false, {
          fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
          lineNumber: 71,
          columnNumber: 16
        }, void 0);
    }
  };
  const formatMetricValue = (key, value) => {
    if (value === null) return "N/A";
    switch (key) {
      case "cls":
        return value.toFixed(3);
      case "fcp":
      case "lcp":
      case "fid":
      case "ttfb":
        return `${Math.round(value)}ms`;
      default:
        return value.toString();
    }
  };
  const getOverallRating = () => {
    if (!report) return "good";
    const ratings = Object.values(report.ratings);
    if (ratings.some((rating) => rating === "poor")) return "poor";
    if (ratings.some((rating) => rating === "needs-improvement")) return "needs-improvement";
    return "good";
  };
  return /* @__PURE__ */ _jsxDEV(AnimatePresence, {
    children: isVisible && /* @__PURE__ */ _jsxDEV(motion.div, {
      initial: {
        opacity: 0,
        x: 300
      },
      animate: {
        opacity: 1,
        x: 0
      },
      exit: {
        opacity: 0,
        x: 300
      },
      className: cn("fixed top-20 right-4 z-50 max-w-sm", className),
      children: /* @__PURE__ */ _jsxDEV(Card, {
        className: "bg-background/95 backdrop-blur-sm border shadow-lg",
        children: [
          /* @__PURE__ */ _jsxDEV(CardHeader, {
            className: "pb-3",
            children: /* @__PURE__ */ _jsxDEV("div", {
              className: "flex items-center justify-between",
              children: [
                /* @__PURE__ */ _jsxDEV(CardTitle, {
                  className: "text-sm font-medium flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ _jsxDEV(Activity, {
                      className: "w-4 h-4"
                    }, void 0, false, {
                      fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                      lineNumber: 117,
                      columnNumber: 19
                    }, void 0),
                    "Performance Monitor"
                  ]
                }, void 0, true, {
                  fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                  lineNumber: 116,
                  columnNumber: 17
                }, void 0),
                /* @__PURE__ */ _jsxDEV("div", {
                  className: "flex items-center gap-1",
                  children: [
                    /* @__PURE__ */ _jsxDEV(Badge, {
                      variant: "outline",
                      className: cn("text-xs", getRatingColor(getOverallRating())),
                      children: getOverallRating().toUpperCase()
                    }, void 0, false, {
                      fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                      lineNumber: 121,
                      columnNumber: 19
                    }, void 0),
                    /* @__PURE__ */ _jsxDEV(Button, {
                      variant: "ghost",
                      size: "sm",
                      onClick: () => setIsExpanded(!isExpanded),
                      className: "h-6 w-6 p-0",
                      children: isExpanded ? /* @__PURE__ */ _jsxDEV(EyeOff, {
                        className: "w-3 h-3"
                      }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                        lineNumber: 137,
                        columnNumber: 23
                      }, void 0) : /* @__PURE__ */ _jsxDEV(Eye, {
                        className: "w-3 h-3"
                      }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                        lineNumber: 139,
                        columnNumber: 23
                      }, void 0)
                    }, void 0, false, {
                      fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                      lineNumber: 130,
                      columnNumber: 19
                    }, void 0),
                    /* @__PURE__ */ _jsxDEV(Button, {
                      variant: "ghost",
                      size: "sm",
                      onClick: () => setIsVisible(false),
                      className: "h-6 w-6 p-0",
                      children: "×"
                    }, void 0, false, {
                      fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                      lineNumber: 142,
                      columnNumber: 19
                    }, void 0)
                  ]
                }, void 0, true, {
                  fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                  lineNumber: 120,
                  columnNumber: 17
                }, void 0)
              ]
            }, void 0, true, {
              fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
              lineNumber: 115,
              columnNumber: 15
            }, void 0)
          }, void 0, false, {
            fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
            lineNumber: 114,
            columnNumber: 13
          }, void 0),
          /* @__PURE__ */ _jsxDEV(AnimatePresence, {
            children: isExpanded && /* @__PURE__ */ _jsxDEV(motion.div, {
              initial: {
                height: 0,
                opacity: 0
              },
              animate: {
                height: "auto",
                opacity: 1
              },
              exit: {
                height: 0,
                opacity: 0
              },
              transition: {
                duration: 0.2
              },
              children: /* @__PURE__ */ _jsxDEV(CardContent, {
                className: "pt-0 space-y-3",
                children: [
                  Object.entries(metrics).map(([key, value]) => {
                    const metricKey = key;
                    const rating = report?.ratings[metricKey] || "good";
                    const threshold = PERFORMANCE_THRESHOLDS.good[metricKey];
                    return /* @__PURE__ */ _jsxDEV(motion.div, {
                      initial: {
                        opacity: 0,
                        y: 10
                      },
                      animate: {
                        opacity: 1,
                        y: 0
                      },
                      className: "flex items-center justify-between p-2 rounded-lg border bg-card",
                      children: [
                        /* @__PURE__ */ _jsxDEV("div", {
                          className: "flex items-center gap-2",
                          children: [
                            /* @__PURE__ */ _jsxDEV("div", {
                              className: cn("p-1 rounded", getRatingColor(rating)),
                              children: getRatingIcon(rating)
                            }, void 0, false, {
                              fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                              lineNumber: 176,
                              columnNumber: 29
                            }, void 0),
                            /* @__PURE__ */ _jsxDEV("div", {
                              children: [
                                /* @__PURE__ */ _jsxDEV("div", {
                                  className: "text-sm font-medium uppercase",
                                  children: key
                                }, void 0, false, {
                                  fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                                  lineNumber: 185,
                                  columnNumber: 31
                                }, void 0),
                                /* @__PURE__ */ _jsxDEV("div", {
                                  className: "text-xs text-muted-foreground",
                                  children: [
                                    "Target:",
                                    " ",
                                    formatMetricValue(metricKey, threshold)
                                  ]
                                }, void 0, true, {
                                  fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                                  lineNumber: 188,
                                  columnNumber: 31
                                }, void 0)
                              ]
                            }, void 0, true, {
                              fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                              lineNumber: 184,
                              columnNumber: 29
                            }, void 0)
                          ]
                        }, void 0, true, {
                          fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                          lineNumber: 175,
                          columnNumber: 27
                        }, void 0),
                        /* @__PURE__ */ _jsxDEV("div", {
                          className: "text-right",
                          children: [
                            /* @__PURE__ */ _jsxDEV("div", {
                              className: cn("text-sm font-mono font-medium", value === null ? "text-muted-foreground" : "text-foreground"),
                              children: formatMetricValue(metricKey, value)
                            }, void 0, false, {
                              fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                              lineNumber: 195,
                              columnNumber: 29
                            }, void 0),
                            /* @__PURE__ */ _jsxDEV("div", {
                              className: "text-xs text-muted-foreground",
                              children: rating.replace("-", " ")
                            }, void 0, false, {
                              fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                              lineNumber: 205,
                              columnNumber: 29
                            }, void 0)
                          ]
                        }, void 0, true, {
                          fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                          lineNumber: 194,
                          columnNumber: 27
                        }, void 0)
                      ]
                    }, key, true, {
                      fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                      lineNumber: 169,
                      columnNumber: 25
                    }, void 0);
                  }),
                  /* @__PURE__ */ _jsxDEV("div", {
                    className: "pt-2 border-t text-xs text-muted-foreground space-y-1",
                    children: [
                      /* @__PURE__ */ _jsxDEV("div", {
                        children: [
                          "Updated:",
                          " ",
                          report ? new Date(report.timestamp).toLocaleTimeString() : "N/A"
                        ]
                      }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                        lineNumber: 215,
                        columnNumber: 23
                      }, void 0),
                      /* @__PURE__ */ _jsxDEV("div", {
                        children: [
                          "Complete: ",
                          isComplete ? "Yes" : "No"
                        ]
                      }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                        lineNumber: 221,
                        columnNumber: 23
                      }, void 0)
                    ]
                  }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                    lineNumber: 214,
                    columnNumber: 21
                  }, void 0),
                  /* @__PURE__ */ _jsxDEV("div", {
                    className: "flex gap-2 pt-2",
                    children: [
                      /* @__PURE__ */ _jsxDEV(Button, {
                        variant: "outline",
                        size: "sm",
                        onClick: () => {
                          console.log("Performance Report:", report);
                          console.log("Current Metrics:", metrics);
                        },
                        className: "flex-1 text-xs",
                        children: "Log Report"
                      }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                        lineNumber: 226,
                        columnNumber: 23
                      }, void 0),
                      /* @__PURE__ */ _jsxDEV(Button, {
                        variant: "outline",
                        size: "sm",
                        onClick: () => window.location.reload(),
                        className: "flex-1 text-xs",
                        children: "Refresh"
                      }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                        lineNumber: 237,
                        columnNumber: 23
                      }, void 0)
                    ]
                  }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                    lineNumber: 225,
                    columnNumber: 21
                  }, void 0)
                ]
              }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
                lineNumber: 162,
                columnNumber: 19
              }, void 0)
            }, void 0, false, {
              fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
              lineNumber: 156,
              columnNumber: 17
            }, void 0)
          }, void 0, false, {
            fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
            lineNumber: 154,
            columnNumber: 13
          }, void 0)
        ]
      }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
        lineNumber: 113,
        columnNumber: 11
      }, void 0)
    }, void 0, false, {
      fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
      lineNumber: 107,
      columnNumber: 9
    }, void 0)
  }, void 0, false, {
    fileName: "D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx",
    lineNumber: 105,
    columnNumber: 5
  }, void 0);
};
_s(PerformanceDashboard, "FccDSQs8cOT1N1IXQY/5/Ktzu0w=", false, function() {
  return [
    usePerformanceMonitor
  ];
});
_c = PerformanceDashboard;
export default PerformanceDashboard;
var _c;
$RefreshReg$(_c, "PerformanceDashboard");
window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;
RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/performance-dashboard.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxPQUFPQSxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDM0MsU0FBU0MsUUFBUUMsdUJBQXVCO0FBQ3hDLFNBQ0VDLFVBQ0FDLGVBQ0FDLGFBQ0FDLE9BQ0FDLEtBQ0FDLGNBQ0s7QUFDUCxTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLE1BQU1DLGFBQWFDLFlBQVlDLGlCQUFpQjtBQUN6RCxTQUFTQyxhQUFhO0FBQ3RCLFNBQ0VDLHVCQUdBQyw4QkFDSztBQUNQLFNBQVNDLFVBQVU7QUFPbkIsTUFBTUMsdUJBQTRELENBQUMsRUFDakVDLFdBQ0FDLG1CQUFtQixNQUFLLE1BQ3pCOztBQUNDLFFBQU0sQ0FBQ0MsV0FBV0MsZ0JBQWdCdkIsU0FBUztBQUMzQyxRQUFNLENBQUN3QixZQUFZQyxpQkFBaUJ6QixTQUFTO0FBQzdDLFFBQU0sRUFBRTBCLFFBQVFDLFNBQVNDLFdBQVUsSUFBS1o7QUFHeEMsUUFBTWEsYUFBYUM7QUFFbkI3QixZQUFVO0FBRVIsUUFBSTJCLGNBQWNDLFlBQVk7QUFDNUJOLG1CQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0YsR0FBRztBQUFBLElBQUNLO0FBQUFBLElBQVlDO0FBQUFBLEdBQVc7QUFFM0IsTUFBSSxDQUFDQSxZQUFZO0FBQ2YsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNRSxpQkFBaUIsQ0FBQ0M7QUFDdEIsWUFBUUE7QUFBQUEsTUFDTixLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVDtBQUNFLGVBQU87QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUVBLFFBQU1DLGdCQUFnQixDQUFDRDtBQUNyQixZQUFRQTtBQUFBQSxNQUNOLEtBQUs7QUFDSCxlQUFPLHdCQUFDMUI7QUFBQUEsVUFBWWMsV0FBVTtBQUFBOzs7OztNQUNoQyxLQUFLO0FBQ0gsZUFBTyx3QkFBQ2I7QUFBQUEsVUFBTWEsV0FBVTtBQUFBOzs7OztNQUMxQixLQUFLO0FBQ0gsZUFBTyx3QkFBQ2Y7QUFBQUEsVUFBY2UsV0FBVTtBQUFBOzs7OztNQUNsQztBQUNFLGVBQU8sd0JBQUNoQjtBQUFBQSxVQUFTZ0IsV0FBVTtBQUFBOzs7OztJQUMvQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNYyxvQkFBb0IsQ0FDeEJDLEtBQ0FDO0FBRUEsUUFBSUEsVUFBVSxLQUFNLFFBQU87QUFFM0IsWUFBUUQ7QUFBQUEsTUFDTixLQUFLO0FBQ0gsZUFBT0MsTUFBTUMsUUFBUTtBQUFBLE1BQ3ZCLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFDSCxlQUFPLEdBQUdDLEtBQUtDLE1BQU1IO0FBQUFBLE1BQ3ZCO0FBQ0UsZUFBT0EsTUFBTUksU0FBUTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUVBLFFBQU1DLG1CQUFtQjtBQUN2QixRQUFJLENBQUNmLE9BQVEsUUFBTztBQUVwQixVQUFNZ0IsVUFBVUMsT0FBT0MsT0FBT2xCLE9BQU9nQixPQUFPO0FBQzVDLFFBQUlBLFFBQVFHLEtBQUtiLFlBQVVBLFdBQVcsUUFBUyxRQUFPO0FBQ3RELFFBQUlVLFFBQVFHLEtBQUtiLFlBQVVBLFdBQVcscUJBQ3BDLFFBQU87QUFDVCxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQ0Usd0JBQUM3QjtBQUFBQSxjQUNFbUIsYUFDQyx3QkFBQ3BCLE9BQU80QyxLQUFHO0FBQUEsTUFDVEMsU0FBUztBQUFBLFFBQUVDLFNBQVM7QUFBQSxRQUFHQyxHQUFHO0FBQUEsTUFBSTtBQUFBLE1BQzlCQyxTQUFTO0FBQUEsUUFBRUYsU0FBUztBQUFBLFFBQUdDLEdBQUc7QUFBQSxNQUFFO0FBQUEsTUFDNUJFLE1BQU07QUFBQSxRQUFFSCxTQUFTO0FBQUEsUUFBR0MsR0FBRztBQUFBLE1BQUk7QUFBQSxNQUMzQjdCLFdBQVdGLEdBQUcsc0NBQXNDRTtBQUFBQSxnQkFFcEQsd0JBQUNUO0FBQUFBLFFBQUtTLFdBQVU7QUFBQTtVQUNkLHdCQUFDUDtBQUFBQSxZQUFXTyxXQUFVO0FBQUEsc0JBQ3BCLHdCQUFDMEI7QUFBQUEsY0FBSTFCLFdBQVU7QUFBQTtnQkFDYix3QkFBQ047QUFBQUEsa0JBQVVNLFdBQVU7QUFBQTtvQkFDbkIsd0JBQUNoQjtBQUFBQSxzQkFBU2dCLFdBQVU7QUFBQTs7Ozs7b0JBQVk7QUFBQTs7Ozs7O2dCQUdsQyx3QkFBQzBCO0FBQUFBLGtCQUFJMUIsV0FBVTtBQUFBO29CQUNiLHdCQUFDTDtBQUFBQSxzQkFDQ3FDLFNBQVE7QUFBQSxzQkFDUmhDLFdBQVdGLEdBQ1QsV0FDQWEsZUFBZVU7QUFBQUEsZ0NBR2hCQSxtQkFBbUJZLFlBQVc7QUFBQTs7Ozs7b0JBRWpDLHdCQUFDM0M7QUFBQUEsc0JBQ0MwQyxTQUFRO0FBQUEsc0JBQ1JFLE1BQUs7QUFBQSxzQkFDTEMsU0FBUyxNQUFNOUIsY0FBYyxDQUFDRDtBQUFBQSxzQkFDOUJKLFdBQVU7QUFBQSxnQ0FFVEksYUFDQyx3QkFBQ2Y7QUFBQUEsd0JBQU9XLFdBQVU7QUFBQTs7OzttQ0FFbEIsd0JBQUNaO0FBQUFBLHdCQUFJWSxXQUFVO0FBQUE7Ozs7Ozs7Ozs7b0JBR25CLHdCQUFDVjtBQUFBQSxzQkFDQzBDLFNBQVE7QUFBQSxzQkFDUkUsTUFBSztBQUFBLHNCQUNMQyxTQUFTLE1BQU1oQyxhQUFhO0FBQUEsc0JBQzVCSCxXQUFVO0FBQUEsZ0NBQ1g7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztVQU9QLHdCQUFDakI7QUFBQUEsc0JBQ0VxQixjQUNDLHdCQUFDdEIsT0FBTzRDLEtBQUc7QUFBQSxjQUNUQyxTQUFTO0FBQUEsZ0JBQUVTLFFBQVE7QUFBQSxnQkFBR1IsU0FBUztBQUFBLGNBQUU7QUFBQSxjQUNqQ0UsU0FBUztBQUFBLGdCQUFFTSxRQUFRO0FBQUEsZ0JBQVFSLFNBQVM7QUFBQSxjQUFFO0FBQUEsY0FDdENHLE1BQU07QUFBQSxnQkFBRUssUUFBUTtBQUFBLGdCQUFHUixTQUFTO0FBQUEsY0FBRTtBQUFBLGNBQzlCUyxZQUFZO0FBQUEsZ0JBQUVDLFVBQVU7QUFBQSxjQUFJO0FBQUEsd0JBRTVCLHdCQUFDOUM7QUFBQUEsZ0JBQVlRLFdBQVU7QUFBQTtrQkFDcEJ1QixPQUFPZ0IsUUFBUWhDLFNBQVNpQyxJQUFJLENBQUMsQ0FBQ3pCLEtBQUtDLFdBQU07QUFDeEMsMEJBQU15QixZQUFZMUI7QUFDbEIsMEJBQU1ILFNBQVNOLFFBQVFnQixRQUFRbUIsY0FBYztBQUM3QywwQkFBTUMsWUFBWTdDLHVCQUF1QjhDLEtBQUtGO0FBRTlDLDJCQUNFLHdCQUFDM0QsT0FBTzRDLEtBQUc7QUFBQSxzQkFFVEMsU0FBUztBQUFBLHdCQUFFQyxTQUFTO0FBQUEsd0JBQUdnQixHQUFHO0FBQUEsc0JBQUc7QUFBQSxzQkFDN0JkLFNBQVM7QUFBQSx3QkFBRUYsU0FBUztBQUFBLHdCQUFHZ0IsR0FBRztBQUFBLHNCQUFFO0FBQUEsc0JBQzVCNUMsV0FBVTtBQUFBO3dCQUVWLHdCQUFDMEI7QUFBQUEsMEJBQUkxQixXQUFVO0FBQUE7NEJBQ2Isd0JBQUMwQjtBQUFBQSw4QkFDQzFCLFdBQVdGLEdBQ1QsZUFDQWEsZUFBZUM7QUFBQUEsd0NBR2hCQyxjQUFjRDtBQUFBQTs7Ozs7NEJBRWpCLHdCQUFDYztBQUFBQTtnQ0FDQyx3QkFBQ0E7QUFBQUEsa0NBQUkxQixXQUFVO0FBQUEsNENBQ1plO0FBQUFBOzs7OztnQ0FFSCx3QkFBQ1c7QUFBQUEsa0NBQUkxQixXQUFVO0FBQUE7b0NBQWdDO0FBQUEsb0NBQ3JDO0FBQUEsb0NBQ1BjLGtCQUFrQjJCLFdBQVdDO0FBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7d0JBSXBDLHdCQUFDaEI7QUFBQUEsMEJBQUkxQixXQUFVO0FBQUE7NEJBQ2Isd0JBQUMwQjtBQUFBQSw4QkFDQzFCLFdBQVdGLEdBQ1QsaUNBQ0FrQixVQUFVLE9BQ04sMEJBQ0E7QUFBQSx3Q0FHTEYsa0JBQWtCMkIsV0FBV3pCO0FBQUFBOzs7Ozs0QkFFaEMsd0JBQUNVO0FBQUFBLDhCQUFJMUIsV0FBVTtBQUFBLHdDQUNaWSxPQUFPaUMsUUFBUSxLQUFLO0FBQUE7Ozs7Ozs7Ozs7Ozt1QkFwQ3BCOUI7QUFBQUE7Ozs7a0JBeUNYO0FBQUEsa0JBR0Esd0JBQUNXO0FBQUFBLG9CQUFJMUIsV0FBVTtBQUFBO3NCQUNiLHdCQUFDMEI7QUFBQUE7MEJBQUk7QUFBQSwwQkFDTTtBQUFBLDBCQUNScEIsU0FDRyxJQUFJd0MsS0FBS3hDLE9BQU95QyxTQUFTLEVBQUVDLG1CQUFrQixJQUM3QztBQUFBOzs7Ozs7c0JBRU4sd0JBQUN0QjtBQUFBQTswQkFBSTtBQUFBLDBCQUFXbEIsYUFBYSxRQUFRO0FBQUE7Ozs7Ozs7Ozs7OztrQkFJdkMsd0JBQUNrQjtBQUFBQSxvQkFBSTFCLFdBQVU7QUFBQTtzQkFDYix3QkFBQ1Y7QUFBQUEsd0JBQ0MwQyxTQUFRO0FBQUEsd0JBQ1JFLE1BQUs7QUFBQSx3QkFDTEMsU0FBUztBQUNQYyxrQ0FBUUMsSUFBSSx1QkFBdUI1QztBQUNuQzJDLGtDQUFRQyxJQUFJLG9CQUFvQjNDO0FBQUFBLHdCQUNsQztBQUFBLHdCQUNBUCxXQUFVO0FBQUEsa0NBQ1g7QUFBQTs7Ozs7c0JBR0Qsd0JBQUNWO0FBQUFBLHdCQUNDMEMsU0FBUTtBQUFBLHdCQUNSRSxNQUFLO0FBQUEsd0JBQ0xDLFNBQVMsTUFBTWdCLE9BQU9DLFNBQVNDLE9BQU07QUFBQSx3QkFDckNyRCxXQUFVO0FBQUEsa0NBQ1g7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWF2QjtHQXBPTUQ7O0lBTW9DSDtBQUFBQTs7S0FOcENHO0FBc09OLGVBQWVBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIm1vdGlvbiIsIkFuaW1hdGVQcmVzZW5jZSIsIkFjdGl2aXR5IiwiQWxlcnRUcmlhbmdsZSIsIkNoZWNrQ2lyY2xlIiwiQ2xvY2siLCJFeWUiLCJFeWVPZmYiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiQmFkZ2UiLCJ1c2VQZXJmb3JtYW5jZU1vbml0b3IiLCJQRVJGT1JNQU5DRV9USFJFU0hPTERTIiwiY24iLCJQZXJmb3JtYW5jZURhc2hib2FyZCIsImNsYXNzTmFtZSIsInNob3dJblByb2R1Y3Rpb24iLCJpc1Zpc2libGUiLCJzZXRJc1Zpc2libGUiLCJpc0V4cGFuZGVkIiwic2V0SXNFeHBhbmRlZCIsInJlcG9ydCIsIm1ldHJpY3MiLCJpc0NvbXBsZXRlIiwic2hvdWxkU2hvdyIsInByb2Nlc3MiLCJnZXRSYXRpbmdDb2xvciIsInJhdGluZyIsImdldFJhdGluZ0ljb24iLCJmb3JtYXRNZXRyaWNWYWx1ZSIsImtleSIsInZhbHVlIiwidG9GaXhlZCIsIk1hdGgiLCJyb3VuZCIsInRvU3RyaW5nIiwiZ2V0T3ZlcmFsbFJhdGluZyIsInJhdGluZ3MiLCJPYmplY3QiLCJ2YWx1ZXMiLCJzb21lIiwiZGl2IiwiaW5pdGlhbCIsIm9wYWNpdHkiLCJ4IiwiYW5pbWF0ZSIsImV4aXQiLCJ2YXJpYW50IiwidG9VcHBlckNhc2UiLCJzaXplIiwib25DbGljayIsImhlaWdodCIsInRyYW5zaXRpb24iLCJkdXJhdGlvbiIsImVudHJpZXMiLCJtYXAiLCJtZXRyaWNLZXkiLCJ0aHJlc2hvbGQiLCJnb29kIiwieSIsInJlcGxhY2UiLCJEYXRlIiwidGltZXN0YW1wIiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwiY29uc29sZSIsImxvZyIsIndpbmRvdyIsImxvY2F0aW9uIiwicmVsb2FkIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInBlcmZvcm1hbmNlLWRhc2hib2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24sIEFuaW1hdGVQcmVzZW5jZSB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHtcbiAgQWN0aXZpdHksXG4gIEFsZXJ0VHJpYW5nbGUsXG4gIENoZWNrQ2lyY2xlLFxuICBDbG9jayxcbiAgRXllLFxuICBFeWVPZmYsXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJztcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkSGVhZGVyLCBDYXJkVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCc7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9iYWRnZSc7XG5pbXBvcnQge1xuICB1c2VQZXJmb3JtYW5jZU1vbml0b3IsXG4gIFBlcmZvcm1hbmNlTWV0cmljcyxcbiAgUGVyZm9ybWFuY2VSYXRpbmcsXG4gIFBFUkZPUk1BTkNFX1RIUkVTSE9MRFMsXG59IGZyb20gJ0AvbGliL3BlcmZvcm1hbmNlLW1vbml0b3InO1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscyc7XG5cbmludGVyZmFjZSBQZXJmb3JtYW5jZURhc2hib2FyZFByb3BzIHtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzaG93SW5Qcm9kdWN0aW9uPzogYm9vbGVhbjtcbn1cblxuY29uc3QgUGVyZm9ybWFuY2VEYXNoYm9hcmQ6IFJlYWN0LkZDPFBlcmZvcm1hbmNlRGFzaGJvYXJkUHJvcHM+ID0gKHtcbiAgY2xhc3NOYW1lLFxuICBzaG93SW5Qcm9kdWN0aW9uID0gZmFsc2UsXG59KSA9PiB7XG4gIGNvbnN0IFtpc1Zpc2libGUsIHNldElzVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0V4cGFuZGVkLCBzZXRJc0V4cGFuZGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgeyByZXBvcnQsIG1ldHJpY3MsIGlzQ29tcGxldGUgfSA9IHVzZVBlcmZvcm1hbmNlTW9uaXRvcigpO1xuXG4gIC8vIE9ubHkgc2hvdyBpbiBkZXZlbG9wbWVudCB1bmxlc3MgZXhwbGljaXRseSBlbmFibGVkIGZvciBwcm9kdWN0aW9uXG4gIGNvbnN0IHNob3VsZFNob3cgPSBwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50JyB8fCBzaG93SW5Qcm9kdWN0aW9uO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gQXV0by1zaG93IGRhc2hib2FyZCB3aGVuIG1ldHJpY3MgYXJlIGF2YWlsYWJsZVxuICAgIGlmIChpc0NvbXBsZXRlICYmIHNob3VsZFNob3cpIHtcbiAgICAgIHNldElzVmlzaWJsZSh0cnVlKTtcbiAgICB9XG4gIH0sIFtpc0NvbXBsZXRlLCBzaG91bGRTaG93XSk7XG5cbiAgaWYgKCFzaG91bGRTaG93KSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBjb25zdCBnZXRSYXRpbmdDb2xvciA9IChyYXRpbmc6IFBlcmZvcm1hbmNlUmF0aW5nKTogc3RyaW5nID0+IHtcbiAgICBzd2l0Y2ggKHJhdGluZykge1xuICAgICAgY2FzZSAnZ29vZCc6XG4gICAgICAgIHJldHVybiAndGV4dC1ncmVlbi02MDAgYmctZ3JlZW4tNTAgYm9yZGVyLWdyZWVuLTIwMCc7XG4gICAgICBjYXNlICduZWVkcy1pbXByb3ZlbWVudCc6XG4gICAgICAgIHJldHVybiAndGV4dC15ZWxsb3ctNjAwIGJnLXllbGxvdy01MCBib3JkZXIteWVsbG93LTIwMCc7XG4gICAgICBjYXNlICdwb29yJzpcbiAgICAgICAgcmV0dXJuICd0ZXh0LXJlZC02MDAgYmctcmVkLTUwIGJvcmRlci1yZWQtMjAwJztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiAndGV4dC1ncmF5LTYwMCBiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTIwMCc7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGdldFJhdGluZ0ljb24gPSAocmF0aW5nOiBQZXJmb3JtYW5jZVJhdGluZykgPT4ge1xuICAgIHN3aXRjaCAocmF0aW5nKSB7XG4gICAgICBjYXNlICdnb29kJzpcbiAgICAgICAgcmV0dXJuIDxDaGVja0NpcmNsZSBjbGFzc05hbWU9J3ctNCBoLTQnIC8+O1xuICAgICAgY2FzZSAnbmVlZHMtaW1wcm92ZW1lbnQnOlxuICAgICAgICByZXR1cm4gPENsb2NrIGNsYXNzTmFtZT0ndy00IGgtNCcgLz47XG4gICAgICBjYXNlICdwb29yJzpcbiAgICAgICAgcmV0dXJuIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT0ndy00IGgtNCcgLz47XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gPEFjdGl2aXR5IGNsYXNzTmFtZT0ndy00IGgtNCcgLz47XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGZvcm1hdE1ldHJpY1ZhbHVlID0gKFxuICAgIGtleToga2V5b2YgUGVyZm9ybWFuY2VNZXRyaWNzLFxuICAgIHZhbHVlOiBudW1iZXIgfCBudWxsXG4gICk6IHN0cmluZyA9PiB7XG4gICAgaWYgKHZhbHVlID09PSBudWxsKSByZXR1cm4gJ04vQSc7XG5cbiAgICBzd2l0Y2ggKGtleSkge1xuICAgICAgY2FzZSAnY2xzJzpcbiAgICAgICAgcmV0dXJuIHZhbHVlLnRvRml4ZWQoMyk7XG4gICAgICBjYXNlICdmY3AnOlxuICAgICAgY2FzZSAnbGNwJzpcbiAgICAgIGNhc2UgJ2ZpZCc6XG4gICAgICBjYXNlICd0dGZiJzpcbiAgICAgICAgcmV0dXJuIGAke01hdGgucm91bmQodmFsdWUpfW1zYDtcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiB2YWx1ZS50b1N0cmluZygpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBnZXRPdmVyYWxsUmF0aW5nID0gKCk6IFBlcmZvcm1hbmNlUmF0aW5nID0+IHtcbiAgICBpZiAoIXJlcG9ydCkgcmV0dXJuICdnb29kJztcblxuICAgIGNvbnN0IHJhdGluZ3MgPSBPYmplY3QudmFsdWVzKHJlcG9ydC5yYXRpbmdzKTtcbiAgICBpZiAocmF0aW5ncy5zb21lKHJhdGluZyA9PiByYXRpbmcgPT09ICdwb29yJykpIHJldHVybiAncG9vcic7XG4gICAgaWYgKHJhdGluZ3Muc29tZShyYXRpbmcgPT4gcmF0aW5nID09PSAnbmVlZHMtaW1wcm92ZW1lbnQnKSlcbiAgICAgIHJldHVybiAnbmVlZHMtaW1wcm92ZW1lbnQnO1xuICAgIHJldHVybiAnZ29vZCc7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8QW5pbWF0ZVByZXNlbmNlPlxuICAgICAge2lzVmlzaWJsZSAmJiAoXG4gICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB4OiAzMDAgfX1cbiAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHg6IDAgfX1cbiAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHg6IDMwMCB9fVxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oJ2ZpeGVkIHRvcC0yMCByaWdodC00IHotNTAgbWF4LXctc20nLCBjbGFzc05hbWUpfVxuICAgICAgICA+XG4gICAgICAgICAgPENhcmQgY2xhc3NOYW1lPSdiZy1iYWNrZ3JvdW5kLzk1IGJhY2tkcm9wLWJsdXItc20gYm9yZGVyIHNoYWRvdy1sZyc+XG4gICAgICAgICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9J3BiLTMnPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuJz5cbiAgICAgICAgICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT0ndGV4dC1zbSBmb250LW1lZGl1bSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMic+XG4gICAgICAgICAgICAgICAgICA8QWN0aXZpdHkgY2xhc3NOYW1lPSd3LTQgaC00JyAvPlxuICAgICAgICAgICAgICAgICAgUGVyZm9ybWFuY2UgTW9uaXRvclxuICAgICAgICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSc+XG4gICAgICAgICAgICAgICAgICA8QmFkZ2VcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD0nb3V0bGluZSdcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAndGV4dC14cycsXG4gICAgICAgICAgICAgICAgICAgICAgZ2V0UmF0aW5nQ29sb3IoZ2V0T3ZlcmFsbFJhdGluZygpKVxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7Z2V0T3ZlcmFsbFJhdGluZygpLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PSdnaG9zdCdcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT0nc20nXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzRXhwYW5kZWQoIWlzRXhwYW5kZWQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2gtNiB3LTYgcC0wJ1xuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7aXNFeHBhbmRlZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8RXllT2ZmIGNsYXNzTmFtZT0ndy0zIGgtMycgLz5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8RXllIGNsYXNzTmFtZT0ndy0zIGgtMycgLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PSdnaG9zdCdcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT0nc20nXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzVmlzaWJsZShmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0naC02IHctNiBwLTAnXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIMOXXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L0NhcmRIZWFkZXI+XG5cbiAgICAgICAgICAgIDxBbmltYXRlUHJlc2VuY2U+XG4gICAgICAgICAgICAgIHtpc0V4cGFuZGVkICYmIChcbiAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAgaW5pdGlhbD17eyBoZWlnaHQ6IDAsIG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgaGVpZ2h0OiAnYXV0bycsIG9wYWNpdHk6IDEgfX1cbiAgICAgICAgICAgICAgICAgIGV4aXQ9e3sgaGVpZ2h0OiAwLCBvcGFjaXR5OiAwIH19XG4gICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjIgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPSdwdC0wIHNwYWNlLXktMyc+XG4gICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhtZXRyaWNzKS5tYXAoKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG1ldHJpY0tleSA9IGtleSBhcyBrZXlvZiBQZXJmb3JtYW5jZU1ldHJpY3M7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmF0aW5nID0gcmVwb3J0Py5yYXRpbmdzW21ldHJpY0tleV0gfHwgJ2dvb2QnO1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRocmVzaG9sZCA9IFBFUkZPUk1BTkNFX1RIUkVTSE9MRFMuZ29vZFttZXRyaWNLZXldO1xuXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17a2V5fVxuICAgICAgICAgICAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDEwIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTIgcm91bmRlZC1sZyBib3JkZXIgYmctY2FyZCdcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGdhcC0yJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAncC0xIHJvdW5kZWQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZXRSYXRpbmdDb2xvcihyYXRpbmcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRSYXRpbmdJY29uKHJhdGluZyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd0ZXh0LXNtIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtrZXl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhcmdldDp7JyAnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0TWV0cmljVmFsdWUobWV0cmljS2V5LCB0aHJlc2hvbGQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ndGV4dC1yaWdodCc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3RleHQtc20gZm9udC1tb25vIGZvbnQtbWVkaXVtJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUgPT09IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LW11dGVkLWZvcmVncm91bmQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1mb3JlZ3JvdW5kJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0TWV0cmljVmFsdWUobWV0cmljS2V5LCB2YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3RleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyYXRpbmcucmVwbGFjZSgnLScsICcgJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH0pfVxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBZGRpdGlvbmFsIEluZm8gKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdwdC0yIGJvcmRlci10IHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHNwYWNlLXktMSc+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFVwZGF0ZWQ6eycgJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZXBvcnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShyZXBvcnQudGltZXN0YW1wKS50b0xvY2FsZVRpbWVTdHJpbmcoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdOL0EnfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+Q29tcGxldGU6IHtpc0NvbXBsZXRlID8gJ1llcycgOiAnTm8nfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogQWN0aW9ucyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggZ2FwLTIgcHQtMic+XG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD0nb3V0bGluZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9J3NtJ1xuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnUGVyZm9ybWFuY2UgUmVwb3J0OicsIHJlcG9ydCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdDdXJyZW50IE1ldHJpY3M6JywgbWV0cmljcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdmbGV4LTEgdGV4dC14cydcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBMb2cgUmVwb3J0XG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD0nb3V0bGluZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9J3NtJ1xuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdmbGV4LTEgdGV4dC14cydcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBSZWZyZXNoXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cbiAgICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L0FuaW1hdGVQcmVzZW5jZT5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICl9XG4gICAgPC9BbmltYXRlUHJlc2VuY2U+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBQZXJmb3JtYW5jZURhc2hib2FyZDtcbiJdLCJmaWxlIjoiRDovUHJvamVjdHMvUG9ydGZvbGlvLVdlYi9zcmMvY29tcG9uZW50cy91aS9wZXJmb3JtYW5jZS1kYXNoYm9hcmQudHN4In0=