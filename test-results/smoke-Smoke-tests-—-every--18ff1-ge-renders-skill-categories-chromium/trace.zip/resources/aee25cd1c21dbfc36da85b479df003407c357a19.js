import {
  clsx,
  clsx_default
} from "/node_modules/.vite/deps/chunk-U7P2NEEE.js?v=e72f996b";
import "/node_modules/.vite/deps/chunk-DC5AMYBS.js?v=e72f996b";
export {
  clsx,
  clsx_default as default
};
//# sourceMappingURL=clsx.js.map
