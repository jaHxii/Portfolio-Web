import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_EMAILJS_PUBLIC_KEY": "0k9GNy3_VgCGbgb6p", "VITE_EMAILJS_SERVICE_ID": "service_69vleyd", "VITE_EMAILJS_TEMPLATE_ID": "template_yltgudd"};/**
 * Performance monitoring service with Core Web Vitals tracking
 */ function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];
import { onCLS, onFCP, onINP, onLCP, onTTFB } from "/node_modules/.vite/deps/web-vitals.js?v=e72f996b";
// Performance thresholds based on Core Web Vitals standards
export const PERFORMANCE_THRESHOLDS = {
    good: {
        fcp: 1800,
        lcp: 2500,
        fid: 100,
        cls: 0.1,
        ttfb: 800
    },
    needsImprovement: {
        fcp: 3000,
        lcp: 4000,
        fid: 300,
        cls: 0.25,
        ttfb: 1800
    }
};
class PerformanceMonitor {
    static getInstance() {
        if (!PerformanceMonitor.instance) {
            PerformanceMonitor.instance = new PerformanceMonitor();
        }
        return PerformanceMonitor.instance;
    }
    /**
   * Initialize performance monitoring
   */ init() {
        if (this.isInitialized || typeof window === 'undefined') {
            return;
        }
        this.isInitialized = true;
        // Track Core Web Vitals
        onCLS(this.handleMetric.bind(this));
        onFCP(this.handleMetric.bind(this));
        onINP(this.handleMetric.bind(this));
        onLCP(this.handleMetric.bind(this));
        onTTFB(this.handleMetric.bind(this));
        // Track additional performance metrics
        this.trackNavigationTiming();
        this.trackResourceTiming();
        this.trackLongTasks();
        console.log('Performance monitoring initialized');
    }
    /**
   * Handle Core Web Vitals metrics
   */ handleMetric(metric) {
        // Map INP (modern replacement for FID) to the 'fid' key for backward compatibility
        const rawName = metric.name.toLowerCase();
        const metricName = rawName === 'inp' ? 'fid' : rawName;
        this.metrics[metricName] = metric.value;
        console.log(`${metric.name}: ${metric.value}`, metric);
        // Check if metric exceeds budget
        this.checkPerformanceBudget(metricName, metric.value);
        // Notify listeners
        this.notifyListeners();
        // Send to analytics (in production)
        this.sendToAnalytics(metric);
    }
    /**
   * Check performance budget and warn if exceeded
   */ checkPerformanceBudget(metricName, value) {
        const thresholds = PERFORMANCE_THRESHOLDS;
        const rating = this.getRating(metricName, value);
        if (rating === 'poor') {
            console.warn(`Performance budget exceeded for ${metricName}: ${value}`, {
                metric: metricName,
                value,
                threshold: thresholds.needsImprovement[metricName],
                rating
            });
            // In production, you might want to send alerts
            this.sendPerformanceAlert(metricName, value, rating);
        }
    }
    /**
   * Get performance rating for a metric
   */ getRating(metricName, value) {
        const thresholds = PERFORMANCE_THRESHOLDS;
        if (value <= thresholds.good[metricName]) {
            return 'good';
        } else if (value <= thresholds.needsImprovement[metricName]) {
            return 'needs-improvement';
        } else {
            return 'poor';
        }
    }
    /**
   * Track Navigation Timing API metrics
   */ trackNavigationTiming() {
        if (!('performance' in window) || !performance.getEntriesByType) {
            return;
        }
        const navigation = performance.getEntriesByType('navigation')[0];
        if (!navigation) return;
        const metrics = {
            domContentLoaded: navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart,
            domComplete: navigation.domComplete - navigation.fetchStart,
            loadComplete: navigation.loadEventEnd - navigation.fetchStart,
            redirectTime: navigation.redirectEnd - navigation.redirectStart,
            dnsTime: navigation.domainLookupEnd - navigation.domainLookupStart,
            connectTime: navigation.connectEnd - navigation.connectStart,
            requestTime: navigation.responseStart - navigation.requestStart,
            responseTime: navigation.responseEnd - navigation.responseStart
        };
        console.log('Navigation Timing:', metrics);
    }
    /**
   * Track Resource Timing API metrics
   */ trackResourceTiming() {
        if (!('performance' in window) || !performance.getEntriesByType) {
            return;
        }
        const resources = performance.getEntriesByType('resource');
        const slowResources = resources.filter((resource)=>resource.duration > 1000);
        if (slowResources.length > 0) {
            console.warn('Slow loading resources detected:', slowResources);
        }
        // Track largest resources
        const largestResources = resources.sort((a, b)=>b.transferSize - a.transferSize).slice(0, 5);
        console.log('Largest resources:', largestResources);
    }
    /**
   * Track Long Tasks API
   */ trackLongTasks() {
        if (!('PerformanceObserver' in window)) {
            return;
        }
        try {
            const observer = new PerformanceObserver((list)=>{
                const longTasks = list.getEntries();
                if (longTasks.length > 0) {
                    console.warn('Long tasks detected:', longTasks);
                    // Send long task data to analytics
                    longTasks.forEach((task)=>{
                        // Create a simple analytics event for long tasks
                        if (import.meta.env.DEV) {
                            console.log('Long Task Analytics (dev):', {
                                name: 'longtask',
                                value: task.duration,
                                timestamp: Date.now(),
                                url: window.location.href
                            });
                        }
                    });
                }
            });
            observer.observe({
                entryTypes: [
                    'longtask'
                ]
            });
        } catch (error) {
            console.warn('Long Tasks API not supported:', error);
        }
    }
    /**
   * Send metric to analytics service
   */ sendToAnalytics(metric) {
        // In production, send to your analytics service
        // Example: Google Analytics, DataDog, New Relic, etc.
        if (import.meta.env.DEV) {
            console.log('Analytics (dev):', {
                name: metric.name,
                value: metric.value,
                rating: this.getRating(metric.name.toLowerCase(), metric.value),
                timestamp: Date.now(),
                url: window.location.href
            });
        }
        // Example implementation for Google Analytics
        if (typeof window !== 'undefined' && 'gtag' in window) {
            const gtag = window.gtag;
            gtag('event', metric.name, {
                event_category: 'Web Vitals',
                value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
                custom_parameter_1: metric.id,
                non_interaction: true
            });
        }
    }
    /**
   * Send performance alert
   */ sendPerformanceAlert(metricName, value, rating) {
        // In production, send to monitoring service (e.g., Sentry, DataDog)
        console.error('Performance Alert:', {
            metric: metricName,
            value,
            rating,
            timestamp: Date.now(),
            url: window.location.href,
            userAgent: navigator.userAgent
        });
    }
    /**
   * Add performance listener
   */ addListener(callback) {
        this.listeners.push(callback);
    }
    /**
   * Remove performance listener
   */ removeListener(callback) {
        const index = this.listeners.indexOf(callback);
        if (index > -1) {
            this.listeners.splice(index, 1);
        }
    }
    /**
   * Notify all listeners
   */ notifyListeners() {
        const report = this.generateReport();
        this.listeners.forEach((callback)=>callback(report));
    }
    /**
   * Generate performance report
   */ generateReport() {
        const ratings = {
            fcp: this.metrics.fcp ? this.getRating('fcp', this.metrics.fcp) : 'good',
            lcp: this.metrics.lcp ? this.getRating('lcp', this.metrics.lcp) : 'good',
            fid: this.metrics.fid ? this.getRating('fid', this.metrics.fid) : 'good',
            cls: this.metrics.cls ? this.getRating('cls', this.metrics.cls) : 'good',
            ttfb: this.metrics.ttfb ? this.getRating('ttfb', this.metrics.ttfb) : 'good'
        };
        return {
            metrics: {
                ...this.metrics
            },
            ratings,
            timestamp: Date.now(),
            url: typeof window !== 'undefined' ? window.location.href : '',
            userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : ''
        };
    }
    /**
   * Get current metrics
   */ getMetrics() {
        return {
            ...this.metrics
        };
    }
    /**
   * Check if all metrics are collected
   */ isComplete() {
        return Object.values(this.metrics).every((value)=>value !== null);
    }
    /**
   * Reset metrics
   */ reset() {
        this.metrics = {
            fcp: null,
            lcp: null,
            fid: null,
            cls: null,
            ttfb: null
        };
        this.isInitialized = false;
    }
    constructor(){
        _define_property(this, "metrics", {
            fcp: null,
            lcp: null,
            fid: null,
            cls: null,
            ttfb: null
        });
        _define_property(this, "listeners", []);
        _define_property(this, "isInitialized", false);
    }
}
_define_property(PerformanceMonitor, "instance", void 0);
// Export singleton instance
export const performanceMonitor = PerformanceMonitor.getInstance();
// React hook for performance monitoring
export function usePerformanceMonitor() {
    const [report, setReport] = useState(null);
    useEffect(()=>{
        const handleReport = (newReport)=>{
            setReport(newReport);
        };
        performanceMonitor.addListener(handleReport);
        performanceMonitor.init();
        return ()=>{
            performanceMonitor.removeListener(handleReport);
        };
    }, []);
    return {
        report,
        metrics: performanceMonitor.getMetrics(),
        isComplete: performanceMonitor.isComplete(),
        generateReport: ()=>performanceMonitor.generateReport()
    };
}
// Initialize performance monitoring
export function initPerformanceMonitoring() {
    if (typeof window !== 'undefined') {
        performanceMonitor.init();
    }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBlcmZvcm1hbmNlLW1vbml0b3IudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBQZXJmb3JtYW5jZSBtb25pdG9yaW5nIHNlcnZpY2Ugd2l0aCBDb3JlIFdlYiBWaXRhbHMgdHJhY2tpbmdcbiAqL1xuXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgb25DTFMsIG9uRkNQLCBvbklOUCwgb25MQ1AsIG9uVFRGQiwgTWV0cmljIH0gZnJvbSAnd2ViLXZpdGFscyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUGVyZm9ybWFuY2VNZXRyaWNzIHtcbiAgZmNwOiBudW1iZXIgfCBudWxsOyAvLyBGaXJzdCBDb250ZW50ZnVsIFBhaW50XG4gIGxjcDogbnVtYmVyIHwgbnVsbDsgLy8gTGFyZ2VzdCBDb250ZW50ZnVsIFBhaW50XG4gIGZpZDogbnVtYmVyIHwgbnVsbDsgLy8gRmlyc3QgSW5wdXQgRGVsYXlcbiAgY2xzOiBudW1iZXIgfCBudWxsOyAvLyBDdW11bGF0aXZlIExheW91dCBTaGlmdFxuICB0dGZiOiBudW1iZXIgfCBudWxsOyAvLyBUaW1lIHRvIEZpcnN0IEJ5dGVcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQZXJmb3JtYW5jZUJ1ZGdldCB7XG4gIGZjcDogbnVtYmVyO1xuICBsY3A6IG51bWJlcjtcbiAgZmlkOiBudW1iZXI7XG4gIGNsczogbnVtYmVyO1xuICB0dGZiOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUGVyZm9ybWFuY2VUaHJlc2hvbGRzIHtcbiAgZ29vZDogUGVyZm9ybWFuY2VCdWRnZXQ7XG4gIG5lZWRzSW1wcm92ZW1lbnQ6IFBlcmZvcm1hbmNlQnVkZ2V0O1xufVxuXG4vLyBQZXJmb3JtYW5jZSB0aHJlc2hvbGRzIGJhc2VkIG9uIENvcmUgV2ViIFZpdGFscyBzdGFuZGFyZHNcbmV4cG9ydCBjb25zdCBQRVJGT1JNQU5DRV9USFJFU0hPTERTOiBQZXJmb3JtYW5jZVRocmVzaG9sZHMgPSB7XG4gIGdvb2Q6IHtcbiAgICBmY3A6IDE4MDAsIC8vIDEuOHNcbiAgICBsY3A6IDI1MDAsIC8vIDIuNXNcbiAgICBmaWQ6IDEwMCwgLy8gMTAwbXNcbiAgICBjbHM6IDAuMSwgLy8gMC4xXG4gICAgdHRmYjogODAwLCAvLyA4MDBtc1xuICB9LFxuICBuZWVkc0ltcHJvdmVtZW50OiB7XG4gICAgZmNwOiAzMDAwLCAvLyAzc1xuICAgIGxjcDogNDAwMCwgLy8gNHNcbiAgICBmaWQ6IDMwMCwgLy8gMzAwbXNcbiAgICBjbHM6IDAuMjUsIC8vIDAuMjVcbiAgICB0dGZiOiAxODAwLCAvLyAxLjhzXG4gIH0sXG59O1xuXG5leHBvcnQgdHlwZSBQZXJmb3JtYW5jZVJhdGluZyA9ICdnb29kJyB8ICduZWVkcy1pbXByb3ZlbWVudCcgfCAncG9vcic7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUGVyZm9ybWFuY2VSZXBvcnQge1xuICBtZXRyaWNzOiBQZXJmb3JtYW5jZU1ldHJpY3M7XG4gIHJhdGluZ3M6IFJlY29yZDxrZXlvZiBQZXJmb3JtYW5jZU1ldHJpY3MsIFBlcmZvcm1hbmNlUmF0aW5nPjtcbiAgdGltZXN0YW1wOiBudW1iZXI7XG4gIHVybDogc3RyaW5nO1xuICB1c2VyQWdlbnQ6IHN0cmluZztcbn1cblxuY2xhc3MgUGVyZm9ybWFuY2VNb25pdG9yIHtcbiAgcHJpdmF0ZSBzdGF0aWMgaW5zdGFuY2U6IFBlcmZvcm1hbmNlTW9uaXRvcjtcbiAgcHJpdmF0ZSBtZXRyaWNzOiBQZXJmb3JtYW5jZU1ldHJpY3MgPSB7XG4gICAgZmNwOiBudWxsLFxuICAgIGxjcDogbnVsbCxcbiAgICBmaWQ6IG51bGwsXG4gICAgY2xzOiBudWxsLFxuICAgIHR0ZmI6IG51bGwsXG4gIH07XG4gIHByaXZhdGUgbGlzdGVuZXJzOiAoKHJlcG9ydDogUGVyZm9ybWFuY2VSZXBvcnQpID0+IHZvaWQpW10gPSBbXTtcbiAgcHJpdmF0ZSBpc0luaXRpYWxpemVkID0gZmFsc2U7XG5cbiAgc3RhdGljIGdldEluc3RhbmNlKCk6IFBlcmZvcm1hbmNlTW9uaXRvciB7XG4gICAgaWYgKCFQZXJmb3JtYW5jZU1vbml0b3IuaW5zdGFuY2UpIHtcbiAgICAgIFBlcmZvcm1hbmNlTW9uaXRvci5pbnN0YW5jZSA9IG5ldyBQZXJmb3JtYW5jZU1vbml0b3IoKTtcbiAgICB9XG4gICAgcmV0dXJuIFBlcmZvcm1hbmNlTW9uaXRvci5pbnN0YW5jZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplIHBlcmZvcm1hbmNlIG1vbml0b3JpbmdcbiAgICovXG4gIGluaXQoKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuaXNJbml0aWFsaXplZCB8fCB0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMuaXNJbml0aWFsaXplZCA9IHRydWU7XG5cbiAgICAvLyBUcmFjayBDb3JlIFdlYiBWaXRhbHNcbiAgICBvbkNMUyh0aGlzLmhhbmRsZU1ldHJpYy5iaW5kKHRoaXMpKTtcbiAgICBvbkZDUCh0aGlzLmhhbmRsZU1ldHJpYy5iaW5kKHRoaXMpKTtcbiAgICBvbklOUCh0aGlzLmhhbmRsZU1ldHJpYy5iaW5kKHRoaXMpKTtcbiAgICBvbkxDUCh0aGlzLmhhbmRsZU1ldHJpYy5iaW5kKHRoaXMpKTtcbiAgICBvblRURkIodGhpcy5oYW5kbGVNZXRyaWMuYmluZCh0aGlzKSk7XG5cbiAgICAvLyBUcmFjayBhZGRpdGlvbmFsIHBlcmZvcm1hbmNlIG1ldHJpY3NcbiAgICB0aGlzLnRyYWNrTmF2aWdhdGlvblRpbWluZygpO1xuICAgIHRoaXMudHJhY2tSZXNvdXJjZVRpbWluZygpO1xuICAgIHRoaXMudHJhY2tMb25nVGFza3MoKTtcblxuICAgIGNvbnNvbGUubG9nKCdQZXJmb3JtYW5jZSBtb25pdG9yaW5nIGluaXRpYWxpemVkJyk7XG4gIH1cblxuICAvKipcbiAgICogSGFuZGxlIENvcmUgV2ViIFZpdGFscyBtZXRyaWNzXG4gICAqL1xuICBwcml2YXRlIGhhbmRsZU1ldHJpYyhtZXRyaWM6IE1ldHJpYyk6IHZvaWQge1xuICAgIC8vIE1hcCBJTlAgKG1vZGVybiByZXBsYWNlbWVudCBmb3IgRklEKSB0byB0aGUgJ2ZpZCcga2V5IGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XG4gICAgY29uc3QgcmF3TmFtZSA9IG1ldHJpYy5uYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgbWV0cmljTmFtZSA9IChcbiAgICAgIHJhd05hbWUgPT09ICdpbnAnID8gJ2ZpZCcgOiByYXdOYW1lXG4gICAgKSBhcyBrZXlvZiBQZXJmb3JtYW5jZU1ldHJpY3M7XG4gICAgdGhpcy5tZXRyaWNzW21ldHJpY05hbWVdID0gbWV0cmljLnZhbHVlO1xuXG4gICAgY29uc29sZS5sb2coYCR7bWV0cmljLm5hbWV9OiAke21ldHJpYy52YWx1ZX1gLCBtZXRyaWMpO1xuXG4gICAgLy8gQ2hlY2sgaWYgbWV0cmljIGV4Y2VlZHMgYnVkZ2V0XG4gICAgdGhpcy5jaGVja1BlcmZvcm1hbmNlQnVkZ2V0KG1ldHJpY05hbWUsIG1ldHJpYy52YWx1ZSk7XG5cbiAgICAvLyBOb3RpZnkgbGlzdGVuZXJzXG4gICAgdGhpcy5ub3RpZnlMaXN0ZW5lcnMoKTtcblxuICAgIC8vIFNlbmQgdG8gYW5hbHl0aWNzIChpbiBwcm9kdWN0aW9uKVxuICAgIHRoaXMuc2VuZFRvQW5hbHl0aWNzKG1ldHJpYyk7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgcGVyZm9ybWFuY2UgYnVkZ2V0IGFuZCB3YXJuIGlmIGV4Y2VlZGVkXG4gICAqL1xuICBwcml2YXRlIGNoZWNrUGVyZm9ybWFuY2VCdWRnZXQoXG4gICAgbWV0cmljTmFtZToga2V5b2YgUGVyZm9ybWFuY2VNZXRyaWNzLFxuICAgIHZhbHVlOiBudW1iZXJcbiAgKTogdm9pZCB7XG4gICAgY29uc3QgdGhyZXNob2xkcyA9IFBFUkZPUk1BTkNFX1RIUkVTSE9MRFM7XG4gICAgY29uc3QgcmF0aW5nID0gdGhpcy5nZXRSYXRpbmcobWV0cmljTmFtZSwgdmFsdWUpO1xuXG4gICAgaWYgKHJhdGluZyA9PT0gJ3Bvb3InKSB7XG4gICAgICBjb25zb2xlLndhcm4oYFBlcmZvcm1hbmNlIGJ1ZGdldCBleGNlZWRlZCBmb3IgJHttZXRyaWNOYW1lfTogJHt2YWx1ZX1gLCB7XG4gICAgICAgIG1ldHJpYzogbWV0cmljTmFtZSxcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIHRocmVzaG9sZDogdGhyZXNob2xkcy5uZWVkc0ltcHJvdmVtZW50W21ldHJpY05hbWVdLFxuICAgICAgICByYXRpbmcsXG4gICAgICB9KTtcblxuICAgICAgLy8gSW4gcHJvZHVjdGlvbiwgeW91IG1pZ2h0IHdhbnQgdG8gc2VuZCBhbGVydHNcbiAgICAgIHRoaXMuc2VuZFBlcmZvcm1hbmNlQWxlcnQobWV0cmljTmFtZSwgdmFsdWUsIHJhdGluZyk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldCBwZXJmb3JtYW5jZSByYXRpbmcgZm9yIGEgbWV0cmljXG4gICAqL1xuICBwcml2YXRlIGdldFJhdGluZyhcbiAgICBtZXRyaWNOYW1lOiBrZXlvZiBQZXJmb3JtYW5jZU1ldHJpY3MsXG4gICAgdmFsdWU6IG51bWJlclxuICApOiBQZXJmb3JtYW5jZVJhdGluZyB7XG4gICAgY29uc3QgdGhyZXNob2xkcyA9IFBFUkZPUk1BTkNFX1RIUkVTSE9MRFM7XG5cbiAgICBpZiAodmFsdWUgPD0gdGhyZXNob2xkcy5nb29kW21ldHJpY05hbWVdKSB7XG4gICAgICByZXR1cm4gJ2dvb2QnO1xuICAgIH0gZWxzZSBpZiAodmFsdWUgPD0gdGhyZXNob2xkcy5uZWVkc0ltcHJvdmVtZW50W21ldHJpY05hbWVdKSB7XG4gICAgICByZXR1cm4gJ25lZWRzLWltcHJvdmVtZW50JztcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuICdwb29yJztcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVHJhY2sgTmF2aWdhdGlvbiBUaW1pbmcgQVBJIG1ldHJpY3NcbiAgICovXG4gIHByaXZhdGUgdHJhY2tOYXZpZ2F0aW9uVGltaW5nKCk6IHZvaWQge1xuICAgIGlmICghKCdwZXJmb3JtYW5jZScgaW4gd2luZG93KSB8fCAhcGVyZm9ybWFuY2UuZ2V0RW50cmllc0J5VHlwZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IG5hdmlnYXRpb24gPSBwZXJmb3JtYW5jZS5nZXRFbnRyaWVzQnlUeXBlKFxuICAgICAgJ25hdmlnYXRpb24nXG4gICAgKVswXSBhcyBQZXJmb3JtYW5jZU5hdmlnYXRpb25UaW1pbmc7XG4gICAgaWYgKCFuYXZpZ2F0aW9uKSByZXR1cm47XG5cbiAgICBjb25zdCBtZXRyaWNzID0ge1xuICAgICAgZG9tQ29udGVudExvYWRlZDpcbiAgICAgICAgbmF2aWdhdGlvbi5kb21Db250ZW50TG9hZGVkRXZlbnRFbmQgLVxuICAgICAgICBuYXZpZ2F0aW9uLmRvbUNvbnRlbnRMb2FkZWRFdmVudFN0YXJ0LFxuICAgICAgZG9tQ29tcGxldGU6IG5hdmlnYXRpb24uZG9tQ29tcGxldGUgLSBuYXZpZ2F0aW9uLmZldGNoU3RhcnQsXG4gICAgICBsb2FkQ29tcGxldGU6IG5hdmlnYXRpb24ubG9hZEV2ZW50RW5kIC0gbmF2aWdhdGlvbi5mZXRjaFN0YXJ0LFxuICAgICAgcmVkaXJlY3RUaW1lOiBuYXZpZ2F0aW9uLnJlZGlyZWN0RW5kIC0gbmF2aWdhdGlvbi5yZWRpcmVjdFN0YXJ0LFxuICAgICAgZG5zVGltZTogbmF2aWdhdGlvbi5kb21haW5Mb29rdXBFbmQgLSBuYXZpZ2F0aW9uLmRvbWFpbkxvb2t1cFN0YXJ0LFxuICAgICAgY29ubmVjdFRpbWU6IG5hdmlnYXRpb24uY29ubmVjdEVuZCAtIG5hdmlnYXRpb24uY29ubmVjdFN0YXJ0LFxuICAgICAgcmVxdWVzdFRpbWU6IG5hdmlnYXRpb24ucmVzcG9uc2VTdGFydCAtIG5hdmlnYXRpb24ucmVxdWVzdFN0YXJ0LFxuICAgICAgcmVzcG9uc2VUaW1lOiBuYXZpZ2F0aW9uLnJlc3BvbnNlRW5kIC0gbmF2aWdhdGlvbi5yZXNwb25zZVN0YXJ0LFxuICAgIH07XG5cbiAgICBjb25zb2xlLmxvZygnTmF2aWdhdGlvbiBUaW1pbmc6JywgbWV0cmljcyk7XG4gIH1cblxuICAvKipcbiAgICogVHJhY2sgUmVzb3VyY2UgVGltaW5nIEFQSSBtZXRyaWNzXG4gICAqL1xuICBwcml2YXRlIHRyYWNrUmVzb3VyY2VUaW1pbmcoKTogdm9pZCB7XG4gICAgaWYgKCEoJ3BlcmZvcm1hbmNlJyBpbiB3aW5kb3cpIHx8ICFwZXJmb3JtYW5jZS5nZXRFbnRyaWVzQnlUeXBlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcmVzb3VyY2VzID0gcGVyZm9ybWFuY2UuZ2V0RW50cmllc0J5VHlwZShcbiAgICAgICdyZXNvdXJjZSdcbiAgICApIGFzIFBlcmZvcm1hbmNlUmVzb3VyY2VUaW1pbmdbXTtcbiAgICBjb25zdCBzbG93UmVzb3VyY2VzID0gcmVzb3VyY2VzLmZpbHRlcihcbiAgICAgIHJlc291cmNlID0+IHJlc291cmNlLmR1cmF0aW9uID4gMTAwMFxuICAgICk7XG5cbiAgICBpZiAoc2xvd1Jlc291cmNlcy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ1Nsb3cgbG9hZGluZyByZXNvdXJjZXMgZGV0ZWN0ZWQ6Jywgc2xvd1Jlc291cmNlcyk7XG4gICAgfVxuXG4gICAgLy8gVHJhY2sgbGFyZ2VzdCByZXNvdXJjZXNcbiAgICBjb25zdCBsYXJnZXN0UmVzb3VyY2VzID0gcmVzb3VyY2VzXG4gICAgICAuc29ydCgoYSwgYikgPT4gYi50cmFuc2ZlclNpemUgLSBhLnRyYW5zZmVyU2l6ZSlcbiAgICAgIC5zbGljZSgwLCA1KTtcblxuICAgIGNvbnNvbGUubG9nKCdMYXJnZXN0IHJlc291cmNlczonLCBsYXJnZXN0UmVzb3VyY2VzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUcmFjayBMb25nIFRhc2tzIEFQSVxuICAgKi9cbiAgcHJpdmF0ZSB0cmFja0xvbmdUYXNrcygpOiB2b2lkIHtcbiAgICBpZiAoISgnUGVyZm9ybWFuY2VPYnNlcnZlcicgaW4gd2luZG93KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBQZXJmb3JtYW5jZU9ic2VydmVyKGxpc3QgPT4ge1xuICAgICAgICBjb25zdCBsb25nVGFza3MgPSBsaXN0LmdldEVudHJpZXMoKTtcbiAgICAgICAgaWYgKGxvbmdUYXNrcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKCdMb25nIHRhc2tzIGRldGVjdGVkOicsIGxvbmdUYXNrcyk7XG5cbiAgICAgICAgICAvLyBTZW5kIGxvbmcgdGFzayBkYXRhIHRvIGFuYWx5dGljc1xuICAgICAgICAgIGxvbmdUYXNrcy5mb3JFYWNoKHRhc2sgPT4ge1xuICAgICAgICAgICAgLy8gQ3JlYXRlIGEgc2ltcGxlIGFuYWx5dGljcyBldmVudCBmb3IgbG9uZyB0YXNrc1xuICAgICAgICAgICAgaWYgKGltcG9ydC5tZXRhLmVudi5ERVYpIHtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0xvbmcgVGFzayBBbmFseXRpY3MgKGRldik6Jywge1xuICAgICAgICAgICAgICAgIG5hbWU6ICdsb25ndGFzaycsXG4gICAgICAgICAgICAgICAgdmFsdWU6IHRhc2suZHVyYXRpb24sXG4gICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICAgIHVybDogd2luZG93LmxvY2F0aW9uLmhyZWYsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZSh7IGVudHJ5VHlwZXM6IFsnbG9uZ3Rhc2snXSB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS53YXJuKCdMb25nIFRhc2tzIEFQSSBub3Qgc3VwcG9ydGVkOicsIGVycm9yKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBtZXRyaWMgdG8gYW5hbHl0aWNzIHNlcnZpY2VcbiAgICovXG4gIHByaXZhdGUgc2VuZFRvQW5hbHl0aWNzKG1ldHJpYzogTWV0cmljKTogdm9pZCB7XG4gICAgLy8gSW4gcHJvZHVjdGlvbiwgc2VuZCB0byB5b3VyIGFuYWx5dGljcyBzZXJ2aWNlXG4gICAgLy8gRXhhbXBsZTogR29vZ2xlIEFuYWx5dGljcywgRGF0YURvZywgTmV3IFJlbGljLCBldGMuXG5cbiAgICBpZiAoaW1wb3J0Lm1ldGEuZW52LkRFVikge1xuICAgICAgY29uc29sZS5sb2coJ0FuYWx5dGljcyAoZGV2KTonLCB7XG4gICAgICAgIG5hbWU6IG1ldHJpYy5uYW1lLFxuICAgICAgICB2YWx1ZTogbWV0cmljLnZhbHVlLFxuICAgICAgICByYXRpbmc6IHRoaXMuZ2V0UmF0aW5nKFxuICAgICAgICAgIG1ldHJpYy5uYW1lLnRvTG93ZXJDYXNlKCkgYXMga2V5b2YgUGVyZm9ybWFuY2VNZXRyaWNzLFxuICAgICAgICAgIG1ldHJpYy52YWx1ZVxuICAgICAgICApLFxuICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgIHVybDogd2luZG93LmxvY2F0aW9uLmhyZWYsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBFeGFtcGxlIGltcGxlbWVudGF0aW9uIGZvciBHb29nbGUgQW5hbHl0aWNzXG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmICdndGFnJyBpbiB3aW5kb3cpIHtcbiAgICAgIGNvbnN0IGd0YWcgPSAod2luZG93IGFzIGFueSkuZ3RhZztcbiAgICAgIGd0YWcoJ2V2ZW50JywgbWV0cmljLm5hbWUsIHtcbiAgICAgICAgZXZlbnRfY2F0ZWdvcnk6ICdXZWIgVml0YWxzJyxcbiAgICAgICAgdmFsdWU6IE1hdGgucm91bmQoXG4gICAgICAgICAgbWV0cmljLm5hbWUgPT09ICdDTFMnID8gbWV0cmljLnZhbHVlICogMTAwMCA6IG1ldHJpYy52YWx1ZVxuICAgICAgICApLFxuICAgICAgICBjdXN0b21fcGFyYW1ldGVyXzE6IG1ldHJpYy5pZCxcbiAgICAgICAgbm9uX2ludGVyYWN0aW9uOiB0cnVlLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFNlbmQgcGVyZm9ybWFuY2UgYWxlcnRcbiAgICovXG4gIHByaXZhdGUgc2VuZFBlcmZvcm1hbmNlQWxlcnQoXG4gICAgbWV0cmljTmFtZTogc3RyaW5nLFxuICAgIHZhbHVlOiBudW1iZXIsXG4gICAgcmF0aW5nOiBQZXJmb3JtYW5jZVJhdGluZ1xuICApOiB2b2lkIHtcbiAgICAvLyBJbiBwcm9kdWN0aW9uLCBzZW5kIHRvIG1vbml0b3Jpbmcgc2VydmljZSAoZS5nLiwgU2VudHJ5LCBEYXRhRG9nKVxuICAgIGNvbnNvbGUuZXJyb3IoJ1BlcmZvcm1hbmNlIEFsZXJ0OicsIHtcbiAgICAgIG1ldHJpYzogbWV0cmljTmFtZSxcbiAgICAgIHZhbHVlLFxuICAgICAgcmF0aW5nLFxuICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgdXJsOiB3aW5kb3cubG9jYXRpb24uaHJlZixcbiAgICAgIHVzZXJBZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgcGVyZm9ybWFuY2UgbGlzdGVuZXJcbiAgICovXG4gIGFkZExpc3RlbmVyKGNhbGxiYWNrOiAocmVwb3J0OiBQZXJmb3JtYW5jZVJlcG9ydCkgPT4gdm9pZCk6IHZvaWQge1xuICAgIHRoaXMubGlzdGVuZXJzLnB1c2goY2FsbGJhY2spO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZSBwZXJmb3JtYW5jZSBsaXN0ZW5lclxuICAgKi9cbiAgcmVtb3ZlTGlzdGVuZXIoY2FsbGJhY2s6IChyZXBvcnQ6IFBlcmZvcm1hbmNlUmVwb3J0KSA9PiB2b2lkKTogdm9pZCB7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLmxpc3RlbmVycy5pbmRleE9mKGNhbGxiYWNrKTtcbiAgICBpZiAoaW5kZXggPiAtMSkge1xuICAgICAgdGhpcy5saXN0ZW5lcnMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogTm90aWZ5IGFsbCBsaXN0ZW5lcnNcbiAgICovXG4gIHByaXZhdGUgbm90aWZ5TGlzdGVuZXJzKCk6IHZvaWQge1xuICAgIGNvbnN0IHJlcG9ydCA9IHRoaXMuZ2VuZXJhdGVSZXBvcnQoKTtcbiAgICB0aGlzLmxpc3RlbmVycy5mb3JFYWNoKGNhbGxiYWNrID0+IGNhbGxiYWNrKHJlcG9ydCkpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlIHBlcmZvcm1hbmNlIHJlcG9ydFxuICAgKi9cbiAgZ2VuZXJhdGVSZXBvcnQoKTogUGVyZm9ybWFuY2VSZXBvcnQge1xuICAgIGNvbnN0IHJhdGluZ3M6IFJlY29yZDxrZXlvZiBQZXJmb3JtYW5jZU1ldHJpY3MsIFBlcmZvcm1hbmNlUmF0aW5nPiA9IHtcbiAgICAgIGZjcDogdGhpcy5tZXRyaWNzLmZjcCA/IHRoaXMuZ2V0UmF0aW5nKCdmY3AnLCB0aGlzLm1ldHJpY3MuZmNwKSA6ICdnb29kJyxcbiAgICAgIGxjcDogdGhpcy5tZXRyaWNzLmxjcCA/IHRoaXMuZ2V0UmF0aW5nKCdsY3AnLCB0aGlzLm1ldHJpY3MubGNwKSA6ICdnb29kJyxcbiAgICAgIGZpZDogdGhpcy5tZXRyaWNzLmZpZCA/IHRoaXMuZ2V0UmF0aW5nKCdmaWQnLCB0aGlzLm1ldHJpY3MuZmlkKSA6ICdnb29kJyxcbiAgICAgIGNsczogdGhpcy5tZXRyaWNzLmNscyA/IHRoaXMuZ2V0UmF0aW5nKCdjbHMnLCB0aGlzLm1ldHJpY3MuY2xzKSA6ICdnb29kJyxcbiAgICAgIHR0ZmI6IHRoaXMubWV0cmljcy50dGZiXG4gICAgICAgID8gdGhpcy5nZXRSYXRpbmcoJ3R0ZmInLCB0aGlzLm1ldHJpY3MudHRmYilcbiAgICAgICAgOiAnZ29vZCcsXG4gICAgfTtcblxuICAgIHJldHVybiB7XG4gICAgICBtZXRyaWNzOiB7IC4uLnRoaXMubWV0cmljcyB9LFxuICAgICAgcmF0aW5ncyxcbiAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSxcbiAgICAgIHVybDogdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cubG9jYXRpb24uaHJlZiA6ICcnLFxuICAgICAgdXNlckFnZW50OiB0eXBlb2YgbmF2aWdhdG9yICE9PSAndW5kZWZpbmVkJyA/IG5hdmlnYXRvci51c2VyQWdlbnQgOiAnJyxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBjdXJyZW50IG1ldHJpY3NcbiAgICovXG4gIGdldE1ldHJpY3MoKTogUGVyZm9ybWFuY2VNZXRyaWNzIHtcbiAgICByZXR1cm4geyAuLi50aGlzLm1ldHJpY3MgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVjayBpZiBhbGwgbWV0cmljcyBhcmUgY29sbGVjdGVkXG4gICAqL1xuICBpc0NvbXBsZXRlKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiBPYmplY3QudmFsdWVzKHRoaXMubWV0cmljcykuZXZlcnkodmFsdWUgPT4gdmFsdWUgIT09IG51bGwpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlc2V0IG1ldHJpY3NcbiAgICovXG4gIHJlc2V0KCk6IHZvaWQge1xuICAgIHRoaXMubWV0cmljcyA9IHtcbiAgICAgIGZjcDogbnVsbCxcbiAgICAgIGxjcDogbnVsbCxcbiAgICAgIGZpZDogbnVsbCxcbiAgICAgIGNsczogbnVsbCxcbiAgICAgIHR0ZmI6IG51bGwsXG4gICAgfTtcbiAgICB0aGlzLmlzSW5pdGlhbGl6ZWQgPSBmYWxzZTtcbiAgfVxufVxuXG4vLyBFeHBvcnQgc2luZ2xldG9uIGluc3RhbmNlXG5leHBvcnQgY29uc3QgcGVyZm9ybWFuY2VNb25pdG9yID0gUGVyZm9ybWFuY2VNb25pdG9yLmdldEluc3RhbmNlKCk7XG5cbi8vIFJlYWN0IGhvb2sgZm9yIHBlcmZvcm1hbmNlIG1vbml0b3JpbmdcbmV4cG9ydCBmdW5jdGlvbiB1c2VQZXJmb3JtYW5jZU1vbml0b3IoKSB7XG4gIGNvbnN0IFtyZXBvcnQsIHNldFJlcG9ydF0gPSB1c2VTdGF0ZTxQZXJmb3JtYW5jZVJlcG9ydCB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlUmVwb3J0ID0gKG5ld1JlcG9ydDogUGVyZm9ybWFuY2VSZXBvcnQpID0+IHtcbiAgICAgIHNldFJlcG9ydChuZXdSZXBvcnQpO1xuICAgIH07XG5cbiAgICBwZXJmb3JtYW5jZU1vbml0b3IuYWRkTGlzdGVuZXIoaGFuZGxlUmVwb3J0KTtcbiAgICBwZXJmb3JtYW5jZU1vbml0b3IuaW5pdCgpO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHBlcmZvcm1hbmNlTW9uaXRvci5yZW1vdmVMaXN0ZW5lcihoYW5kbGVSZXBvcnQpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICByZXR1cm4ge1xuICAgIHJlcG9ydCxcbiAgICBtZXRyaWNzOiBwZXJmb3JtYW5jZU1vbml0b3IuZ2V0TWV0cmljcygpLFxuICAgIGlzQ29tcGxldGU6IHBlcmZvcm1hbmNlTW9uaXRvci5pc0NvbXBsZXRlKCksXG4gICAgZ2VuZXJhdGVSZXBvcnQ6ICgpID0+IHBlcmZvcm1hbmNlTW9uaXRvci5nZW5lcmF0ZVJlcG9ydCgpLFxuICB9O1xufVxuXG4vLyBJbml0aWFsaXplIHBlcmZvcm1hbmNlIG1vbml0b3JpbmdcbmV4cG9ydCBmdW5jdGlvbiBpbml0UGVyZm9ybWFuY2VNb25pdG9yaW5nKCk6IHZvaWQge1xuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICBwZXJmb3JtYW5jZU1vbml0b3IuaW5pdCgpO1xuICB9XG59XG4iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJvbkNMUyIsIm9uRkNQIiwib25JTlAiLCJvbkxDUCIsIm9uVFRGQiIsIlBFUkZPUk1BTkNFX1RIUkVTSE9MRFMiLCJnb29kIiwiZmNwIiwibGNwIiwiZmlkIiwiY2xzIiwidHRmYiIsIm5lZWRzSW1wcm92ZW1lbnQiLCJQZXJmb3JtYW5jZU1vbml0b3IiLCJnZXRJbnN0YW5jZSIsImluc3RhbmNlIiwiaW5pdCIsImlzSW5pdGlhbGl6ZWQiLCJ3aW5kb3ciLCJoYW5kbGVNZXRyaWMiLCJiaW5kIiwidHJhY2tOYXZpZ2F0aW9uVGltaW5nIiwidHJhY2tSZXNvdXJjZVRpbWluZyIsInRyYWNrTG9uZ1Rhc2tzIiwiY29uc29sZSIsImxvZyIsIm1ldHJpYyIsInJhd05hbWUiLCJuYW1lIiwidG9Mb3dlckNhc2UiLCJtZXRyaWNOYW1lIiwibWV0cmljcyIsInZhbHVlIiwiY2hlY2tQZXJmb3JtYW5jZUJ1ZGdldCIsIm5vdGlmeUxpc3RlbmVycyIsInNlbmRUb0FuYWx5dGljcyIsInRocmVzaG9sZHMiLCJyYXRpbmciLCJnZXRSYXRpbmciLCJ3YXJuIiwidGhyZXNob2xkIiwic2VuZFBlcmZvcm1hbmNlQWxlcnQiLCJwZXJmb3JtYW5jZSIsImdldEVudHJpZXNCeVR5cGUiLCJuYXZpZ2F0aW9uIiwiZG9tQ29udGVudExvYWRlZCIsImRvbUNvbnRlbnRMb2FkZWRFdmVudEVuZCIsImRvbUNvbnRlbnRMb2FkZWRFdmVudFN0YXJ0IiwiZG9tQ29tcGxldGUiLCJmZXRjaFN0YXJ0IiwibG9hZENvbXBsZXRlIiwibG9hZEV2ZW50RW5kIiwicmVkaXJlY3RUaW1lIiwicmVkaXJlY3RFbmQiLCJyZWRpcmVjdFN0YXJ0IiwiZG5zVGltZSIsImRvbWFpbkxvb2t1cEVuZCIsImRvbWFpbkxvb2t1cFN0YXJ0IiwiY29ubmVjdFRpbWUiLCJjb25uZWN0RW5kIiwiY29ubmVjdFN0YXJ0IiwicmVxdWVzdFRpbWUiLCJyZXNwb25zZVN0YXJ0IiwicmVxdWVzdFN0YXJ0IiwicmVzcG9uc2VUaW1lIiwicmVzcG9uc2VFbmQiLCJyZXNvdXJjZXMiLCJzbG93UmVzb3VyY2VzIiwiZmlsdGVyIiwicmVzb3VyY2UiLCJkdXJhdGlvbiIsImxlbmd0aCIsImxhcmdlc3RSZXNvdXJjZXMiLCJzb3J0IiwiYSIsImIiLCJ0cmFuc2ZlclNpemUiLCJzbGljZSIsIm9ic2VydmVyIiwiUGVyZm9ybWFuY2VPYnNlcnZlciIsImxpc3QiLCJsb25nVGFza3MiLCJnZXRFbnRyaWVzIiwiZm9yRWFjaCIsInRhc2siLCJlbnYiLCJERVYiLCJ0aW1lc3RhbXAiLCJEYXRlIiwibm93IiwidXJsIiwibG9jYXRpb24iLCJocmVmIiwib2JzZXJ2ZSIsImVudHJ5VHlwZXMiLCJlcnJvciIsImd0YWciLCJldmVudF9jYXRlZ29yeSIsIk1hdGgiLCJyb3VuZCIsImN1c3RvbV9wYXJhbWV0ZXJfMSIsImlkIiwibm9uX2ludGVyYWN0aW9uIiwidXNlckFnZW50IiwibmF2aWdhdG9yIiwiYWRkTGlzdGVuZXIiLCJjYWxsYmFjayIsImxpc3RlbmVycyIsInB1c2giLCJyZW1vdmVMaXN0ZW5lciIsImluZGV4IiwiaW5kZXhPZiIsInNwbGljZSIsInJlcG9ydCIsImdlbmVyYXRlUmVwb3J0IiwicmF0aW5ncyIsImdldE1ldHJpY3MiLCJpc0NvbXBsZXRlIiwiT2JqZWN0IiwidmFsdWVzIiwiZXZlcnkiLCJyZXNldCIsInBlcmZvcm1hbmNlTW9uaXRvciIsInVzZVBlcmZvcm1hbmNlTW9uaXRvciIsInNldFJlcG9ydCIsImhhbmRsZVJlcG9ydCIsIm5ld1JlcG9ydCIsImluaXRQZXJmb3JtYW5jZU1vbml0b3JpbmciXSwibWFwcGluZ3MiOiJBQUFBOztDQUVDOzs7Ozs7Ozs7Ozs7O0FBRUQsU0FBU0EsUUFBUSxFQUFFQyxTQUFTLFFBQVEsUUFBUTtBQUM1QyxTQUFTQyxLQUFLLEVBQUVDLEtBQUssRUFBRUMsS0FBSyxFQUFFQyxLQUFLLEVBQUVDLE1BQU0sUUFBZ0IsYUFBYTtBQXVCeEUsNERBQTREO0FBQzVELE9BQU8sTUFBTUMseUJBQWdEO0lBQzNEQyxNQUFNO1FBQ0pDLEtBQUs7UUFDTEMsS0FBSztRQUNMQyxLQUFLO1FBQ0xDLEtBQUs7UUFDTEMsTUFBTTtJQUNSO0lBQ0FDLGtCQUFrQjtRQUNoQkwsS0FBSztRQUNMQyxLQUFLO1FBQ0xDLEtBQUs7UUFDTEMsS0FBSztRQUNMQyxNQUFNO0lBQ1I7QUFDRixFQUFFO0FBWUYsTUFBTUU7SUFZSixPQUFPQyxjQUFrQztRQUN2QyxJQUFJLENBQUNELG1CQUFtQkUsUUFBUSxFQUFFO1lBQ2hDRixtQkFBbUJFLFFBQVEsR0FBRyxJQUFJRjtRQUNwQztRQUNBLE9BQU9BLG1CQUFtQkUsUUFBUTtJQUNwQztJQUVBOztHQUVDLEdBQ0RDLE9BQWE7UUFDWCxJQUFJLElBQUksQ0FBQ0MsYUFBYSxJQUFJLE9BQU9DLFdBQVcsYUFBYTtZQUN2RDtRQUNGO1FBRUEsSUFBSSxDQUFDRCxhQUFhLEdBQUc7UUFFckIsd0JBQXdCO1FBQ3hCakIsTUFBTSxJQUFJLENBQUNtQixZQUFZLENBQUNDLElBQUksQ0FBQyxJQUFJO1FBQ2pDbkIsTUFBTSxJQUFJLENBQUNrQixZQUFZLENBQUNDLElBQUksQ0FBQyxJQUFJO1FBQ2pDbEIsTUFBTSxJQUFJLENBQUNpQixZQUFZLENBQUNDLElBQUksQ0FBQyxJQUFJO1FBQ2pDakIsTUFBTSxJQUFJLENBQUNnQixZQUFZLENBQUNDLElBQUksQ0FBQyxJQUFJO1FBQ2pDaEIsT0FBTyxJQUFJLENBQUNlLFlBQVksQ0FBQ0MsSUFBSSxDQUFDLElBQUk7UUFFbEMsdUNBQXVDO1FBQ3ZDLElBQUksQ0FBQ0MscUJBQXFCO1FBQzFCLElBQUksQ0FBQ0MsbUJBQW1CO1FBQ3hCLElBQUksQ0FBQ0MsY0FBYztRQUVuQkMsUUFBUUMsR0FBRyxDQUFDO0lBQ2Q7SUFFQTs7R0FFQyxHQUNELEFBQVFOLGFBQWFPLE1BQWMsRUFBUTtRQUN6QyxtRkFBbUY7UUFDbkYsTUFBTUMsVUFBVUQsT0FBT0UsSUFBSSxDQUFDQyxXQUFXO1FBQ3ZDLE1BQU1DLGFBQ0pILFlBQVksUUFBUSxRQUFRQTtRQUU5QixJQUFJLENBQUNJLE9BQU8sQ0FBQ0QsV0FBVyxHQUFHSixPQUFPTSxLQUFLO1FBRXZDUixRQUFRQyxHQUFHLENBQUMsR0FBR0MsT0FBT0UsSUFBSSxDQUFDLEVBQUUsRUFBRUYsT0FBT00sS0FBSyxFQUFFLEVBQUVOO1FBRS9DLGlDQUFpQztRQUNqQyxJQUFJLENBQUNPLHNCQUFzQixDQUFDSCxZQUFZSixPQUFPTSxLQUFLO1FBRXBELG1CQUFtQjtRQUNuQixJQUFJLENBQUNFLGVBQWU7UUFFcEIsb0NBQW9DO1FBQ3BDLElBQUksQ0FBQ0MsZUFBZSxDQUFDVDtJQUN2QjtJQUVBOztHQUVDLEdBQ0QsQUFBUU8sdUJBQ05ILFVBQW9DLEVBQ3BDRSxLQUFhLEVBQ1A7UUFDTixNQUFNSSxhQUFhL0I7UUFDbkIsTUFBTWdDLFNBQVMsSUFBSSxDQUFDQyxTQUFTLENBQUNSLFlBQVlFO1FBRTFDLElBQUlLLFdBQVcsUUFBUTtZQUNyQmIsUUFBUWUsSUFBSSxDQUFDLENBQUMsZ0NBQWdDLEVBQUVULFdBQVcsRUFBRSxFQUFFRSxPQUFPLEVBQUU7Z0JBQ3RFTixRQUFRSTtnQkFDUkU7Z0JBQ0FRLFdBQVdKLFdBQVd4QixnQkFBZ0IsQ0FBQ2tCLFdBQVc7Z0JBQ2xETztZQUNGO1lBRUEsK0NBQStDO1lBQy9DLElBQUksQ0FBQ0ksb0JBQW9CLENBQUNYLFlBQVlFLE9BQU9LO1FBQy9DO0lBQ0Y7SUFFQTs7R0FFQyxHQUNELEFBQVFDLFVBQ05SLFVBQW9DLEVBQ3BDRSxLQUFhLEVBQ007UUFDbkIsTUFBTUksYUFBYS9CO1FBRW5CLElBQUkyQixTQUFTSSxXQUFXOUIsSUFBSSxDQUFDd0IsV0FBVyxFQUFFO1lBQ3hDLE9BQU87UUFDVCxPQUFPLElBQUlFLFNBQVNJLFdBQVd4QixnQkFBZ0IsQ0FBQ2tCLFdBQVcsRUFBRTtZQUMzRCxPQUFPO1FBQ1QsT0FBTztZQUNMLE9BQU87UUFDVDtJQUNGO0lBRUE7O0dBRUMsR0FDRCxBQUFRVCx3QkFBOEI7UUFDcEMsSUFBSSxDQUFFLENBQUEsaUJBQWlCSCxNQUFLLEtBQU0sQ0FBQ3dCLFlBQVlDLGdCQUFnQixFQUFFO1lBQy9EO1FBQ0Y7UUFFQSxNQUFNQyxhQUFhRixZQUFZQyxnQkFBZ0IsQ0FDN0MsYUFDRCxDQUFDLEVBQUU7UUFDSixJQUFJLENBQUNDLFlBQVk7UUFFakIsTUFBTWIsVUFBVTtZQUNkYyxrQkFDRUQsV0FBV0Usd0JBQXdCLEdBQ25DRixXQUFXRywwQkFBMEI7WUFDdkNDLGFBQWFKLFdBQVdJLFdBQVcsR0FBR0osV0FBV0ssVUFBVTtZQUMzREMsY0FBY04sV0FBV08sWUFBWSxHQUFHUCxXQUFXSyxVQUFVO1lBQzdERyxjQUFjUixXQUFXUyxXQUFXLEdBQUdULFdBQVdVLGFBQWE7WUFDL0RDLFNBQVNYLFdBQVdZLGVBQWUsR0FBR1osV0FBV2EsaUJBQWlCO1lBQ2xFQyxhQUFhZCxXQUFXZSxVQUFVLEdBQUdmLFdBQVdnQixZQUFZO1lBQzVEQyxhQUFhakIsV0FBV2tCLGFBQWEsR0FBR2xCLFdBQVdtQixZQUFZO1lBQy9EQyxjQUFjcEIsV0FBV3FCLFdBQVcsR0FBR3JCLFdBQVdrQixhQUFhO1FBQ2pFO1FBRUF0QyxRQUFRQyxHQUFHLENBQUMsc0JBQXNCTTtJQUNwQztJQUVBOztHQUVDLEdBQ0QsQUFBUVQsc0JBQTRCO1FBQ2xDLElBQUksQ0FBRSxDQUFBLGlCQUFpQkosTUFBSyxLQUFNLENBQUN3QixZQUFZQyxnQkFBZ0IsRUFBRTtZQUMvRDtRQUNGO1FBRUEsTUFBTXVCLFlBQVl4QixZQUFZQyxnQkFBZ0IsQ0FDNUM7UUFFRixNQUFNd0IsZ0JBQWdCRCxVQUFVRSxNQUFNLENBQ3BDQyxDQUFBQSxXQUFZQSxTQUFTQyxRQUFRLEdBQUc7UUFHbEMsSUFBSUgsY0FBY0ksTUFBTSxHQUFHLEdBQUc7WUFDNUIvQyxRQUFRZSxJQUFJLENBQUMsb0NBQW9DNEI7UUFDbkQ7UUFFQSwwQkFBMEI7UUFDMUIsTUFBTUssbUJBQW1CTixVQUN0Qk8sSUFBSSxDQUFDLENBQUNDLEdBQUdDLElBQU1BLEVBQUVDLFlBQVksR0FBR0YsRUFBRUUsWUFBWSxFQUM5Q0MsS0FBSyxDQUFDLEdBQUc7UUFFWnJELFFBQVFDLEdBQUcsQ0FBQyxzQkFBc0IrQztJQUNwQztJQUVBOztHQUVDLEdBQ0QsQUFBUWpELGlCQUF1QjtRQUM3QixJQUFJLENBQUUsQ0FBQSx5QkFBeUJMLE1BQUssR0FBSTtZQUN0QztRQUNGO1FBRUEsSUFBSTtZQUNGLE1BQU00RCxXQUFXLElBQUlDLG9CQUFvQkMsQ0FBQUE7Z0JBQ3ZDLE1BQU1DLFlBQVlELEtBQUtFLFVBQVU7Z0JBQ2pDLElBQUlELFVBQVVWLE1BQU0sR0FBRyxHQUFHO29CQUN4Qi9DLFFBQVFlLElBQUksQ0FBQyx3QkFBd0IwQztvQkFFckMsbUNBQW1DO29CQUNuQ0EsVUFBVUUsT0FBTyxDQUFDQyxDQUFBQTt3QkFDaEIsaURBQWlEO3dCQUNqRCxJQUFJLFlBQVlDLEdBQUcsQ0FBQ0MsR0FBRyxFQUFFOzRCQUN2QjlELFFBQVFDLEdBQUcsQ0FBQyw4QkFBOEI7Z0NBQ3hDRyxNQUFNO2dDQUNOSSxPQUFPb0QsS0FBS2QsUUFBUTtnQ0FDcEJpQixXQUFXQyxLQUFLQyxHQUFHO2dDQUNuQkMsS0FBS3hFLE9BQU95RSxRQUFRLENBQUNDLElBQUk7NEJBQzNCO3dCQUNGO29CQUNGO2dCQUNGO1lBQ0Y7WUFFQWQsU0FBU2UsT0FBTyxDQUFDO2dCQUFFQyxZQUFZO29CQUFDO2lCQUFXO1lBQUM7UUFDOUMsRUFBRSxPQUFPQyxPQUFPO1lBQ2R2RSxRQUFRZSxJQUFJLENBQUMsaUNBQWlDd0Q7UUFDaEQ7SUFDRjtJQUVBOztHQUVDLEdBQ0QsQUFBUTVELGdCQUFnQlQsTUFBYyxFQUFRO1FBQzVDLGdEQUFnRDtRQUNoRCxzREFBc0Q7UUFFdEQsSUFBSSxZQUFZMkQsR0FBRyxDQUFDQyxHQUFHLEVBQUU7WUFDdkI5RCxRQUFRQyxHQUFHLENBQUMsb0JBQW9CO2dCQUM5QkcsTUFBTUYsT0FBT0UsSUFBSTtnQkFDakJJLE9BQU9OLE9BQU9NLEtBQUs7Z0JBQ25CSyxRQUFRLElBQUksQ0FBQ0MsU0FBUyxDQUNwQlosT0FBT0UsSUFBSSxDQUFDQyxXQUFXLElBQ3ZCSCxPQUFPTSxLQUFLO2dCQUVkdUQsV0FBV0MsS0FBS0MsR0FBRztnQkFDbkJDLEtBQUt4RSxPQUFPeUUsUUFBUSxDQUFDQyxJQUFJO1lBQzNCO1FBQ0Y7UUFFQSw4Q0FBOEM7UUFDOUMsSUFBSSxPQUFPMUUsV0FBVyxlQUFlLFVBQVVBLFFBQVE7WUFDckQsTUFBTThFLE9BQU8sQUFBQzlFLE9BQWU4RSxJQUFJO1lBQ2pDQSxLQUFLLFNBQVN0RSxPQUFPRSxJQUFJLEVBQUU7Z0JBQ3pCcUUsZ0JBQWdCO2dCQUNoQmpFLE9BQU9rRSxLQUFLQyxLQUFLLENBQ2Z6RSxPQUFPRSxJQUFJLEtBQUssUUFBUUYsT0FBT00sS0FBSyxHQUFHLE9BQU9OLE9BQU9NLEtBQUs7Z0JBRTVEb0Usb0JBQW9CMUUsT0FBTzJFLEVBQUU7Z0JBQzdCQyxpQkFBaUI7WUFDbkI7UUFDRjtJQUNGO0lBRUE7O0dBRUMsR0FDRCxBQUFRN0QscUJBQ05YLFVBQWtCLEVBQ2xCRSxLQUFhLEVBQ2JLLE1BQXlCLEVBQ25CO1FBQ04sb0VBQW9FO1FBQ3BFYixRQUFRdUUsS0FBSyxDQUFDLHNCQUFzQjtZQUNsQ3JFLFFBQVFJO1lBQ1JFO1lBQ0FLO1lBQ0FrRCxXQUFXQyxLQUFLQyxHQUFHO1lBQ25CQyxLQUFLeEUsT0FBT3lFLFFBQVEsQ0FBQ0MsSUFBSTtZQUN6QlcsV0FBV0MsVUFBVUQsU0FBUztRQUNoQztJQUNGO0lBRUE7O0dBRUMsR0FDREUsWUFBWUMsUUFBNkMsRUFBUTtRQUMvRCxJQUFJLENBQUNDLFNBQVMsQ0FBQ0MsSUFBSSxDQUFDRjtJQUN0QjtJQUVBOztHQUVDLEdBQ0RHLGVBQWVILFFBQTZDLEVBQVE7UUFDbEUsTUFBTUksUUFBUSxJQUFJLENBQUNILFNBQVMsQ0FBQ0ksT0FBTyxDQUFDTDtRQUNyQyxJQUFJSSxRQUFRLENBQUMsR0FBRztZQUNkLElBQUksQ0FBQ0gsU0FBUyxDQUFDSyxNQUFNLENBQUNGLE9BQU87UUFDL0I7SUFDRjtJQUVBOztHQUVDLEdBQ0QsQUFBUTVFLGtCQUF3QjtRQUM5QixNQUFNK0UsU0FBUyxJQUFJLENBQUNDLGNBQWM7UUFDbEMsSUFBSSxDQUFDUCxTQUFTLENBQUN4QixPQUFPLENBQUN1QixDQUFBQSxXQUFZQSxTQUFTTztJQUM5QztJQUVBOztHQUVDLEdBQ0RDLGlCQUFvQztRQUNsQyxNQUFNQyxVQUErRDtZQUNuRTVHLEtBQUssSUFBSSxDQUFDd0IsT0FBTyxDQUFDeEIsR0FBRyxHQUFHLElBQUksQ0FBQytCLFNBQVMsQ0FBQyxPQUFPLElBQUksQ0FBQ1AsT0FBTyxDQUFDeEIsR0FBRyxJQUFJO1lBQ2xFQyxLQUFLLElBQUksQ0FBQ3VCLE9BQU8sQ0FBQ3ZCLEdBQUcsR0FBRyxJQUFJLENBQUM4QixTQUFTLENBQUMsT0FBTyxJQUFJLENBQUNQLE9BQU8sQ0FBQ3ZCLEdBQUcsSUFBSTtZQUNsRUMsS0FBSyxJQUFJLENBQUNzQixPQUFPLENBQUN0QixHQUFHLEdBQUcsSUFBSSxDQUFDNkIsU0FBUyxDQUFDLE9BQU8sSUFBSSxDQUFDUCxPQUFPLENBQUN0QixHQUFHLElBQUk7WUFDbEVDLEtBQUssSUFBSSxDQUFDcUIsT0FBTyxDQUFDckIsR0FBRyxHQUFHLElBQUksQ0FBQzRCLFNBQVMsQ0FBQyxPQUFPLElBQUksQ0FBQ1AsT0FBTyxDQUFDckIsR0FBRyxJQUFJO1lBQ2xFQyxNQUFNLElBQUksQ0FBQ29CLE9BQU8sQ0FBQ3BCLElBQUksR0FDbkIsSUFBSSxDQUFDMkIsU0FBUyxDQUFDLFFBQVEsSUFBSSxDQUFDUCxPQUFPLENBQUNwQixJQUFJLElBQ3hDO1FBQ047UUFFQSxPQUFPO1lBQ0xvQixTQUFTO2dCQUFFLEdBQUcsSUFBSSxDQUFDQSxPQUFPO1lBQUM7WUFDM0JvRjtZQUNBNUIsV0FBV0MsS0FBS0MsR0FBRztZQUNuQkMsS0FBSyxPQUFPeEUsV0FBVyxjQUFjQSxPQUFPeUUsUUFBUSxDQUFDQyxJQUFJLEdBQUc7WUFDNURXLFdBQVcsT0FBT0MsY0FBYyxjQUFjQSxVQUFVRCxTQUFTLEdBQUc7UUFDdEU7SUFDRjtJQUVBOztHQUVDLEdBQ0RhLGFBQWlDO1FBQy9CLE9BQU87WUFBRSxHQUFHLElBQUksQ0FBQ3JGLE9BQU87UUFBQztJQUMzQjtJQUVBOztHQUVDLEdBQ0RzRixhQUFzQjtRQUNwQixPQUFPQyxPQUFPQyxNQUFNLENBQUMsSUFBSSxDQUFDeEYsT0FBTyxFQUFFeUYsS0FBSyxDQUFDeEYsQ0FBQUEsUUFBU0EsVUFBVTtJQUM5RDtJQUVBOztHQUVDLEdBQ0R5RixRQUFjO1FBQ1osSUFBSSxDQUFDMUYsT0FBTyxHQUFHO1lBQ2J4QixLQUFLO1lBQ0xDLEtBQUs7WUFDTEMsS0FBSztZQUNMQyxLQUFLO1lBQ0xDLE1BQU07UUFDUjtRQUNBLElBQUksQ0FBQ00sYUFBYSxHQUFHO0lBQ3ZCOztRQXBVQSx1QkFBUWMsV0FBOEI7WUFDcEN4QixLQUFLO1lBQ0xDLEtBQUs7WUFDTEMsS0FBSztZQUNMQyxLQUFLO1lBQ0xDLE1BQU07UUFDUjtRQUNBLHVCQUFRZ0csYUFBcUQsRUFBRTtRQUMvRCx1QkFBUTFGLGlCQUFnQjs7QUE2VDFCO0FBdFVFLGlCQURJSixvQkFDV0UsWUFBZixLQUFBO0FBd1VGLDRCQUE0QjtBQUM1QixPQUFPLE1BQU0yRyxxQkFBcUI3RyxtQkFBbUJDLFdBQVcsR0FBRztBQUVuRSx3Q0FBd0M7QUFDeEMsT0FBTyxTQUFTNkc7SUFDZCxNQUFNLENBQUNWLFFBQVFXLFVBQVUsR0FBRzlILFNBQW1DO0lBRS9EQyxVQUFVO1FBQ1IsTUFBTThILGVBQWUsQ0FBQ0M7WUFDcEJGLFVBQVVFO1FBQ1o7UUFFQUosbUJBQW1CakIsV0FBVyxDQUFDb0I7UUFDL0JILG1CQUFtQjFHLElBQUk7UUFFdkIsT0FBTztZQUNMMEcsbUJBQW1CYixjQUFjLENBQUNnQjtRQUNwQztJQUNGLEdBQUcsRUFBRTtJQUVMLE9BQU87UUFDTFo7UUFDQWxGLFNBQVMyRixtQkFBbUJOLFVBQVU7UUFDdENDLFlBQVlLLG1CQUFtQkwsVUFBVTtRQUN6Q0gsZ0JBQWdCLElBQU1RLG1CQUFtQlIsY0FBYztJQUN6RDtBQUNGO0FBRUEsb0NBQW9DO0FBQ3BDLE9BQU8sU0FBU2E7SUFDZCxJQUFJLE9BQU83RyxXQUFXLGFBQWE7UUFDakN3RyxtQkFBbUIxRyxJQUFJO0lBQ3pCO0FBQ0YifQ==