import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const useMemo = __vite__cjsImport0_react["useMemo"];
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=e72f996b";
import { createPersonSchema, createWebSiteSchema, createBreadcrumbSchema, createWorkSchema } from "/src/lib/structured-data.ts";
export const useStructuredData = (customData)=>{
    const location = useLocation();
    return useMemo(()=>{
        // Create person schema
        const personSchema = createPersonSchema({
            url: window.location.origin
        });
        // Create website schema
        const websiteSchema = createWebSiteSchema({
            url: window.location.origin
        });
        // Create breadcrumb schema based on current path
        const breadcrumbSchema = createBreadcrumbSchema(getBreadcrumbsFromPath(location.pathname, window.location.origin));
        // Create project schemas if provided
        const projectSchemas = customData?.projects?.map((project)=>createWorkSchema(project));
        return {
            personSchema,
            websiteSchema,
            breadcrumbSchema,
            projectSchemas
        };
    }, [
        location.pathname,
        customData
    ]);
};
// Helper function to generate breadcrumbs from path
const getBreadcrumbsFromPath = (pathname, origin)=>{
    const breadcrumbs = [
        {
            name: 'Home',
            url: origin
        }
    ];
    const pathSegments = pathname.split('/').filter((segment)=>segment);
    pathSegments.forEach((segment, index)=>{
        const url = `${origin}/${pathSegments.slice(0, index + 1).join('/')}`;
        const name = getPageNameFromSegment(segment);
        breadcrumbs.push({
            name,
            url
        });
    });
    return breadcrumbs;
};
// Helper function to get readable page names from URL segments
const getPageNameFromSegment = (segment)=>{
    const pageNames = {
        projects: 'Projects',
        skills: 'Skills & Technologies',
        experience: 'Professional Experience',
        contact: 'Contact',
        about: 'About'
    };
    return pageNames[segment] || segment.charAt(0).toUpperCase() + segment.slice(1);
};
export default useStructuredData;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZS1zdHJ1Y3R1cmVkLWRhdGEudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUxvY2F0aW9uIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQge1xuICBjcmVhdGVQZXJzb25TY2hlbWEsXG4gIGNyZWF0ZVdlYlNpdGVTY2hlbWEsXG4gIGNyZWF0ZUJyZWFkY3J1bWJTY2hlbWEsXG4gIGNyZWF0ZVdvcmtTY2hlbWEsXG4gIFBlcnNvblNjaGVtYSxcbiAgV2ViU2l0ZVNjaGVtYSxcbiAgQnJlYWRjcnVtYkxpc3RTY2hlbWEsXG4gIFdvcmtTY2hlbWEsXG59IGZyb20gJ0AvbGliL3N0cnVjdHVyZWQtZGF0YSc7XG5cbmludGVyZmFjZSBVc2VTdHJ1Y3R1cmVkRGF0YVJldHVybiB7XG4gIHBlcnNvblNjaGVtYTogUGVyc29uU2NoZW1hO1xuICB3ZWJzaXRlU2NoZW1hOiBXZWJTaXRlU2NoZW1hO1xuICBicmVhZGNydW1iU2NoZW1hOiBCcmVhZGNydW1iTGlzdFNjaGVtYTtcbiAgcHJvamVjdFNjaGVtYXM/OiBXb3JrU2NoZW1hW107XG59XG5cbmV4cG9ydCBjb25zdCB1c2VTdHJ1Y3R1cmVkRGF0YSA9IChjdXN0b21EYXRhPzoge1xuICBwcm9qZWN0cz86IEFycmF5PHtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgICB1cmw/OiBzdHJpbmc7XG4gICAgaW1hZ2U/OiBzdHJpbmc7XG4gICAgZGF0ZUNyZWF0ZWQ/OiBzdHJpbmc7XG4gICAga2V5d29yZHM/OiBzdHJpbmdbXTtcbiAgICBwcm9ncmFtbWluZ0xhbmd1YWdlPzogc3RyaW5nW107XG4gICAgY29kZVJlcG9zaXRvcnk/OiBzdHJpbmc7XG4gIH0+O1xufSk6IFVzZVN0cnVjdHVyZWREYXRhUmV0dXJuID0+IHtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuXG4gIHJldHVybiB1c2VNZW1vKCgpID0+IHtcbiAgICAvLyBDcmVhdGUgcGVyc29uIHNjaGVtYVxuICAgIGNvbnN0IHBlcnNvblNjaGVtYSA9IGNyZWF0ZVBlcnNvblNjaGVtYSh7XG4gICAgICB1cmw6IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4sXG4gICAgfSk7XG5cbiAgICAvLyBDcmVhdGUgd2Vic2l0ZSBzY2hlbWFcbiAgICBjb25zdCB3ZWJzaXRlU2NoZW1hID0gY3JlYXRlV2ViU2l0ZVNjaGVtYSh7XG4gICAgICB1cmw6IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4sXG4gICAgfSk7XG5cbiAgICAvLyBDcmVhdGUgYnJlYWRjcnVtYiBzY2hlbWEgYmFzZWQgb24gY3VycmVudCBwYXRoXG4gICAgY29uc3QgYnJlYWRjcnVtYlNjaGVtYSA9IGNyZWF0ZUJyZWFkY3J1bWJTY2hlbWEoXG4gICAgICBnZXRCcmVhZGNydW1ic0Zyb21QYXRoKGxvY2F0aW9uLnBhdGhuYW1lLCB3aW5kb3cubG9jYXRpb24ub3JpZ2luKVxuICAgICk7XG5cbiAgICAvLyBDcmVhdGUgcHJvamVjdCBzY2hlbWFzIGlmIHByb3ZpZGVkXG4gICAgY29uc3QgcHJvamVjdFNjaGVtYXMgPSBjdXN0b21EYXRhPy5wcm9qZWN0cz8ubWFwKHByb2plY3QgPT5cbiAgICAgIGNyZWF0ZVdvcmtTY2hlbWEocHJvamVjdClcbiAgICApO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIHBlcnNvblNjaGVtYSxcbiAgICAgIHdlYnNpdGVTY2hlbWEsXG4gICAgICBicmVhZGNydW1iU2NoZW1hLFxuICAgICAgcHJvamVjdFNjaGVtYXMsXG4gICAgfTtcbiAgfSwgW2xvY2F0aW9uLnBhdGhuYW1lLCBjdXN0b21EYXRhXSk7XG59O1xuXG4vLyBIZWxwZXIgZnVuY3Rpb24gdG8gZ2VuZXJhdGUgYnJlYWRjcnVtYnMgZnJvbSBwYXRoXG5jb25zdCBnZXRCcmVhZGNydW1ic0Zyb21QYXRoID0gKFxuICBwYXRobmFtZTogc3RyaW5nLFxuICBvcmlnaW46IHN0cmluZ1xuKTogQXJyYXk8eyBuYW1lOiBzdHJpbmc7IHVybDogc3RyaW5nIH0+ID0+IHtcbiAgY29uc3QgYnJlYWRjcnVtYnMgPSBbeyBuYW1lOiAnSG9tZScsIHVybDogb3JpZ2luIH1dO1xuXG4gIGNvbnN0IHBhdGhTZWdtZW50cyA9IHBhdGhuYW1lLnNwbGl0KCcvJykuZmlsdGVyKHNlZ21lbnQgPT4gc2VnbWVudCk7XG5cbiAgcGF0aFNlZ21lbnRzLmZvckVhY2goKHNlZ21lbnQsIGluZGV4KSA9PiB7XG4gICAgY29uc3QgdXJsID0gYCR7b3JpZ2lufS8ke3BhdGhTZWdtZW50cy5zbGljZSgwLCBpbmRleCArIDEpLmpvaW4oJy8nKX1gO1xuICAgIGNvbnN0IG5hbWUgPSBnZXRQYWdlTmFtZUZyb21TZWdtZW50KHNlZ21lbnQpO1xuICAgIGJyZWFkY3J1bWJzLnB1c2goeyBuYW1lLCB1cmwgfSk7XG4gIH0pO1xuXG4gIHJldHVybiBicmVhZGNydW1icztcbn07XG5cbi8vIEhlbHBlciBmdW5jdGlvbiB0byBnZXQgcmVhZGFibGUgcGFnZSBuYW1lcyBmcm9tIFVSTCBzZWdtZW50c1xuY29uc3QgZ2V0UGFnZU5hbWVGcm9tU2VnbWVudCA9IChzZWdtZW50OiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICBjb25zdCBwYWdlTmFtZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICAgcHJvamVjdHM6ICdQcm9qZWN0cycsXG4gICAgc2tpbGxzOiAnU2tpbGxzICYgVGVjaG5vbG9naWVzJyxcbiAgICBleHBlcmllbmNlOiAnUHJvZmVzc2lvbmFsIEV4cGVyaWVuY2UnLFxuICAgIGNvbnRhY3Q6ICdDb250YWN0JyxcbiAgICBhYm91dDogJ0Fib3V0JyxcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIHBhZ2VOYW1lc1tzZWdtZW50XSB8fCBzZWdtZW50LmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc2VnbWVudC5zbGljZSgxKVxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgdXNlU3RydWN0dXJlZERhdGE7XG4iXSwibmFtZXMiOlsidXNlTWVtbyIsInVzZUxvY2F0aW9uIiwiY3JlYXRlUGVyc29uU2NoZW1hIiwiY3JlYXRlV2ViU2l0ZVNjaGVtYSIsImNyZWF0ZUJyZWFkY3J1bWJTY2hlbWEiLCJjcmVhdGVXb3JrU2NoZW1hIiwidXNlU3RydWN0dXJlZERhdGEiLCJjdXN0b21EYXRhIiwibG9jYXRpb24iLCJwZXJzb25TY2hlbWEiLCJ1cmwiLCJ3aW5kb3ciLCJvcmlnaW4iLCJ3ZWJzaXRlU2NoZW1hIiwiYnJlYWRjcnVtYlNjaGVtYSIsImdldEJyZWFkY3J1bWJzRnJvbVBhdGgiLCJwYXRobmFtZSIsInByb2plY3RTY2hlbWFzIiwicHJvamVjdHMiLCJtYXAiLCJwcm9qZWN0IiwiYnJlYWRjcnVtYnMiLCJuYW1lIiwicGF0aFNlZ21lbnRzIiwic3BsaXQiLCJmaWx0ZXIiLCJzZWdtZW50IiwiZm9yRWFjaCIsImluZGV4Iiwic2xpY2UiLCJqb2luIiwiZ2V0UGFnZU5hbWVGcm9tU2VnbWVudCIsInB1c2giLCJwYWdlTmFtZXMiLCJza2lsbHMiLCJleHBlcmllbmNlIiwiY29udGFjdCIsImFib3V0IiwiY2hhckF0IiwidG9VcHBlckNhc2UiXSwibWFwcGluZ3MiOiJBQUFBLFNBQVNBLE9BQU8sUUFBUSxRQUFRO0FBQ2hDLFNBQVNDLFdBQVcsUUFBUSxtQkFBbUI7QUFDL0MsU0FDRUMsa0JBQWtCLEVBQ2xCQyxtQkFBbUIsRUFDbkJDLHNCQUFzQixFQUN0QkMsZ0JBQWdCLFFBS1gsd0JBQXdCO0FBUy9CLE9BQU8sTUFBTUMsb0JBQW9CLENBQUNDO0lBWWhDLE1BQU1DLFdBQVdQO0lBRWpCLE9BQU9ELFFBQVE7UUFDYix1QkFBdUI7UUFDdkIsTUFBTVMsZUFBZVAsbUJBQW1CO1lBQ3RDUSxLQUFLQyxPQUFPSCxRQUFRLENBQUNJLE1BQU07UUFDN0I7UUFFQSx3QkFBd0I7UUFDeEIsTUFBTUMsZ0JBQWdCVixvQkFBb0I7WUFDeENPLEtBQUtDLE9BQU9ILFFBQVEsQ0FBQ0ksTUFBTTtRQUM3QjtRQUVBLGlEQUFpRDtRQUNqRCxNQUFNRSxtQkFBbUJWLHVCQUN2QlcsdUJBQXVCUCxTQUFTUSxRQUFRLEVBQUVMLE9BQU9ILFFBQVEsQ0FBQ0ksTUFBTTtRQUdsRSxxQ0FBcUM7UUFDckMsTUFBTUssaUJBQWlCVixZQUFZVyxVQUFVQyxJQUFJQyxDQUFBQSxVQUMvQ2YsaUJBQWlCZTtRQUduQixPQUFPO1lBQ0xYO1lBQ0FJO1lBQ0FDO1lBQ0FHO1FBQ0Y7SUFDRixHQUFHO1FBQUNULFNBQVNRLFFBQVE7UUFBRVQ7S0FBVztBQUNwQyxFQUFFO0FBRUYsb0RBQW9EO0FBQ3BELE1BQU1RLHlCQUF5QixDQUM3QkMsVUFDQUo7SUFFQSxNQUFNUyxjQUFjO1FBQUM7WUFBRUMsTUFBTTtZQUFRWixLQUFLRTtRQUFPO0tBQUU7SUFFbkQsTUFBTVcsZUFBZVAsU0FBU1EsS0FBSyxDQUFDLEtBQUtDLE1BQU0sQ0FBQ0MsQ0FBQUEsVUFBV0E7SUFFM0RILGFBQWFJLE9BQU8sQ0FBQyxDQUFDRCxTQUFTRTtRQUM3QixNQUFNbEIsTUFBTSxHQUFHRSxPQUFPLENBQUMsRUFBRVcsYUFBYU0sS0FBSyxDQUFDLEdBQUdELFFBQVEsR0FBR0UsSUFBSSxDQUFDLE1BQU07UUFDckUsTUFBTVIsT0FBT1MsdUJBQXVCTDtRQUNwQ0wsWUFBWVcsSUFBSSxDQUFDO1lBQUVWO1lBQU1aO1FBQUk7SUFDL0I7SUFFQSxPQUFPVztBQUNUO0FBRUEsK0RBQStEO0FBQy9ELE1BQU1VLHlCQUF5QixDQUFDTDtJQUM5QixNQUFNTyxZQUFvQztRQUN4Q2YsVUFBVTtRQUNWZ0IsUUFBUTtRQUNSQyxZQUFZO1FBQ1pDLFNBQVM7UUFDVEMsT0FBTztJQUNUO0lBRUEsT0FDRUosU0FBUyxDQUFDUCxRQUFRLElBQUlBLFFBQVFZLE1BQU0sQ0FBQyxHQUFHQyxXQUFXLEtBQUtiLFFBQVFHLEtBQUssQ0FBQztBQUUxRTtBQUVBLGVBQWV2QixrQkFBa0IifQ==