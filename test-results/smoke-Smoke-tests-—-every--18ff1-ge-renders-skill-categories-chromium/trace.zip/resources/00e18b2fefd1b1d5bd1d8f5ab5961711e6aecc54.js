import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/scroll-progress.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/scroll-progress.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { motion, useScroll, useSpring } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
const ScrollProgress = ()=>{
    _s();
    const { scrollYProgress } = useScroll();
    const scaleX = useSpring(scrollYProgress, {
        stiffness: 100,
        damping: 30,
        restDelta: 0.001
    });
    return /*#__PURE__*/ _jsxDEV(motion.div, {
        style: {
            scaleX
        },
        className: "fixed top-0 left-0 right-0 h-[3px] bg-gradient-primary z-[60] origin-left"
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/scroll-progress.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
};
_s(ScrollProgress, "UYAOtHxiUth0DU6Git6zGRnUBB4=", false, function() {
    return [
        useScroll,
        useSpring
    ];
});
_c = ScrollProgress;
export { ScrollProgress };
var _c;
$RefreshReg$(_c, "ScrollProgress");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/scroll-progress.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/scroll-progress.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjcm9sbC1wcm9ncmVzcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiwgdXNlU2Nyb2xsLCB1c2VTcHJpbmcgfSBmcm9tICdmcmFtZXItbW90aW9uJztcblxuY29uc3QgU2Nyb2xsUHJvZ3Jlc3MgPSAoKSA9PiB7XG4gIGNvbnN0IHsgc2Nyb2xsWVByb2dyZXNzIH0gPSB1c2VTY3JvbGwoKTtcbiAgY29uc3Qgc2NhbGVYID0gdXNlU3ByaW5nKHNjcm9sbFlQcm9ncmVzcywge1xuICAgIHN0aWZmbmVzczogMTAwLFxuICAgIGRhbXBpbmc6IDMwLFxuICAgIHJlc3REZWx0YTogMC4wMDEsXG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPG1vdGlvbi5kaXZcbiAgICAgIHN0eWxlPXt7IHNjYWxlWCB9fVxuICAgICAgY2xhc3NOYW1lPSdmaXhlZCB0b3AtMCBsZWZ0LTAgcmlnaHQtMCBoLVszcHhdIGJnLWdyYWRpZW50LXByaW1hcnkgei1bNjBdIG9yaWdpbi1sZWZ0J1xuICAgIC8+XG4gICk7XG59O1xuXG5leHBvcnQgeyBTY3JvbGxQcm9ncmVzcyB9O1xuIl0sIm5hbWVzIjpbIlJlYWN0IiwibW90aW9uIiwidXNlU2Nyb2xsIiwidXNlU3ByaW5nIiwiU2Nyb2xsUHJvZ3Jlc3MiLCJzY3JvbGxZUHJvZ3Jlc3MiLCJzY2FsZVgiLCJzdGlmZm5lc3MiLCJkYW1waW5nIiwicmVzdERlbHRhIiwiZGl2Iiwic3R5bGUiLCJjbGFzc05hbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxPQUFPQSxXQUFXLFFBQVE7QUFDMUIsU0FBU0MsTUFBTSxFQUFFQyxTQUFTLEVBQUVDLFNBQVMsUUFBUSxnQkFBZ0I7QUFFN0QsTUFBTUMsaUJBQWlCOztJQUNyQixNQUFNLEVBQUVDLGVBQWUsRUFBRSxHQUFHSDtJQUM1QixNQUFNSSxTQUFTSCxVQUFVRSxpQkFBaUI7UUFDeENFLFdBQVc7UUFDWEMsU0FBUztRQUNUQyxXQUFXO0lBQ2I7SUFFQSxxQkFDRSxRQUFDUixPQUFPUyxHQUFHO1FBQ1RDLE9BQU87WUFBRUw7UUFBTztRQUNoQk0sV0FBVTs7Ozs7O0FBR2hCO0dBZE1SOztRQUN3QkY7UUFDYkM7OztLQUZYQztBQWdCTixTQUFTQSxjQUFjLEdBQUcifQ==