import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/accessibility/SkipLink.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/accessibility/SkipLink.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { cn } from "/src/lib/utils.ts";
/**
 * SkipLink gives keyboard users a fast path to the main content region.
 */ export const SkipLink = ({ targetId, label = 'Skip to content', className })=>{
    return /*#__PURE__*/ _jsxDEV("a", {
        href: `#${targetId}`,
        className: cn('sr-only focus:not-sr-only focus:fixed focus:z-[100] focus:top-2 focus:left-2 focus:px-4 focus:py-2 focus:rounded-md focus:bg-primary focus:text-primary-foreground focus:outline-none focus:ring-2 focus:ring-primary', className),
        children: label
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/components/accessibility/SkipLink.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
};
_c = SkipLink;
export default SkipLink;
var _c;
$RefreshReg$(_c, "SkipLink");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/accessibility/SkipLink.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/accessibility/SkipLink.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNraXBMaW5rLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgU2tpcExpbmtQcm9wcyB7XG4gIHRhcmdldElkOiBzdHJpbmc7XG4gIGxhYmVsPzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbi8qKlxuICogU2tpcExpbmsgZ2l2ZXMga2V5Ym9hcmQgdXNlcnMgYSBmYXN0IHBhdGggdG8gdGhlIG1haW4gY29udGVudCByZWdpb24uXG4gKi9cbmV4cG9ydCBjb25zdCBTa2lwTGluazogUmVhY3QuRkM8U2tpcExpbmtQcm9wcz4gPSAoe1xuICB0YXJnZXRJZCxcbiAgbGFiZWwgPSAnU2tpcCB0byBjb250ZW50JyxcbiAgY2xhc3NOYW1lLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxhXG4gICAgICBocmVmPXtgIyR7dGFyZ2V0SWR9YH1cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICdzci1vbmx5IGZvY3VzOm5vdC1zci1vbmx5IGZvY3VzOmZpeGVkIGZvY3VzOnotWzEwMF0gZm9jdXM6dG9wLTIgZm9jdXM6bGVmdC0yIGZvY3VzOnB4LTQgZm9jdXM6cHktMiBmb2N1czpyb3VuZGVkLW1kIGZvY3VzOmJnLXByaW1hcnkgZm9jdXM6dGV4dC1wcmltYXJ5LWZvcmVncm91bmQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXByaW1hcnknLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgPlxuICAgICAge2xhYmVsfVxuICAgIDwvYT5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFNraXBMaW5rO1xuIl0sIm5hbWVzIjpbIlJlYWN0IiwiY24iLCJTa2lwTGluayIsInRhcmdldElkIiwibGFiZWwiLCJjbGFzc05hbWUiLCJhIiwiaHJlZiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVyxRQUFRO0FBQzFCLFNBQVNDLEVBQUUsUUFBUSxjQUFjO0FBUWpDOztDQUVDLEdBQ0QsT0FBTyxNQUFNQyxXQUFvQyxDQUFDLEVBQ2hEQyxRQUFRLEVBQ1JDLFFBQVEsaUJBQWlCLEVBQ3pCQyxTQUFTLEVBQ1Y7SUFDQyxxQkFDRSxRQUFDQztRQUNDQyxNQUFNLENBQUMsQ0FBQyxFQUFFSixVQUFVO1FBQ3BCRSxXQUFXSixHQUNULHlOQUNBSTtrQkFHREQ7Ozs7OztBQUdQLEVBQUU7S0FoQldGO0FBa0JiLGVBQWVBLFNBQVMifQ==