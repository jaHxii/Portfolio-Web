import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/atmosphere/Atmosphere.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/atmosphere/Atmosphere.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { cn } from "/src/lib/utils.ts";
/**
 * Shared atmospheric background — layered blurred cloud silhouettes,
 * silver cloud bands and a soft golden light near a focal area.
 * Decorative only; place behind content inside a `relative` parent.
 */ const Atmosphere = ({ variant = 'hero', className })=>{
    const base = variant === 'mist' ? 'bg-atmo-mist' : variant === 'horizon' ? 'bg-atmo-horizon' : 'bg-atmo-hero';
    return /*#__PURE__*/ _jsxDEV("div", {
        "aria-hidden": "true",
        className: cn('pointer-events-none absolute inset-0 overflow-hidden', className),
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                className: cn('absolute inset-0', base)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/Atmosphere.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "absolute -top-24 right-[-10%] h-[55vh] w-[75vw] motion-safe:animate-cloud-drift",
                style: {
                    opacity: variant === 'horizon' ? 0.04 : 0.06,
                    background: 'radial-gradient(circle at 60% 40%, hsl(210 8% 77%), transparent 65%)',
                    filter: 'blur(80px)'
                }
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/Atmosphere.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "absolute left-[-10%] top-[34%] h-[42vh] w-[95vw] motion-safe:animate-cloud-drift",
                style: {
                    opacity: variant === 'hero' ? 0.05 : 0.07,
                    background: 'radial-gradient(circle at 50% 50%, hsl(210 10% 66%), transparent 70%)',
                    filter: 'blur(70px)',
                    animationDelay: '4s'
                }
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/Atmosphere.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "absolute inset-x-[-10%] bottom-[-15%] h-[45vh]",
                style: {
                    opacity: variant === 'hero' ? 0.07 : 0.08,
                    background: 'linear-gradient(180deg, transparent, hsl(210 8% 66%))',
                    filter: 'blur(60px)'
                }
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/Atmosphere.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: cn('absolute left-1/2 h-[50vh] w-[70vw] -translate-x-1/2', variant === 'hero' ? 'top-[55%]' : variant === 'horizon' ? 'bottom-[-15%]' : 'top-[30%]'),
                style: {
                    opacity: variant === 'horizon' ? 0.16 : 0.1,
                    background: 'radial-gradient(circle, hsl(42 58% 64%), transparent 60%)',
                    filter: 'blur(90px)'
                }
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/Atmosphere.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/Atmosphere.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
};
_c = Atmosphere;
export default Atmosphere;
var _c;
$RefreshReg$(_c, "Atmosphere");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/atmosphere/Atmosphere.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/atmosphere/Atmosphere.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkF0bW9zcGhlcmUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJztcblxuaW50ZXJmYWNlIEF0bW9zcGhlcmVQcm9wcyB7XG4gIHZhcmlhbnQ/OiAnaGVybycgfCAnbWlzdCcgfCAnaG9yaXpvbic7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn1cblxuLyoqXG4gKiBTaGFyZWQgYXRtb3NwaGVyaWMgYmFja2dyb3VuZCDigJQgbGF5ZXJlZCBibHVycmVkIGNsb3VkIHNpbGhvdWV0dGVzLFxuICogc2lsdmVyIGNsb3VkIGJhbmRzIGFuZCBhIHNvZnQgZ29sZGVuIGxpZ2h0IG5lYXIgYSBmb2NhbCBhcmVhLlxuICogRGVjb3JhdGl2ZSBvbmx5OyBwbGFjZSBiZWhpbmQgY29udGVudCBpbnNpZGUgYSBgcmVsYXRpdmVgIHBhcmVudC5cbiAqL1xuY29uc3QgQXRtb3NwaGVyZSA9ICh7IHZhcmlhbnQgPSAnaGVybycsIGNsYXNzTmFtZSB9OiBBdG1vc3BoZXJlUHJvcHMpID0+IHtcbiAgY29uc3QgYmFzZSA9XG4gICAgdmFyaWFudCA9PT0gJ21pc3QnXG4gICAgICA/ICdiZy1hdG1vLW1pc3QnXG4gICAgICA6IHZhcmlhbnQgPT09ICdob3Jpem9uJ1xuICAgICAgICA/ICdiZy1hdG1vLWhvcml6b24nXG4gICAgICAgIDogJ2JnLWF0bW8taGVybyc7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBhcmlhLWhpZGRlbj0ndHJ1ZSdcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICdwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LTAgb3ZlcmZsb3ctaGlkZGVuJyxcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtjbignYWJzb2x1dGUgaW5zZXQtMCcsIGJhc2UpfSAvPlxuXG4gICAgICB7LyogRGlzdGFudCBjbG91ZCBtYXNzIOKAlCB1cHBlciByaWdodCAqL31cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSAtdG9wLTI0IHJpZ2h0LVstMTAlXSBoLVs1NXZoXSB3LVs3NXZ3XSBtb3Rpb24tc2FmZTphbmltYXRlLWNsb3VkLWRyaWZ0J1xuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIG9wYWNpdHk6IHZhcmlhbnQgPT09ICdob3Jpem9uJyA/IDAuMDQgOiAwLjA2LFxuICAgICAgICAgIGJhY2tncm91bmQ6XG4gICAgICAgICAgICAncmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCA2MCUgNDAlLCBoc2woMjEwIDglIDc3JSksIHRyYW5zcGFyZW50IDY1JSknLFxuICAgICAgICAgIGZpbHRlcjogJ2JsdXIoODBweCknLFxuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAgey8qIE1pZGdyb3VuZCBjbG91ZCBiYW5kICovfVxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9J2Fic29sdXRlIGxlZnQtWy0xMCVdIHRvcC1bMzQlXSBoLVs0MnZoXSB3LVs5NXZ3XSBtb3Rpb24tc2FmZTphbmltYXRlLWNsb3VkLWRyaWZ0J1xuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIG9wYWNpdHk6IHZhcmlhbnQgPT09ICdoZXJvJyA/IDAuMDUgOiAwLjA3LFxuICAgICAgICAgIGJhY2tncm91bmQ6XG4gICAgICAgICAgICAncmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCA1MCUgNTAlLCBoc2woMjEwIDEwJSA2NiUpLCB0cmFuc3BhcmVudCA3MCUpJyxcbiAgICAgICAgICBmaWx0ZXI6ICdibHVyKDcwcHgpJyxcbiAgICAgICAgICBhbmltYXRpb25EZWxheTogJzRzJyxcbiAgICAgICAgfX1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBMb3cgc2lsdmVyIGxheWVyIHJpc2luZyB0b3dhcmQgdGhlIGhvcml6b24gKi99XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT0nYWJzb2x1dGUgaW5zZXQteC1bLTEwJV0gYm90dG9tLVstMTUlXSBoLVs0NXZoXSdcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBvcGFjaXR5OiB2YXJpYW50ID09PSAnaGVybycgPyAwLjA3IDogMC4wOCxcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDE4MGRlZywgdHJhbnNwYXJlbnQsIGhzbCgyMTAgOCUgNjYlKSknLFxuICAgICAgICAgIGZpbHRlcjogJ2JsdXIoNjBweCknLFxuICAgICAgICB9fVxuICAgICAgLz5cblxuICAgICAgey8qIEdvbGRlbiBzdW5saWdodCBuZWFyIGZvY2FsIGFyZWEgKi99XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgJ2Fic29sdXRlIGxlZnQtMS8yIGgtWzUwdmhdIHctWzcwdnddIC10cmFuc2xhdGUteC0xLzInLFxuICAgICAgICAgIHZhcmlhbnQgPT09ICdoZXJvJ1xuICAgICAgICAgICAgPyAndG9wLVs1NSVdJ1xuICAgICAgICAgICAgOiB2YXJpYW50ID09PSAnaG9yaXpvbidcbiAgICAgICAgICAgICAgPyAnYm90dG9tLVstMTUlXSdcbiAgICAgICAgICAgICAgOiAndG9wLVszMCVdJ1xuICAgICAgICApfVxuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIG9wYWNpdHk6IHZhcmlhbnQgPT09ICdob3Jpem9uJyA/IDAuMTYgOiAwLjEsXG4gICAgICAgICAgYmFja2dyb3VuZDpcbiAgICAgICAgICAgICdyYWRpYWwtZ3JhZGllbnQoY2lyY2xlLCBoc2woNDIgNTglIDY0JSksIHRyYW5zcGFyZW50IDYwJSknLFxuICAgICAgICAgIGZpbHRlcjogJ2JsdXIoOTBweCknLFxuICAgICAgICB9fVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEF0bW9zcGhlcmU7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJjbiIsIkF0bW9zcGhlcmUiLCJ2YXJpYW50IiwiY2xhc3NOYW1lIiwiYmFzZSIsImRpdiIsImFyaWEtaGlkZGVuIiwic3R5bGUiLCJvcGFjaXR5IiwiYmFja2dyb3VuZCIsImZpbHRlciIsImFuaW1hdGlvbkRlbGF5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxPQUFPQSxXQUFXLFFBQVE7QUFDMUIsU0FBU0MsRUFBRSxRQUFRLGNBQWM7QUFPakM7Ozs7Q0FJQyxHQUNELE1BQU1DLGFBQWEsQ0FBQyxFQUFFQyxVQUFVLE1BQU0sRUFBRUMsU0FBUyxFQUFtQjtJQUNsRSxNQUFNQyxPQUNKRixZQUFZLFNBQ1IsaUJBQ0FBLFlBQVksWUFDVixvQkFDQTtJQUVSLHFCQUNFLFFBQUNHO1FBQ0NDLGVBQVk7UUFDWkgsV0FBV0gsR0FDVCx3REFDQUc7OzBCQUdGLFFBQUNFO2dCQUFJRixXQUFXSCxHQUFHLG9CQUFvQkk7Ozs7OzswQkFHdkMsUUFBQ0M7Z0JBQ0NGLFdBQVU7Z0JBQ1ZJLE9BQU87b0JBQ0xDLFNBQVNOLFlBQVksWUFBWSxPQUFPO29CQUN4Q08sWUFDRTtvQkFDRkMsUUFBUTtnQkFDVjs7Ozs7OzBCQUlGLFFBQUNMO2dCQUNDRixXQUFVO2dCQUNWSSxPQUFPO29CQUNMQyxTQUFTTixZQUFZLFNBQVMsT0FBTztvQkFDckNPLFlBQ0U7b0JBQ0ZDLFFBQVE7b0JBQ1JDLGdCQUFnQjtnQkFDbEI7Ozs7OzswQkFJRixRQUFDTjtnQkFDQ0YsV0FBVTtnQkFDVkksT0FBTztvQkFDTEMsU0FBU04sWUFBWSxTQUFTLE9BQU87b0JBQ3JDTyxZQUFZO29CQUNaQyxRQUFRO2dCQUNWOzs7Ozs7MEJBSUYsUUFBQ0w7Z0JBQ0NGLFdBQVdILEdBQ1Qsd0RBQ0FFLFlBQVksU0FDUixjQUNBQSxZQUFZLFlBQ1Ysa0JBQ0E7Z0JBRVJLLE9BQU87b0JBQ0xDLFNBQVNOLFlBQVksWUFBWSxPQUFPO29CQUN4Q08sWUFDRTtvQkFDRkMsUUFBUTtnQkFDVjs7Ozs7Ozs7Ozs7O0FBSVI7S0F0RU1UO0FBd0VOLGVBQWVBLFdBQVcifQ==