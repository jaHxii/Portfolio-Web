import { MESOB_DEMO_IMAGES } from "/src/lib/mesob-demo-images.ts";
import { CAREHUB_DEMO_IMAGES, CAREHUB_MAIN_IMAGE } from "/src/lib/carehub-demo-images.ts";
import { PYTHON_SNMP_DEMO_IMAGES, PYTHON_SNMP_MAIN_IMAGE } from "/src/lib/python-snmp-demo-images.ts";
/**
 * All projects in display order.
 * Consumer pages pick the fields they need — no duplication.
 */ export const ALL_PROJECTS = [
    {
        title: 'Melala Coffee',
        description: 'A modern, responsive website for Melala Coffee Wesen - an authentic Ethiopian coffee shop in Addis Ababa - with a menu, story, gallery, and location pages. Deployed and served worldwide via Netlify.',
        category: 'Frontend',
        tech: [
            'React',
            'TypeScript',
            'Tailwind CSS',
            'Netlify'
        ],
        github: 'https://github.com/jaHxii/melala-buna-brand',
        demo: 'https://melalacoffee.netlify.app',
        image: '/melalaCoffee.webp',
        metrics: [
            'Live production site',
            'Responsive design',
            'Fast CDN delivery'
        ]
    },
    {
        title: 'KIRAY - Rental & Building Management System',
        description: 'Full-stack rental management platform built as a final year project. Handles tenant management, payment tracking, and reporting, with a relational database schema, authentication, and user role control.',
        category: 'Full Stack',
        tech: [
            'React',
            'Node.js',
            'Database',
            'Authentication'
        ],
        github: 'https://github.com/jaHxii/kiray.git',
        image: '/kiray_page.webp',
        metrics: [
            'Final Year Project',
            'Tenant, payment & reporting modules',
            'Relational database schema',
            'Authentication and role control'
        ]
    },
    {
        title: 'MESOB IT Helpdesk Ticketing System',
        description: 'Automated IT support ticketing platform for managing helpdesk workflows - issue tracking, prioritization, and lifecycle management, improving coordination between technical staff and users.',
        category: 'Full Stack',
        tech: [
            'Backend Logic',
            'Workflow Management',
            'Ticketing'
        ],
        github: 'https://github.com/jaHxii/Mesob-Help_Desk.git',
        image: '/mesob_page.webp',
        metrics: [
            'Built for enterprise IT support',
            'Issue tracking and prioritization',
            'Ticket lifecycle management',
            'Workflow automation between staff & users'
        ],
        demoImages: MESOB_DEMO_IMAGES
    },
    {
        title: 'CareHub - Healthcare Management System',
        description: 'Fullstack clinic platform handling appointments, patient records, and prescriptions with PostgreSQL-enforced conflict-free scheduling and role-based access.',
        category: 'Full Stack',
        tech: [
            'React',
            'TypeScript',
            'Node.js',
            'Express',
            'PostgreSQL',
            'JWT',
            'Docker'
        ],
        github: 'https://github.com/jaHxii/CareHub.git',
        image: CAREHUB_MAIN_IMAGE,
        metrics: [
            'End-to-end fullstack: React + Express + PostgreSQL',
            'Overlap-free scheduling via tstzrange exclusion constraint',
            'JWT + RBAC with row-level scoping',
            'Medical history as JSONB - no schema migrations'
        ],
        demoImages: CAREHUB_DEMO_IMAGES
    },
    {
        title: 'Realtime Support Ops Dashboard',
        description: 'Real-time customer support ops dashboard streaming simulated ticket activity over WebSocket, visualized with a custom D3 chart and a virtualized 10,000-row live log - with offline fallback, filters, and 15 passing tests.',
        category: 'Frontend',
        tech: [
            'React',
            'WebSocket',
            'Data Visualization'
        ],
        github: 'https://github.com/jaHxii/realtime-support-ops-dashboard.git',
        image: '/realtime-support-ops-dashboard_page.webp',
        metrics: [
            'WebSocket live ticket streaming',
            'Custom D3 data visualizations',
            'Virtualized 10,000-row live log',
            'Offline fallback + filters',
            '15 passing tests'
        ],
        demoImages: [
            '/realtime-support-ops-dashboard_page.webp'
        ]
    },
    {
        title: 'Local Network Printer Information Collector',
        description: 'Windows executable tool that scans printers on a local network, automating device discovery and configuration reporting for IT asset monitoring.',
        category: 'IT/DevOps',
        tech: [
            'Python',
            'SNMP',
            'Windows',
            'Network Scanning'
        ],
        github: 'https://github.com/jaHxii/Python-SNMP-Printer.git',
        image: PYTHON_SNMP_MAIN_IMAGE,
        metrics: [
            'SNMP-based printer discovery',
            'Automated configuration reporting',
            'Packaged as a Windows executable',
            'Built for IT asset monitoring'
        ],
        demoImages: PYTHON_SNMP_DEMO_IMAGES
    },
    {
        title: 'Sador Bar & Restaurant - Digital Menu',
        description: 'Bilingual Amharic/English digital menu for Sador Bar and Restaurant - a small frontend with separate food and drinks/bar pages, categorized sections with prices including 15% VAT, and a QR code for scanning the menu on your phone. Deployed and served via Netlify.',
        category: 'Frontend',
        tech: [
            'React',
            'TypeScript',
            'Tailwind CSS',
            'Netlify'
        ],
        demo: 'https://sador-menu.netlify.app/',
        image: '/sador-menu.webp',
        metrics: [
            'Bilingual Amharic & English UI',
            'Food and drinks/bar menu pages',
            'Prices shown with 15% VAT included',
            'QR code for phone access',
            'Live production site on Netlify'
        ]
    }
];

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3RzLWRhdGEudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTUVTT0JfREVNT19JTUFHRVMgfSBmcm9tICdAL2xpYi9tZXNvYi1kZW1vLWltYWdlcyc7XG5pbXBvcnQge1xuICBDQVJFSFVCX0RFTU9fSU1BR0VTLFxuICBDQVJFSFVCX01BSU5fSU1BR0UsXG59IGZyb20gJ0AvbGliL2NhcmVodWItZGVtby1pbWFnZXMnO1xuaW1wb3J0IHtcbiAgUFlUSE9OX1NOTVBfREVNT19JTUFHRVMsXG4gIFBZVEhPTl9TTk1QX01BSU5fSU1BR0UsXG59IGZyb20gJ0AvbGliL3B5dGhvbi1zbm1wLWRlbW8taW1hZ2VzJztcblxuZXhwb3J0IGludGVyZmFjZSBQcm9qZWN0RGF0YSB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIGNhdGVnb3J5OiBzdHJpbmc7XG4gIHRlY2g6IHN0cmluZ1tdO1xuICBnaXRodWI/OiBzdHJpbmc7XG4gIGRlbW8/OiBzdHJpbmc7XG4gIGltYWdlPzogc3RyaW5nO1xuICAvKiogRXh0ZW5kZWQgYnVsbGV0LXBvaW50IG1ldHJpY3Mgc2hvd24gb24gdGhlIFByb2plY3RzIHBhZ2UgKi9cbiAgbWV0cmljcz86IHN0cmluZ1tdO1xuICAvKiogU2NyZWVuc2hvdHMgc2hvd24gaW4gdGhlIERlbW9HYWxsZXJ5IGxpZ2h0Ym94ICovXG4gIGRlbW9JbWFnZXM/OiBzdHJpbmdbXTtcbn1cblxuLyoqXG4gKiBBbGwgcHJvamVjdHMgaW4gZGlzcGxheSBvcmRlci5cbiAqIENvbnN1bWVyIHBhZ2VzIHBpY2sgdGhlIGZpZWxkcyB0aGV5IG5lZWQg4oCUIG5vIGR1cGxpY2F0aW9uLlxuICovXG5leHBvcnQgY29uc3QgQUxMX1BST0pFQ1RTOiByZWFkb25seSBQcm9qZWN0RGF0YVtdID0gW1xuICB7XG4gICAgdGl0bGU6ICdNZWxhbGEgQ29mZmVlJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdBIG1vZGVybiwgcmVzcG9uc2l2ZSB3ZWJzaXRlIGZvciBNZWxhbGEgQ29mZmVlIFdlc2VuIC0gYW4gYXV0aGVudGljIEV0aGlvcGlhbiBjb2ZmZWUgc2hvcCBpbiBBZGRpcyBBYmFiYSAtIHdpdGggYSBtZW51LCBzdG9yeSwgZ2FsbGVyeSwgYW5kIGxvY2F0aW9uIHBhZ2VzLiBEZXBsb3llZCBhbmQgc2VydmVkIHdvcmxkd2lkZSB2aWEgTmV0bGlmeS4nLFxuICAgIGNhdGVnb3J5OiAnRnJvbnRlbmQnLFxuICAgIHRlY2g6IFsnUmVhY3QnLCAnVHlwZVNjcmlwdCcsICdUYWlsd2luZCBDU1MnLCAnTmV0bGlmeSddLFxuICAgIGdpdGh1YjogJ2h0dHBzOi8vZ2l0aHViLmNvbS9qYUh4aWkvbWVsYWxhLWJ1bmEtYnJhbmQnLFxuICAgIGRlbW86ICdodHRwczovL21lbGFsYWNvZmZlZS5uZXRsaWZ5LmFwcCcsXG4gICAgaW1hZ2U6ICcvbWVsYWxhQ29mZmVlLndlYnAnLFxuICAgIG1ldHJpY3M6IFtcbiAgICAgICdMaXZlIHByb2R1Y3Rpb24gc2l0ZScsXG4gICAgICAnUmVzcG9uc2l2ZSBkZXNpZ24nLFxuICAgICAgJ0Zhc3QgQ0ROIGRlbGl2ZXJ5JyxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgdGl0bGU6ICdLSVJBWSAtIFJlbnRhbCAmIEJ1aWxkaW5nIE1hbmFnZW1lbnQgU3lzdGVtJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdGdWxsLXN0YWNrIHJlbnRhbCBtYW5hZ2VtZW50IHBsYXRmb3JtIGJ1aWx0IGFzIGEgZmluYWwgeWVhciBwcm9qZWN0LiBIYW5kbGVzIHRlbmFudCBtYW5hZ2VtZW50LCBwYXltZW50IHRyYWNraW5nLCBhbmQgcmVwb3J0aW5nLCB3aXRoIGEgcmVsYXRpb25hbCBkYXRhYmFzZSBzY2hlbWEsIGF1dGhlbnRpY2F0aW9uLCBhbmQgdXNlciByb2xlIGNvbnRyb2wuJyxcbiAgICBjYXRlZ29yeTogJ0Z1bGwgU3RhY2snLFxuICAgIHRlY2g6IFsnUmVhY3QnLCAnTm9kZS5qcycsICdEYXRhYmFzZScsICdBdXRoZW50aWNhdGlvbiddLFxuICAgIGdpdGh1YjogJ2h0dHBzOi8vZ2l0aHViLmNvbS9qYUh4aWkva2lyYXkuZ2l0JyxcbiAgICBpbWFnZTogJy9raXJheV9wYWdlLndlYnAnLFxuICAgIG1ldHJpY3M6IFtcbiAgICAgICdGaW5hbCBZZWFyIFByb2plY3QnLFxuICAgICAgJ1RlbmFudCwgcGF5bWVudCAmIHJlcG9ydGluZyBtb2R1bGVzJyxcbiAgICAgICdSZWxhdGlvbmFsIGRhdGFiYXNlIHNjaGVtYScsXG4gICAgICAnQXV0aGVudGljYXRpb24gYW5kIHJvbGUgY29udHJvbCcsXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIHRpdGxlOiAnTUVTT0IgSVQgSGVscGRlc2sgVGlja2V0aW5nIFN5c3RlbScsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnQXV0b21hdGVkIElUIHN1cHBvcnQgdGlja2V0aW5nIHBsYXRmb3JtIGZvciBtYW5hZ2luZyBoZWxwZGVzayB3b3JrZmxvd3MgLSBpc3N1ZSB0cmFja2luZywgcHJpb3JpdGl6YXRpb24sIGFuZCBsaWZlY3ljbGUgbWFuYWdlbWVudCwgaW1wcm92aW5nIGNvb3JkaW5hdGlvbiBiZXR3ZWVuIHRlY2huaWNhbCBzdGFmZiBhbmQgdXNlcnMuJyxcbiAgICBjYXRlZ29yeTogJ0Z1bGwgU3RhY2snLFxuICAgIHRlY2g6IFsnQmFja2VuZCBMb2dpYycsICdXb3JrZmxvdyBNYW5hZ2VtZW50JywgJ1RpY2tldGluZyddLFxuICAgIGdpdGh1YjogJ2h0dHBzOi8vZ2l0aHViLmNvbS9qYUh4aWkvTWVzb2ItSGVscF9EZXNrLmdpdCcsXG4gICAgaW1hZ2U6ICcvbWVzb2JfcGFnZS53ZWJwJyxcbiAgICBtZXRyaWNzOiBbXG4gICAgICAnQnVpbHQgZm9yIGVudGVycHJpc2UgSVQgc3VwcG9ydCcsXG4gICAgICAnSXNzdWUgdHJhY2tpbmcgYW5kIHByaW9yaXRpemF0aW9uJyxcbiAgICAgICdUaWNrZXQgbGlmZWN5Y2xlIG1hbmFnZW1lbnQnLFxuICAgICAgJ1dvcmtmbG93IGF1dG9tYXRpb24gYmV0d2VlbiBzdGFmZiAmIHVzZXJzJyxcbiAgICBdLFxuICAgIGRlbW9JbWFnZXM6IE1FU09CX0RFTU9fSU1BR0VTLFxuICB9LFxuICB7XG4gICAgdGl0bGU6ICdDYXJlSHViIC0gSGVhbHRoY2FyZSBNYW5hZ2VtZW50IFN5c3RlbScsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnRnVsbHN0YWNrIGNsaW5pYyBwbGF0Zm9ybSBoYW5kbGluZyBhcHBvaW50bWVudHMsIHBhdGllbnQgcmVjb3JkcywgYW5kIHByZXNjcmlwdGlvbnMgd2l0aCBQb3N0Z3JlU1FMLWVuZm9yY2VkIGNvbmZsaWN0LWZyZWUgc2NoZWR1bGluZyBhbmQgcm9sZS1iYXNlZCBhY2Nlc3MuJyxcbiAgICBjYXRlZ29yeTogJ0Z1bGwgU3RhY2snLFxuICAgIHRlY2g6IFtcbiAgICAgICdSZWFjdCcsXG4gICAgICAnVHlwZVNjcmlwdCcsXG4gICAgICAnTm9kZS5qcycsXG4gICAgICAnRXhwcmVzcycsXG4gICAgICAnUG9zdGdyZVNRTCcsXG4gICAgICAnSldUJyxcbiAgICAgICdEb2NrZXInLFxuICAgIF0sXG4gICAgZ2l0aHViOiAnaHR0cHM6Ly9naXRodWIuY29tL2phSHhpaS9DYXJlSHViLmdpdCcsXG4gICAgaW1hZ2U6IENBUkVIVUJfTUFJTl9JTUFHRSxcbiAgICBtZXRyaWNzOiBbXG4gICAgICAnRW5kLXRvLWVuZCBmdWxsc3RhY2s6IFJlYWN0ICsgRXhwcmVzcyArIFBvc3RncmVTUUwnLFxuICAgICAgJ092ZXJsYXAtZnJlZSBzY2hlZHVsaW5nIHZpYSB0c3R6cmFuZ2UgZXhjbHVzaW9uIGNvbnN0cmFpbnQnLFxuICAgICAgJ0pXVCArIFJCQUMgd2l0aCByb3ctbGV2ZWwgc2NvcGluZycsXG4gICAgICAnTWVkaWNhbCBoaXN0b3J5IGFzIEpTT05CIC0gbm8gc2NoZW1hIG1pZ3JhdGlvbnMnLFxuICAgIF0sXG4gICAgZGVtb0ltYWdlczogQ0FSRUhVQl9ERU1PX0lNQUdFUyxcbiAgfSxcbiAge1xuICAgIHRpdGxlOiAnUmVhbHRpbWUgU3VwcG9ydCBPcHMgRGFzaGJvYXJkJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdSZWFsLXRpbWUgY3VzdG9tZXIgc3VwcG9ydCBvcHMgZGFzaGJvYXJkIHN0cmVhbWluZyBzaW11bGF0ZWQgdGlja2V0IGFjdGl2aXR5IG92ZXIgV2ViU29ja2V0LCB2aXN1YWxpemVkIHdpdGggYSBjdXN0b20gRDMgY2hhcnQgYW5kIGEgdmlydHVhbGl6ZWQgMTAsMDAwLXJvdyBsaXZlIGxvZyAtIHdpdGggb2ZmbGluZSBmYWxsYmFjaywgZmlsdGVycywgYW5kIDE1IHBhc3NpbmcgdGVzdHMuJyxcbiAgICBjYXRlZ29yeTogJ0Zyb250ZW5kJyxcbiAgICB0ZWNoOiBbJ1JlYWN0JywgJ1dlYlNvY2tldCcsICdEYXRhIFZpc3VhbGl6YXRpb24nXSxcbiAgICBnaXRodWI6ICdodHRwczovL2dpdGh1Yi5jb20vamFIeGlpL3JlYWx0aW1lLXN1cHBvcnQtb3BzLWRhc2hib2FyZC5naXQnLFxuICAgIGltYWdlOiAnL3JlYWx0aW1lLXN1cHBvcnQtb3BzLWRhc2hib2FyZF9wYWdlLndlYnAnLFxuICAgIG1ldHJpY3M6IFtcbiAgICAgICdXZWJTb2NrZXQgbGl2ZSB0aWNrZXQgc3RyZWFtaW5nJyxcbiAgICAgICdDdXN0b20gRDMgZGF0YSB2aXN1YWxpemF0aW9ucycsXG4gICAgICAnVmlydHVhbGl6ZWQgMTAsMDAwLXJvdyBsaXZlIGxvZycsXG4gICAgICAnT2ZmbGluZSBmYWxsYmFjayArIGZpbHRlcnMnLFxuICAgICAgJzE1IHBhc3NpbmcgdGVzdHMnLFxuICAgIF0sXG4gICAgZGVtb0ltYWdlczogWycvcmVhbHRpbWUtc3VwcG9ydC1vcHMtZGFzaGJvYXJkX3BhZ2Uud2VicCddLFxuICB9LFxuICB7XG4gICAgdGl0bGU6ICdMb2NhbCBOZXR3b3JrIFByaW50ZXIgSW5mb3JtYXRpb24gQ29sbGVjdG9yJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdXaW5kb3dzIGV4ZWN1dGFibGUgdG9vbCB0aGF0IHNjYW5zIHByaW50ZXJzIG9uIGEgbG9jYWwgbmV0d29yaywgYXV0b21hdGluZyBkZXZpY2UgZGlzY292ZXJ5IGFuZCBjb25maWd1cmF0aW9uIHJlcG9ydGluZyBmb3IgSVQgYXNzZXQgbW9uaXRvcmluZy4nLFxuICAgIGNhdGVnb3J5OiAnSVQvRGV2T3BzJyxcbiAgICB0ZWNoOiBbJ1B5dGhvbicsICdTTk1QJywgJ1dpbmRvd3MnLCAnTmV0d29yayBTY2FubmluZyddLFxuICAgIGdpdGh1YjogJ2h0dHBzOi8vZ2l0aHViLmNvbS9qYUh4aWkvUHl0aG9uLVNOTVAtUHJpbnRlci5naXQnLFxuICAgIGltYWdlOiBQWVRIT05fU05NUF9NQUlOX0lNQUdFLFxuICAgIG1ldHJpY3M6IFtcbiAgICAgICdTTk1QLWJhc2VkIHByaW50ZXIgZGlzY292ZXJ5JyxcbiAgICAgICdBdXRvbWF0ZWQgY29uZmlndXJhdGlvbiByZXBvcnRpbmcnLFxuICAgICAgJ1BhY2thZ2VkIGFzIGEgV2luZG93cyBleGVjdXRhYmxlJyxcbiAgICAgICdCdWlsdCBmb3IgSVQgYXNzZXQgbW9uaXRvcmluZycsXG4gICAgXSxcbiAgICBkZW1vSW1hZ2VzOiBQWVRIT05fU05NUF9ERU1PX0lNQUdFUyxcbiAgfSxcbiAge1xuICAgIHRpdGxlOiAnU2Fkb3IgQmFyICYgUmVzdGF1cmFudCAtIERpZ2l0YWwgTWVudScsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnQmlsaW5ndWFsIEFtaGFyaWMvRW5nbGlzaCBkaWdpdGFsIG1lbnUgZm9yIFNhZG9yIEJhciBhbmQgUmVzdGF1cmFudCAtIGEgc21hbGwgZnJvbnRlbmQgd2l0aCBzZXBhcmF0ZSBmb29kIGFuZCBkcmlua3MvYmFyIHBhZ2VzLCBjYXRlZ29yaXplZCBzZWN0aW9ucyB3aXRoIHByaWNlcyBpbmNsdWRpbmcgMTUlIFZBVCwgYW5kIGEgUVIgY29kZSBmb3Igc2Nhbm5pbmcgdGhlIG1lbnUgb24geW91ciBwaG9uZS4gRGVwbG95ZWQgYW5kIHNlcnZlZCB2aWEgTmV0bGlmeS4nLFxuICAgIGNhdGVnb3J5OiAnRnJvbnRlbmQnLFxuICAgIHRlY2g6IFsnUmVhY3QnLCAnVHlwZVNjcmlwdCcsICdUYWlsd2luZCBDU1MnLCAnTmV0bGlmeSddLFxuICAgIGRlbW86ICdodHRwczovL3NhZG9yLW1lbnUubmV0bGlmeS5hcHAvJyxcbiAgICBpbWFnZTogJy9zYWRvci1tZW51LndlYnAnLFxuICAgIG1ldHJpY3M6IFtcbiAgICAgICdCaWxpbmd1YWwgQW1oYXJpYyAmIEVuZ2xpc2ggVUknLFxuICAgICAgJ0Zvb2QgYW5kIGRyaW5rcy9iYXIgbWVudSBwYWdlcycsXG4gICAgICAnUHJpY2VzIHNob3duIHdpdGggMTUlIFZBVCBpbmNsdWRlZCcsXG4gICAgICAnUVIgY29kZSBmb3IgcGhvbmUgYWNjZXNzJyxcbiAgICAgICdMaXZlIHByb2R1Y3Rpb24gc2l0ZSBvbiBOZXRsaWZ5JyxcbiAgICBdLFxuICB9LFxuXSBhcyBjb25zdDtcbiJdLCJuYW1lcyI6WyJNRVNPQl9ERU1PX0lNQUdFUyIsIkNBUkVIVUJfREVNT19JTUFHRVMiLCJDQVJFSFVCX01BSU5fSU1BR0UiLCJQWVRIT05fU05NUF9ERU1PX0lNQUdFUyIsIlBZVEhPTl9TTk1QX01BSU5fSU1BR0UiLCJBTExfUFJPSkVDVFMiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiY2F0ZWdvcnkiLCJ0ZWNoIiwiZ2l0aHViIiwiZGVtbyIsImltYWdlIiwibWV0cmljcyIsImRlbW9JbWFnZXMiXSwibWFwcGluZ3MiOiJBQUFBLFNBQVNBLGlCQUFpQixRQUFRLDBCQUEwQjtBQUM1RCxTQUNFQyxtQkFBbUIsRUFDbkJDLGtCQUFrQixRQUNiLDRCQUE0QjtBQUNuQyxTQUNFQyx1QkFBdUIsRUFDdkJDLHNCQUFzQixRQUNqQixnQ0FBZ0M7QUFnQnZDOzs7Q0FHQyxHQUNELE9BQU8sTUFBTUMsZUFBdUM7SUFDbEQ7UUFDRUMsT0FBTztRQUNQQyxhQUNFO1FBQ0ZDLFVBQVU7UUFDVkMsTUFBTTtZQUFDO1lBQVM7WUFBYztZQUFnQjtTQUFVO1FBQ3hEQyxRQUFRO1FBQ1JDLE1BQU07UUFDTkMsT0FBTztRQUNQQyxTQUFTO1lBQ1A7WUFDQTtZQUNBO1NBQ0Q7SUFDSDtJQUNBO1FBQ0VQLE9BQU87UUFDUEMsYUFDRTtRQUNGQyxVQUFVO1FBQ1ZDLE1BQU07WUFBQztZQUFTO1lBQVc7WUFBWTtTQUFpQjtRQUN4REMsUUFBUTtRQUNSRSxPQUFPO1FBQ1BDLFNBQVM7WUFDUDtZQUNBO1lBQ0E7WUFDQTtTQUNEO0lBQ0g7SUFDQTtRQUNFUCxPQUFPO1FBQ1BDLGFBQ0U7UUFDRkMsVUFBVTtRQUNWQyxNQUFNO1lBQUM7WUFBaUI7WUFBdUI7U0FBWTtRQUMzREMsUUFBUTtRQUNSRSxPQUFPO1FBQ1BDLFNBQVM7WUFDUDtZQUNBO1lBQ0E7WUFDQTtTQUNEO1FBQ0RDLFlBQVlkO0lBQ2Q7SUFDQTtRQUNFTSxPQUFPO1FBQ1BDLGFBQ0U7UUFDRkMsVUFBVTtRQUNWQyxNQUFNO1lBQ0o7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7U0FDRDtRQUNEQyxRQUFRO1FBQ1JFLE9BQU9WO1FBQ1BXLFNBQVM7WUFDUDtZQUNBO1lBQ0E7WUFDQTtTQUNEO1FBQ0RDLFlBQVliO0lBQ2Q7SUFDQTtRQUNFSyxPQUFPO1FBQ1BDLGFBQ0U7UUFDRkMsVUFBVTtRQUNWQyxNQUFNO1lBQUM7WUFBUztZQUFhO1NBQXFCO1FBQ2xEQyxRQUFRO1FBQ1JFLE9BQU87UUFDUEMsU0FBUztZQUNQO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7U0FDRDtRQUNEQyxZQUFZO1lBQUM7U0FBNEM7SUFDM0Q7SUFDQTtRQUNFUixPQUFPO1FBQ1BDLGFBQ0U7UUFDRkMsVUFBVTtRQUNWQyxNQUFNO1lBQUM7WUFBVTtZQUFRO1lBQVc7U0FBbUI7UUFDdkRDLFFBQVE7UUFDUkUsT0FBT1I7UUFDUFMsU0FBUztZQUNQO1lBQ0E7WUFDQTtZQUNBO1NBQ0Q7UUFDREMsWUFBWVg7SUFDZDtJQUNBO1FBQ0VHLE9BQU87UUFDUEMsYUFDRTtRQUNGQyxVQUFVO1FBQ1ZDLE1BQU07WUFBQztZQUFTO1lBQWM7WUFBZ0I7U0FBVTtRQUN4REUsTUFBTTtRQUNOQyxPQUFPO1FBQ1BDLFNBQVM7WUFDUDtZQUNBO1lBQ0E7WUFDQTtZQUNBO1NBQ0Q7SUFDSDtDQUNELENBQVUifQ==