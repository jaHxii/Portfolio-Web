import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Projects.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/pages/Projects.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s1 = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useMemo = __vite__cjsImport2_react["useMemo"]; const useState = __vite__cjsImport2_react["useState"];
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { useInView } from "/node_modules/.vite/deps/react-intersection-observer.js?v=e72f996b";
import { ExternalLink, Search } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Card, CardContent } from "/src/components/ui/card.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import Navigation from "/src/components/layout/Navigation.tsx";
import Footer from "/src/components/layout/Footer.tsx";
import Atmosphere from "/src/components/atmosphere/Atmosphere.tsx";
import FlightLog from "/src/components/ui/flight-log.tsx";
import ConfirmCodeLink from "/src/components/ui/confirm-code-link.tsx";
import SEO from "/src/components/seo/SEO.tsx";
import StructuredData from "/src/components/seo/StructuredData.tsx";
import { useSEO } from "/src/hooks/use-seo.ts";
import { useStructuredData } from "/src/hooks/use-structured-data.ts";
import DemoGallery from "/src/components/sections/DemoGallery.tsx";
import { ALL_PROJECTS } from "/src/lib/projects-data.ts";
const CATEGORIES = [
    'All',
    'Frontend',
    'Full Stack',
    'IT/DevOps'
];
const ALTITUDE_LAYERS = [
    'FOUNDATION',
    'SYSTEMS',
    'NETWORK',
    'INTELLIGENCE',
    'APPLICATIONS',
    'PLATFORM'
];
const Projects = ()=>{
    _s();
    const seoProps = useSEO();
    const [searchQuery, setSearchQuery] = useState('');
    const [activeCategory, setActiveCategory] = useState('All');
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    });
    const projects = useMemo(()=>[
            ...ALL_PROJECTS
        ], []);
    // Filter and search projects
    const filteredProjects = useMemo(()=>{
        return projects.filter((project)=>{
            const matchesCategory = activeCategory === 'All' || project.category === activeCategory;
            const query = searchQuery.toLowerCase().trim();
            const matchesSearch = query === '' || project.title.toLowerCase().includes(query) || project.description.toLowerCase().includes(query) || project.tech.some((tech)=>tech.toLowerCase().includes(query));
            return matchesCategory && matchesSearch;
        });
    }, [
        projects,
        activeCategory,
        searchQuery
    ]);
    // Prepare project data for structured data
    const projectsForSchema = projects.map((project)=>({
            name: project.title,
            description: project.description,
            ...project.demo ? {
                url: project.demo
            } : {},
            ...project.image ? {
                image: project.image
            } : {},
            keywords: project.tech,
            programmingLanguage: project.tech,
            ...project.github ? {
                codeRepository: project.github
            } : {}
        }));
    const { breadcrumbSchema, projectSchemas } = useStructuredData({
        projects: projectsForSchema
    });
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "min-h-screen bg-background",
        children: [
            /*#__PURE__*/ _jsxDEV(SEO, {
                ...seoProps
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(StructuredData, {
                schema: breadcrumbSchema
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            projectSchemas?.map((schema, index)=>/*#__PURE__*/ _jsxDEV(StructuredData, {
                    schema: schema
                }, index, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                    lineNumber: 79,
                    columnNumber: 9
                }, this)),
            /*#__PURE__*/ _jsxDEV(Navigation, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("section", {
                className: "relative pt-36 pb-20 overflow-hidden",
                children: [
                    /*#__PURE__*/ _jsxDEV(Atmosphere, {}, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "relative z-10 container mx-auto px-4",
                        children: /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.8
                            },
                            className: "text-center max-w-3xl mx-auto",
                            children: [
                                /*#__PURE__*/ _jsxDEV(FlightLog, {
                                    entries: [
                                        'FLIGHT LOG / SELECTED WORK',
                                        'WAYPOINT 04 · NORTH-WEST',
                                        'ALTITUDE 28,000 FT · STABLE',
                                        'CRUISING · SYSTEMS NOMINAL'
                                    ]
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                    lineNumber: 93,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("h1", {
                                    className: "text-4xl md:text-6xl font-bold font-heading tracking-tight leading-tight",
                                    children: /*#__PURE__*/ _jsxDEV("span", {
                                        className: "name-gradient",
                                        children: "Projects"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 102,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                    lineNumber: 101,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "mt-5 text-lg text-mist-soft leading-relaxed font-light",
                                    children: "Systems, dashboards, and websites designed and built - each a different altitude layer in an engineering climb."
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                    lineNumber: 104,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                            lineNumber: 87,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                lineNumber: 84,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("section", {
                className: "relative py-8",
                children: /*#__PURE__*/ _jsxDEV("div", {
                    className: "container mx-auto px-4 max-w-6xl",
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex flex-col md:flex-row gap-4 items-center justify-between mb-10",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "flex flex-wrap gap-2 justify-center",
                                children: CATEGORIES.map((category)=>/*#__PURE__*/ _jsxDEV("button", {
                                        onClick: ()=>setActiveCategory(category),
                                        className: `px-4 py-2 text-sm font-medium rounded-md transition-all duration-300 border ${activeCategory === category ? 'bg-gold/15 text-gold border-gold/50' : 'glass border-transparent text-mist-soft hover:border-gold/40 hover:text-foreground'}`,
                                        children: category
                                    }, category, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 118,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 116,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "relative w-full md:w-72",
                                children: [
                                    /*#__PURE__*/ _jsxDEV(Search, {
                                        className: "absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-mist-soft"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 132,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV(Input, {
                                        type: "text",
                                        placeholder: "Search projects...",
                                        value: searchQuery,
                                        onChange: (e)=>setSearchQuery(e.target.value),
                                        className: "pl-10 bg-white/[0.02] border-border focus:border-gold/50",
                                        "aria-label": "Search projects"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 133,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 131,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                        lineNumber: 115,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                    lineNumber: 114,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                lineNumber: 113,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("section", {
                className: "relative py-16 overflow-hidden",
                children: [
                    /*#__PURE__*/ _jsxDEV(Atmosphere, {
                        variant: "mist",
                        className: "opacity-70"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                        lineNumber: 148,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "relative z-10 container mx-auto px-4 max-w-6xl",
                        children: [
                            /*#__PURE__*/ _jsxDEV(motion.div, {
                                ref: ref,
                                initial: {
                                    opacity: 0,
                                    y: 30
                                },
                                animate: inView ? {
                                    opacity: 1,
                                    y: 0
                                } : {},
                                transition: {
                                    duration: 0.8
                                },
                                className: "grid md:grid-cols-2 gap-8",
                                children: filteredProjects.map((project)=>/*#__PURE__*/ _jsxDEV(ProjectCard, {
                                        project: project,
                                        layer: ALTITUDE_LAYERS[projects.indexOf(project)] ?? 'SECTOR',
                                        number: projects.indexOf(project) + 1
                                    }, project.title, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 158,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 150,
                                columnNumber: 11
                            }, this),
                            filteredProjects.length === 0 && /*#__PURE__*/ _jsxDEV("div", {
                                className: "text-center py-16 text-mist-soft",
                                children: "No projects match your search."
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 170,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                        lineNumber: 149,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                lineNumber: 147,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(Footer, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                lineNumber: 176,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
};
_s(Projects, "4Gu0MP1YV439xfDpRiMUgDfQFf8=", false, function() {
    return [
        useSEO,
        useInView,
        useStructuredData
    ];
});
_c = Projects;
const ProjectCard = ({ project, layer, number })=>{
    _s1();
    const [demoOpen, setDemoOpen] = useState(false);
    return /*#__PURE__*/ _jsxDEV(motion.div, {
        initial: {
            opacity: 0,
            y: 24
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            duration: 0.6
        },
        className: "group",
        children: [
            /*#__PURE__*/ _jsxDEV(Card, {
                className: "glass-cloud h-full flex flex-col overflow-hidden rounded-2xl transition-all duration-300 group-hover:shadow-glow-strong",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "px-7 pt-7 pb-5 flex items-center justify-between border-b border-white/5",
                        children: [
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "font-mono text-sm tracking-[0.25em] gold-text",
                                children: String(number).padStart(2, '0')
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 202,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("span", {
                                className: "font-mono text-[10px] tracking-[0.3em] text-mist-soft/60",
                                children: layer
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 205,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                        lineNumber: 201,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(CardContent, {
                        className: "p-7 flex-1 flex flex-col",
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "relative overflow-hidden rounded-lg mb-6",
                                children: [
                                    project.image ? /*#__PURE__*/ _jsxDEV("img", {
                                        src: project.image,
                                        alt: project.title,
                                        className: "w-full h-44 object-cover group-hover:scale-105 transition-transform duration-500"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 214,
                                        columnNumber: 15
                                    }, this) : /*#__PURE__*/ _jsxDEV("div", {
                                        className: "w-full h-44 bg-gradient-to-br from-storm via-background to-background flex items-center justify-center",
                                        children: /*#__PURE__*/ _jsxDEV("span", {
                                            className: "text-6xl font-heading font-bold gold-text/70",
                                            children: project.title.charAt(0)
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                            lineNumber: 221,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 220,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "absolute top-3 left-3",
                                        children: /*#__PURE__*/ _jsxDEV("span", {
                                            className: "px-3 py-1 rounded-md border border-gold/40 bg-background/70 backdrop-blur-sm text-xs font-mono text-gold",
                                            children: project.category
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                            lineNumber: 227,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 226,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        "aria-hidden": "true",
                                        className: "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none",
                                        style: {
                                            background: 'radial-gradient(circle at 70% 30%, hsl(42 58% 64% / 0.12), transparent 55%)'
                                        }
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 232,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 212,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("h3", {
                                className: "font-heading font-bold text-xl tracking-tight mb-3",
                                children: project.title
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 242,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("p", {
                                className: "text-mist-soft leading-relaxed text-sm flex-1 mb-6",
                                children: project.description
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 245,
                                columnNumber: 11
                            }, this),
                            project.metrics && /*#__PURE__*/ _jsxDEV("div", {
                                className: "space-y-2 mb-6",
                                children: project.metrics.map((metric, i)=>/*#__PURE__*/ _jsxDEV("div", {
                                        className: "flex items-center gap-2.5 text-sm",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("div", {
                                                className: "w-1 h-1 bg-gold rounded-full"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                                lineNumber: 254,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "text-foreground/80",
                                                children: metric
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                                lineNumber: 255,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, i, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 253,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 251,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "flex flex-wrap gap-2 mb-7",
                                children: project.tech.map((tech)=>/*#__PURE__*/ _jsxDEV("span", {
                                        className: "glass rounded-md px-2.5 py-1 font-mono text-xs text-mist-soft",
                                        children: tech
                                    }, tech, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 264,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 262,
                                columnNumber: 11
                            }, this),
                            (project.github || project.demo || project.demoImages) && /*#__PURE__*/ _jsxDEV("div", {
                                className: "flex gap-3 pt-1 mt-auto",
                                children: [
                                    project.github && /*#__PURE__*/ _jsxDEV(ConfirmCodeLink, {
                                        href: project.github,
                                        projectName: project.title,
                                        className: "glass flex-1 text-mist-soft hover:border-gold/60"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 277,
                                        columnNumber: 17
                                    }, this),
                                    project.demoImages ? /*#__PURE__*/ _jsxDEV(Button, {
                                        size: "sm",
                                        className: "flex-1 bg-mist text-storm-deep hover:bg-mist/90",
                                        onClick: ()=>setDemoOpen(true),
                                        children: [
                                            /*#__PURE__*/ _jsxDEV(ExternalLink, {
                                                className: "h-4 w-4 mr-2"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                                lineNumber: 289,
                                                columnNumber: 19
                                            }, this),
                                            "Demo"
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 284,
                                        columnNumber: 17
                                    }, this) : project.demo && /*#__PURE__*/ _jsxDEV(Button, {
                                        size: "sm",
                                        className: "flex-1 bg-mist text-storm-deep hover:bg-mist/90",
                                        asChild: true,
                                        children: /*#__PURE__*/ _jsxDEV("a", {
                                            href: project.demo,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV(ExternalLink, {
                                                    className: "h-4 w-4 mr-2"
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                                    lineNumber: 304,
                                                    columnNumber: 23
                                                }, this),
                                                "Demo"
                                            ]
                                        }, void 0, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                            lineNumber: 299,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                        lineNumber: 294,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                                lineNumber: 275,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                        lineNumber: 210,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                lineNumber: 199,
                columnNumber: 7
            }, this),
            project.demoImages && /*#__PURE__*/ _jsxDEV(DemoGallery, {
                open: demoOpen,
                onOpenChange: setDemoOpen,
                title: project.title,
                images: project.demoImages
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
                lineNumber: 315,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/Projects.tsx",
        lineNumber: 193,
        columnNumber: 5
    }, this);
};
_s1(ProjectCard, "4ng6odNWQ+tDewqubbTZv364jEM=");
_c1 = ProjectCard;
export default Projects;
var _c, _c1;
$RefreshReg$(_c, "Projects");
$RefreshReg$(_c1, "ProjectCard");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/pages/Projects.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/pages/Projects.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlByb2plY3RzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IHVzZUluVmlldyB9IGZyb20gJ3JlYWN0LWludGVyc2VjdGlvbi1vYnNlcnZlcic7XG5pbXBvcnQgeyBFeHRlcm5hbExpbmssIFNlYXJjaCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9jYXJkJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnO1xuaW1wb3J0IE5hdmlnYXRpb24gZnJvbSAnQC9jb21wb25lbnRzL2xheW91dC9OYXZpZ2F0aW9uJztcbmltcG9ydCBGb290ZXIgZnJvbSAnQC9jb21wb25lbnRzL2xheW91dC9Gb290ZXInO1xuaW1wb3J0IEF0bW9zcGhlcmUgZnJvbSAnQC9jb21wb25lbnRzL2F0bW9zcGhlcmUvQXRtb3NwaGVyZSc7XG5pbXBvcnQgRmxpZ2h0TG9nIGZyb20gJ0AvY29tcG9uZW50cy91aS9mbGlnaHQtbG9nJztcbmltcG9ydCBDb25maXJtQ29kZUxpbmsgZnJvbSAnQC9jb21wb25lbnRzL3VpL2NvbmZpcm0tY29kZS1saW5rJztcbmltcG9ydCBTRU8gZnJvbSAnQC9jb21wb25lbnRzL3Nlby9TRU8nO1xuaW1wb3J0IFN0cnVjdHVyZWREYXRhIGZyb20gJ0AvY29tcG9uZW50cy9zZW8vU3RydWN0dXJlZERhdGEnO1xuaW1wb3J0IHsgdXNlU0VPIH0gZnJvbSAnQC9ob29rcy91c2Utc2VvJztcbmltcG9ydCB7IHVzZVN0cnVjdHVyZWREYXRhIH0gZnJvbSAnQC9ob29rcy91c2Utc3RydWN0dXJlZC1kYXRhJztcbmltcG9ydCBEZW1vR2FsbGVyeSBmcm9tICdAL2NvbXBvbmVudHMvc2VjdGlvbnMvRGVtb0dhbGxlcnknO1xuaW1wb3J0IHsgQUxMX1BST0pFQ1RTLCB0eXBlIFByb2plY3REYXRhIH0gZnJvbSAnQC9saWIvcHJvamVjdHMtZGF0YSc7XG5cbmNvbnN0IENBVEVHT1JJRVMgPSBbJ0FsbCcsICdGcm9udGVuZCcsICdGdWxsIFN0YWNrJywgJ0lUL0Rldk9wcyddO1xuXG5jb25zdCBBTFRJVFVERV9MQVlFUlMgPSBbXG4gICdGT1VOREFUSU9OJyxcbiAgJ1NZU1RFTVMnLFxuICAnTkVUV09SSycsXG4gICdJTlRFTExJR0VOQ0UnLFxuICAnQVBQTElDQVRJT05TJyxcbiAgJ1BMQVRGT1JNJyxcbl07XG5cbmNvbnN0IFByb2plY3RzID0gKCkgPT4ge1xuICBjb25zdCBzZW9Qcm9wcyA9IHVzZVNFTygpO1xuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2FjdGl2ZUNhdGVnb3J5LCBzZXRBY3RpdmVDYXRlZ29yeV0gPSB1c2VTdGF0ZSgnQWxsJyk7XG5cbiAgY29uc3QgW3JlZiwgaW5WaWV3XSA9IHVzZUluVmlldyh7XG4gICAgdHJpZ2dlck9uY2U6IHRydWUsXG4gICAgdGhyZXNob2xkOiAwLjEsXG4gIH0pO1xuXG4gIGNvbnN0IHByb2plY3RzOiBQcm9qZWN0RGF0YVtdID0gdXNlTWVtbygoKSA9PiBbLi4uQUxMX1BST0pFQ1RTXSwgW10pO1xuXG4gIC8vIEZpbHRlciBhbmQgc2VhcmNoIHByb2plY3RzXG4gIGNvbnN0IGZpbHRlcmVkUHJvamVjdHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gcHJvamVjdHMuZmlsdGVyKHByb2plY3QgPT4ge1xuICAgICAgY29uc3QgbWF0Y2hlc0NhdGVnb3J5ID1cbiAgICAgICAgYWN0aXZlQ2F0ZWdvcnkgPT09ICdBbGwnIHx8IHByb2plY3QuY2F0ZWdvcnkgPT09IGFjdGl2ZUNhdGVnb3J5O1xuICAgICAgY29uc3QgcXVlcnkgPSBzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcbiAgICAgIGNvbnN0IG1hdGNoZXNTZWFyY2ggPVxuICAgICAgICBxdWVyeSA9PT0gJycgfHxcbiAgICAgICAgcHJvamVjdC50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSB8fFxuICAgICAgICBwcm9qZWN0LmRlc2NyaXB0aW9uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnkpIHx8XG4gICAgICAgIHByb2plY3QudGVjaC5zb21lKHRlY2ggPT4gdGVjaC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSk7XG5cbiAgICAgIHJldHVybiBtYXRjaGVzQ2F0ZWdvcnkgJiYgbWF0Y2hlc1NlYXJjaDtcbiAgICB9KTtcbiAgfSwgW3Byb2plY3RzLCBhY3RpdmVDYXRlZ29yeSwgc2VhcmNoUXVlcnldKTtcblxuICAvLyBQcmVwYXJlIHByb2plY3QgZGF0YSBmb3Igc3RydWN0dXJlZCBkYXRhXG4gIGNvbnN0IHByb2plY3RzRm9yU2NoZW1hID0gcHJvamVjdHMubWFwKHByb2plY3QgPT4gKHtcbiAgICBuYW1lOiBwcm9qZWN0LnRpdGxlLFxuICAgIGRlc2NyaXB0aW9uOiBwcm9qZWN0LmRlc2NyaXB0aW9uLFxuICAgIC4uLihwcm9qZWN0LmRlbW8gPyB7IHVybDogcHJvamVjdC5kZW1vIH0gOiB7fSksXG4gICAgLi4uKHByb2plY3QuaW1hZ2UgPyB7IGltYWdlOiBwcm9qZWN0LmltYWdlIH0gOiB7fSksXG4gICAga2V5d29yZHM6IHByb2plY3QudGVjaCxcbiAgICBwcm9ncmFtbWluZ0xhbmd1YWdlOiBwcm9qZWN0LnRlY2gsXG4gICAgLi4uKHByb2plY3QuZ2l0aHViID8geyBjb2RlUmVwb3NpdG9yeTogcHJvamVjdC5naXRodWIgfSA6IHt9KSxcbiAgfSkpO1xuXG4gIGNvbnN0IHsgYnJlYWRjcnVtYlNjaGVtYSwgcHJvamVjdFNjaGVtYXMgfSA9IHVzZVN0cnVjdHVyZWREYXRhKHtcbiAgICBwcm9qZWN0czogcHJvamVjdHNGb3JTY2hlbWEsXG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9J21pbi1oLXNjcmVlbiBiZy1iYWNrZ3JvdW5kJz5cbiAgICAgIDxTRU8gey4uLnNlb1Byb3BzfSAvPlxuICAgICAgPFN0cnVjdHVyZWREYXRhIHNjaGVtYT17YnJlYWRjcnVtYlNjaGVtYX0gLz5cbiAgICAgIHtwcm9qZWN0U2NoZW1hcz8ubWFwKChzY2hlbWEsIGluZGV4KSA9PiAoXG4gICAgICAgIDxTdHJ1Y3R1cmVkRGF0YSBrZXk9e2luZGV4fSBzY2hlbWE9e3NjaGVtYX0gLz5cbiAgICAgICkpfVxuICAgICAgPE5hdmlnYXRpb24gLz5cblxuICAgICAgey8qIEhlcm8gKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9J3JlbGF0aXZlIHB0LTM2IHBiLTIwIG92ZXJmbG93LWhpZGRlbic+XG4gICAgICAgIDxBdG1vc3BoZXJlIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdyZWxhdGl2ZSB6LTEwIGNvbnRhaW5lciBteC1hdXRvIHB4LTQnPlxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDMwIH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuOCB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPSd0ZXh0LWNlbnRlciBtYXgtdy0zeGwgbXgtYXV0bydcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RmxpZ2h0TG9nXG4gICAgICAgICAgICAgIGVudHJpZXM9e1tcbiAgICAgICAgICAgICAgICAnRkxJR0hUIExPRyAvIFNFTEVDVEVEIFdPUksnLFxuICAgICAgICAgICAgICAgICdXQVlQT0lOVCAwNCDCtyBOT1JUSC1XRVNUJyxcbiAgICAgICAgICAgICAgICAnQUxUSVRVREUgMjgsMDAwIEZUIMK3IFNUQUJMRScsXG4gICAgICAgICAgICAgICAgJ0NSVUlTSU5HIMK3IFNZU1RFTVMgTk9NSU5BTCcsXG4gICAgICAgICAgICAgIF19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT0ndGV4dC00eGwgbWQ6dGV4dC02eGwgZm9udC1ib2xkIGZvbnQtaGVhZGluZyB0cmFja2luZy10aWdodCBsZWFkaW5nLXRpZ2h0Jz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSduYW1lLWdyYWRpZW50Jz5Qcm9qZWN0czwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9J210LTUgdGV4dC1sZyB0ZXh0LW1pc3Qtc29mdCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1saWdodCc+XG4gICAgICAgICAgICAgIFN5c3RlbXMsIGRhc2hib2FyZHMsIGFuZCB3ZWJzaXRlcyBkZXNpZ25lZCBhbmQgYnVpbHQgLSBlYWNoIGFcbiAgICAgICAgICAgICAgZGlmZmVyZW50IGFsdGl0dWRlIGxheWVyIGluIGFuIGVuZ2luZWVyaW5nIGNsaW1iLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiBTZWFyY2ggJiBGaWx0ZXIgKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9J3JlbGF0aXZlIHB5LTgnPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nY29udGFpbmVyIG14LWF1dG8gcHgtNCBtYXgtdy02eGwnPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGdhcC00IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMTAnPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggZmxleC13cmFwIGdhcC0yIGp1c3RpZnktY2VudGVyJz5cbiAgICAgICAgICAgICAge0NBVEVHT1JJRVMubWFwKGNhdGVnb3J5ID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2NhdGVnb3J5fVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlQ2F0ZWdvcnkoY2F0ZWdvcnkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gcm91bmRlZC1tZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYm9yZGVyICR7XG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZUNhdGVnb3J5ID09PSBjYXRlZ29yeVxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWdvbGQvMTUgdGV4dC1nb2xkIGJvcmRlci1nb2xkLzUwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2dsYXNzIGJvcmRlci10cmFuc3BhcmVudCB0ZXh0LW1pc3Qtc29mdCBob3Zlcjpib3JkZXItZ29sZC80MCBob3Zlcjp0ZXh0LWZvcmVncm91bmQnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncmVsYXRpdmUgdy1mdWxsIG1kOnctNzInPlxuICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT0nYWJzb2x1dGUgbGVmdC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBoLTQgdy00IHRleHQtbWlzdC1zb2Z0JyAvPlxuICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPSd0ZXh0J1xuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPSdTZWFyY2ggcHJvamVjdHMuLi4nXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFF1ZXJ5fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9J3BsLTEwIGJnLXdoaXRlL1swLjAyXSBib3JkZXItYm9yZGVyIGZvY3VzOmJvcmRlci1nb2xkLzUwJ1xuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9J1NlYXJjaCBwcm9qZWN0cydcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgey8qIFByb2plY3RzIEdyaWQgKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9J3JlbGF0aXZlIHB5LTE2IG92ZXJmbG93LWhpZGRlbic+XG4gICAgICAgIDxBdG1vc3BoZXJlIHZhcmlhbnQ9J21pc3QnIGNsYXNzTmFtZT0nb3BhY2l0eS03MCcgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J3JlbGF0aXZlIHotMTAgY29udGFpbmVyIG14LWF1dG8gcHgtNCBtYXgtdy02eGwnPlxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICByZWY9e3JlZn1cbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMzAgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e2luVmlldyA/IHsgb3BhY2l0eTogMSwgeTogMCB9IDoge319XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjggfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT0nZ3JpZCBtZDpncmlkLWNvbHMtMiBnYXAtOCdcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7ZmlsdGVyZWRQcm9qZWN0cy5tYXAocHJvamVjdCA9PiAoXG4gICAgICAgICAgICAgIDxQcm9qZWN0Q2FyZFxuICAgICAgICAgICAgICAgIGtleT17cHJvamVjdC50aXRsZX1cbiAgICAgICAgICAgICAgICBwcm9qZWN0PXtwcm9qZWN0fVxuICAgICAgICAgICAgICAgIGxheWVyPXtcbiAgICAgICAgICAgICAgICAgIEFMVElUVURFX0xBWUVSU1twcm9qZWN0cy5pbmRleE9mKHByb2plY3QpXSA/PyAnU0VDVE9SJ1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBudW1iZXI9e3Byb2plY3RzLmluZGV4T2YocHJvamVjdCkgKyAxfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICAgICAge2ZpbHRlcmVkUHJvamVjdHMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd0ZXh0LWNlbnRlciBweS0xNiB0ZXh0LW1pc3Qtc29mdCc+XG4gICAgICAgICAgICAgIE5vIHByb2plY3RzIG1hdGNoIHlvdXIgc2VhcmNoLlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgICA8Rm9vdGVyIC8+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5jb25zdCBQcm9qZWN0Q2FyZCA9ICh7XG4gIHByb2plY3QsXG4gIGxheWVyLFxuICBudW1iZXIsXG59OiB7XG4gIHByb2plY3Q6IFByb2plY3REYXRhO1xuICBsYXllcjogc3RyaW5nO1xuICBudW1iZXI6IG51bWJlcjtcbn0pID0+IHtcbiAgY29uc3QgW2RlbW9PcGVuLCBzZXREZW1vT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgcmV0dXJuIChcbiAgICA8bW90aW9uLmRpdlxuICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAyNCB9fVxuICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjYgfX1cbiAgICAgIGNsYXNzTmFtZT0nZ3JvdXAnXG4gICAgPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPSdnbGFzcy1jbG91ZCBoLWZ1bGwgZmxleCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGdyb3VwLWhvdmVyOnNoYWRvdy1nbG93LXN0cm9uZyc+XG4gICAgICAgIHsvKiBBbHRpdHVkZSBoZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdweC03IHB0LTcgcGItNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXdoaXRlLzUnPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQtc20gdHJhY2tpbmctWzAuMjVlbV0gZ29sZC10ZXh0Jz5cbiAgICAgICAgICAgIHtTdHJpbmcobnVtYmVyKS5wYWRTdGFydCgyLCAnMCcpfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LVsxMHB4XSB0cmFja2luZy1bMC4zZW1dIHRleHQtbWlzdC1zb2Z0LzYwJz5cbiAgICAgICAgICAgIHtsYXllcn1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9J3AtNyBmbGV4LTEgZmxleCBmbGV4LWNvbCc+XG4gICAgICAgICAgey8qIFByb2plY3QgSW1hZ2UgLyBQbGFjZWhvbGRlciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbGcgbWItNic+XG4gICAgICAgICAgICB7cHJvamVjdC5pbWFnZSA/IChcbiAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgIHNyYz17cHJvamVjdC5pbWFnZX1cbiAgICAgICAgICAgICAgICBhbHQ9e3Byb2plY3QudGl0bGV9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPSd3LWZ1bGwgaC00NCBvYmplY3QtY292ZXIgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTUwMCdcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd3LWZ1bGwgaC00NCBiZy1ncmFkaWVudC10by1iciBmcm9tLXN0b3JtIHZpYS1iYWNrZ3JvdW5kIHRvLWJhY2tncm91bmQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXInPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0ndGV4dC02eGwgZm9udC1oZWFkaW5nIGZvbnQtYm9sZCBnb2xkLXRleHQvNzAnPlxuICAgICAgICAgICAgICAgICAge3Byb2plY3QudGl0bGUuY2hhckF0KDApfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Fic29sdXRlIHRvcC0zIGxlZnQtMyc+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0ncHgtMyBweS0xIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1nb2xkLzQwIGJnLWJhY2tncm91bmQvNzAgYmFja2Ryb3AtYmx1ci1zbSB0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWdvbGQnPlxuICAgICAgICAgICAgICAgIHtwcm9qZWN0LmNhdGVnb3J5fVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHsvKiBjbG91ZC9saWdodCB0ZXh0dXJlIG9uIGhvdmVyICovfVxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBhcmlhLWhpZGRlbj0ndHJ1ZSdcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSBpbnNldC0wIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tNTAwIHBvaW50ZXItZXZlbnRzLW5vbmUnXG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDpcbiAgICAgICAgICAgICAgICAgICdyYWRpYWwtZ3JhZGllbnQoY2lyY2xlIGF0IDcwJSAzMCUsIGhzbCg0MiA1OCUgNjQlIC8gMC4xMiksIHRyYW5zcGFyZW50IDU1JSknLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9J2ZvbnQtaGVhZGluZyBmb250LWJvbGQgdGV4dC14bCB0cmFja2luZy10aWdodCBtYi0zJz5cbiAgICAgICAgICAgIHtwcm9qZWN0LnRpdGxlfVxuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPSd0ZXh0LW1pc3Qtc29mdCBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1zbSBmbGV4LTEgbWItNic+XG4gICAgICAgICAgICB7cHJvamVjdC5kZXNjcmlwdGlvbn1cbiAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICB7LyogTWV0cmljcyAqL31cbiAgICAgICAgICB7cHJvamVjdC5tZXRyaWNzICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdzcGFjZS15LTIgbWItNic+XG4gICAgICAgICAgICAgIHtwcm9qZWN0Lm1ldHJpY3MubWFwKChtZXRyaWMsIGkpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPSdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHRleHQtc20nPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3ctMSBoLTEgYmctZ29sZCByb3VuZGVkLWZ1bGwnIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J3RleHQtZm9yZWdyb3VuZC84MCc+e21ldHJpY308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBUZWNoIFN0YWNrICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGZsZXgtd3JhcCBnYXAtMiBtYi03Jz5cbiAgICAgICAgICAgIHtwcm9qZWN0LnRlY2gubWFwKHRlY2ggPT4gKFxuICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgIGtleT17dGVjaH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2dsYXNzIHJvdW5kZWQtbWQgcHgtMi41IHB5LTEgZm9udC1tb25vIHRleHQteHMgdGV4dC1taXN0LXNvZnQnXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7dGVjaH1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogTGlua3MgKi99XG4gICAgICAgICAgeyhwcm9qZWN0LmdpdGh1YiB8fCBwcm9qZWN0LmRlbW8gfHwgcHJvamVjdC5kZW1vSW1hZ2VzKSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBnYXAtMyBwdC0xIG10LWF1dG8nPlxuICAgICAgICAgICAgICB7cHJvamVjdC5naXRodWIgJiYgKFxuICAgICAgICAgICAgICAgIDxDb25maXJtQ29kZUxpbmtcbiAgICAgICAgICAgICAgICAgIGhyZWY9e3Byb2plY3QuZ2l0aHVifVxuICAgICAgICAgICAgICAgICAgcHJvamVjdE5hbWU9e3Byb2plY3QudGl0bGV9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2dsYXNzIGZsZXgtMSB0ZXh0LW1pc3Qtc29mdCBob3Zlcjpib3JkZXItZ29sZC82MCdcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICB7cHJvamVjdC5kZW1vSW1hZ2VzID8gKFxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHNpemU9J3NtJ1xuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdmbGV4LTEgYmctbWlzdCB0ZXh0LXN0b3JtLWRlZXAgaG92ZXI6YmctbWlzdC85MCdcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldERlbW9PcGVuKHRydWUpfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPSdoLTQgdy00IG1yLTInIC8+XG4gICAgICAgICAgICAgICAgICBEZW1vXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgcHJvamVjdC5kZW1vICYmIChcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgc2l6ZT0nc20nXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZmxleC0xIGJnLW1pc3QgdGV4dC1zdG9ybS1kZWVwIGhvdmVyOmJnLW1pc3QvOTAnXG4gICAgICAgICAgICAgICAgICAgIGFzQ2hpbGRcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPXtwcm9qZWN0LmRlbW99XG4gICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PSdfYmxhbmsnXG4gICAgICAgICAgICAgICAgICAgICAgcmVsPSdub29wZW5lciBub3JlZmVycmVyJ1xuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPEV4dGVybmFsTGluayBjbGFzc05hbWU9J2gtNCB3LTQgbXItMicgLz5cbiAgICAgICAgICAgICAgICAgICAgICBEZW1vXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICA8L0NhcmQ+XG4gICAgICB7cHJvamVjdC5kZW1vSW1hZ2VzICYmIChcbiAgICAgICAgPERlbW9HYWxsZXJ5XG4gICAgICAgICAgb3Blbj17ZGVtb09wZW59XG4gICAgICAgICAgb25PcGVuQ2hhbmdlPXtzZXREZW1vT3Blbn1cbiAgICAgICAgICB0aXRsZT17cHJvamVjdC50aXRsZX1cbiAgICAgICAgICBpbWFnZXM9e3Byb2plY3QuZGVtb0ltYWdlc31cbiAgICAgICAgLz5cbiAgICAgICl9XG4gICAgPC9tb3Rpb24uZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUHJvamVjdHM7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJtb3Rpb24iLCJ1c2VJblZpZXciLCJFeHRlcm5hbExpbmsiLCJTZWFyY2giLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJCdXR0b24iLCJJbnB1dCIsIk5hdmlnYXRpb24iLCJGb290ZXIiLCJBdG1vc3BoZXJlIiwiRmxpZ2h0TG9nIiwiQ29uZmlybUNvZGVMaW5rIiwiU0VPIiwiU3RydWN0dXJlZERhdGEiLCJ1c2VTRU8iLCJ1c2VTdHJ1Y3R1cmVkRGF0YSIsIkRlbW9HYWxsZXJ5IiwiQUxMX1BST0pFQ1RTIiwiQ0FURUdPUklFUyIsIkFMVElUVURFX0xBWUVSUyIsIlByb2plY3RzIiwic2VvUHJvcHMiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5IiwiYWN0aXZlQ2F0ZWdvcnkiLCJzZXRBY3RpdmVDYXRlZ29yeSIsInJlZiIsImluVmlldyIsInRyaWdnZXJPbmNlIiwidGhyZXNob2xkIiwicHJvamVjdHMiLCJmaWx0ZXJlZFByb2plY3RzIiwiZmlsdGVyIiwicHJvamVjdCIsIm1hdGNoZXNDYXRlZ29yeSIsImNhdGVnb3J5IiwicXVlcnkiLCJ0b0xvd2VyQ2FzZSIsInRyaW0iLCJtYXRjaGVzU2VhcmNoIiwidGl0bGUiLCJpbmNsdWRlcyIsImRlc2NyaXB0aW9uIiwidGVjaCIsInNvbWUiLCJwcm9qZWN0c0ZvclNjaGVtYSIsIm1hcCIsIm5hbWUiLCJkZW1vIiwidXJsIiwiaW1hZ2UiLCJrZXl3b3JkcyIsInByb2dyYW1taW5nTGFuZ3VhZ2UiLCJnaXRodWIiLCJjb2RlUmVwb3NpdG9yeSIsImJyZWFkY3J1bWJTY2hlbWEiLCJwcm9qZWN0U2NoZW1hcyIsImRpdiIsImNsYXNzTmFtZSIsInNjaGVtYSIsImluZGV4Iiwic2VjdGlvbiIsImluaXRpYWwiLCJvcGFjaXR5IiwieSIsImFuaW1hdGUiLCJ0cmFuc2l0aW9uIiwiZHVyYXRpb24iLCJlbnRyaWVzIiwiaDEiLCJzcGFuIiwicCIsImJ1dHRvbiIsIm9uQ2xpY2siLCJ0eXBlIiwicGxhY2Vob2xkZXIiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiZSIsInRhcmdldCIsImFyaWEtbGFiZWwiLCJ2YXJpYW50IiwiUHJvamVjdENhcmQiLCJsYXllciIsImluZGV4T2YiLCJudW1iZXIiLCJsZW5ndGgiLCJkZW1vT3BlbiIsInNldERlbW9PcGVuIiwiU3RyaW5nIiwicGFkU3RhcnQiLCJpbWciLCJzcmMiLCJhbHQiLCJjaGFyQXQiLCJhcmlhLWhpZGRlbiIsInN0eWxlIiwiYmFja2dyb3VuZCIsImgzIiwibWV0cmljcyIsIm1ldHJpYyIsImkiLCJkZW1vSW1hZ2VzIiwiaHJlZiIsInByb2plY3ROYW1lIiwic2l6ZSIsImFzQ2hpbGQiLCJhIiwicmVsIiwib3BlbiIsIm9uT3BlbkNoYW5nZSIsImltYWdlcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLE9BQU8sRUFBRUMsUUFBUSxRQUFRLFFBQVE7QUFDakQsU0FBU0MsTUFBTSxRQUFRLGdCQUFnQjtBQUN2QyxTQUFTQyxTQUFTLFFBQVEsOEJBQThCO0FBQ3hELFNBQVNDLFlBQVksRUFBRUMsTUFBTSxRQUFRLGVBQWU7QUFDcEQsU0FBU0MsSUFBSSxFQUFFQyxXQUFXLFFBQVEsdUJBQXVCO0FBQ3pELFNBQVNDLE1BQU0sUUFBUSx5QkFBeUI7QUFDaEQsU0FBU0MsS0FBSyxRQUFRLHdCQUF3QjtBQUM5QyxPQUFPQyxnQkFBZ0IsaUNBQWlDO0FBQ3hELE9BQU9DLFlBQVksNkJBQTZCO0FBQ2hELE9BQU9DLGdCQUFnQixxQ0FBcUM7QUFDNUQsT0FBT0MsZUFBZSw2QkFBNkI7QUFDbkQsT0FBT0MscUJBQXFCLG9DQUFvQztBQUNoRSxPQUFPQyxTQUFTLHVCQUF1QjtBQUN2QyxPQUFPQyxvQkFBb0Isa0NBQWtDO0FBQzdELFNBQVNDLE1BQU0sUUFBUSxrQkFBa0I7QUFDekMsU0FBU0MsaUJBQWlCLFFBQVEsOEJBQThCO0FBQ2hFLE9BQU9DLGlCQUFpQixvQ0FBb0M7QUFDNUQsU0FBU0MsWUFBWSxRQUEwQixzQkFBc0I7QUFFckUsTUFBTUMsYUFBYTtJQUFDO0lBQU87SUFBWTtJQUFjO0NBQVk7QUFFakUsTUFBTUMsa0JBQWtCO0lBQ3RCO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtDQUNEO0FBRUQsTUFBTUMsV0FBVzs7SUFDZixNQUFNQyxXQUFXUDtJQUNqQixNQUFNLENBQUNRLGFBQWFDLGVBQWUsR0FBR3pCLFNBQVM7SUFDL0MsTUFBTSxDQUFDMEIsZ0JBQWdCQyxrQkFBa0IsR0FBRzNCLFNBQVM7SUFFckQsTUFBTSxDQUFDNEIsS0FBS0MsT0FBTyxHQUFHM0IsVUFBVTtRQUM5QjRCLGFBQWE7UUFDYkMsV0FBVztJQUNiO0lBRUEsTUFBTUMsV0FBMEJqQyxRQUFRLElBQU07ZUFBSW9CO1NBQWEsRUFBRSxFQUFFO0lBRW5FLDZCQUE2QjtJQUM3QixNQUFNYyxtQkFBbUJsQyxRQUFRO1FBQy9CLE9BQU9pQyxTQUFTRSxNQUFNLENBQUNDLENBQUFBO1lBQ3JCLE1BQU1DLGtCQUNKVixtQkFBbUIsU0FBU1MsUUFBUUUsUUFBUSxLQUFLWDtZQUNuRCxNQUFNWSxRQUFRZCxZQUFZZSxXQUFXLEdBQUdDLElBQUk7WUFDNUMsTUFBTUMsZ0JBQ0pILFVBQVUsTUFDVkgsUUFBUU8sS0FBSyxDQUFDSCxXQUFXLEdBQUdJLFFBQVEsQ0FBQ0wsVUFDckNILFFBQVFTLFdBQVcsQ0FBQ0wsV0FBVyxHQUFHSSxRQUFRLENBQUNMLFVBQzNDSCxRQUFRVSxJQUFJLENBQUNDLElBQUksQ0FBQ0QsQ0FBQUEsT0FBUUEsS0FBS04sV0FBVyxHQUFHSSxRQUFRLENBQUNMO1lBRXhELE9BQU9GLG1CQUFtQks7UUFDNUI7SUFDRixHQUFHO1FBQUNUO1FBQVVOO1FBQWdCRjtLQUFZO0lBRTFDLDJDQUEyQztJQUMzQyxNQUFNdUIsb0JBQW9CZixTQUFTZ0IsR0FBRyxDQUFDYixDQUFBQSxVQUFZLENBQUE7WUFDakRjLE1BQU1kLFFBQVFPLEtBQUs7WUFDbkJFLGFBQWFULFFBQVFTLFdBQVc7WUFDaEMsR0FBSVQsUUFBUWUsSUFBSSxHQUFHO2dCQUFFQyxLQUFLaEIsUUFBUWUsSUFBSTtZQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdDLEdBQUlmLFFBQVFpQixLQUFLLEdBQUc7Z0JBQUVBLE9BQU9qQixRQUFRaUIsS0FBSztZQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2pEQyxVQUFVbEIsUUFBUVUsSUFBSTtZQUN0QlMscUJBQXFCbkIsUUFBUVUsSUFBSTtZQUNqQyxHQUFJVixRQUFRb0IsTUFBTSxHQUFHO2dCQUFFQyxnQkFBZ0JyQixRQUFRb0IsTUFBTTtZQUFDLElBQUksQ0FBQyxDQUFDO1FBQzlELENBQUE7SUFFQSxNQUFNLEVBQUVFLGdCQUFnQixFQUFFQyxjQUFjLEVBQUUsR0FBR3pDLGtCQUFrQjtRQUM3RGUsVUFBVWU7SUFDWjtJQUVBLHFCQUNFLFFBQUNZO1FBQUlDLFdBQVU7OzBCQUNiLFFBQUM5QztnQkFBSyxHQUFHUyxRQUFROzs7Ozs7MEJBQ2pCLFFBQUNSO2dCQUFlOEMsUUFBUUo7Ozs7OztZQUN2QkMsZ0JBQWdCVixJQUFJLENBQUNhLFFBQVFDLHNCQUM1QixRQUFDL0M7b0JBQTJCOEMsUUFBUUE7bUJBQWZDOzs7OzswQkFFdkIsUUFBQ3JEOzs7OzswQkFHRCxRQUFDc0Q7Z0JBQVFILFdBQVU7O2tDQUNqQixRQUFDakQ7Ozs7O2tDQUNELFFBQUNnRDt3QkFBSUMsV0FBVTtrQ0FDYixjQUFBLFFBQUMzRCxPQUFPMEQsR0FBRzs0QkFDVEssU0FBUztnQ0FBRUMsU0FBUztnQ0FBR0MsR0FBRzs0QkFBRzs0QkFDN0JDLFNBQVM7Z0NBQUVGLFNBQVM7Z0NBQUdDLEdBQUc7NEJBQUU7NEJBQzVCRSxZQUFZO2dDQUFFQyxVQUFVOzRCQUFJOzRCQUM1QlQsV0FBVTs7OENBRVYsUUFBQ2hEO29DQUNDMEQsU0FBUzt3Q0FDUDt3Q0FDQTt3Q0FDQTt3Q0FDQTtxQ0FDRDs7Ozs7OzhDQUVILFFBQUNDO29DQUFHWCxXQUFVOzhDQUNaLGNBQUEsUUFBQ1k7d0NBQUtaLFdBQVU7a0RBQWdCOzs7Ozs7Ozs7Ozs4Q0FFbEMsUUFBQ2E7b0NBQUViLFdBQVU7OENBQXlEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFTNUUsUUFBQ0c7Z0JBQVFILFdBQVU7MEJBQ2pCLGNBQUEsUUFBQ0Q7b0JBQUlDLFdBQVU7OEJBQ2IsY0FBQSxRQUFDRDt3QkFBSUMsV0FBVTs7MENBQ2IsUUFBQ0Q7Z0NBQUlDLFdBQVU7MENBQ1p4QyxXQUFXNEIsR0FBRyxDQUFDWCxDQUFBQSx5QkFDZCxRQUFDcUM7d0NBRUNDLFNBQVMsSUFBTWhELGtCQUFrQlU7d0NBQ2pDdUIsV0FBVyxDQUFDLDRFQUE0RSxFQUN0RmxDLG1CQUFtQlcsV0FDZix3Q0FDQSxzRkFDSjtrREFFREE7dUNBUklBOzs7Ozs7Ozs7OzBDQVlYLFFBQUNzQjtnQ0FBSUMsV0FBVTs7a0RBQ2IsUUFBQ3hEO3dDQUFPd0QsV0FBVTs7Ozs7O2tEQUNsQixRQUFDcEQ7d0NBQ0NvRSxNQUFLO3dDQUNMQyxhQUFZO3dDQUNaQyxPQUFPdEQ7d0NBQ1B1RCxVQUFVQyxDQUFBQSxJQUFLdkQsZUFBZXVELEVBQUVDLE1BQU0sQ0FBQ0gsS0FBSzt3Q0FDNUNsQixXQUFVO3dDQUNWc0IsY0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFRckIsUUFBQ25CO2dCQUFRSCxXQUFVOztrQ0FDakIsUUFBQ2pEO3dCQUFXd0UsU0FBUTt3QkFBT3ZCLFdBQVU7Ozs7OztrQ0FDckMsUUFBQ0Q7d0JBQUlDLFdBQVU7OzBDQUNiLFFBQUMzRCxPQUFPMEQsR0FBRztnQ0FDVC9CLEtBQUtBO2dDQUNMb0MsU0FBUztvQ0FBRUMsU0FBUztvQ0FBR0MsR0FBRztnQ0FBRztnQ0FDN0JDLFNBQVN0QyxTQUFTO29DQUFFb0MsU0FBUztvQ0FBR0MsR0FBRztnQ0FBRSxJQUFJLENBQUM7Z0NBQzFDRSxZQUFZO29DQUFFQyxVQUFVO2dDQUFJO2dDQUM1QlQsV0FBVTswQ0FFVDNCLGlCQUFpQmUsR0FBRyxDQUFDYixDQUFBQSx3QkFDcEIsUUFBQ2lEO3dDQUVDakQsU0FBU0E7d0NBQ1RrRCxPQUNFaEUsZUFBZSxDQUFDVyxTQUFTc0QsT0FBTyxDQUFDbkQsU0FBUyxJQUFJO3dDQUVoRG9ELFFBQVF2RCxTQUFTc0QsT0FBTyxDQUFDbkQsV0FBVzt1Q0FML0JBLFFBQVFPLEtBQUs7Ozs7Ozs7Ozs7NEJBVXZCVCxpQkFBaUJ1RCxNQUFNLEtBQUssbUJBQzNCLFFBQUM3QjtnQ0FBSUMsV0FBVTswQ0FBbUM7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFNeEQsUUFBQ2xEOzs7Ozs7Ozs7OztBQUdQO0dBcEpNWTs7UUFDYU47UUFJS2Q7UUFrQ3VCZTs7O0tBdkN6Q0s7QUFzSk4sTUFBTThELGNBQWMsQ0FBQyxFQUNuQmpELE9BQU8sRUFDUGtELEtBQUssRUFDTEUsTUFBTSxFQUtQOztJQUNDLE1BQU0sQ0FBQ0UsVUFBVUMsWUFBWSxHQUFHMUYsU0FBUztJQUV6QyxxQkFDRSxRQUFDQyxPQUFPMEQsR0FBRztRQUNUSyxTQUFTO1lBQUVDLFNBQVM7WUFBR0MsR0FBRztRQUFHO1FBQzdCQyxTQUFTO1lBQUVGLFNBQVM7WUFBR0MsR0FBRztRQUFFO1FBQzVCRSxZQUFZO1lBQUVDLFVBQVU7UUFBSTtRQUM1QlQsV0FBVTs7MEJBRVYsUUFBQ3ZEO2dCQUFLdUQsV0FBVTs7a0NBRWQsUUFBQ0Q7d0JBQUlDLFdBQVU7OzBDQUNiLFFBQUNZO2dDQUFLWixXQUFVOzBDQUNiK0IsT0FBT0osUUFBUUssUUFBUSxDQUFDLEdBQUc7Ozs7OzswQ0FFOUIsUUFBQ3BCO2dDQUFLWixXQUFVOzBDQUNieUI7Ozs7Ozs7Ozs7OztrQ0FJTCxRQUFDL0U7d0JBQVlzRCxXQUFVOzswQ0FFckIsUUFBQ0Q7Z0NBQUlDLFdBQVU7O29DQUNaekIsUUFBUWlCLEtBQUssaUJBQ1osUUFBQ3lDO3dDQUNDQyxLQUFLM0QsUUFBUWlCLEtBQUs7d0NBQ2xCMkMsS0FBSzVELFFBQVFPLEtBQUs7d0NBQ2xCa0IsV0FBVTs7Ozs7NkRBR1osUUFBQ0Q7d0NBQUlDLFdBQVU7a0RBQ2IsY0FBQSxRQUFDWTs0Q0FBS1osV0FBVTtzREFDYnpCLFFBQVFPLEtBQUssQ0FBQ3NELE1BQU0sQ0FBQzs7Ozs7Ozs7Ozs7a0RBSTVCLFFBQUNyQzt3Q0FBSUMsV0FBVTtrREFDYixjQUFBLFFBQUNZOzRDQUFLWixXQUFVO3NEQUNiekIsUUFBUUUsUUFBUTs7Ozs7Ozs7Ozs7a0RBSXJCLFFBQUNzQjt3Q0FDQ3NDLGVBQVk7d0NBQ1pyQyxXQUFVO3dDQUNWc0MsT0FBTzs0Q0FDTEMsWUFDRTt3Q0FDSjs7Ozs7Ozs7Ozs7OzBDQUlKLFFBQUNDO2dDQUFHeEMsV0FBVTswQ0FDWHpCLFFBQVFPLEtBQUs7Ozs7OzswQ0FFaEIsUUFBQytCO2dDQUFFYixXQUFVOzBDQUNWekIsUUFBUVMsV0FBVzs7Ozs7OzRCQUlyQlQsUUFBUWtFLE9BQU8sa0JBQ2QsUUFBQzFDO2dDQUFJQyxXQUFVOzBDQUNaekIsUUFBUWtFLE9BQU8sQ0FBQ3JELEdBQUcsQ0FBQyxDQUFDc0QsUUFBUUMsa0JBQzVCLFFBQUM1Qzt3Q0FBWUMsV0FBVTs7MERBQ3JCLFFBQUNEO2dEQUFJQyxXQUFVOzs7Ozs7MERBQ2YsUUFBQ1k7Z0RBQUtaLFdBQVU7MERBQXNCMEM7Ozs7Ozs7dUNBRjlCQzs7Ozs7Ozs7OzswQ0FTaEIsUUFBQzVDO2dDQUFJQyxXQUFVOzBDQUNaekIsUUFBUVUsSUFBSSxDQUFDRyxHQUFHLENBQUNILENBQUFBLHFCQUNoQixRQUFDMkI7d0NBRUNaLFdBQVU7a0RBRVRmO3VDQUhJQTs7Ozs7Ozs7Ozs0QkFTVFYsQ0FBQUEsUUFBUW9CLE1BQU0sSUFBSXBCLFFBQVFlLElBQUksSUFBSWYsUUFBUXFFLFVBQVUsQUFBRCxtQkFDbkQsUUFBQzdDO2dDQUFJQyxXQUFVOztvQ0FDWnpCLFFBQVFvQixNQUFNLGtCQUNiLFFBQUMxQzt3Q0FDQzRGLE1BQU10RSxRQUFRb0IsTUFBTTt3Q0FDcEJtRCxhQUFhdkUsUUFBUU8sS0FBSzt3Q0FDMUJrQixXQUFVOzs7Ozs7b0NBR2J6QixRQUFRcUUsVUFBVSxpQkFDakIsUUFBQ2pHO3dDQUNDb0csTUFBSzt3Q0FDTC9DLFdBQVU7d0NBQ1ZlLFNBQVMsSUFBTWUsWUFBWTs7MERBRTNCLFFBQUN2RjtnREFBYXlELFdBQVU7Ozs7Ozs0Q0FBaUI7Ozs7OzsrQ0FJM0N6QixRQUFRZSxJQUFJLGtCQUNWLFFBQUMzQzt3Q0FDQ29HLE1BQUs7d0NBQ0wvQyxXQUFVO3dDQUNWZ0QsT0FBTztrREFFUCxjQUFBLFFBQUNDOzRDQUNDSixNQUFNdEUsUUFBUWUsSUFBSTs0Q0FDbEIrQixRQUFPOzRDQUNQNkIsS0FBSTs7OERBRUosUUFBQzNHO29EQUFheUQsV0FBVTs7Ozs7O2dEQUFpQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBVXhEekIsUUFBUXFFLFVBQVUsa0JBQ2pCLFFBQUN0RjtnQkFDQzZGLE1BQU10QjtnQkFDTnVCLGNBQWN0QjtnQkFDZGhELE9BQU9QLFFBQVFPLEtBQUs7Z0JBQ3BCdUUsUUFBUTlFLFFBQVFxRSxVQUFVOzs7Ozs7Ozs7Ozs7QUFLcEM7SUEvSU1wQjtNQUFBQTtBQWlKTixlQUFlOUQsU0FBUyJ9