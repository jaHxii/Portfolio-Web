import {
  useLayoutEffect2
} from "/node_modules/.vite/deps/chunk-EB6MHUD6.js?v=e72f996b";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-RLJ2RCJQ.js?v=e72f996b";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-DC5AMYBS.js?v=e72f996b";

// node_modules/@radix-ui/react-id/dist/index.mjs
var React = __toESM(require_react(), 1);
var useReactId = React["useId".toString()] || (() => void 0);
var count = 0;
function useId(deterministicId) {
  const [id, setId] = React.useState(useReactId());
  useLayoutEffect2(() => {
    if (!deterministicId) setId((reactId) => reactId ?? String(count++));
  }, [deterministicId]);
  return deterministicId || (id ? `radix-${id}` : "");
}

export {
  useId
};
//# sourceMappingURL=chunk-WBNYTDFD.js.map
