import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_EMAILJS_PUBLIC_KEY": "0k9GNy3_VgCGbgb6p", "VITE_EMAILJS_SERVICE_ID": "service_69vleyd", "VITE_EMAILJS_TEMPLATE_ID": "template_yltgudd"};if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/App.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];
var _s = $RefreshSig$(), _s1 = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const Suspense = __vite__cjsImport2_react["Suspense"]; const useEffect = __vite__cjsImport2_react["useEffect"];
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { Toaster } from "/src/components/ui/toaster.tsx";
import { TooltipProvider } from "/src/components/ui/tooltip.tsx";
import { BrowserRouter, Routes, Route, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=e72f996b";
import LoadingFallback from "/src/components/layout/LoadingFallback.tsx";
import RouteErrorBoundary from "/src/components/layout/RouteErrorBoundary.tsx";
import { preloadCriticalRoutes } from "/src/lib/route-preloader.ts";
import { SkipLink } from "/src/components/accessibility/SkipLink.tsx";
import { ScrollProgress } from "/src/components/ui/scroll-progress.tsx";
import { CursorGlow } from "/src/components/ui/cursor-glow.tsx";
import { BackToTop } from "/src/components/ui/back-to-top.tsx";
import AltitudeCounter from "/src/components/ui/altitude-counter.tsx";
// Lazy load all page components for code splitting
const Index = /*#__PURE__*/ React.lazy(_c = ()=>import("/src/pages/Index.tsx"));
_c1 = Index;
const Projects = /*#__PURE__*/ React.lazy(_c2 = ()=>import("/src/pages/Projects.tsx"));
_c3 = Projects;
const Skills = /*#__PURE__*/ React.lazy(_c4 = ()=>import("/src/pages/Skills.tsx"));
_c5 = Skills;
const Experience = /*#__PURE__*/ React.lazy(_c6 = ()=>import("/src/pages/Experience.tsx"));
_c7 = Experience;
const Contact = /*#__PURE__*/ React.lazy(_c8 = ()=>import("/src/pages/Contact.tsx"));
_c9 = Contact;
const Resume = /*#__PURE__*/ React.lazy(_c10 = ()=>import("/src/pages/Resume.tsx"));
_c11 = Resume;
const NotFound = /*#__PURE__*/ React.lazy(_c12 = ()=>import("/src/pages/NotFound.tsx"));
_c13 = NotFound;
// Performance dashboard — dev only, split into its own chunk
const ScrollSky = /*#__PURE__*/ React.lazy(()=>import("/src/components/atmosphere/ScrollSky.tsx"));
_c14 = ScrollSky;
const CloudField = /*#__PURE__*/ React.lazy(()=>import("/src/components/atmosphere/CloudField.tsx"));
_c15 = CloudField;
// Performance dashboard — dev only, split into its own chunk
const PerformanceDashboard = /*#__PURE__*/ React.lazy(()=>import("/src/components/ui/performance-dashboard.tsx"));
_c16 = PerformanceDashboard;
const AnimatedRoutesInner = ()=>{
    _s();
    const location = useLocation();
    return /*#__PURE__*/ _jsxDEV(_Fragment, {
        children: [
            /*#__PURE__*/ _jsxDEV(AnimatePresence, {
                mode: "wait",
                children: /*#__PURE__*/ _jsxDEV(motion.div, {
                    initial: {
                        opacity: 0,
                        y: 12
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    exit: {
                        opacity: 0,
                        y: -12
                    },
                    transition: {
                        duration: 0.25,
                        ease: 'easeOut'
                    },
                    children: /*#__PURE__*/ _jsxDEV(Suspense, {
                        fallback: /*#__PURE__*/ _jsxDEV(LoadingFallback, {}, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                            lineNumber: 50,
                            columnNumber: 31
                        }, void 0),
                        children: /*#__PURE__*/ _jsxDEV(Routes, {
                            location: location,
                            children: [
                                /*#__PURE__*/ _jsxDEV(Route, {
                                    path: "/",
                                    element: /*#__PURE__*/ _jsxDEV(Index, {}, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                        lineNumber: 52,
                                        columnNumber: 40
                                    }, void 0)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                    lineNumber: 52,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV(Route, {
                                    path: "/projects",
                                    element: /*#__PURE__*/ _jsxDEV(Projects, {}, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                        lineNumber: 53,
                                        columnNumber: 48
                                    }, void 0)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                    lineNumber: 53,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV(Route, {
                                    path: "/skills",
                                    element: /*#__PURE__*/ _jsxDEV(Skills, {}, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                        lineNumber: 54,
                                        columnNumber: 46
                                    }, void 0)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                    lineNumber: 54,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV(Route, {
                                    path: "/experience",
                                    element: /*#__PURE__*/ _jsxDEV(Experience, {}, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                        lineNumber: 55,
                                        columnNumber: 50
                                    }, void 0)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                    lineNumber: 55,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV(Route, {
                                    path: "/contact",
                                    element: /*#__PURE__*/ _jsxDEV(Contact, {}, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                        lineNumber: 56,
                                        columnNumber: 47
                                    }, void 0)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                    lineNumber: 56,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV(Route, {
                                    path: "/resume",
                                    element: /*#__PURE__*/ _jsxDEV(Resume, {}, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                        lineNumber: 57,
                                        columnNumber: 46
                                    }, void 0)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                    lineNumber: 57,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV(Route, {
                                    path: "*",
                                    element: /*#__PURE__*/ _jsxDEV(NotFound, {}, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                        lineNumber: 59,
                                        columnNumber: 40
                                    }, void 0)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                    lineNumber: 59,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                            lineNumber: 51,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                        lineNumber: 50,
                        columnNumber: 11
                    }, this)
                }, location.pathname, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                    lineNumber: 43,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(motion.div, {
                initial: {
                    opacity: 0.45
                },
                animate: {
                    opacity: 0
                },
                transition: {
                    duration: 0.45,
                    ease: 'easeOut'
                },
                className: "pointer-events-none fixed inset-0 z-[60]",
                style: {
                    background: 'linear-gradient(180deg, hsl(210 24% 4%) 0%, hsl(42 58% 64% / 0.12) 50%, hsl(210 24% 4%) 100%)'
                }
            }, location.pathname, false, {
                fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
_s(AnimatedRoutesInner, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
    return [
        useLocation
    ];
});
_c17 = AnimatedRoutesInner;
const AnimatedRoutes = ()=>{
    _s1();
    const navigate = useNavigate();
    return /*#__PURE__*/ _jsxDEV(RouteErrorBoundary, {
        navigate: navigate,
        children: /*#__PURE__*/ _jsxDEV(AnimatedRoutesInner, {}, void 0, false, {
            fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
            lineNumber: 84,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
        lineNumber: 83,
        columnNumber: 5
    }, this);
};
_s1(AnimatedRoutes, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
    return [
        useNavigate
    ];
});
_c18 = AnimatedRoutes;
const App = ()=>{
    _s2();
    useEffect(()=>{
        // Preload critical routes on app initialization
        preloadCriticalRoutes();
        // Performance monitoring is dev-only; load on demand to keep it out of prod
        if (import.meta.env.DEV) {
            void import("/src/lib/performance-monitor.ts").then(({ initPerformanceMonitoring })=>initPerformanceMonitoring());
        }
    }, []);
    return /*#__PURE__*/ _jsxDEV(TooltipProvider, {
        children: [
            /*#__PURE__*/ _jsxDEV(Toaster, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(BrowserRouter, {
                children: [
                    /*#__PURE__*/ _jsxDEV(SkipLink, {
                        targetId: "main-content"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(ScrollProgress, {}, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(CursorGlow, {}, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                        lineNumber: 108,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(BackToTop, {}, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                        lineNumber: 109,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(AltitudeCounter, {}, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(Suspense, {
                        fallback: null,
                        children: [
                            /*#__PURE__*/ _jsxDEV(ScrollSky, {}, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                lineNumber: 112,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV(CloudField, {}, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                                lineNumber: 113,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                        lineNumber: 111,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        id: "main-content",
                        tabIndex: -1,
                        children: /*#__PURE__*/ _jsxDEV(AnimatedRoutes, {}, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                            lineNumber: 116,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                        lineNumber: 115,
                        columnNumber: 9
                    }, this),
                    import.meta.env.DEV && /*#__PURE__*/ _jsxDEV(Suspense, {
                        fallback: null,
                        children: /*#__PURE__*/ _jsxDEV(PerformanceDashboard, {}, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                            lineNumber: 122,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                        lineNumber: 121,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/App.tsx",
        lineNumber: 103,
        columnNumber: 5
    }, this);
};
_s2(App, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c19 = App;
export default App;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17, _c18, _c19;
$RefreshReg$(_c, "Index$React.lazy");
$RefreshReg$(_c1, "Index");
$RefreshReg$(_c2, "Projects$React.lazy");
$RefreshReg$(_c3, "Projects");
$RefreshReg$(_c4, "Skills$React.lazy");
$RefreshReg$(_c5, "Skills");
$RefreshReg$(_c6, "Experience$React.lazy");
$RefreshReg$(_c7, "Experience");
$RefreshReg$(_c8, "Contact$React.lazy");
$RefreshReg$(_c9, "Contact");
$RefreshReg$(_c10, "Resume$React.lazy");
$RefreshReg$(_c11, "Resume");
$RefreshReg$(_c12, "NotFound$React.lazy");
$RefreshReg$(_c13, "NotFound");
$RefreshReg$(_c14, "ScrollSky");
$RefreshReg$(_c15, "CloudField");
$RefreshReg$(_c16, "PerformanceDashboard");
$RefreshReg$(_c17, "AnimatedRoutesInner");
$RefreshReg$(_c18, "AnimatedRoutes");
$RefreshReg$(_c19, "App");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/App.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/App.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IFN1c3BlbnNlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24sIEFuaW1hdGVQcmVzZW5jZSB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgVG9hc3RlciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS90b2FzdGVyJztcbmltcG9ydCB7IFRvb2x0aXBQcm92aWRlciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS90b29sdGlwJztcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXIsIFJvdXRlcywgUm91dGUsIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IExvYWRpbmdGYWxsYmFjayBmcm9tICcuL2NvbXBvbmVudHMvbGF5b3V0L0xvYWRpbmdGYWxsYmFjayc7XG5pbXBvcnQgUm91dGVFcnJvckJvdW5kYXJ5IGZyb20gJy4vY29tcG9uZW50cy9sYXlvdXQvUm91dGVFcnJvckJvdW5kYXJ5JztcbmltcG9ydCB7IHByZWxvYWRDcml0aWNhbFJvdXRlcyB9IGZyb20gJy4vbGliL3JvdXRlLXByZWxvYWRlcic7XG5pbXBvcnQgeyBTa2lwTGluayB9IGZyb20gJy4vY29tcG9uZW50cy9hY2Nlc3NpYmlsaXR5L1NraXBMaW5rJztcbmltcG9ydCB7IFNjcm9sbFByb2dyZXNzIH0gZnJvbSAnLi9jb21wb25lbnRzL3VpL3Njcm9sbC1wcm9ncmVzcyc7XG5pbXBvcnQgeyBDdXJzb3JHbG93IH0gZnJvbSAnLi9jb21wb25lbnRzL3VpL2N1cnNvci1nbG93JztcbmltcG9ydCB7IEJhY2tUb1RvcCB9IGZyb20gJy4vY29tcG9uZW50cy91aS9iYWNrLXRvLXRvcCc7XG5pbXBvcnQgQWx0aXR1ZGVDb3VudGVyIGZyb20gJy4vY29tcG9uZW50cy91aS9hbHRpdHVkZS1jb3VudGVyJztcblxuLy8gTGF6eSBsb2FkIGFsbCBwYWdlIGNvbXBvbmVudHMgZm9yIGNvZGUgc3BsaXR0aW5nXG5jb25zdCBJbmRleCA9IFJlYWN0LmxhenkoKCkgPT4gaW1wb3J0KCcuL3BhZ2VzL0luZGV4JykpO1xuY29uc3QgUHJvamVjdHMgPSBSZWFjdC5sYXp5KCgpID0+IGltcG9ydCgnLi9wYWdlcy9Qcm9qZWN0cycpKTtcbmNvbnN0IFNraWxscyA9IFJlYWN0LmxhenkoKCkgPT4gaW1wb3J0KCcuL3BhZ2VzL1NraWxscycpKTtcbmNvbnN0IEV4cGVyaWVuY2UgPSBSZWFjdC5sYXp5KCgpID0+IGltcG9ydCgnLi9wYWdlcy9FeHBlcmllbmNlJykpO1xuY29uc3QgQ29udGFjdCA9IFJlYWN0LmxhenkoKCkgPT4gaW1wb3J0KCcuL3BhZ2VzL0NvbnRhY3QnKSk7XG5jb25zdCBSZXN1bWUgPSBSZWFjdC5sYXp5KCgpID0+IGltcG9ydCgnLi9wYWdlcy9SZXN1bWUnKSk7XG5jb25zdCBOb3RGb3VuZCA9IFJlYWN0LmxhenkoKCkgPT4gaW1wb3J0KCcuL3BhZ2VzL05vdEZvdW5kJykpO1xuXG4vLyBQZXJmb3JtYW5jZSBkYXNoYm9hcmQg4oCUIGRldiBvbmx5LCBzcGxpdCBpbnRvIGl0cyBvd24gY2h1bmtcbmNvbnN0IFNjcm9sbFNreSA9IFJlYWN0LmxhenkoXG4gICgpID0+IGltcG9ydCgnLi9jb21wb25lbnRzL2F0bW9zcGhlcmUvU2Nyb2xsU2t5Jylcbik7XG5jb25zdCBDbG91ZEZpZWxkID0gUmVhY3QubGF6eShcbiAgKCkgPT4gaW1wb3J0KCcuL2NvbXBvbmVudHMvYXRtb3NwaGVyZS9DbG91ZEZpZWxkJylcbik7XG5cbi8vIFBlcmZvcm1hbmNlIGRhc2hib2FyZCDigJQgZGV2IG9ubHksIHNwbGl0IGludG8gaXRzIG93biBjaHVua1xuY29uc3QgUGVyZm9ybWFuY2VEYXNoYm9hcmQgPSBSZWFjdC5sYXp5KFxuICAoKSA9PiBpbXBvcnQoJy4vY29tcG9uZW50cy91aS9wZXJmb3JtYW5jZS1kYXNoYm9hcmQnKVxuKTtcblxuY29uc3QgQW5pbWF0ZWRSb3V0ZXNJbm5lciA9ICgpID0+IHtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxBbmltYXRlUHJlc2VuY2UgbW9kZT0nd2FpdCc+XG4gICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAga2V5PXtsb2NhdGlvbi5wYXRobmFtZX1cbiAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDEyIH19XG4gICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwLCB5OiAtMTIgfX1cbiAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjI1LCBlYXNlOiAnZWFzZU91dCcgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PExvYWRpbmdGYWxsYmFjayAvPn0+XG4gICAgICAgICAgICA8Um91dGVzIGxvY2F0aW9uPXtsb2NhdGlvbn0+XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPScvJyBlbGVtZW50PXs8SW5kZXggLz59IC8+XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPScvcHJvamVjdHMnIGVsZW1lbnQ9ezxQcm9qZWN0cyAvPn0gLz5cbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9Jy9za2lsbHMnIGVsZW1lbnQ9ezxTa2lsbHMgLz59IC8+XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPScvZXhwZXJpZW5jZScgZWxlbWVudD17PEV4cGVyaWVuY2UgLz59IC8+XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPScvY29udGFjdCcgZWxlbWVudD17PENvbnRhY3QgLz59IC8+XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPScvcmVzdW1lJyBlbGVtZW50PXs8UmVzdW1lIC8+fSAvPlxuICAgICAgICAgICAgICB7LyogQUREIEFMTCBDVVNUT00gUk9VVEVTIEFCT1ZFIFRIRSBDQVRDSC1BTEwgXCIqXCIgUk9VVEUgKi99XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPScqJyBlbGVtZW50PXs8Tm90Rm91bmQgLz59IC8+XG4gICAgICAgICAgICA8L1JvdXRlcz5cbiAgICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICA8L0FuaW1hdGVQcmVzZW5jZT5cbiAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgIGtleT17bG9jYXRpb24ucGF0aG5hbWV9XG4gICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMC40NSB9fVxuICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDAgfX1cbiAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC40NSwgZWFzZTogJ2Vhc2VPdXQnIH19XG4gICAgICAgIGNsYXNzTmFtZT0ncG9pbnRlci1ldmVudHMtbm9uZSBmaXhlZCBpbnNldC0wIHotWzYwXSdcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBiYWNrZ3JvdW5kOlxuICAgICAgICAgICAgJ2xpbmVhci1ncmFkaWVudCgxODBkZWcsIGhzbCgyMTAgMjQlIDQlKSAwJSwgaHNsKDQyIDU4JSA2NCUgLyAwLjEyKSA1MCUsIGhzbCgyMTAgMjQlIDQlKSAxMDAlKScsXG4gICAgICAgIH19XG4gICAgICAvPlxuICAgIDwvPlxuICApO1xufTtcblxuY29uc3QgQW5pbWF0ZWRSb3V0ZXMgPSAoKSA9PiB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICByZXR1cm4gKFxuICAgIDxSb3V0ZUVycm9yQm91bmRhcnkgbmF2aWdhdGU9e25hdmlnYXRlfT5cbiAgICAgIDxBbmltYXRlZFJvdXRlc0lubmVyIC8+XG4gICAgPC9Sb3V0ZUVycm9yQm91bmRhcnk+XG4gICk7XG59O1xuXG5jb25zdCBBcHAgPSAoKSA9PiB7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gUHJlbG9hZCBjcml0aWNhbCByb3V0ZXMgb24gYXBwIGluaXRpYWxpemF0aW9uXG4gICAgcHJlbG9hZENyaXRpY2FsUm91dGVzKCk7XG5cbiAgICAvLyBQZXJmb3JtYW5jZSBtb25pdG9yaW5nIGlzIGRldi1vbmx5OyBsb2FkIG9uIGRlbWFuZCB0byBrZWVwIGl0IG91dCBvZiBwcm9kXG4gICAgaWYgKGltcG9ydC5tZXRhLmVudi5ERVYpIHtcbiAgICAgIHZvaWQgaW1wb3J0KCcuL2xpYi9wZXJmb3JtYW5jZS1tb25pdG9yJykudGhlbihcbiAgICAgICAgKHsgaW5pdFBlcmZvcm1hbmNlTW9uaXRvcmluZyB9KSA9PiBpbml0UGVyZm9ybWFuY2VNb25pdG9yaW5nKClcbiAgICAgICk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8VG9vbHRpcFByb3ZpZGVyPlxuICAgICAgPFRvYXN0ZXIgLz5cbiAgICAgIDxCcm93c2VyUm91dGVyPlxuICAgICAgICA8U2tpcExpbmsgdGFyZ2V0SWQ9J21haW4tY29udGVudCcgLz5cbiAgICAgICAgPFNjcm9sbFByb2dyZXNzIC8+XG4gICAgICAgIDxDdXJzb3JHbG93IC8+XG4gICAgICAgIDxCYWNrVG9Ub3AgLz5cbiAgICAgICAgPEFsdGl0dWRlQ291bnRlciAvPlxuICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9e251bGx9PlxuICAgICAgICAgIDxTY3JvbGxTa3kgLz5cbiAgICAgICAgICA8Q2xvdWRGaWVsZCAvPlxuICAgICAgICA8L1N1c3BlbnNlPlxuICAgICAgICA8ZGl2IGlkPSdtYWluLWNvbnRlbnQnIHRhYkluZGV4PXstMX0+XG4gICAgICAgICAgPEFuaW1hdGVkUm91dGVzIC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBQZXJmb3JtYW5jZSBEYXNoYm9hcmQgKGRldmVsb3BtZW50IG9ubHkpICovfVxuICAgICAgICB7aW1wb3J0Lm1ldGEuZW52LkRFViAmJiAoXG4gICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXtudWxsfT5cbiAgICAgICAgICAgIDxQZXJmb3JtYW5jZURhc2hib2FyZCAvPlxuICAgICAgICAgIDwvU3VzcGVuc2U+XG4gICAgICAgICl9XG4gICAgICA8L0Jyb3dzZXJSb3V0ZXI+XG4gICAgPC9Ub29sdGlwUHJvdmlkZXI+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJTdXNwZW5zZSIsInVzZUVmZmVjdCIsIm1vdGlvbiIsIkFuaW1hdGVQcmVzZW5jZSIsIlRvYXN0ZXIiLCJUb29sdGlwUHJvdmlkZXIiLCJCcm93c2VyUm91dGVyIiwiUm91dGVzIiwiUm91dGUiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwiTG9hZGluZ0ZhbGxiYWNrIiwiUm91dGVFcnJvckJvdW5kYXJ5IiwicHJlbG9hZENyaXRpY2FsUm91dGVzIiwiU2tpcExpbmsiLCJTY3JvbGxQcm9ncmVzcyIsIkN1cnNvckdsb3ciLCJCYWNrVG9Ub3AiLCJBbHRpdHVkZUNvdW50ZXIiLCJJbmRleCIsImxhenkiLCJQcm9qZWN0cyIsIlNraWxscyIsIkV4cGVyaWVuY2UiLCJDb250YWN0IiwiUmVzdW1lIiwiTm90Rm91bmQiLCJTY3JvbGxTa3kiLCJDbG91ZEZpZWxkIiwiUGVyZm9ybWFuY2VEYXNoYm9hcmQiLCJBbmltYXRlZFJvdXRlc0lubmVyIiwibG9jYXRpb24iLCJtb2RlIiwiZGl2IiwiaW5pdGlhbCIsIm9wYWNpdHkiLCJ5IiwiYW5pbWF0ZSIsImV4aXQiLCJ0cmFuc2l0aW9uIiwiZHVyYXRpb24iLCJlYXNlIiwiZmFsbGJhY2siLCJwYXRoIiwiZWxlbWVudCIsInBhdGhuYW1lIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJiYWNrZ3JvdW5kIiwiQW5pbWF0ZWRSb3V0ZXMiLCJuYXZpZ2F0ZSIsIkFwcCIsImVudiIsIkRFViIsInRoZW4iLCJpbml0UGVyZm9ybWFuY2VNb25pdG9yaW5nIiwidGFyZ2V0SWQiLCJpZCIsInRhYkluZGV4Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsUUFBUSxFQUFFQyxTQUFTLFFBQVEsUUFBUTtBQUNuRCxTQUFTQyxNQUFNLEVBQUVDLGVBQWUsUUFBUSxnQkFBZ0I7QUFDeEQsU0FBU0MsT0FBTyxRQUFRLDBCQUEwQjtBQUNsRCxTQUFTQyxlQUFlLFFBQVEsMEJBQTBCO0FBQzFELFNBQVNDLGFBQWEsRUFBRUMsTUFBTSxFQUFFQyxLQUFLLEVBQUVDLFdBQVcsRUFBRUMsV0FBVyxRQUFRLG1CQUFtQjtBQUMxRixPQUFPQyxxQkFBcUIsc0NBQXNDO0FBQ2xFLE9BQU9DLHdCQUF3Qix5Q0FBeUM7QUFDeEUsU0FBU0MscUJBQXFCLFFBQVEsd0JBQXdCO0FBQzlELFNBQVNDLFFBQVEsUUFBUSxzQ0FBc0M7QUFDL0QsU0FBU0MsY0FBYyxRQUFRLGtDQUFrQztBQUNqRSxTQUFTQyxVQUFVLFFBQVEsOEJBQThCO0FBQ3pELFNBQVNDLFNBQVMsUUFBUSw4QkFBOEI7QUFDeEQsT0FBT0MscUJBQXFCLG1DQUFtQztBQUUvRCxtREFBbUQ7QUFDbkQsTUFBTUMsc0JBQVFwQixNQUFNcUIsSUFBSSxNQUFDLElBQU0sTUFBTSxDQUFDOztBQUN0QyxNQUFNQyx5QkFBV3RCLE1BQU1xQixJQUFJLE9BQUMsSUFBTSxNQUFNLENBQUM7O0FBQ3pDLE1BQU1FLHVCQUFTdkIsTUFBTXFCLElBQUksT0FBQyxJQUFNLE1BQU0sQ0FBQzs7QUFDdkMsTUFBTUcsMkJBQWF4QixNQUFNcUIsSUFBSSxPQUFDLElBQU0sTUFBTSxDQUFDOztBQUMzQyxNQUFNSSx3QkFBVXpCLE1BQU1xQixJQUFJLE9BQUMsSUFBTSxNQUFNLENBQUM7O0FBQ3hDLE1BQU1LLHVCQUFTMUIsTUFBTXFCLElBQUksUUFBQyxJQUFNLE1BQU0sQ0FBQzs7QUFDdkMsTUFBTU0seUJBQVczQixNQUFNcUIsSUFBSSxRQUFDLElBQU0sTUFBTSxDQUFDOztBQUV6Qyw2REFBNkQ7QUFDN0QsTUFBTU8sMEJBQVk1QixNQUFNcUIsSUFBSSxDQUMxQixJQUFNLE1BQU0sQ0FBQztPQURUTztBQUdOLE1BQU1DLDJCQUFhN0IsTUFBTXFCLElBQUksQ0FDM0IsSUFBTSxNQUFNLENBQUM7T0FEVFE7QUFJTiw2REFBNkQ7QUFDN0QsTUFBTUMscUNBQXVCOUIsTUFBTXFCLElBQUksQ0FDckMsSUFBTSxNQUFNLENBQUM7T0FEVFM7QUFJTixNQUFNQyxzQkFBc0I7O0lBQzFCLE1BQU1DLFdBQVd0QjtJQUVqQixxQkFDRTs7MEJBQ0UsUUFBQ047Z0JBQWdCNkIsTUFBSzswQkFDcEIsY0FBQSxRQUFDOUIsT0FBTytCLEdBQUc7b0JBRVRDLFNBQVM7d0JBQUVDLFNBQVM7d0JBQUdDLEdBQUc7b0JBQUc7b0JBQzdCQyxTQUFTO3dCQUFFRixTQUFTO3dCQUFHQyxHQUFHO29CQUFFO29CQUM1QkUsTUFBTTt3QkFBRUgsU0FBUzt3QkFBR0MsR0FBRyxDQUFDO29CQUFHO29CQUMzQkcsWUFBWTt3QkFBRUMsVUFBVTt3QkFBTUMsTUFBTTtvQkFBVTs4QkFFOUMsY0FBQSxRQUFDekM7d0JBQVMwQyx3QkFBVSxRQUFDL0I7Ozs7O2tDQUNuQixjQUFBLFFBQUNKOzRCQUFPd0IsVUFBVUE7OzhDQUNoQixRQUFDdkI7b0NBQU1tQyxNQUFLO29DQUFJQyx1QkFBUyxRQUFDekI7Ozs7Ozs7Ozs7OENBQzFCLFFBQUNYO29DQUFNbUMsTUFBSztvQ0FBWUMsdUJBQVMsUUFBQ3ZCOzs7Ozs7Ozs7OzhDQUNsQyxRQUFDYjtvQ0FBTW1DLE1BQUs7b0NBQVVDLHVCQUFTLFFBQUN0Qjs7Ozs7Ozs7Ozs4Q0FDaEMsUUFBQ2Q7b0NBQU1tQyxNQUFLO29DQUFjQyx1QkFBUyxRQUFDckI7Ozs7Ozs7Ozs7OENBQ3BDLFFBQUNmO29DQUFNbUMsTUFBSztvQ0FBV0MsdUJBQVMsUUFBQ3BCOzs7Ozs7Ozs7OzhDQUNqQyxRQUFDaEI7b0NBQU1tQyxNQUFLO29DQUFVQyx1QkFBUyxRQUFDbkI7Ozs7Ozs7Ozs7OENBRWhDLFFBQUNqQjtvQ0FBTW1DLE1BQUs7b0NBQUlDLHVCQUFTLFFBQUNsQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O21CQWZ6QkssU0FBU2MsUUFBUTs7Ozs7Ozs7OzswQkFvQjFCLFFBQUMzQyxPQUFPK0IsR0FBRztnQkFFVEMsU0FBUztvQkFBRUMsU0FBUztnQkFBSztnQkFDekJFLFNBQVM7b0JBQUVGLFNBQVM7Z0JBQUU7Z0JBQ3RCSSxZQUFZO29CQUFFQyxVQUFVO29CQUFNQyxNQUFNO2dCQUFVO2dCQUM5Q0ssV0FBVTtnQkFDVkMsT0FBTztvQkFDTEMsWUFDRTtnQkFDSjtlQVJLakIsU0FBU2MsUUFBUTs7Ozs7OztBQVk5QjtHQXhDTWY7O1FBQ2FyQjs7O09BRGJxQjtBQTBDTixNQUFNbUIsaUJBQWlCOztJQUNyQixNQUFNQyxXQUFXeEM7SUFFakIscUJBQ0UsUUFBQ0U7UUFBbUJzQyxVQUFVQTtrQkFDNUIsY0FBQSxRQUFDcEI7Ozs7Ozs7Ozs7QUFHUDtJQVJNbUI7O1FBQ2F2Qzs7O09BRGJ1QztBQVVOLE1BQU1FLE1BQU07O0lBQ1ZsRCxVQUFVO1FBQ1IsZ0RBQWdEO1FBQ2hEWTtRQUVBLDRFQUE0RTtRQUM1RSxJQUFJLFlBQVl1QyxHQUFHLENBQUNDLEdBQUcsRUFBRTtZQUN2QixLQUFLLE1BQU0sQ0FBQyw2QkFBNkJDLElBQUksQ0FDM0MsQ0FBQyxFQUFFQyx5QkFBeUIsRUFBRSxHQUFLQTtRQUV2QztJQUNGLEdBQUcsRUFBRTtJQUVMLHFCQUNFLFFBQUNsRDs7MEJBQ0MsUUFBQ0Q7Ozs7OzBCQUNELFFBQUNFOztrQ0FDQyxRQUFDUTt3QkFBUzBDLFVBQVM7Ozs7OztrQ0FDbkIsUUFBQ3pDOzs7OztrQ0FDRCxRQUFDQzs7Ozs7a0NBQ0QsUUFBQ0M7Ozs7O2tDQUNELFFBQUNDOzs7OztrQ0FDRCxRQUFDbEI7d0JBQVMwQyxVQUFVOzswQ0FDbEIsUUFBQ2Y7Ozs7OzBDQUNELFFBQUNDOzs7Ozs7Ozs7OztrQ0FFSCxRQUFDSzt3QkFBSXdCLElBQUc7d0JBQWVDLFVBQVUsQ0FBQztrQ0FDaEMsY0FBQSxRQUFDVDs7Ozs7Ozs7OztvQkFJRixZQUFZRyxHQUFHLENBQUNDLEdBQUcsa0JBQ2xCLFFBQUNyRDt3QkFBUzBDLFVBQVU7a0NBQ2xCLGNBQUEsUUFBQ2I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFNYjtJQXZDTXNCO09BQUFBO0FBeUNOLGVBQWVBLElBQUkifQ==