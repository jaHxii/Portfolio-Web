import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Navigation.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useState = __vite__cjsImport2_react["useState"]; const useEffect = __vite__cjsImport2_react["useEffect"];
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=e72f996b";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { Menu, X, Sun, Moon } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Button } from "/src/components/ui/button.tsx";
import PreloadLink from "/src/components/ui/preload-link.tsx";
import { cn } from "/src/lib/utils.ts";
const NAV_ITEMS = [
    {
        name: 'Home',
        path: '/',
        index: '01'
    },
    {
        name: 'Projects',
        path: '/projects',
        index: '02'
    },
    {
        name: 'Skills',
        path: '/skills',
        index: '03'
    },
    {
        name: 'Experience',
        path: '/experience',
        index: '04'
    },
    {
        name: 'Contact',
        path: '/contact',
        index: '05'
    },
    {
        name: 'Resume',
        path: '/resume',
        index: '06'
    }
];
const Navigation = ()=>{
    _s();
    const [isOpen, setIsOpen] = useState(false);
    const [scrolled, setScrolled] = useState(false);
    const [theme, setTheme] = useState('dark');
    const location = useLocation();
    useEffect(()=>{
        const savedTheme = localStorage.getItem('theme') || 'dark';
        setTheme(savedTheme);
        document.documentElement.classList.toggle('light', savedTheme === 'light');
    }, []);
    // Close mobile menu on resize to desktop
    useEffect(()=>{
        const onResize = ()=>{
            if (window.innerWidth >= 768) setIsOpen(false);
        };
        window.addEventListener('resize', onResize, {
            passive: true
        });
        return ()=>window.removeEventListener('resize', onResize);
    }, []);
    // Lock body scroll when mobile menu is open
    useEffect(()=>{
        if (isOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
        return ()=>{
            document.body.style.overflow = '';
        };
    }, [
        isOpen
    ]);
    useEffect(()=>{
        const onScroll = ()=>setScrolled(window.scrollY > 24);
        onScroll();
        window.addEventListener('scroll', onScroll, {
            passive: true
        });
        return ()=>window.removeEventListener('scroll', onScroll);
    }, []);
    const toggleTheme = ()=>{
        const newTheme = theme === 'dark' ? 'light' : 'dark';
        setTheme(newTheme);
        localStorage.setItem('theme', newTheme);
        document.documentElement.classList.toggle('light', newTheme === 'light');
    };
    const handleNavClick = (path)=>{
        setIsOpen(false);
        if (path.includes('#')) {
            const [route, hash] = path.split('#');
            if (route === '' || route === '/') {
                if (location.pathname !== '/') {
                    window.location.href = path;
                } else {
                    const element = document.getElementById(hash);
                    element?.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            }
        }
    };
    return /*#__PURE__*/ _jsxDEV(motion.nav, {
        initial: {
            y: -20,
            opacity: 0
        },
        animate: {
            y: 0,
            opacity: 1
        },
        transition: {
            duration: 0.6,
            ease: 'easeOut'
        },
        className: cn('fixed top-0 left-0 right-0 z-50 border-b transition-all duration-500', scrolled ? 'bg-background/70 backdrop-blur-xl border-border' : 'bg-transparent border-transparent'),
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ _jsxDEV("div", {
                    className: "flex items-center justify-between h-16",
                    children: [
                        /*#__PURE__*/ _jsxDEV(PreloadLink, {
                            to: "/",
                            className: "flex items-center gap-3 group",
                            children: [
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "relative w-9 h-9 rounded-md bg-storm border border-border flex items-center justify-center overflow-hidden",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "font-heading font-bold text-sm gold-text",
                                            children: "EL"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 98,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "absolute inset-x-0 bottom-0 h-px bg-gradient-gold opacity-60"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 101,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                    lineNumber: 97,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("span", {
                                    className: "font-heading font-semibold text-lg tracking-tight text-foreground",
                                    children: [
                                        "Ermias ",
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "text-mist",
                                            children: "Lemesa"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 104,
                                            columnNumber: 22
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                    lineNumber: 103,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                            lineNumber: 96,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "hidden md:flex items-center gap-7",
                            children: [
                                NAV_ITEMS.map((item)=>{
                                    const active = location.pathname === item.path;
                                    return /*#__PURE__*/ _jsxDEV(PreloadLink, {
                                        to: item.path,
                                        onClick: ()=>handleNavClick(item.path),
                                        className: cn('text-sm font-medium transition-colors relative group', active ? 'text-gold' : 'text-mist-soft hover:text-foreground'),
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "font-mono text-[10px] mr-1 opacity-60",
                                                children: item.index
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                                lineNumber: 124,
                                                columnNumber: 19
                                            }, this),
                                            item.name,
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: cn('absolute -bottom-1 left-0 h-px bg-gradient-gold transition-all duration-300', active ? 'w-full' : 'w-0 group-hover:w-full')
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                                lineNumber: 128,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, item.name, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                        lineNumber: 113,
                                        columnNumber: 17
                                    }, this);
                                }),
                                /*#__PURE__*/ _jsxDEV(Button, {
                                    variant: "ghost",
                                    size: "icon",
                                    onClick: toggleTheme,
                                    className: "text-mist-soft hover:text-gold hover:bg-white/5",
                                    "aria-label": "Toggle theme",
                                    children: /*#__PURE__*/ _jsxDEV(AnimatePresence, {
                                        mode: "wait",
                                        children: theme === 'dark' ? /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                rotate: -90,
                                                opacity: 0
                                            },
                                            animate: {
                                                rotate: 0,
                                                opacity: 1
                                            },
                                            exit: {
                                                rotate: 90,
                                                opacity: 0
                                            },
                                            transition: {
                                                duration: 0.2
                                            },
                                            children: /*#__PURE__*/ _jsxDEV(Sun, {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                                lineNumber: 155,
                                                columnNumber: 21
                                            }, this)
                                        }, "sun", false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 148,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                rotate: 90,
                                                opacity: 0
                                            },
                                            animate: {
                                                rotate: 0,
                                                opacity: 1
                                            },
                                            exit: {
                                                rotate: -90,
                                                opacity: 0
                                            },
                                            transition: {
                                                duration: 0.2
                                            },
                                            children: /*#__PURE__*/ _jsxDEV(Moon, {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                                lineNumber: 165,
                                                columnNumber: 21
                                            }, this)
                                        }, "moon", false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 158,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                        lineNumber: 146,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                    lineNumber: 139,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("span", {
                                    className: "font-mono text-[10px] tracking-[0.3em] text-mist-soft/40 select-none hidden lg:inline",
                                    children: "ALT 38,000 FT"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                    lineNumber: 172,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                            lineNumber: 109,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "md:hidden flex items-center gap-1",
                            children: [
                                /*#__PURE__*/ _jsxDEV(Button, {
                                    variant: "ghost",
                                    size: "icon",
                                    onClick: toggleTheme,
                                    className: "text-mist-soft hover:text-gold",
                                    "aria-label": "Toggle theme",
                                    children: /*#__PURE__*/ _jsxDEV(AnimatePresence, {
                                        mode: "wait",
                                        children: theme === 'dark' ? /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                rotate: -90,
                                                opacity: 0
                                            },
                                            animate: {
                                                rotate: 0,
                                                opacity: 1
                                            },
                                            exit: {
                                                rotate: 90,
                                                opacity: 0
                                            },
                                            transition: {
                                                duration: 0.2
                                            },
                                            children: /*#__PURE__*/ _jsxDEV(Sun, {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                                lineNumber: 195,
                                                columnNumber: 21
                                            }, this)
                                        }, "sun", false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 188,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                rotate: 90,
                                                opacity: 0
                                            },
                                            animate: {
                                                rotate: 0,
                                                opacity: 1
                                            },
                                            exit: {
                                                rotate: -90,
                                                opacity: 0
                                            },
                                            transition: {
                                                duration: 0.2
                                            },
                                            children: /*#__PURE__*/ _jsxDEV(Moon, {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                                lineNumber: 205,
                                                columnNumber: 21
                                            }, this)
                                        }, "moon", false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 198,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                        lineNumber: 186,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                    lineNumber: 179,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV(Button, {
                                    variant: "ghost",
                                    size: "icon",
                                    onClick: ()=>setIsOpen(!isOpen),
                                    "aria-label": isOpen ? 'Close menu' : 'Open menu',
                                    children: /*#__PURE__*/ _jsxDEV(AnimatePresence, {
                                        mode: "wait",
                                        children: isOpen ? /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                rotate: -90,
                                                opacity: 0
                                            },
                                            animate: {
                                                rotate: 0,
                                                opacity: 1
                                            },
                                            exit: {
                                                rotate: 90,
                                                opacity: 0
                                            },
                                            transition: {
                                                duration: 0.2
                                            },
                                            children: /*#__PURE__*/ _jsxDEV(X, {
                                                className: "h-5 w-5"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                                lineNumber: 226,
                                                columnNumber: 21
                                            }, this)
                                        }, "close", false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 219,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                rotate: 90,
                                                opacity: 0
                                            },
                                            animate: {
                                                rotate: 0,
                                                opacity: 1
                                            },
                                            exit: {
                                                rotate: -90,
                                                opacity: 0
                                            },
                                            transition: {
                                                duration: 0.2
                                            },
                                            children: /*#__PURE__*/ _jsxDEV(Menu, {
                                                className: "h-5 w-5"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                                lineNumber: 236,
                                                columnNumber: 21
                                            }, this)
                                        }, "menu", false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 229,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                        lineNumber: 217,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                    lineNumber: 211,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                            lineNumber: 178,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(AnimatePresence, {
                children: isOpen && /*#__PURE__*/ _jsxDEV(motion.div, {
                    initial: {
                        opacity: 0,
                        height: 0
                    },
                    animate: {
                        opacity: 1,
                        height: 'auto'
                    },
                    exit: {
                        opacity: 0,
                        height: 0
                    },
                    transition: {
                        duration: 0.2
                    },
                    className: "md:hidden bg-background/90 backdrop-blur-xl border-t border-border",
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "px-6 py-6 space-y-5",
                        children: NAV_ITEMS.map((item, index)=>/*#__PURE__*/ _jsxDEV(motion.div, {
                                initial: {
                                    x: -20,
                                    opacity: 0
                                },
                                animate: {
                                    x: 0,
                                    opacity: 1
                                },
                                transition: {
                                    delay: index * 0.06
                                },
                                children: /*#__PURE__*/ _jsxDEV(PreloadLink, {
                                    to: item.path,
                                    onClick: ()=>handleNavClick(item.path),
                                    className: cn('flex items-center gap-3 text-base font-medium transition-colors', location.pathname === item.path ? 'text-gold' : 'text-mist-soft hover:text-foreground'),
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "font-mono text-xs opacity-60",
                                            children: item.index
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                            lineNumber: 273,
                                            columnNumber: 21
                                        }, this),
                                        item.name
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                    lineNumber: 263,
                                    columnNumber: 19
                                }, this)
                            }, item.name, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                                lineNumber: 257,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                        lineNumber: 255,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                    lineNumber: 248,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
                lineNumber: 246,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx",
        lineNumber: 82,
        columnNumber: 5
    }, this);
};
_s(Navigation, "J9nalk7yvLZbKyjaGa5B+usj+EI=", false, function() {
    return [
        useLocation
    ];
});
_c = Navigation;
export default Navigation;
var _c;
$RefreshReg$(_c, "Navigation");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/layout/Navigation.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIk5hdmlnYXRpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IG1vdGlvbiwgQW5pbWF0ZVByZXNlbmNlIH0gZnJvbSAnZnJhbWVyLW1vdGlvbic7XG5pbXBvcnQgeyBNZW51LCBYLCBTdW4sIE1vb24gfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5pbXBvcnQgUHJlbG9hZExpbmsgZnJvbSAnQC9jb21wb25lbnRzL3VpL3ByZWxvYWQtbGluayc7XG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJztcblxuY29uc3QgTkFWX0lURU1TID0gW1xuICB7IG5hbWU6ICdIb21lJywgcGF0aDogJy8nLCBpbmRleDogJzAxJyB9LFxuICB7IG5hbWU6ICdQcm9qZWN0cycsIHBhdGg6ICcvcHJvamVjdHMnLCBpbmRleDogJzAyJyB9LFxuICB7IG5hbWU6ICdTa2lsbHMnLCBwYXRoOiAnL3NraWxscycsIGluZGV4OiAnMDMnIH0sXG4gIHsgbmFtZTogJ0V4cGVyaWVuY2UnLCBwYXRoOiAnL2V4cGVyaWVuY2UnLCBpbmRleDogJzA0JyB9LFxuICB7IG5hbWU6ICdDb250YWN0JywgcGF0aDogJy9jb250YWN0JywgaW5kZXg6ICcwNScgfSxcbiAgeyBuYW1lOiAnUmVzdW1lJywgcGF0aDogJy9yZXN1bWUnLCBpbmRleDogJzA2JyB9LFxuXTtcblxuY29uc3QgTmF2aWdhdGlvbiA9ICgpID0+IHtcbiAgY29uc3QgW2lzT3Blbiwgc2V0SXNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Njcm9sbGVkLCBzZXRTY3JvbGxlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFt0aGVtZSwgc2V0VGhlbWVdID0gdXNlU3RhdGUoJ2RhcmsnKTtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWRUaGVtZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0aGVtZScpIHx8ICdkYXJrJztcbiAgICBzZXRUaGVtZShzYXZlZFRoZW1lKTtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LnRvZ2dsZSgnbGlnaHQnLCBzYXZlZFRoZW1lID09PSAnbGlnaHQnKTtcbiAgfSwgW10pO1xuXG4gIC8vIENsb3NlIG1vYmlsZSBtZW51IG9uIHJlc2l6ZSB0byBkZXNrdG9wXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgb25SZXNpemUgPSAoKSA9PiB7XG4gICAgICBpZiAod2luZG93LmlubmVyV2lkdGggPj0gNzY4KSBzZXRJc09wZW4oZmFsc2UpO1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIG9uUmVzaXplLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdyZXNpemUnLCBvblJlc2l6ZSk7XG4gIH0sIFtdKTtcblxuICAvLyBMb2NrIGJvZHkgc2Nyb2xsIHdoZW4gbW9iaWxlIG1lbnUgaXMgb3BlblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc09wZW4pIHtcbiAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSAnaGlkZGVuJztcbiAgICB9IGVsc2Uge1xuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9ICcnO1xuICAgIH1cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9ICcnO1xuICAgIH07XG4gIH0sIFtpc09wZW5dKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IG9uU2Nyb2xsID0gKCkgPT4gc2V0U2Nyb2xsZWQod2luZG93LnNjcm9sbFkgPiAyNCk7XG4gICAgb25TY3JvbGwoKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgb25TY3JvbGwsIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIG9uU2Nyb2xsKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHRvZ2dsZVRoZW1lID0gKCkgPT4ge1xuICAgIGNvbnN0IG5ld1RoZW1lID0gdGhlbWUgPT09ICdkYXJrJyA/ICdsaWdodCcgOiAnZGFyayc7XG4gICAgc2V0VGhlbWUobmV3VGhlbWUpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd0aGVtZScsIG5ld1RoZW1lKTtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LnRvZ2dsZSgnbGlnaHQnLCBuZXdUaGVtZSA9PT0gJ2xpZ2h0Jyk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTmF2Q2xpY2sgPSAocGF0aDogc3RyaW5nKSA9PiB7XG4gICAgc2V0SXNPcGVuKGZhbHNlKTtcblxuICAgIGlmIChwYXRoLmluY2x1ZGVzKCcjJykpIHtcbiAgICAgIGNvbnN0IFtyb3V0ZSwgaGFzaF0gPSBwYXRoLnNwbGl0KCcjJyk7XG4gICAgICBpZiAocm91dGUgPT09ICcnIHx8IHJvdXRlID09PSAnLycpIHtcbiAgICAgICAgaWYgKGxvY2F0aW9uLnBhdGhuYW1lICE9PSAnLycpIHtcbiAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHBhdGg7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgZWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGhhc2gpO1xuICAgICAgICAgIGVsZW1lbnQ/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPG1vdGlvbi5uYXZcbiAgICAgIGluaXRpYWw9e3sgeTogLTIwLCBvcGFjaXR5OiAwIH19XG4gICAgICBhbmltYXRlPXt7IHk6IDAsIG9wYWNpdHk6IDEgfX1cbiAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuNiwgZWFzZTogJ2Vhc2VPdXQnIH19XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAnZml4ZWQgdG9wLTAgbGVmdC0wIHJpZ2h0LTAgei01MCBib3JkZXItYiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAnLFxuICAgICAgICBzY3JvbGxlZFxuICAgICAgICAgID8gJ2JnLWJhY2tncm91bmQvNzAgYmFja2Ryb3AtYmx1ci14bCBib3JkZXItYm9yZGVyJ1xuICAgICAgICAgIDogJ2JnLXRyYW5zcGFyZW50IGJvcmRlci10cmFuc3BhcmVudCdcbiAgICAgICl9XG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9J21heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04Jz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBoLTE2Jz5cbiAgICAgICAgICB7LyogTG9nbyAqL31cbiAgICAgICAgICA8UHJlbG9hZExpbmsgdG89Jy8nIGNsYXNzTmFtZT0nZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZ3JvdXAnPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3JlbGF0aXZlIHctOSBoLTkgcm91bmRlZC1tZCBiZy1zdG9ybSBib3JkZXIgYm9yZGVyLWJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4nPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtaGVhZGluZyBmb250LWJvbGQgdGV4dC1zbSBnb2xkLXRleHQnPlxuICAgICAgICAgICAgICAgIEVMXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Fic29sdXRlIGluc2V0LXgtMCBib3R0b20tMCBoLXB4IGJnLWdyYWRpZW50LWdvbGQgb3BhY2l0eS02MCcgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdmb250LWhlYWRpbmcgZm9udC1zZW1pYm9sZCB0ZXh0LWxnIHRyYWNraW5nLXRpZ2h0IHRleHQtZm9yZWdyb3VuZCc+XG4gICAgICAgICAgICAgIEVybWlhcyA8c3BhbiBjbGFzc05hbWU9J3RleHQtbWlzdCc+TGVtZXNhPC9zcGFuPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvUHJlbG9hZExpbms+XG5cbiAgICAgICAgICB7LyogRGVza3RvcCBOYXZpZ2F0aW9uICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdoaWRkZW4gbWQ6ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTcnPlxuICAgICAgICAgICAge05BVl9JVEVNUy5tYXAoaXRlbSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGFjdGl2ZSA9IGxvY2F0aW9uLnBhdGhuYW1lID09PSBpdGVtLnBhdGg7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPFByZWxvYWRMaW5rXG4gICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ubmFtZX1cbiAgICAgICAgICAgICAgICAgIHRvPXtpdGVtLnBhdGh9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVOYXZDbGljayhpdGVtLnBhdGgpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgJ3RleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgcmVsYXRpdmUgZ3JvdXAnLFxuICAgICAgICAgICAgICAgICAgICBhY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LWdvbGQnXG4gICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1taXN0LXNvZnQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kJ1xuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LVsxMHB4XSBtci0xIG9wYWNpdHktNjAnPlxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5pbmRleH1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLm5hbWV9XG4gICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICdhYnNvbHV0ZSAtYm90dG9tLTEgbGVmdC0wIGgtcHggYmctZ3JhZGllbnQtZ29sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAnLFxuICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZSA/ICd3LWZ1bGwnIDogJ3ctMCBncm91cC1ob3Zlcjp3LWZ1bGwnXG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvUHJlbG9hZExpbms+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cblxuICAgICAgICAgICAgey8qIFRoZW1lIFRvZ2dsZSAqL31cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgdmFyaWFudD0nZ2hvc3QnXG4gICAgICAgICAgICAgIHNpemU9J2ljb24nXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVRoZW1lfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9J3RleHQtbWlzdC1zb2Z0IGhvdmVyOnRleHQtZ29sZCBob3ZlcjpiZy13aGl0ZS81J1xuICAgICAgICAgICAgICBhcmlhLWxhYmVsPSdUb2dnbGUgdGhlbWUnXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxBbmltYXRlUHJlc2VuY2UgbW9kZT0nd2FpdCc+XG4gICAgICAgICAgICAgICAge3RoZW1lID09PSAnZGFyaycgPyAoXG4gICAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAgICBrZXk9J3N1bidcbiAgICAgICAgICAgICAgICAgICAgaW5pdGlhbD17eyByb3RhdGU6IC05MCwgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgICAgICAgICBhbmltYXRlPXt7IHJvdGF0ZTogMCwgb3BhY2l0eTogMSB9fVxuICAgICAgICAgICAgICAgICAgICBleGl0PXt7IHJvdGF0ZTogOTAsIG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC4yIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxTdW4gY2xhc3NOYW1lPSdoLTQgdy00JyAvPlxuICAgICAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAgICBrZXk9J21vb24nXG4gICAgICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgcm90YXRlOiA5MCwgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgICAgICAgICBhbmltYXRlPXt7IHJvdGF0ZTogMCwgb3BhY2l0eTogMSB9fVxuICAgICAgICAgICAgICAgICAgICBleGl0PXt7IHJvdGF0ZTogLTkwLCBvcGFjaXR5OiAwIH19XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMiB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8TW9vbiBjbGFzc05hbWU9J2gtNCB3LTQnIC8+XG4gICAgICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG4gICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgey8qIEFsdGl0dWRlIG1pY3JvLWRldGFpbCDigJQgYWxtb3N0IGhpZGRlbiAqL31cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQtWzEwcHhdIHRyYWNraW5nLVswLjNlbV0gdGV4dC1taXN0LXNvZnQvNDAgc2VsZWN0LW5vbmUgaGlkZGVuIGxnOmlubGluZSc+XG4gICAgICAgICAgICAgIEFMVCAzOCwwMDAgRlRcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBNb2JpbGUgY29udHJvbHMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9J21kOmhpZGRlbiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSc+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9J2dob3N0J1xuICAgICAgICAgICAgICBzaXplPSdpY29uJ1xuICAgICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVUaGVtZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSd0ZXh0LW1pc3Qtc29mdCBob3Zlcjp0ZXh0LWdvbGQnXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9J1RvZ2dsZSB0aGVtZSdcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEFuaW1hdGVQcmVzZW5jZSBtb2RlPSd3YWl0Jz5cbiAgICAgICAgICAgICAgICB7dGhlbWUgPT09ICdkYXJrJyA/IChcbiAgICAgICAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT0nc3VuJ1xuICAgICAgICAgICAgICAgICAgICBpbml0aWFsPXt7IHJvdGF0ZTogLTkwLCBvcGFjaXR5OiAwIH19XG4gICAgICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgcm90YXRlOiAwLCBvcGFjaXR5OiAxIH19XG4gICAgICAgICAgICAgICAgICAgIGV4aXQ9e3sgcm90YXRlOiA5MCwgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjIgfX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFN1biBjbGFzc05hbWU9J2gtNCB3LTQnIC8+XG4gICAgICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT0nbW9vbidcbiAgICAgICAgICAgICAgICAgICAgaW5pdGlhbD17eyByb3RhdGU6IDkwLCBvcGFjaXR5OiAwIH19XG4gICAgICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgcm90YXRlOiAwLCBvcGFjaXR5OiAxIH19XG4gICAgICAgICAgICAgICAgICAgIGV4aXQ9e3sgcm90YXRlOiAtOTAsIG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC4yIH19XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxNb29uIGNsYXNzTmFtZT0naC00IHctNCcgLz5cbiAgICAgICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L0FuaW1hdGVQcmVzZW5jZT5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuXG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9J2dob3N0J1xuICAgICAgICAgICAgICBzaXplPSdpY29uJ1xuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc09wZW4oIWlzT3Blbil9XG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2lzT3BlbiA/ICdDbG9zZSBtZW51JyA6ICdPcGVuIG1lbnUnfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8QW5pbWF0ZVByZXNlbmNlIG1vZGU9J3dhaXQnPlxuICAgICAgICAgICAgICAgIHtpc09wZW4gPyAoXG4gICAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAgICBrZXk9J2Nsb3NlJ1xuICAgICAgICAgICAgICAgICAgICBpbml0aWFsPXt7IHJvdGF0ZTogLTkwLCBvcGFjaXR5OiAwIH19XG4gICAgICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgcm90YXRlOiAwLCBvcGFjaXR5OiAxIH19XG4gICAgICAgICAgICAgICAgICAgIGV4aXQ9e3sgcm90YXRlOiA5MCwgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjIgfX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPSdoLTUgdy01JyAvPlxuICAgICAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAgICBrZXk9J21lbnUnXG4gICAgICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgcm90YXRlOiA5MCwgb3BhY2l0eTogMCB9fVxuICAgICAgICAgICAgICAgICAgICBhbmltYXRlPXt7IHJvdGF0ZTogMCwgb3BhY2l0eTogMSB9fVxuICAgICAgICAgICAgICAgICAgICBleGl0PXt7IHJvdGF0ZTogLTkwLCBvcGFjaXR5OiAwIH19XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMiB9fVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8TWVudSBjbGFzc05hbWU9J2gtNSB3LTUnIC8+XG4gICAgICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE1vYmlsZSBOYXZpZ2F0aW9uIE1lbnUgKi99XG4gICAgICA8QW5pbWF0ZVByZXNlbmNlPlxuICAgICAgICB7aXNPcGVuICYmIChcbiAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCBoZWlnaHQ6IDAgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgaGVpZ2h0OiAnYXV0bycgfX1cbiAgICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgaGVpZ2h0OiAwIH19XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjIgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT0nbWQ6aGlkZGVuIGJnLWJhY2tncm91bmQvOTAgYmFja2Ryb3AtYmx1ci14bCBib3JkZXItdCBib3JkZXItYm9yZGVyJ1xuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdweC02IHB5LTYgc3BhY2UteS01Jz5cbiAgICAgICAgICAgICAge05BVl9JVEVNUy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5uYW1lfVxuICAgICAgICAgICAgICAgICAgaW5pdGlhbD17eyB4OiAtMjAsIG9wYWNpdHk6IDAgfX1cbiAgICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgeDogMCwgb3BhY2l0eTogMSB9fVxuICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogaW5kZXggKiAwLjA2IH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFByZWxvYWRMaW5rXG4gICAgICAgICAgICAgICAgICAgIHRvPXtpdGVtLnBhdGh9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU5hdkNsaWNrKGl0ZW0ucGF0aCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgJ2ZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtYmFzZSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycycsXG4gICAgICAgICAgICAgICAgICAgICAgbG9jYXRpb24ucGF0aG5hbWUgPT09IGl0ZW0ucGF0aFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1nb2xkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1taXN0LXNvZnQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kJ1xuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIG9wYWNpdHktNjAnPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmluZGV4fVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLm5hbWV9XG4gICAgICAgICAgICAgICAgICA8L1ByZWxvYWRMaW5rPlxuICAgICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICl9XG4gICAgICA8L0FuaW1hdGVQcmVzZW5jZT5cbiAgICA8L21vdGlvbi5uYXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBOYXZpZ2F0aW9uO1xuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VMb2NhdGlvbiIsIm1vdGlvbiIsIkFuaW1hdGVQcmVzZW5jZSIsIk1lbnUiLCJYIiwiU3VuIiwiTW9vbiIsIkJ1dHRvbiIsIlByZWxvYWRMaW5rIiwiY24iLCJOQVZfSVRFTVMiLCJuYW1lIiwicGF0aCIsImluZGV4IiwiTmF2aWdhdGlvbiIsImlzT3BlbiIsInNldElzT3BlbiIsInNjcm9sbGVkIiwic2V0U2Nyb2xsZWQiLCJ0aGVtZSIsInNldFRoZW1lIiwibG9jYXRpb24iLCJzYXZlZFRoZW1lIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50IiwiY2xhc3NMaXN0IiwidG9nZ2xlIiwib25SZXNpemUiLCJ3aW5kb3ciLCJpbm5lcldpZHRoIiwiYWRkRXZlbnRMaXN0ZW5lciIsInBhc3NpdmUiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiYm9keSIsInN0eWxlIiwib3ZlcmZsb3ciLCJvblNjcm9sbCIsInNjcm9sbFkiLCJ0b2dnbGVUaGVtZSIsIm5ld1RoZW1lIiwic2V0SXRlbSIsImhhbmRsZU5hdkNsaWNrIiwiaW5jbHVkZXMiLCJyb3V0ZSIsImhhc2giLCJzcGxpdCIsInBhdGhuYW1lIiwiaHJlZiIsImVsZW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInNjcm9sbEludG9WaWV3IiwiYmVoYXZpb3IiLCJuYXYiLCJpbml0aWFsIiwieSIsIm9wYWNpdHkiLCJhbmltYXRlIiwidHJhbnNpdGlvbiIsImR1cmF0aW9uIiwiZWFzZSIsImNsYXNzTmFtZSIsImRpdiIsInRvIiwic3BhbiIsIm1hcCIsIml0ZW0iLCJhY3RpdmUiLCJvbkNsaWNrIiwidmFyaWFudCIsInNpemUiLCJhcmlhLWxhYmVsIiwibW9kZSIsInJvdGF0ZSIsImV4aXQiLCJoZWlnaHQiLCJ4IiwiZGVsYXkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxPQUFPQSxTQUFTQyxRQUFRLEVBQUVDLFNBQVMsUUFBUSxRQUFRO0FBQ25ELFNBQVNDLFdBQVcsUUFBUSxtQkFBbUI7QUFDL0MsU0FBU0MsTUFBTSxFQUFFQyxlQUFlLFFBQVEsZ0JBQWdCO0FBQ3hELFNBQVNDLElBQUksRUFBRUMsQ0FBQyxFQUFFQyxHQUFHLEVBQUVDLElBQUksUUFBUSxlQUFlO0FBQ2xELFNBQVNDLE1BQU0sUUFBUSx5QkFBeUI7QUFDaEQsT0FBT0MsaUJBQWlCLCtCQUErQjtBQUN2RCxTQUFTQyxFQUFFLFFBQVEsY0FBYztBQUVqQyxNQUFNQyxZQUFZO0lBQ2hCO1FBQUVDLE1BQU07UUFBUUMsTUFBTTtRQUFLQyxPQUFPO0lBQUs7SUFDdkM7UUFBRUYsTUFBTTtRQUFZQyxNQUFNO1FBQWFDLE9BQU87SUFBSztJQUNuRDtRQUFFRixNQUFNO1FBQVVDLE1BQU07UUFBV0MsT0FBTztJQUFLO0lBQy9DO1FBQUVGLE1BQU07UUFBY0MsTUFBTTtRQUFlQyxPQUFPO0lBQUs7SUFDdkQ7UUFBRUYsTUFBTTtRQUFXQyxNQUFNO1FBQVlDLE9BQU87SUFBSztJQUNqRDtRQUFFRixNQUFNO1FBQVVDLE1BQU07UUFBV0MsT0FBTztJQUFLO0NBQ2hEO0FBRUQsTUFBTUMsYUFBYTs7SUFDakIsTUFBTSxDQUFDQyxRQUFRQyxVQUFVLEdBQUdsQixTQUFTO0lBQ3JDLE1BQU0sQ0FBQ21CLFVBQVVDLFlBQVksR0FBR3BCLFNBQVM7SUFDekMsTUFBTSxDQUFDcUIsT0FBT0MsU0FBUyxHQUFHdEIsU0FBUztJQUNuQyxNQUFNdUIsV0FBV3JCO0lBRWpCRCxVQUFVO1FBQ1IsTUFBTXVCLGFBQWFDLGFBQWFDLE9BQU8sQ0FBQyxZQUFZO1FBQ3BESixTQUFTRTtRQUNURyxTQUFTQyxlQUFlLENBQUNDLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLFNBQVNOLGVBQWU7SUFDcEUsR0FBRyxFQUFFO0lBRUwseUNBQXlDO0lBQ3pDdkIsVUFBVTtRQUNSLE1BQU04QixXQUFXO1lBQ2YsSUFBSUMsT0FBT0MsVUFBVSxJQUFJLEtBQUtmLFVBQVU7UUFDMUM7UUFDQWMsT0FBT0UsZ0JBQWdCLENBQUMsVUFBVUgsVUFBVTtZQUFFSSxTQUFTO1FBQUs7UUFDNUQsT0FBTyxJQUFNSCxPQUFPSSxtQkFBbUIsQ0FBQyxVQUFVTDtJQUNwRCxHQUFHLEVBQUU7SUFFTCw0Q0FBNEM7SUFDNUM5QixVQUFVO1FBQ1IsSUFBSWdCLFFBQVE7WUFDVlUsU0FBU1UsSUFBSSxDQUFDQyxLQUFLLENBQUNDLFFBQVEsR0FBRztRQUNqQyxPQUFPO1lBQ0xaLFNBQVNVLElBQUksQ0FBQ0MsS0FBSyxDQUFDQyxRQUFRLEdBQUc7UUFDakM7UUFDQSxPQUFPO1lBQ0xaLFNBQVNVLElBQUksQ0FBQ0MsS0FBSyxDQUFDQyxRQUFRLEdBQUc7UUFDakM7SUFDRixHQUFHO1FBQUN0QjtLQUFPO0lBRVhoQixVQUFVO1FBQ1IsTUFBTXVDLFdBQVcsSUFBTXBCLFlBQVlZLE9BQU9TLE9BQU8sR0FBRztRQUNwREQ7UUFDQVIsT0FBT0UsZ0JBQWdCLENBQUMsVUFBVU0sVUFBVTtZQUFFTCxTQUFTO1FBQUs7UUFDNUQsT0FBTyxJQUFNSCxPQUFPSSxtQkFBbUIsQ0FBQyxVQUFVSTtJQUNwRCxHQUFHLEVBQUU7SUFFTCxNQUFNRSxjQUFjO1FBQ2xCLE1BQU1DLFdBQVd0QixVQUFVLFNBQVMsVUFBVTtRQUM5Q0MsU0FBU3FCO1FBQ1RsQixhQUFhbUIsT0FBTyxDQUFDLFNBQVNEO1FBQzlCaEIsU0FBU0MsZUFBZSxDQUFDQyxTQUFTLENBQUNDLE1BQU0sQ0FBQyxTQUFTYSxhQUFhO0lBQ2xFO0lBRUEsTUFBTUUsaUJBQWlCLENBQUMvQjtRQUN0QkksVUFBVTtRQUVWLElBQUlKLEtBQUtnQyxRQUFRLENBQUMsTUFBTTtZQUN0QixNQUFNLENBQUNDLE9BQU9DLEtBQUssR0FBR2xDLEtBQUttQyxLQUFLLENBQUM7WUFDakMsSUFBSUYsVUFBVSxNQUFNQSxVQUFVLEtBQUs7Z0JBQ2pDLElBQUl4QixTQUFTMkIsUUFBUSxLQUFLLEtBQUs7b0JBQzdCbEIsT0FBT1QsUUFBUSxDQUFDNEIsSUFBSSxHQUFHckM7Z0JBQ3pCLE9BQU87b0JBQ0wsTUFBTXNDLFVBQVV6QixTQUFTMEIsY0FBYyxDQUFDTDtvQkFDeENJLFNBQVNFLGVBQWU7d0JBQUVDLFVBQVU7b0JBQVM7Z0JBQy9DO1lBQ0Y7UUFDRjtJQUNGO0lBRUEscUJBQ0UsUUFBQ3BELE9BQU9xRCxHQUFHO1FBQ1RDLFNBQVM7WUFBRUMsR0FBRyxDQUFDO1lBQUlDLFNBQVM7UUFBRTtRQUM5QkMsU0FBUztZQUFFRixHQUFHO1lBQUdDLFNBQVM7UUFBRTtRQUM1QkUsWUFBWTtZQUFFQyxVQUFVO1lBQUtDLE1BQU07UUFBVTtRQUM3Q0MsV0FBV3JELEdBQ1Qsd0VBQ0FRLFdBQ0ksb0RBQ0E7OzBCQUdOLFFBQUM4QztnQkFBSUQsV0FBVTswQkFDYixjQUFBLFFBQUNDO29CQUFJRCxXQUFVOztzQ0FFYixRQUFDdEQ7NEJBQVl3RCxJQUFHOzRCQUFJRixXQUFVOzs4Q0FDNUIsUUFBQ0M7b0NBQUlELFdBQVU7O3NEQUNiLFFBQUNHOzRDQUFLSCxXQUFVO3NEQUEyQzs7Ozs7O3NEQUczRCxRQUFDQzs0Q0FBSUQsV0FBVTs7Ozs7Ozs7Ozs7OzhDQUVqQixRQUFDRztvQ0FBS0gsV0FBVTs7d0NBQW9FO3NEQUMzRSxRQUFDRzs0Q0FBS0gsV0FBVTtzREFBWTs7Ozs7Ozs7Ozs7Ozs7Ozs7O3NDQUt2QyxRQUFDQzs0QkFBSUQsV0FBVTs7Z0NBQ1pwRCxVQUFVd0QsR0FBRyxDQUFDQyxDQUFBQTtvQ0FDYixNQUFNQyxTQUFTL0MsU0FBUzJCLFFBQVEsS0FBS21CLEtBQUt2RCxJQUFJO29DQUM5QyxxQkFDRSxRQUFDSjt3Q0FFQ3dELElBQUlHLEtBQUt2RCxJQUFJO3dDQUNieUQsU0FBUyxJQUFNMUIsZUFBZXdCLEtBQUt2RCxJQUFJO3dDQUN2Q2tELFdBQVdyRCxHQUNULHdEQUNBMkQsU0FDSSxjQUNBOzswREFHTixRQUFDSDtnREFBS0gsV0FBVTswREFDYkssS0FBS3RELEtBQUs7Ozs7Ozs0Q0FFWnNELEtBQUt4RCxJQUFJOzBEQUNWLFFBQUNzRDtnREFDQ0gsV0FBV3JELEdBQ1QsK0VBQ0EyRCxTQUFTLFdBQVc7Ozs7Ozs7dUNBakJuQkQsS0FBS3hELElBQUk7Ozs7O2dDQXNCcEI7OENBR0EsUUFBQ0o7b0NBQ0MrRCxTQUFRO29DQUNSQyxNQUFLO29DQUNMRixTQUFTN0I7b0NBQ1RzQixXQUFVO29DQUNWVSxjQUFXOzhDQUVYLGNBQUEsUUFBQ3RFO3dDQUFnQnVFLE1BQUs7a0RBQ25CdEQsVUFBVSx1QkFDVCxRQUFDbEIsT0FBTzhELEdBQUc7NENBRVRSLFNBQVM7Z0RBQUVtQixRQUFRLENBQUM7Z0RBQUlqQixTQUFTOzRDQUFFOzRDQUNuQ0MsU0FBUztnREFBRWdCLFFBQVE7Z0RBQUdqQixTQUFTOzRDQUFFOzRDQUNqQ2tCLE1BQU07Z0RBQUVELFFBQVE7Z0RBQUlqQixTQUFTOzRDQUFFOzRDQUMvQkUsWUFBWTtnREFBRUMsVUFBVTs0Q0FBSTtzREFFNUIsY0FBQSxRQUFDdkQ7Z0RBQUl5RCxXQUFVOzs7Ozs7MkNBTlg7Ozs7aUVBU04sUUFBQzdELE9BQU84RCxHQUFHOzRDQUVUUixTQUFTO2dEQUFFbUIsUUFBUTtnREFBSWpCLFNBQVM7NENBQUU7NENBQ2xDQyxTQUFTO2dEQUFFZ0IsUUFBUTtnREFBR2pCLFNBQVM7NENBQUU7NENBQ2pDa0IsTUFBTTtnREFBRUQsUUFBUSxDQUFDO2dEQUFJakIsU0FBUzs0Q0FBRTs0Q0FDaENFLFlBQVk7Z0RBQUVDLFVBQVU7NENBQUk7c0RBRTVCLGNBQUEsUUFBQ3REO2dEQUFLd0QsV0FBVTs7Ozs7OzJDQU5aOzs7Ozs7Ozs7Ozs7Ozs7OENBYVosUUFBQ0c7b0NBQUtILFdBQVU7OENBQXdGOzs7Ozs7Ozs7Ozs7c0NBTTFHLFFBQUNDOzRCQUFJRCxXQUFVOzs4Q0FDYixRQUFDdkQ7b0NBQ0MrRCxTQUFRO29DQUNSQyxNQUFLO29DQUNMRixTQUFTN0I7b0NBQ1RzQixXQUFVO29DQUNWVSxjQUFXOzhDQUVYLGNBQUEsUUFBQ3RFO3dDQUFnQnVFLE1BQUs7a0RBQ25CdEQsVUFBVSx1QkFDVCxRQUFDbEIsT0FBTzhELEdBQUc7NENBRVRSLFNBQVM7Z0RBQUVtQixRQUFRLENBQUM7Z0RBQUlqQixTQUFTOzRDQUFFOzRDQUNuQ0MsU0FBUztnREFBRWdCLFFBQVE7Z0RBQUdqQixTQUFTOzRDQUFFOzRDQUNqQ2tCLE1BQU07Z0RBQUVELFFBQVE7Z0RBQUlqQixTQUFTOzRDQUFFOzRDQUMvQkUsWUFBWTtnREFBRUMsVUFBVTs0Q0FBSTtzREFFNUIsY0FBQSxRQUFDdkQ7Z0RBQUl5RCxXQUFVOzs7Ozs7MkNBTlg7Ozs7aUVBU04sUUFBQzdELE9BQU84RCxHQUFHOzRDQUVUUixTQUFTO2dEQUFFbUIsUUFBUTtnREFBSWpCLFNBQVM7NENBQUU7NENBQ2xDQyxTQUFTO2dEQUFFZ0IsUUFBUTtnREFBR2pCLFNBQVM7NENBQUU7NENBQ2pDa0IsTUFBTTtnREFBRUQsUUFBUSxDQUFDO2dEQUFJakIsU0FBUzs0Q0FBRTs0Q0FDaENFLFlBQVk7Z0RBQUVDLFVBQVU7NENBQUk7c0RBRTVCLGNBQUEsUUFBQ3REO2dEQUFLd0QsV0FBVTs7Ozs7OzJDQU5aOzs7Ozs7Ozs7Ozs7Ozs7OENBWVosUUFBQ3ZEO29DQUNDK0QsU0FBUTtvQ0FDUkMsTUFBSztvQ0FDTEYsU0FBUyxJQUFNckQsVUFBVSxDQUFDRDtvQ0FDMUJ5RCxjQUFZekQsU0FBUyxlQUFlOzhDQUVwQyxjQUFBLFFBQUNiO3dDQUFnQnVFLE1BQUs7a0RBQ25CMUQsdUJBQ0MsUUFBQ2QsT0FBTzhELEdBQUc7NENBRVRSLFNBQVM7Z0RBQUVtQixRQUFRLENBQUM7Z0RBQUlqQixTQUFTOzRDQUFFOzRDQUNuQ0MsU0FBUztnREFBRWdCLFFBQVE7Z0RBQUdqQixTQUFTOzRDQUFFOzRDQUNqQ2tCLE1BQU07Z0RBQUVELFFBQVE7Z0RBQUlqQixTQUFTOzRDQUFFOzRDQUMvQkUsWUFBWTtnREFBRUMsVUFBVTs0Q0FBSTtzREFFNUIsY0FBQSxRQUFDeEQ7Z0RBQUUwRCxXQUFVOzs7Ozs7MkNBTlQ7Ozs7aUVBU04sUUFBQzdELE9BQU84RCxHQUFHOzRDQUVUUixTQUFTO2dEQUFFbUIsUUFBUTtnREFBSWpCLFNBQVM7NENBQUU7NENBQ2xDQyxTQUFTO2dEQUFFZ0IsUUFBUTtnREFBR2pCLFNBQVM7NENBQUU7NENBQ2pDa0IsTUFBTTtnREFBRUQsUUFBUSxDQUFDO2dEQUFJakIsU0FBUzs0Q0FBRTs0Q0FDaENFLFlBQVk7Z0RBQUVDLFVBQVU7NENBQUk7c0RBRTVCLGNBQUEsUUFBQ3pEO2dEQUFLMkQsV0FBVTs7Ozs7OzJDQU5aOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFnQmxCLFFBQUM1RDswQkFDRWEsd0JBQ0MsUUFBQ2QsT0FBTzhELEdBQUc7b0JBQ1RSLFNBQVM7d0JBQUVFLFNBQVM7d0JBQUdtQixRQUFRO29CQUFFO29CQUNqQ2xCLFNBQVM7d0JBQUVELFNBQVM7d0JBQUdtQixRQUFRO29CQUFPO29CQUN0Q0QsTUFBTTt3QkFBRWxCLFNBQVM7d0JBQUdtQixRQUFRO29CQUFFO29CQUM5QmpCLFlBQVk7d0JBQUVDLFVBQVU7b0JBQUk7b0JBQzVCRSxXQUFVOzhCQUVWLGNBQUEsUUFBQ0M7d0JBQUlELFdBQVU7a0NBQ1pwRCxVQUFVd0QsR0FBRyxDQUFDLENBQUNDLE1BQU10RCxzQkFDcEIsUUFBQ1osT0FBTzhELEdBQUc7Z0NBRVRSLFNBQVM7b0NBQUVzQixHQUFHLENBQUM7b0NBQUlwQixTQUFTO2dDQUFFO2dDQUM5QkMsU0FBUztvQ0FBRW1CLEdBQUc7b0NBQUdwQixTQUFTO2dDQUFFO2dDQUM1QkUsWUFBWTtvQ0FBRW1CLE9BQU9qRSxRQUFRO2dDQUFLOzBDQUVsQyxjQUFBLFFBQUNMO29DQUNDd0QsSUFBSUcsS0FBS3ZELElBQUk7b0NBQ2J5RCxTQUFTLElBQU0xQixlQUFld0IsS0FBS3ZELElBQUk7b0NBQ3ZDa0QsV0FBV3JELEdBQ1QsbUVBQ0FZLFNBQVMyQixRQUFRLEtBQUttQixLQUFLdkQsSUFBSSxHQUMzQixjQUNBOztzREFHTixRQUFDcUQ7NENBQUtILFdBQVU7c0RBQ2JLLEtBQUt0RCxLQUFLOzs7Ozs7d0NBRVpzRCxLQUFLeEQsSUFBSTs7Ozs7OzsrQkFsQlB3RCxLQUFLeEQsSUFBSTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE0QmhDO0dBNVFNRzs7UUFJYWQ7OztLQUpiYztBQThRTixlQUFlQSxXQUFXIn0=