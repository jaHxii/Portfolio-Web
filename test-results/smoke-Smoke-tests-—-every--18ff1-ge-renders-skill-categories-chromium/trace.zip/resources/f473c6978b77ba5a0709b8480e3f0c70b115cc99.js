import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/cursor-glow.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/cursor-glow.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useEffect = __vite__cjsImport2_react["useEffect"]; const useRef = __vite__cjsImport2_react["useRef"];
const CursorGlow = ()=>{
    _s();
    const glowRef = useRef(null);
    const frameRef = useRef(null);
    const posRef = useRef({
        x: 0,
        y: 0
    });
    useEffect(()=>{
        const applyTransform = ()=>{
            frameRef.current = null;
            if (!glowRef.current) return;
            const { x, y } = posRef.current;
            glowRef.current.style.transform = `translate(${x}px, ${y}px)`;
        };
        const handleMouseMove = (e)=>{
            posRef.current = {
                x: e.clientX,
                y: e.clientY
            };
            if (frameRef.current === null) {
                frameRef.current = requestAnimationFrame(applyTransform);
            }
        };
        window.addEventListener('mousemove', handleMouseMove, {
            passive: true
        });
        return ()=>{
            window.removeEventListener('mousemove', handleMouseMove);
            if (frameRef.current !== null) {
                cancelAnimationFrame(frameRef.current);
            }
        };
    }, []);
    return /*#__PURE__*/ _jsxDEV("div", {
        ref: glowRef,
        "aria-hidden": "true",
        className: "pointer-events-none cursor-glow fixed top-0 left-0 z-0 hidden md:block w-[600px] h-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full",
        style: {
            background: 'radial-gradient(circle, hsl(var(--primary) / 0.07) 0%, transparent 60%)',
            willChange: 'transform'
        }
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/cursor-glow.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
};
_s(CursorGlow, "8IhashsX15O+jM/2S4suk10UN1w=");
_c = CursorGlow;
export { CursorGlow };
var _c;
$RefreshReg$(_c, "CursorGlow");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/cursor-glow.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/cursor-glow.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1cnNvci1nbG93LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5cbmNvbnN0IEN1cnNvckdsb3cgPSAoKSA9PiB7XG4gIGNvbnN0IGdsb3dSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBmcmFtZVJlZiA9IHVzZVJlZjxudW1iZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgcG9zUmVmID0gdXNlUmVmKHsgeDogMCwgeTogMCB9KTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGFwcGx5VHJhbnNmb3JtID0gKCkgPT4ge1xuICAgICAgZnJhbWVSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBpZiAoIWdsb3dSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgICAgY29uc3QgeyB4LCB5IH0gPSBwb3NSZWYuY3VycmVudDtcbiAgICAgIGdsb3dSZWYuY3VycmVudC5zdHlsZS50cmFuc2Zvcm0gPSBgdHJhbnNsYXRlKCR7eH1weCwgJHt5fXB4KWA7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZU1vdXNlTW92ZSA9IChlOiBNb3VzZUV2ZW50KSA9PiB7XG4gICAgICBwb3NSZWYuY3VycmVudCA9IHsgeDogZS5jbGllbnRYLCB5OiBlLmNsaWVudFkgfTtcbiAgICAgIGlmIChmcmFtZVJlZi5jdXJyZW50ID09PSBudWxsKSB7XG4gICAgICAgIGZyYW1lUmVmLmN1cnJlbnQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoYXBwbHlUcmFuc2Zvcm0pO1xuICAgICAgfVxuICAgIH07XG5cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgaGFuZGxlTW91c2VNb3ZlLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZW1vdmUnLCBoYW5kbGVNb3VzZU1vdmUpO1xuICAgICAgaWYgKGZyYW1lUmVmLmN1cnJlbnQgIT09IG51bGwpIHtcbiAgICAgICAgY2FuY2VsQW5pbWF0aW9uRnJhbWUoZnJhbWVSZWYuY3VycmVudCk7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcmVmPXtnbG93UmVmfVxuICAgICAgYXJpYS1oaWRkZW49J3RydWUnXG4gICAgICBjbGFzc05hbWU9J3BvaW50ZXItZXZlbnRzLW5vbmUgY3Vyc29yLWdsb3cgZml4ZWQgdG9wLTAgbGVmdC0wIHotMCBoaWRkZW4gbWQ6YmxvY2sgdy1bNjAwcHhdIGgtWzYwMHB4XSAtdHJhbnNsYXRlLXgtMS8yIC10cmFuc2xhdGUteS0xLzIgcm91bmRlZC1mdWxsJ1xuICAgICAgc3R5bGU9e3tcbiAgICAgICAgYmFja2dyb3VuZDpcbiAgICAgICAgICAncmFkaWFsLWdyYWRpZW50KGNpcmNsZSwgaHNsKHZhcigtLXByaW1hcnkpIC8gMC4wNykgMCUsIHRyYW5zcGFyZW50IDYwJSknLFxuICAgICAgICB3aWxsQ2hhbmdlOiAndHJhbnNmb3JtJyxcbiAgICAgIH19XG4gICAgLz5cbiAgKTtcbn07XG5cbmV4cG9ydCB7IEN1cnNvckdsb3cgfTtcbiJdLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVJlZiIsIkN1cnNvckdsb3ciLCJnbG93UmVmIiwiZnJhbWVSZWYiLCJwb3NSZWYiLCJ4IiwieSIsImFwcGx5VHJhbnNmb3JtIiwiY3VycmVudCIsInN0eWxlIiwidHJhbnNmb3JtIiwiaGFuZGxlTW91c2VNb3ZlIiwiZSIsImNsaWVudFgiLCJjbGllbnRZIiwicmVxdWVzdEFuaW1hdGlvbkZyYW1lIiwid2luZG93IiwiYWRkRXZlbnRMaXN0ZW5lciIsInBhc3NpdmUiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiY2FuY2VsQW5pbWF0aW9uRnJhbWUiLCJkaXYiLCJyZWYiLCJhcmlhLWhpZGRlbiIsImNsYXNzTmFtZSIsImJhY2tncm91bmQiLCJ3aWxsQ2hhbmdlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsU0FBUyxFQUFFQyxNQUFNLFFBQVEsUUFBUTtBQUVqRCxNQUFNQyxhQUFhOztJQUNqQixNQUFNQyxVQUFVRixPQUF1QjtJQUN2QyxNQUFNRyxXQUFXSCxPQUFzQjtJQUN2QyxNQUFNSSxTQUFTSixPQUFPO1FBQUVLLEdBQUc7UUFBR0MsR0FBRztJQUFFO0lBRW5DUCxVQUFVO1FBQ1IsTUFBTVEsaUJBQWlCO1lBQ3JCSixTQUFTSyxPQUFPLEdBQUc7WUFDbkIsSUFBSSxDQUFDTixRQUFRTSxPQUFPLEVBQUU7WUFDdEIsTUFBTSxFQUFFSCxDQUFDLEVBQUVDLENBQUMsRUFBRSxHQUFHRixPQUFPSSxPQUFPO1lBQy9CTixRQUFRTSxPQUFPLENBQUNDLEtBQUssQ0FBQ0MsU0FBUyxHQUFHLENBQUMsVUFBVSxFQUFFTCxFQUFFLElBQUksRUFBRUMsRUFBRSxHQUFHLENBQUM7UUFDL0Q7UUFFQSxNQUFNSyxrQkFBa0IsQ0FBQ0M7WUFDdkJSLE9BQU9JLE9BQU8sR0FBRztnQkFBRUgsR0FBR08sRUFBRUMsT0FBTztnQkFBRVAsR0FBR00sRUFBRUUsT0FBTztZQUFDO1lBQzlDLElBQUlYLFNBQVNLLE9BQU8sS0FBSyxNQUFNO2dCQUM3QkwsU0FBU0ssT0FBTyxHQUFHTyxzQkFBc0JSO1lBQzNDO1FBQ0Y7UUFFQVMsT0FBT0MsZ0JBQWdCLENBQUMsYUFBYU4saUJBQWlCO1lBQUVPLFNBQVM7UUFBSztRQUN0RSxPQUFPO1lBQ0xGLE9BQU9HLG1CQUFtQixDQUFDLGFBQWFSO1lBQ3hDLElBQUlSLFNBQVNLLE9BQU8sS0FBSyxNQUFNO2dCQUM3QlkscUJBQXFCakIsU0FBU0ssT0FBTztZQUN2QztRQUNGO0lBQ0YsR0FBRyxFQUFFO0lBRUwscUJBQ0UsUUFBQ2E7UUFDQ0MsS0FBS3BCO1FBQ0xxQixlQUFZO1FBQ1pDLFdBQVU7UUFDVmYsT0FBTztZQUNMZ0IsWUFDRTtZQUNGQyxZQUFZO1FBQ2Q7Ozs7OztBQUdOO0dBekNNekI7S0FBQUE7QUEyQ04sU0FBU0EsVUFBVSxHQUFHIn0=