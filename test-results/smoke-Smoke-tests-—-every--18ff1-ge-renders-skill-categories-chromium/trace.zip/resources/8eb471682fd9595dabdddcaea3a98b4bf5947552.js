import {
  Root,
  Slot,
  Slottable
} from "/node_modules/.vite/deps/chunk-UHRFJVI6.js?v=e72f996b";
import "/node_modules/.vite/deps/chunk-S725DACQ.js?v=e72f996b";
import "/node_modules/.vite/deps/chunk-RLJ2RCJQ.js?v=e72f996b";
import "/node_modules/.vite/deps/chunk-DC5AMYBS.js?v=e72f996b";
export {
  Root,
  Slot,
  Slottable
};
//# sourceMappingURL=@radix-ui_react-slot.js.map
