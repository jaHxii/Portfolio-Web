import {
  require_react
} from "/node_modules/.vite/deps/chunk-RLJ2RCJQ.js?v=e72f996b";
import "/node_modules/.vite/deps/chunk-DC5AMYBS.js?v=e72f996b";
export default require_react();
//# sourceMappingURL=react.js.map
