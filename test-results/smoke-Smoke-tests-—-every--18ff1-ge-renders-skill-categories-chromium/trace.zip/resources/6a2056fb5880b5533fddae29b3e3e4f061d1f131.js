import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=e72f996b"; const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];
import { HelmetProvider } from "/node_modules/.vite/deps/react-helmet-async.js?v=e72f996b";
import App from "/src/App.tsx";
import "/src/index.css";
createRoot(document.getElementById('root')).render(/*#__PURE__*/ _jsxDEV(HelmetProvider, {
    children: /*#__PURE__*/ _jsxDEV(App, {}, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/main.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this)
}, void 0, false, {
    fileName: "D:/Projects/Portfolio-Web/src/main.tsx",
    lineNumber: 7,
    columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZVJvb3QgfSBmcm9tICdyZWFjdC1kb20vY2xpZW50JztcbmltcG9ydCB7IEhlbG1ldFByb3ZpZGVyIH0gZnJvbSAncmVhY3QtaGVsbWV0LWFzeW5jJztcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAudHN4JztcbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuXG5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykhKS5yZW5kZXIoXG4gIDxIZWxtZXRQcm92aWRlcj5cbiAgICA8QXBwIC8+XG4gIDwvSGVsbWV0UHJvdmlkZXI+XG4pO1xuIl0sIm5hbWVzIjpbImNyZWF0ZVJvb3QiLCJIZWxtZXRQcm92aWRlciIsIkFwcCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiXSwibWFwcGluZ3MiOiI7QUFBQSxTQUFTQSxVQUFVLFFBQVEsbUJBQW1CO0FBQzlDLFNBQVNDLGNBQWMsUUFBUSxxQkFBcUI7QUFDcEQsT0FBT0MsU0FBUyxZQUFZO0FBQzVCLE9BQU8sY0FBYztBQUVyQkYsV0FBV0csU0FBU0MsY0FBYyxDQUFDLFNBQVVDLE1BQU0sZUFDakQsUUFBQ0o7Y0FDQyxjQUFBLFFBQUNDIn0=