import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Skills.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/pages/Skills.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { useInView } from "/node_modules/.vite/deps/react-intersection-observer.js?v=e72f996b";
import Navigation from "/src/components/layout/Navigation.tsx";
import Footer from "/src/components/layout/Footer.tsx";
import Atmosphere from "/src/components/atmosphere/Atmosphere.tsx";
import FlightLog from "/src/components/ui/flight-log.tsx";
import SEO from "/src/components/seo/SEO.tsx";
import StructuredData from "/src/components/seo/StructuredData.tsx";
import { useSEO } from "/src/hooks/use-seo.ts";
import { useStructuredData } from "/src/hooks/use-structured-data.ts";
import { cn } from "/src/lib/utils.ts";
const ENGINEERING_STACK = [
    {
        code: 'SYS',
        title: 'Systems',
        skills: [
            'Windows',
            'Linux',
            'Hardware',
            'Troubleshooting'
        ],
        level: 92
    },
    {
        code: 'NET',
        title: 'Network',
        skills: [
            'TCP/IP',
            'Routing',
            'Switching',
            'Network troubleshooting'
        ],
        level: 85
    },
    {
        code: 'DEV',
        title: 'Development',
        skills: [
            'Python',
            'React',
            'JavaScript',
            'SQL'
        ],
        level: 82
    },
    {
        code: 'ML',
        title: 'AI / ML',
        skills: [
            'PyTorch',
            'TensorFlow',
            'Computer Vision'
        ],
        level: 75
    }
];
const Skills = ()=>{
    _s();
    const seoProps = useSEO();
    const { breadcrumbSchema } = useStructuredData();
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    });
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "min-h-screen bg-background",
        children: [
            /*#__PURE__*/ _jsxDEV(SEO, {
                ...seoProps
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(StructuredData, {
                schema: breadcrumbSchema
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(Navigation, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("section", {
                className: "relative pt-36 pb-20 overflow-hidden",
                children: [
                    /*#__PURE__*/ _jsxDEV(Atmosphere, {
                        variant: "mist"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "relative z-10 container mx-auto px-4",
                        children: /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.8
                            },
                            className: "max-w-3xl mx-auto text-center",
                            children: [
                                /*#__PURE__*/ _jsxDEV(FlightLog, {
                                    entries: [
                                        'FLIGHT LOG / ENGINEERING STACK',
                                        'ENGINE ROOM · NOMINAL',
                                        'INSTRUMENTS · ALL GREEN',
                                        'MULTI-MODULE / CO-PILOTED'
                                    ]
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                    lineNumber: 66,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("h1", {
                                    className: "text-4xl md:text-5xl font-bold font-heading tracking-tight",
                                    children: /*#__PURE__*/ _jsxDEV("span", {
                                        className: "name-gradient",
                                        children: "Skills"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                        lineNumber: 75,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                    lineNumber: 74,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "mt-5 text-lg text-mist-soft leading-relaxed font-light max-w-2xl mx-auto",
                                    children: "Practical, hands-on expertise across infrastructure, networking, development, and AI/ML."
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("section", {
                className: "relative py-12 overflow-hidden",
                children: [
                    /*#__PURE__*/ _jsxDEV(Atmosphere, {}, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                        lineNumber: 87,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "relative z-10 container mx-auto px-4 max-w-5xl",
                        children: [
                            /*#__PURE__*/ _jsxDEV(motion.div, {
                                ref: ref,
                                initial: {
                                    opacity: 0,
                                    y: 30
                                },
                                animate: inView ? {
                                    opacity: 1,
                                    y: 0
                                } : {},
                                transition: {
                                    duration: 0.8
                                },
                                className: "space-y-5",
                                children: ENGINEERING_STACK.map((group, gi)=>/*#__PURE__*/ _jsxDEV(motion.div, {
                                        initial: {
                                            opacity: 0,
                                            y: 24
                                        },
                                        animate: inView ? {
                                            opacity: 1,
                                            y: 0
                                        } : {},
                                        transition: {
                                            delay: 0.3 + gi * 0.12,
                                            duration: 0.6
                                        },
                                        className: "glass-cloud rounded-xl p-7 md:p-8",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("div", {
                                                className: "flex items-center gap-4 mb-6",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                        className: "font-mono text-xs tracking-[0.3em] gold-text",
                                                        children: group.code
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                        lineNumber: 105,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("h2", {
                                                        className: "font-heading font-semibold text-xl tracking-tight uppercase",
                                                        children: group.title
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                        lineNumber: 108,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                        className: "font-mono text-xs text-mist-soft/60 ml-auto",
                                                        children: [
                                                            group.level,
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                        lineNumber: 111,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                lineNumber: 104,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("div", {
                                                className: "grid sm:grid-cols-2 gap-x-8 gap-y-4",
                                                children: group.skills.map((skill)=>/*#__PURE__*/ _jsxDEV("div", {
                                                        className: "flex items-center gap-3",
                                                        children: [
                                                            /*#__PURE__*/ _jsxDEV("span", {
                                                                className: "h-1 w-1 rounded-full bg-gold shrink-0"
                                                            }, void 0, false, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                                lineNumber: 119,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ _jsxDEV("span", {
                                                                className: "text-sm text-foreground/85",
                                                                children: skill
                                                            }, void 0, false, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                                lineNumber: 120,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, skill, true, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                        lineNumber: 118,
                                                        columnNumber: 21
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                lineNumber: 116,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("div", {
                                                className: "mt-6 h-px w-full bg-white/5",
                                                children: /*#__PURE__*/ _jsxDEV(motion.div, {
                                                    initial: {
                                                        width: 0
                                                    },
                                                    animate: inView ? {
                                                        width: `${group.level}%`
                                                    } : {},
                                                    transition: {
                                                        delay: 0.6 + gi * 0.12,
                                                        duration: 1,
                                                        ease: 'easeOut'
                                                    },
                                                    className: "h-px bg-gradient-gold"
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                    lineNumber: 128,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                lineNumber: 127,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, group.code, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                        lineNumber: 97,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                lineNumber: 89,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV(motion.div, {
                                initial: {
                                    opacity: 0,
                                    y: 24
                                },
                                animate: inView ? {
                                    opacity: 1,
                                    y: 0
                                } : {},
                                transition: {
                                    delay: 0.9,
                                    duration: 0.6
                                },
                                className: cn('mt-12 glass rounded-xl p-7'),
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "flex items-center gap-3 mb-5",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "font-mono text-xs tracking-[0.3em] gold-text",
                                                children: "OPS"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                lineNumber: 151,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("h2", {
                                                className: "font-heading font-semibold text-lg tracking-tight uppercase",
                                                children: "Operations & Practices"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                lineNumber: 154,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                        lineNumber: 150,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "flex flex-wrap gap-2",
                                        children: [
                                            'Helpdesk & SLA Management',
                                            'IT Procurement',
                                            'Technical Documentation',
                                            'Process Automation',
                                            'Git / GitHub',
                                            'User Training'
                                        ].map((skill)=>/*#__PURE__*/ _jsxDEV("span", {
                                                className: "glass inline-flex items-center gap-2 px-4 py-2 rounded-md font-mono text-xs text-mist-soft",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                        className: "h-1 w-1 rounded-full bg-gold/70"
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                        lineNumber: 171,
                                                        columnNumber: 19
                                                    }, this),
                                                    skill
                                                ]
                                            }, skill, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                                lineNumber: 167,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                        lineNumber: 158,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                                lineNumber: 144,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                        lineNumber: 88,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                lineNumber: 86,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(Footer, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
                lineNumber: 179,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/Skills.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
};
_s(Skills, "UzxfgszjPNZMiyUoNSeIGAfAq4E=", false, function() {
    return [
        useSEO,
        useStructuredData,
        useInView
    ];
});
_c = Skills;
export default Skills;
var _c;
$RefreshReg$(_c, "Skills");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/pages/Skills.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/pages/Skills.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNraWxscy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgdXNlSW5WaWV3IH0gZnJvbSAncmVhY3QtaW50ZXJzZWN0aW9uLW9ic2VydmVyJztcbmltcG9ydCBOYXZpZ2F0aW9uIGZyb20gJ0AvY29tcG9uZW50cy9sYXlvdXQvTmF2aWdhdGlvbic7XG5pbXBvcnQgRm9vdGVyIGZyb20gJ0AvY29tcG9uZW50cy9sYXlvdXQvRm9vdGVyJztcbmltcG9ydCBBdG1vc3BoZXJlIGZyb20gJ0AvY29tcG9uZW50cy9hdG1vc3BoZXJlL0F0bW9zcGhlcmUnO1xuaW1wb3J0IEZsaWdodExvZyBmcm9tICdAL2NvbXBvbmVudHMvdWkvZmxpZ2h0LWxvZyc7XG5pbXBvcnQgU0VPIGZyb20gJ0AvY29tcG9uZW50cy9zZW8vU0VPJztcbmltcG9ydCBTdHJ1Y3R1cmVkRGF0YSBmcm9tICdAL2NvbXBvbmVudHMvc2VvL1N0cnVjdHVyZWREYXRhJztcbmltcG9ydCB7IHVzZVNFTyB9IGZyb20gJ0AvaG9va3MvdXNlLXNlbyc7XG5pbXBvcnQgeyB1c2VTdHJ1Y3R1cmVkRGF0YSB9IGZyb20gJ0AvaG9va3MvdXNlLXN0cnVjdHVyZWQtZGF0YSc7XG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJztcblxuY29uc3QgRU5HSU5FRVJJTkdfU1RBQ0sgPSBbXG4gIHtcbiAgICBjb2RlOiAnU1lTJyxcbiAgICB0aXRsZTogJ1N5c3RlbXMnLFxuICAgIHNraWxsczogWydXaW5kb3dzJywgJ0xpbnV4JywgJ0hhcmR3YXJlJywgJ1Ryb3VibGVzaG9vdGluZyddLFxuICAgIGxldmVsOiA5MixcbiAgfSxcbiAge1xuICAgIGNvZGU6ICdORVQnLFxuICAgIHRpdGxlOiAnTmV0d29yaycsXG4gICAgc2tpbGxzOiBbJ1RDUC9JUCcsICdSb3V0aW5nJywgJ1N3aXRjaGluZycsICdOZXR3b3JrIHRyb3VibGVzaG9vdGluZyddLFxuICAgIGxldmVsOiA4NSxcbiAgfSxcbiAge1xuICAgIGNvZGU6ICdERVYnLFxuICAgIHRpdGxlOiAnRGV2ZWxvcG1lbnQnLFxuICAgIHNraWxsczogWydQeXRob24nLCAnUmVhY3QnLCAnSmF2YVNjcmlwdCcsICdTUUwnXSxcbiAgICBsZXZlbDogODIsXG4gIH0sXG4gIHtcbiAgICBjb2RlOiAnTUwnLFxuICAgIHRpdGxlOiAnQUkgLyBNTCcsXG4gICAgc2tpbGxzOiBbJ1B5VG9yY2gnLCAnVGVuc29yRmxvdycsICdDb21wdXRlciBWaXNpb24nXSxcbiAgICBsZXZlbDogNzUsXG4gIH0sXG5dO1xuXG5jb25zdCBTa2lsbHMgPSAoKSA9PiB7XG4gIGNvbnN0IHNlb1Byb3BzID0gdXNlU0VPKCk7XG4gIGNvbnN0IHsgYnJlYWRjcnVtYlNjaGVtYSB9ID0gdXNlU3RydWN0dXJlZERhdGEoKTtcblxuICBjb25zdCBbcmVmLCBpblZpZXddID0gdXNlSW5WaWV3KHtcbiAgICB0cmlnZ2VyT25jZTogdHJ1ZSxcbiAgICB0aHJlc2hvbGQ6IDAuMSxcbiAgfSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT0nbWluLWgtc2NyZWVuIGJnLWJhY2tncm91bmQnPlxuICAgICAgPFNFTyB7Li4uc2VvUHJvcHN9IC8+XG4gICAgICA8U3RydWN0dXJlZERhdGEgc2NoZW1hPXticmVhZGNydW1iU2NoZW1hfSAvPlxuICAgICAgPE5hdmlnYXRpb24gLz5cblxuICAgICAgey8qIEhlcm8gKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9J3JlbGF0aXZlIHB0LTM2IHBiLTIwIG92ZXJmbG93LWhpZGRlbic+XG4gICAgICAgIDxBdG1vc3BoZXJlIHZhcmlhbnQ9J21pc3QnIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdyZWxhdGl2ZSB6LTEwIGNvbnRhaW5lciBteC1hdXRvIHB4LTQnPlxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDMwIH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuOCB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPSdtYXgtdy0zeGwgbXgtYXV0byB0ZXh0LWNlbnRlcidcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RmxpZ2h0TG9nXG4gICAgICAgICAgICAgIGVudHJpZXM9e1tcbiAgICAgICAgICAgICAgICAnRkxJR0hUIExPRyAvIEVOR0lORUVSSU5HIFNUQUNLJyxcbiAgICAgICAgICAgICAgICAnRU5HSU5FIFJPT00gwrcgTk9NSU5BTCcsXG4gICAgICAgICAgICAgICAgJ0lOU1RSVU1FTlRTIMK3IEFMTCBHUkVFTicsXG4gICAgICAgICAgICAgICAgJ01VTFRJLU1PRFVMRSAvIENPLVBJTE9URUQnLFxuICAgICAgICAgICAgICBdfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9J3RleHQtNHhsIG1kOnRleHQtNXhsIGZvbnQtYm9sZCBmb250LWhlYWRpbmcgdHJhY2tpbmctdGlnaHQnPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J25hbWUtZ3JhZGllbnQnPlNraWxsczwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9J210LTUgdGV4dC1sZyB0ZXh0LW1pc3Qtc29mdCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1saWdodCBtYXgtdy0yeGwgbXgtYXV0byc+XG4gICAgICAgICAgICAgIFByYWN0aWNhbCwgaGFuZHMtb24gZXhwZXJ0aXNlIGFjcm9zcyBpbmZyYXN0cnVjdHVyZSwgbmV0d29ya2luZyxcbiAgICAgICAgICAgICAgZGV2ZWxvcG1lbnQsIGFuZCBBSS9NTC5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogRW5naW5lZXJpbmcgU3RhY2sgKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9J3JlbGF0aXZlIHB5LTEyIG92ZXJmbG93LWhpZGRlbic+XG4gICAgICAgIDxBdG1vc3BoZXJlIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdyZWxhdGl2ZSB6LTEwIGNvbnRhaW5lciBteC1hdXRvIHB4LTQgbWF4LXctNXhsJz5cbiAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgcmVmPXtyZWZ9XG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDMwIH19XG4gICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHk6IDAgfSA6IHt9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC44IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J3NwYWNlLXktNSdcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7RU5HSU5FRVJJTkdfU1RBQ0subWFwKChncm91cCwgZ2kpID0+IChcbiAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgICBrZXk9e2dyb3VwLmNvZGV9XG4gICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAyNCB9fVxuICAgICAgICAgICAgICAgIGFuaW1hdGU9e2luVmlldyA/IHsgb3BhY2l0eTogMSwgeTogMCB9IDoge319XG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC4zICsgZ2kgKiAwLjEyLCBkdXJhdGlvbjogMC42IH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdnbGFzcy1jbG91ZCByb3VuZGVkLXhsIHAtNyBtZDpwLTgnXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNic+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIHRyYWNraW5nLVswLjNlbV0gZ29sZC10ZXh0Jz5cbiAgICAgICAgICAgICAgICAgICAge2dyb3VwLmNvZGV9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPSdmb250LWhlYWRpbmcgZm9udC1zZW1pYm9sZCB0ZXh0LXhsIHRyYWNraW5nLXRpZ2h0IHVwcGVyY2FzZSc+XG4gICAgICAgICAgICAgICAgICAgIHtncm91cC50aXRsZX1cbiAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtbWlzdC1zb2Z0LzYwIG1sLWF1dG8nPlxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXAubGV2ZWx9JVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2dyaWQgc206Z3JpZC1jb2xzLTIgZ2FwLXgtOCBnYXAteS00Jz5cbiAgICAgICAgICAgICAgICAgIHtncm91cC5za2lsbHMubWFwKHNraWxsID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3NraWxsfSBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGdhcC0zJz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2gtMSB3LTEgcm91bmRlZC1mdWxsIGJnLWdvbGQgc2hyaW5rLTAnIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSd0ZXh0LXNtIHRleHQtZm9yZWdyb3VuZC84NSc+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2tpbGx9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J210LTYgaC1weCB3LWZ1bGwgYmctd2hpdGUvNSc+XG4gICAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAgICBpbml0aWFsPXt7IHdpZHRoOiAwIH19XG4gICAgICAgICAgICAgICAgICAgIGFuaW1hdGU9e2luVmlldyA/IHsgd2lkdGg6IGAke2dyb3VwLmxldmVsfSVgIH0gOiB7fX1cbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17e1xuICAgICAgICAgICAgICAgICAgICAgIGRlbGF5OiAwLjYgKyBnaSAqIDAuMTIsXG4gICAgICAgICAgICAgICAgICAgICAgZHVyYXRpb246IDEsXG4gICAgICAgICAgICAgICAgICAgICAgZWFzZTogJ2Vhc2VPdXQnLFxuICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2gtcHggYmctZ3JhZGllbnQtZ29sZCdcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgICAgIHsvKiBCYXNlLWxldmVsIHByb2ZpY2llbmNpZXMgKi99XG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMjQgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e2luVmlldyA/IHsgb3BhY2l0eTogMSwgeTogMCB9IDoge319XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjksIGR1cmF0aW9uOiAwLjYgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oJ210LTEyIGdsYXNzIHJvdW5kZWQteGwgcC03Jyl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTUnPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIHRyYWNraW5nLVswLjNlbV0gZ29sZC10ZXh0Jz5cbiAgICAgICAgICAgICAgICBPUFNcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPSdmb250LWhlYWRpbmcgZm9udC1zZW1pYm9sZCB0ZXh0LWxnIHRyYWNraW5nLXRpZ2h0IHVwcGVyY2FzZSc+XG4gICAgICAgICAgICAgICAgT3BlcmF0aW9ucyAmIFByYWN0aWNlc1xuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBmbGV4LXdyYXAgZ2FwLTInPlxuICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICdIZWxwZGVzayAmIFNMQSBNYW5hZ2VtZW50JyxcbiAgICAgICAgICAgICAgICAnSVQgUHJvY3VyZW1lbnQnLFxuICAgICAgICAgICAgICAgICdUZWNobmljYWwgRG9jdW1lbnRhdGlvbicsXG4gICAgICAgICAgICAgICAgJ1Byb2Nlc3MgQXV0b21hdGlvbicsXG4gICAgICAgICAgICAgICAgJ0dpdCAvIEdpdEh1YicsXG4gICAgICAgICAgICAgICAgJ1VzZXIgVHJhaW5pbmcnLFxuICAgICAgICAgICAgICBdLm1hcChza2lsbCA9PiAoXG4gICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgIGtleT17c2tpbGx9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2dsYXNzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgcm91bmRlZC1tZCBmb250LW1vbm8gdGV4dC14cyB0ZXh0LW1pc3Qtc29mdCdcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2gtMSB3LTEgcm91bmRlZC1mdWxsIGJnLWdvbGQvNzAnIC8+XG4gICAgICAgICAgICAgICAgICB7c2tpbGx9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgICA8Rm9vdGVyIC8+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBTa2lsbHM7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJtb3Rpb24iLCJ1c2VJblZpZXciLCJOYXZpZ2F0aW9uIiwiRm9vdGVyIiwiQXRtb3NwaGVyZSIsIkZsaWdodExvZyIsIlNFTyIsIlN0cnVjdHVyZWREYXRhIiwidXNlU0VPIiwidXNlU3RydWN0dXJlZERhdGEiLCJjbiIsIkVOR0lORUVSSU5HX1NUQUNLIiwiY29kZSIsInRpdGxlIiwic2tpbGxzIiwibGV2ZWwiLCJTa2lsbHMiLCJzZW9Qcm9wcyIsImJyZWFkY3J1bWJTY2hlbWEiLCJyZWYiLCJpblZpZXciLCJ0cmlnZ2VyT25jZSIsInRocmVzaG9sZCIsImRpdiIsImNsYXNzTmFtZSIsInNjaGVtYSIsInNlY3Rpb24iLCJ2YXJpYW50IiwiaW5pdGlhbCIsIm9wYWNpdHkiLCJ5IiwiYW5pbWF0ZSIsInRyYW5zaXRpb24iLCJkdXJhdGlvbiIsImVudHJpZXMiLCJoMSIsInNwYW4iLCJwIiwibWFwIiwiZ3JvdXAiLCJnaSIsImRlbGF5IiwiaDIiLCJza2lsbCIsIndpZHRoIiwiZWFzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLE9BQU9BLFdBQVcsUUFBUTtBQUMxQixTQUFTQyxNQUFNLFFBQVEsZ0JBQWdCO0FBQ3ZDLFNBQVNDLFNBQVMsUUFBUSw4QkFBOEI7QUFDeEQsT0FBT0MsZ0JBQWdCLGlDQUFpQztBQUN4RCxPQUFPQyxZQUFZLDZCQUE2QjtBQUNoRCxPQUFPQyxnQkFBZ0IscUNBQXFDO0FBQzVELE9BQU9DLGVBQWUsNkJBQTZCO0FBQ25ELE9BQU9DLFNBQVMsdUJBQXVCO0FBQ3ZDLE9BQU9DLG9CQUFvQixrQ0FBa0M7QUFDN0QsU0FBU0MsTUFBTSxRQUFRLGtCQUFrQjtBQUN6QyxTQUFTQyxpQkFBaUIsUUFBUSw4QkFBOEI7QUFDaEUsU0FBU0MsRUFBRSxRQUFRLGNBQWM7QUFFakMsTUFBTUMsb0JBQW9CO0lBQ3hCO1FBQ0VDLE1BQU07UUFDTkMsT0FBTztRQUNQQyxRQUFRO1lBQUM7WUFBVztZQUFTO1lBQVk7U0FBa0I7UUFDM0RDLE9BQU87SUFDVDtJQUNBO1FBQ0VILE1BQU07UUFDTkMsT0FBTztRQUNQQyxRQUFRO1lBQUM7WUFBVTtZQUFXO1lBQWE7U0FBMEI7UUFDckVDLE9BQU87SUFDVDtJQUNBO1FBQ0VILE1BQU07UUFDTkMsT0FBTztRQUNQQyxRQUFRO1lBQUM7WUFBVTtZQUFTO1lBQWM7U0FBTTtRQUNoREMsT0FBTztJQUNUO0lBQ0E7UUFDRUgsTUFBTTtRQUNOQyxPQUFPO1FBQ1BDLFFBQVE7WUFBQztZQUFXO1lBQWM7U0FBa0I7UUFDcERDLE9BQU87SUFDVDtDQUNEO0FBRUQsTUFBTUMsU0FBUzs7SUFDYixNQUFNQyxXQUFXVDtJQUNqQixNQUFNLEVBQUVVLGdCQUFnQixFQUFFLEdBQUdUO0lBRTdCLE1BQU0sQ0FBQ1UsS0FBS0MsT0FBTyxHQUFHbkIsVUFBVTtRQUM5Qm9CLGFBQWE7UUFDYkMsV0FBVztJQUNiO0lBRUEscUJBQ0UsUUFBQ0M7UUFBSUMsV0FBVTs7MEJBQ2IsUUFBQ2xCO2dCQUFLLEdBQUdXLFFBQVE7Ozs7OzswQkFDakIsUUFBQ1Y7Z0JBQWVrQixRQUFRUDs7Ozs7OzBCQUN4QixRQUFDaEI7Ozs7OzBCQUdELFFBQUN3QjtnQkFBUUYsV0FBVTs7a0NBQ2pCLFFBQUNwQjt3QkFBV3VCLFNBQVE7Ozs7OztrQ0FDcEIsUUFBQ0o7d0JBQUlDLFdBQVU7a0NBQ2IsY0FBQSxRQUFDeEIsT0FBT3VCLEdBQUc7NEJBQ1RLLFNBQVM7Z0NBQUVDLFNBQVM7Z0NBQUdDLEdBQUc7NEJBQUc7NEJBQzdCQyxTQUFTO2dDQUFFRixTQUFTO2dDQUFHQyxHQUFHOzRCQUFFOzRCQUM1QkUsWUFBWTtnQ0FBRUMsVUFBVTs0QkFBSTs0QkFDNUJULFdBQVU7OzhDQUVWLFFBQUNuQjtvQ0FDQzZCLFNBQVM7d0NBQ1A7d0NBQ0E7d0NBQ0E7d0NBQ0E7cUNBQ0Q7Ozs7Ozs4Q0FFSCxRQUFDQztvQ0FBR1gsV0FBVTs4Q0FDWixjQUFBLFFBQUNZO3dDQUFLWixXQUFVO2tEQUFnQjs7Ozs7Ozs7Ozs7OENBRWxDLFFBQUNhO29DQUFFYixXQUFVOzhDQUEyRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBUzlGLFFBQUNFO2dCQUFRRixXQUFVOztrQ0FDakIsUUFBQ3BCOzs7OztrQ0FDRCxRQUFDbUI7d0JBQUlDLFdBQVU7OzBDQUNiLFFBQUN4QixPQUFPdUIsR0FBRztnQ0FDVEosS0FBS0E7Z0NBQ0xTLFNBQVM7b0NBQUVDLFNBQVM7b0NBQUdDLEdBQUc7Z0NBQUc7Z0NBQzdCQyxTQUFTWCxTQUFTO29DQUFFUyxTQUFTO29DQUFHQyxHQUFHO2dDQUFFLElBQUksQ0FBQztnQ0FDMUNFLFlBQVk7b0NBQUVDLFVBQVU7Z0NBQUk7Z0NBQzVCVCxXQUFVOzBDQUVUYixrQkFBa0IyQixHQUFHLENBQUMsQ0FBQ0MsT0FBT0MsbUJBQzdCLFFBQUN4QyxPQUFPdUIsR0FBRzt3Q0FFVEssU0FBUzs0Q0FBRUMsU0FBUzs0Q0FBR0MsR0FBRzt3Q0FBRzt3Q0FDN0JDLFNBQVNYLFNBQVM7NENBQUVTLFNBQVM7NENBQUdDLEdBQUc7d0NBQUUsSUFBSSxDQUFDO3dDQUMxQ0UsWUFBWTs0Q0FBRVMsT0FBTyxNQUFNRCxLQUFLOzRDQUFNUCxVQUFVO3dDQUFJO3dDQUNwRFQsV0FBVTs7MERBRVYsUUFBQ0Q7Z0RBQUlDLFdBQVU7O2tFQUNiLFFBQUNZO3dEQUFLWixXQUFVO2tFQUNiZSxNQUFNM0IsSUFBSTs7Ozs7O2tFQUViLFFBQUM4Qjt3REFBR2xCLFdBQVU7a0VBQ1hlLE1BQU0xQixLQUFLOzs7Ozs7a0VBRWQsUUFBQ3VCO3dEQUFLWixXQUFVOzs0REFDYmUsTUFBTXhCLEtBQUs7NERBQUM7Ozs7Ozs7Ozs7Ozs7MERBSWpCLFFBQUNRO2dEQUFJQyxXQUFVOzBEQUNaZSxNQUFNekIsTUFBTSxDQUFDd0IsR0FBRyxDQUFDSyxDQUFBQSxzQkFDaEIsUUFBQ3BCO3dEQUFnQkMsV0FBVTs7MEVBQ3pCLFFBQUNZO2dFQUFLWixXQUFVOzs7Ozs7MEVBQ2hCLFFBQUNZO2dFQUFLWixXQUFVOzBFQUNibUI7Ozs7Ozs7dURBSEtBOzs7Ozs7Ozs7OzBEQVNkLFFBQUNwQjtnREFBSUMsV0FBVTswREFDYixjQUFBLFFBQUN4QixPQUFPdUIsR0FBRztvREFDVEssU0FBUzt3REFBRWdCLE9BQU87b0RBQUU7b0RBQ3BCYixTQUFTWCxTQUFTO3dEQUFFd0IsT0FBTyxHQUFHTCxNQUFNeEIsS0FBSyxDQUFDLENBQUMsQ0FBQztvREFBQyxJQUFJLENBQUM7b0RBQ2xEaUIsWUFBWTt3REFDVlMsT0FBTyxNQUFNRCxLQUFLO3dEQUNsQlAsVUFBVTt3REFDVlksTUFBTTtvREFDUjtvREFDQXJCLFdBQVU7Ozs7Ozs7Ozs7Ozt1Q0F0Q1RlLE1BQU0zQixJQUFJOzs7Ozs7Ozs7OzBDQThDckIsUUFBQ1osT0FBT3VCLEdBQUc7Z0NBQ1RLLFNBQVM7b0NBQUVDLFNBQVM7b0NBQUdDLEdBQUc7Z0NBQUc7Z0NBQzdCQyxTQUFTWCxTQUFTO29DQUFFUyxTQUFTO29DQUFHQyxHQUFHO2dDQUFFLElBQUksQ0FBQztnQ0FDMUNFLFlBQVk7b0NBQUVTLE9BQU87b0NBQUtSLFVBQVU7Z0NBQUk7Z0NBQ3hDVCxXQUFXZCxHQUFHOztrREFFZCxRQUFDYTt3Q0FBSUMsV0FBVTs7MERBQ2IsUUFBQ1k7Z0RBQUtaLFdBQVU7MERBQStDOzs7Ozs7MERBRy9ELFFBQUNrQjtnREFBR2xCLFdBQVU7MERBQThEOzs7Ozs7Ozs7Ozs7a0RBSTlFLFFBQUNEO3dDQUFJQyxXQUFVO2tEQUNaOzRDQUNDOzRDQUNBOzRDQUNBOzRDQUNBOzRDQUNBOzRDQUNBO3lDQUNELENBQUNjLEdBQUcsQ0FBQ0ssQ0FBQUEsc0JBQ0osUUFBQ1A7Z0RBRUNaLFdBQVU7O2tFQUVWLFFBQUNZO3dEQUFLWixXQUFVOzs7Ozs7b0RBQ2ZtQjs7K0NBSklBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBCQVdqQixRQUFDeEM7Ozs7Ozs7Ozs7O0FBR1A7R0E3SU1hOztRQUNhUjtRQUNZQztRQUVQUjs7O0tBSmxCZTtBQStJTixlQUFlQSxPQUFPIn0=