import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/preload-link.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/preload-link.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useCallback = __vite__cjsImport2_react["useCallback"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=e72f996b";
import { scheduleRoutePreload, cancelScheduledPreload } from "/src/lib/route-preloader.ts";
import { cn } from "/src/lib/utils.ts";
const PreloadLink = ({ to, preloadOnHover = true, preloadOnFocus = true, preloadDelay = 100, className, onMouseEnter, onMouseLeave, onFocus, onBlur, children, ...props })=>{
    _s();
    const handleMouseEnter = useCallback((event)=>{
        if (preloadOnHover) {
            scheduleRoutePreload(to, preloadDelay);
        }
        onMouseEnter?.(event);
    }, [
        to,
        preloadOnHover,
        preloadDelay,
        onMouseEnter
    ]);
    const handleMouseLeave = useCallback((event)=>{
        if (preloadOnHover) {
            cancelScheduledPreload();
        }
        onMouseLeave?.(event);
    }, [
        preloadOnHover,
        onMouseLeave
    ]);
    const handleFocus = useCallback((event)=>{
        if (preloadOnFocus) {
            scheduleRoutePreload(to, preloadDelay);
        }
        onFocus?.(event);
    }, [
        to,
        preloadOnFocus,
        preloadDelay,
        onFocus
    ]);
    const handleBlur = useCallback((event)=>{
        if (preloadOnFocus) {
            cancelScheduledPreload();
        }
        onBlur?.(event);
    }, [
        preloadOnFocus,
        onBlur
    ]);
    return /*#__PURE__*/ _jsxDEV(Link, {
        to: to,
        className: cn(className),
        onMouseEnter: handleMouseEnter,
        onMouseLeave: handleMouseLeave,
        onFocus: handleFocus,
        onBlur: handleBlur,
        ...props,
        children: children
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/preload-link.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
};
_s(PreloadLink, "1GYHopJMScPTxeQ9jWdjoADTk/A=");
_c = PreloadLink;
export default PreloadLink;
var _c;
$RefreshReg$(_c, "PreloadLink");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/preload-link.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/preload-link.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByZWxvYWQtbGluay50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgTGlua1Byb3BzIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQge1xuICBzY2hlZHVsZVJvdXRlUHJlbG9hZCxcbiAgY2FuY2VsU2NoZWR1bGVkUHJlbG9hZCxcbn0gZnJvbSAnQC9saWIvcm91dGUtcHJlbG9hZGVyJztcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnO1xuXG5pbnRlcmZhY2UgUHJlbG9hZExpbmtQcm9wcyBleHRlbmRzIE9taXQ8TGlua1Byb3BzLCAndG8nPiB7XG4gIHRvOiBzdHJpbmc7XG4gIHByZWxvYWRPbkhvdmVyPzogYm9vbGVhbjtcbiAgcHJlbG9hZE9uRm9jdXM/OiBib29sZWFuO1xuICBwcmVsb2FkRGVsYXk/OiBudW1iZXI7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59XG5cbmNvbnN0IFByZWxvYWRMaW5rOiBSZWFjdC5GQzxQcmVsb2FkTGlua1Byb3BzPiA9ICh7XG4gIHRvLFxuICBwcmVsb2FkT25Ib3ZlciA9IHRydWUsXG4gIHByZWxvYWRPbkZvY3VzID0gdHJ1ZSxcbiAgcHJlbG9hZERlbGF5ID0gMTAwLFxuICBjbGFzc05hbWUsXG4gIG9uTW91c2VFbnRlcixcbiAgb25Nb3VzZUxlYXZlLFxuICBvbkZvY3VzLFxuICBvbkJsdXIsXG4gIGNoaWxkcmVuLFxuICAuLi5wcm9wc1xufSkgPT4ge1xuICBjb25zdCBoYW5kbGVNb3VzZUVudGVyID0gdXNlQ2FsbGJhY2soXG4gICAgKGV2ZW50OiBSZWFjdC5Nb3VzZUV2ZW50PEhUTUxBbmNob3JFbGVtZW50PikgPT4ge1xuICAgICAgaWYgKHByZWxvYWRPbkhvdmVyKSB7XG4gICAgICAgIHNjaGVkdWxlUm91dGVQcmVsb2FkKHRvLCBwcmVsb2FkRGVsYXkpO1xuICAgICAgfVxuICAgICAgb25Nb3VzZUVudGVyPy4oZXZlbnQpO1xuICAgIH0sXG4gICAgW3RvLCBwcmVsb2FkT25Ib3ZlciwgcHJlbG9hZERlbGF5LCBvbk1vdXNlRW50ZXJdXG4gICk7XG5cbiAgY29uc3QgaGFuZGxlTW91c2VMZWF2ZSA9IHVzZUNhbGxiYWNrKFxuICAgIChldmVudDogUmVhY3QuTW91c2VFdmVudDxIVE1MQW5jaG9yRWxlbWVudD4pID0+IHtcbiAgICAgIGlmIChwcmVsb2FkT25Ib3Zlcikge1xuICAgICAgICBjYW5jZWxTY2hlZHVsZWRQcmVsb2FkKCk7XG4gICAgICB9XG4gICAgICBvbk1vdXNlTGVhdmU/LihldmVudCk7XG4gICAgfSxcbiAgICBbcHJlbG9hZE9uSG92ZXIsIG9uTW91c2VMZWF2ZV1cbiAgKTtcblxuICBjb25zdCBoYW5kbGVGb2N1cyA9IHVzZUNhbGxiYWNrKFxuICAgIChldmVudDogUmVhY3QuRm9jdXNFdmVudDxIVE1MQW5jaG9yRWxlbWVudD4pID0+IHtcbiAgICAgIGlmIChwcmVsb2FkT25Gb2N1cykge1xuICAgICAgICBzY2hlZHVsZVJvdXRlUHJlbG9hZCh0bywgcHJlbG9hZERlbGF5KTtcbiAgICAgIH1cbiAgICAgIG9uRm9jdXM/LihldmVudCk7XG4gICAgfSxcbiAgICBbdG8sIHByZWxvYWRPbkZvY3VzLCBwcmVsb2FkRGVsYXksIG9uRm9jdXNdXG4gICk7XG5cbiAgY29uc3QgaGFuZGxlQmx1ciA9IHVzZUNhbGxiYWNrKFxuICAgIChldmVudDogUmVhY3QuRm9jdXNFdmVudDxIVE1MQW5jaG9yRWxlbWVudD4pID0+IHtcbiAgICAgIGlmIChwcmVsb2FkT25Gb2N1cykge1xuICAgICAgICBjYW5jZWxTY2hlZHVsZWRQcmVsb2FkKCk7XG4gICAgICB9XG4gICAgICBvbkJsdXI/LihldmVudCk7XG4gICAgfSxcbiAgICBbcHJlbG9hZE9uRm9jdXMsIG9uQmx1cl1cbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxMaW5rXG4gICAgICB0bz17dG99XG4gICAgICBjbGFzc05hbWU9e2NuKGNsYXNzTmFtZSl9XG4gICAgICBvbk1vdXNlRW50ZXI9e2hhbmRsZU1vdXNlRW50ZXJ9XG4gICAgICBvbk1vdXNlTGVhdmU9e2hhbmRsZU1vdXNlTGVhdmV9XG4gICAgICBvbkZvY3VzPXtoYW5kbGVGb2N1c31cbiAgICAgIG9uQmx1cj17aGFuZGxlQmx1cn1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9MaW5rPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUHJlbG9hZExpbms7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJ1c2VDYWxsYmFjayIsIkxpbmsiLCJzY2hlZHVsZVJvdXRlUHJlbG9hZCIsImNhbmNlbFNjaGVkdWxlZFByZWxvYWQiLCJjbiIsIlByZWxvYWRMaW5rIiwidG8iLCJwcmVsb2FkT25Ib3ZlciIsInByZWxvYWRPbkZvY3VzIiwicHJlbG9hZERlbGF5IiwiY2xhc3NOYW1lIiwib25Nb3VzZUVudGVyIiwib25Nb3VzZUxlYXZlIiwib25Gb2N1cyIsIm9uQmx1ciIsImNoaWxkcmVuIiwicHJvcHMiLCJoYW5kbGVNb3VzZUVudGVyIiwiZXZlbnQiLCJoYW5kbGVNb3VzZUxlYXZlIiwiaGFuZGxlRm9jdXMiLCJoYW5kbGVCbHVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsV0FBVyxRQUFRLFFBQVE7QUFDM0MsU0FBU0MsSUFBSSxRQUFtQixtQkFBbUI7QUFDbkQsU0FDRUMsb0JBQW9CLEVBQ3BCQyxzQkFBc0IsUUFDakIsd0JBQXdCO0FBQy9CLFNBQVNDLEVBQUUsUUFBUSxjQUFjO0FBVWpDLE1BQU1DLGNBQTBDLENBQUMsRUFDL0NDLEVBQUUsRUFDRkMsaUJBQWlCLElBQUksRUFDckJDLGlCQUFpQixJQUFJLEVBQ3JCQyxlQUFlLEdBQUcsRUFDbEJDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxZQUFZLEVBQ1pDLE9BQU8sRUFDUEMsTUFBTSxFQUNOQyxRQUFRLEVBQ1IsR0FBR0MsT0FDSjs7SUFDQyxNQUFNQyxtQkFBbUJqQixZQUN2QixDQUFDa0I7UUFDQyxJQUFJWCxnQkFBZ0I7WUFDbEJMLHFCQUFxQkksSUFBSUc7UUFDM0I7UUFDQUUsZUFBZU87SUFDakIsR0FDQTtRQUFDWjtRQUFJQztRQUFnQkU7UUFBY0U7S0FBYTtJQUdsRCxNQUFNUSxtQkFBbUJuQixZQUN2QixDQUFDa0I7UUFDQyxJQUFJWCxnQkFBZ0I7WUFDbEJKO1FBQ0Y7UUFDQVMsZUFBZU07SUFDakIsR0FDQTtRQUFDWDtRQUFnQks7S0FBYTtJQUdoQyxNQUFNUSxjQUFjcEIsWUFDbEIsQ0FBQ2tCO1FBQ0MsSUFBSVYsZ0JBQWdCO1lBQ2xCTixxQkFBcUJJLElBQUlHO1FBQzNCO1FBQ0FJLFVBQVVLO0lBQ1osR0FDQTtRQUFDWjtRQUFJRTtRQUFnQkM7UUFBY0k7S0FBUTtJQUc3QyxNQUFNUSxhQUFhckIsWUFDakIsQ0FBQ2tCO1FBQ0MsSUFBSVYsZ0JBQWdCO1lBQ2xCTDtRQUNGO1FBQ0FXLFNBQVNJO0lBQ1gsR0FDQTtRQUFDVjtRQUFnQk07S0FBTztJQUcxQixxQkFDRSxRQUFDYjtRQUNDSyxJQUFJQTtRQUNKSSxXQUFXTixHQUFHTTtRQUNkQyxjQUFjTTtRQUNkTCxjQUFjTztRQUNkTixTQUFTTztRQUNUTixRQUFRTztRQUNQLEdBQUdMLEtBQUs7a0JBRVJEOzs7Ozs7QUFHUDtHQWxFTVY7S0FBQUE7QUFvRU4sZUFBZUEsWUFBWSJ9