import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/back-to-top.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/back-to-top.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { ArrowUp } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Button } from "/src/components/ui/button.tsx";
const BackToTop = ()=>{
    _s();
    const [visible, setVisible] = React.useState(false);
    React.useEffect(()=>{
        const check = ()=>setVisible(window.scrollY > 400);
        check();
        window.addEventListener('scroll', check, {
            passive: true
        });
        return ()=>window.removeEventListener('scroll', check);
    }, []);
    const scrollToTop = ()=>window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    return /*#__PURE__*/ _jsxDEV(AnimatePresence, {
        children: visible && /*#__PURE__*/ _jsxDEV(motion.div, {
            initial: {
                opacity: 0,
                scale: 0.5
            },
            animate: {
                opacity: 1,
                scale: 1
            },
            exit: {
                opacity: 0,
                scale: 0.5
            },
            className: "fixed bottom-6 right-6 z-50",
            children: /*#__PURE__*/ _jsxDEV(Button, {
                onClick: scrollToTop,
                size: "icon",
                "aria-label": "Back to top",
                className: "glass rounded-full shadow-glow hover:scale-110 transition-transform",
                children: /*#__PURE__*/ _jsxDEV(ArrowUp, {
                    className: "h-4 w-4"
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/ui/back-to-top.tsx",
                    lineNumber: 33,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/back-to-top.tsx",
                lineNumber: 27,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "D:/Projects/Portfolio-Web/src/components/ui/back-to-top.tsx",
            lineNumber: 21,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/back-to-top.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
};
_s(BackToTop, "cz/DzCD06IMMsoBJ0A1IgCy1P5M=");
_c = BackToTop;
export { BackToTop };
var _c;
$RefreshReg$(_c, "BackToTop");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/back-to-top.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/back-to-top.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhY2stdG8tdG9wLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uLCBBbmltYXRlUHJlc2VuY2UgfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IEFycm93VXAgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5cbmNvbnN0IEJhY2tUb1RvcCA9ICgpID0+IHtcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xuXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgY2hlY2sgPSAoKSA9PiBzZXRWaXNpYmxlKHdpbmRvdy5zY3JvbGxZID4gNDAwKTtcbiAgICBjaGVjaygpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCBjaGVjaywgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgY2hlY2spO1xuICB9LCBbXSk7XG5cbiAgY29uc3Qgc2Nyb2xsVG9Ub3AgPSAoKSA9PiB3aW5kb3cuc2Nyb2xsVG8oeyB0b3A6IDAsIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcblxuICByZXR1cm4gKFxuICAgIDxBbmltYXRlUHJlc2VuY2U+XG4gICAgICB7dmlzaWJsZSAmJiAoXG4gICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCBzY2FsZTogMC41IH19XG4gICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCBzY2FsZTogMSB9fVxuICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgc2NhbGU6IDAuNSB9fVxuICAgICAgICAgIGNsYXNzTmFtZT0nZml4ZWQgYm90dG9tLTYgcmlnaHQtNiB6LTUwJ1xuICAgICAgICA+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17c2Nyb2xsVG9Ub3B9XG4gICAgICAgICAgICBzaXplPSdpY29uJ1xuICAgICAgICAgICAgYXJpYS1sYWJlbD0nQmFjayB0byB0b3AnXG4gICAgICAgICAgICBjbGFzc05hbWU9J2dsYXNzIHJvdW5kZWQtZnVsbCBzaGFkb3ctZ2xvdyBob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0nXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEFycm93VXAgY2xhc3NOYW1lPSdoLTQgdy00JyAvPlxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICApfVxuICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxuICApO1xufTtcblxuZXhwb3J0IHsgQmFja1RvVG9wIH07XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJtb3Rpb24iLCJBbmltYXRlUHJlc2VuY2UiLCJBcnJvd1VwIiwiQnV0dG9uIiwiQmFja1RvVG9wIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImNoZWNrIiwid2luZG93Iiwic2Nyb2xsWSIsImFkZEV2ZW50TGlzdGVuZXIiLCJwYXNzaXZlIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsInNjcm9sbFRvVG9wIiwic2Nyb2xsVG8iLCJ0b3AiLCJiZWhhdmlvciIsImRpdiIsImluaXRpYWwiLCJvcGFjaXR5Iiwic2NhbGUiLCJhbmltYXRlIiwiZXhpdCIsImNsYXNzTmFtZSIsIm9uQ2xpY2siLCJzaXplIiwiYXJpYS1sYWJlbCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLE9BQU9BLFdBQVcsUUFBUTtBQUMxQixTQUFTQyxNQUFNLEVBQUVDLGVBQWUsUUFBUSxnQkFBZ0I7QUFDeEQsU0FBU0MsT0FBTyxRQUFRLGVBQWU7QUFDdkMsU0FBU0MsTUFBTSxRQUFRLHlCQUF5QjtBQUVoRCxNQUFNQyxZQUFZOztJQUNoQixNQUFNLENBQUNDLFNBQVNDLFdBQVcsR0FBR1AsTUFBTVEsUUFBUSxDQUFDO0lBRTdDUixNQUFNUyxTQUFTLENBQUM7UUFDZCxNQUFNQyxRQUFRLElBQU1ILFdBQVdJLE9BQU9DLE9BQU8sR0FBRztRQUNoREY7UUFDQUMsT0FBT0UsZ0JBQWdCLENBQUMsVUFBVUgsT0FBTztZQUFFSSxTQUFTO1FBQUs7UUFDekQsT0FBTyxJQUFNSCxPQUFPSSxtQkFBbUIsQ0FBQyxVQUFVTDtJQUNwRCxHQUFHLEVBQUU7SUFFTCxNQUFNTSxjQUFjLElBQU1MLE9BQU9NLFFBQVEsQ0FBQztZQUFFQyxLQUFLO1lBQUdDLFVBQVU7UUFBUztJQUV2RSxxQkFDRSxRQUFDakI7a0JBQ0VJLHlCQUNDLFFBQUNMLE9BQU9tQixHQUFHO1lBQ1RDLFNBQVM7Z0JBQUVDLFNBQVM7Z0JBQUdDLE9BQU87WUFBSTtZQUNsQ0MsU0FBUztnQkFBRUYsU0FBUztnQkFBR0MsT0FBTztZQUFFO1lBQ2hDRSxNQUFNO2dCQUFFSCxTQUFTO2dCQUFHQyxPQUFPO1lBQUk7WUFDL0JHLFdBQVU7c0JBRVYsY0FBQSxRQUFDdEI7Z0JBQ0N1QixTQUFTWDtnQkFDVFksTUFBSztnQkFDTEMsY0FBVztnQkFDWEgsV0FBVTswQkFFVixjQUFBLFFBQUN2QjtvQkFBUXVCLFdBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU0vQjtHQWpDTXJCO0tBQUFBO0FBbUNOLFNBQVNBLFNBQVMsR0FBRyJ9