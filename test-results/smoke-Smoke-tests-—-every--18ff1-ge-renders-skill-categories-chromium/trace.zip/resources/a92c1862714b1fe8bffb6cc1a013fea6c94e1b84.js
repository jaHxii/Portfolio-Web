import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/seo/SEO.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=e72f996b";
const SEO = ({ title = 'Portfolio - Frontend Developer & AI/ML Engineer', description = 'Professional portfolio showcasing expertise in Frontend Development, AI/ML, and IT Infrastructure. Explore projects, skills, and experience.', keywords = [
    'frontend developer',
    'react',
    'typescript',
    'ai',
    'machine learning',
    'portfolio'
], image = '/portfolio.png', url = typeof window !== 'undefined' ? window.location.href : '', type = 'website', author = 'Portfolio Owner', publishedTime, modifiedTime, section, tags, noIndex = false, noFollow = false, canonicalUrl })=>{
    // Construct full URL for image if it's a relative path
    const fullImageUrl = image.startsWith('http') ? image : `${typeof window !== 'undefined' ? window.location.origin : ''}${image}`;
    // Construct canonical URL
    const canonical = canonicalUrl || url;
    // Create structured keywords string
    const keywordsString = keywords.join(', ');
    // Robots meta content
    const robotsContent = `${noIndex ? 'noindex' : 'index'},${noFollow ? 'nofollow' : 'follow'}`;
    return /*#__PURE__*/ _jsxDEV(Helmet, {
        children: [
            /*#__PURE__*/ _jsxDEV("title", {
                children: title
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "description",
                content: description
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "keywords",
                content: keywordsString
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "author",
                content: author
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "robots",
                content: robotsContent
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            canonical && /*#__PURE__*/ _jsxDEV("link", {
                rel: "canonical",
                href: canonical
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 68,
                columnNumber: 21
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                property: "og:title",
                content: title
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                property: "og:description",
                content: description
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                property: "og:image",
                content: fullImageUrl
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                property: "og:url",
                content: url
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                property: "og:type",
                content: type
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                property: "og:site_name",
                content: "Professional Portfolio"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            type === 'article' && publishedTime && /*#__PURE__*/ _jsxDEV("meta", {
                property: "article:published_time",
                content: publishedTime
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 80,
                columnNumber: 9
            }, this),
            type === 'article' && modifiedTime && /*#__PURE__*/ _jsxDEV("meta", {
                property: "article:modified_time",
                content: modifiedTime
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 83,
                columnNumber: 9
            }, this),
            type === 'article' && author && /*#__PURE__*/ _jsxDEV("meta", {
                property: "article:author",
                content: author
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 86,
                columnNumber: 9
            }, this),
            type === 'article' && section && /*#__PURE__*/ _jsxDEV("meta", {
                property: "article:section",
                content: section
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 89,
                columnNumber: 9
            }, this),
            type === 'article' && tags && tags.map((tag, index)=>/*#__PURE__*/ _jsxDEV("meta", {
                    property: "article:tag",
                    content: tag
                }, index, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                    lineNumber: 94,
                    columnNumber: 11
                }, this)),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "twitter:title",
                content: title
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 99,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "twitter:description",
                content: description
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "twitter:image",
                content: fullImageUrl
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "viewport",
                content: "width=device-width, initial-scale=1.0"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                httpEquiv: "Content-Type",
                content: "text/html; charset=utf-8"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "language",
                content: "English"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("meta", {
                name: "revisit-after",
                content: "7 days"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("link", {
                rel: "preconnect",
                href: "https://fonts.googleapis.com"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("link", {
                rel: "preconnect",
                href: "https://fonts.gstatic.com",
                crossOrigin: "anonymous"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
                lineNumber: 111,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx",
        lineNumber: 59,
        columnNumber: 5
    }, this);
};
_c = SEO;
export default SEO;
var _c;
$RefreshReg$(_c, "SEO");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/seo/SEO.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNFTy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gJ3JlYWN0LWhlbG1ldC1hc3luYyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgU0VPUHJvcHMge1xuICB0aXRsZT86IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIGtleXdvcmRzPzogc3RyaW5nW107XG4gIGltYWdlPzogc3RyaW5nO1xuICB1cmw/OiBzdHJpbmc7XG4gIHR5cGU/OiAnd2Vic2l0ZScgfCAnYXJ0aWNsZScgfCAncHJvZmlsZSc7XG4gIGF1dGhvcj86IHN0cmluZztcbiAgcHVibGlzaGVkVGltZT86IHN0cmluZztcbiAgbW9kaWZpZWRUaW1lPzogc3RyaW5nO1xuICBzZWN0aW9uPzogc3RyaW5nO1xuICB0YWdzPzogc3RyaW5nW107XG4gIG5vSW5kZXg/OiBib29sZWFuO1xuICBub0ZvbGxvdz86IGJvb2xlYW47XG4gIGNhbm9uaWNhbFVybD86IHN0cmluZztcbn1cblxuY29uc3QgU0VPOiBSZWFjdC5GQzxTRU9Qcm9wcz4gPSAoe1xuICB0aXRsZSA9ICdQb3J0Zm9saW8gLSBGcm9udGVuZCBEZXZlbG9wZXIgJiBBSS9NTCBFbmdpbmVlcicsXG4gIGRlc2NyaXB0aW9uID0gJ1Byb2Zlc3Npb25hbCBwb3J0Zm9saW8gc2hvd2Nhc2luZyBleHBlcnRpc2UgaW4gRnJvbnRlbmQgRGV2ZWxvcG1lbnQsIEFJL01MLCBhbmQgSVQgSW5mcmFzdHJ1Y3R1cmUuIEV4cGxvcmUgcHJvamVjdHMsIHNraWxscywgYW5kIGV4cGVyaWVuY2UuJyxcbiAga2V5d29yZHMgPSBbXG4gICAgJ2Zyb250ZW5kIGRldmVsb3BlcicsXG4gICAgJ3JlYWN0JyxcbiAgICAndHlwZXNjcmlwdCcsXG4gICAgJ2FpJyxcbiAgICAnbWFjaGluZSBsZWFybmluZycsXG4gICAgJ3BvcnRmb2xpbycsXG4gIF0sXG4gIGltYWdlID0gJy9wb3J0Zm9saW8ucG5nJyxcbiAgdXJsID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cubG9jYXRpb24uaHJlZiA6ICcnLFxuICB0eXBlID0gJ3dlYnNpdGUnLFxuICBhdXRob3IgPSAnUG9ydGZvbGlvIE93bmVyJyxcbiAgcHVibGlzaGVkVGltZSxcbiAgbW9kaWZpZWRUaW1lLFxuICBzZWN0aW9uLFxuICB0YWdzLFxuICBub0luZGV4ID0gZmFsc2UsXG4gIG5vRm9sbG93ID0gZmFsc2UsXG4gIGNhbm9uaWNhbFVybCxcbn0pID0+IHtcbiAgLy8gQ29uc3RydWN0IGZ1bGwgVVJMIGZvciBpbWFnZSBpZiBpdCdzIGEgcmVsYXRpdmUgcGF0aFxuICBjb25zdCBmdWxsSW1hZ2VVcmwgPSBpbWFnZS5zdGFydHNXaXRoKCdodHRwJylcbiAgICA/IGltYWdlXG4gICAgOiBgJHt0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gOiAnJ30ke2ltYWdlfWA7XG5cbiAgLy8gQ29uc3RydWN0IGNhbm9uaWNhbCBVUkxcbiAgY29uc3QgY2Fub25pY2FsID0gY2Fub25pY2FsVXJsIHx8IHVybDtcblxuICAvLyBDcmVhdGUgc3RydWN0dXJlZCBrZXl3b3JkcyBzdHJpbmdcbiAgY29uc3Qga2V5d29yZHNTdHJpbmcgPSBrZXl3b3Jkcy5qb2luKCcsICcpO1xuXG4gIC8vIFJvYm90cyBtZXRhIGNvbnRlbnRcbiAgY29uc3Qgcm9ib3RzQ29udGVudCA9IGAke25vSW5kZXggPyAnbm9pbmRleCcgOiAnaW5kZXgnfSwke25vRm9sbG93ID8gJ25vZm9sbG93JyA6ICdmb2xsb3cnfWA7XG5cbiAgcmV0dXJuIChcbiAgICA8SGVsbWV0PlxuICAgICAgey8qIEJhc2ljIE1ldGEgVGFncyAqL31cbiAgICAgIDx0aXRsZT57dGl0bGV9PC90aXRsZT5cbiAgICAgIDxtZXRhIG5hbWU9J2Rlc2NyaXB0aW9uJyBjb250ZW50PXtkZXNjcmlwdGlvbn0gLz5cbiAgICAgIDxtZXRhIG5hbWU9J2tleXdvcmRzJyBjb250ZW50PXtrZXl3b3Jkc1N0cmluZ30gLz5cbiAgICAgIDxtZXRhIG5hbWU9J2F1dGhvcicgY29udGVudD17YXV0aG9yfSAvPlxuICAgICAgPG1ldGEgbmFtZT0ncm9ib3RzJyBjb250ZW50PXtyb2JvdHNDb250ZW50fSAvPlxuXG4gICAgICB7LyogQ2Fub25pY2FsIFVSTCAqL31cbiAgICAgIHtjYW5vbmljYWwgJiYgPGxpbmsgcmVsPSdjYW5vbmljYWwnIGhyZWY9e2Nhbm9uaWNhbH0gLz59XG5cbiAgICAgIHsvKiBPcGVuIEdyYXBoIE1ldGEgVGFncyAqL31cbiAgICAgIDxtZXRhIHByb3BlcnR5PSdvZzp0aXRsZScgY29udGVudD17dGl0bGV9IC8+XG4gICAgICA8bWV0YSBwcm9wZXJ0eT0nb2c6ZGVzY3JpcHRpb24nIGNvbnRlbnQ9e2Rlc2NyaXB0aW9ufSAvPlxuICAgICAgPG1ldGEgcHJvcGVydHk9J29nOmltYWdlJyBjb250ZW50PXtmdWxsSW1hZ2VVcmx9IC8+XG4gICAgICA8bWV0YSBwcm9wZXJ0eT0nb2c6dXJsJyBjb250ZW50PXt1cmx9IC8+XG4gICAgICA8bWV0YSBwcm9wZXJ0eT0nb2c6dHlwZScgY29udGVudD17dHlwZX0gLz5cbiAgICAgIDxtZXRhIHByb3BlcnR5PSdvZzpzaXRlX25hbWUnIGNvbnRlbnQ9J1Byb2Zlc3Npb25hbCBQb3J0Zm9saW8nIC8+XG5cbiAgICAgIHsvKiBBcnRpY2xlLXNwZWNpZmljIE9wZW4gR3JhcGggdGFncyAqL31cbiAgICAgIHt0eXBlID09PSAnYXJ0aWNsZScgJiYgcHVibGlzaGVkVGltZSAmJiAoXG4gICAgICAgIDxtZXRhIHByb3BlcnR5PSdhcnRpY2xlOnB1Ymxpc2hlZF90aW1lJyBjb250ZW50PXtwdWJsaXNoZWRUaW1lfSAvPlxuICAgICAgKX1cbiAgICAgIHt0eXBlID09PSAnYXJ0aWNsZScgJiYgbW9kaWZpZWRUaW1lICYmIChcbiAgICAgICAgPG1ldGEgcHJvcGVydHk9J2FydGljbGU6bW9kaWZpZWRfdGltZScgY29udGVudD17bW9kaWZpZWRUaW1lfSAvPlxuICAgICAgKX1cbiAgICAgIHt0eXBlID09PSAnYXJ0aWNsZScgJiYgYXV0aG9yICYmIChcbiAgICAgICAgPG1ldGEgcHJvcGVydHk9J2FydGljbGU6YXV0aG9yJyBjb250ZW50PXthdXRob3J9IC8+XG4gICAgICApfVxuICAgICAge3R5cGUgPT09ICdhcnRpY2xlJyAmJiBzZWN0aW9uICYmIChcbiAgICAgICAgPG1ldGEgcHJvcGVydHk9J2FydGljbGU6c2VjdGlvbicgY29udGVudD17c2VjdGlvbn0gLz5cbiAgICAgICl9XG4gICAgICB7dHlwZSA9PT0gJ2FydGljbGUnICYmXG4gICAgICAgIHRhZ3MgJiZcbiAgICAgICAgdGFncy5tYXAoKHRhZywgaW5kZXgpID0+IChcbiAgICAgICAgICA8bWV0YSBrZXk9e2luZGV4fSBwcm9wZXJ0eT0nYXJ0aWNsZTp0YWcnIGNvbnRlbnQ9e3RhZ30gLz5cbiAgICAgICAgKSl9XG5cbiAgICAgIHsvKiBUd2l0dGVyIENhcmQgTWV0YSBUYWdzICovfVxuICAgICAgPG1ldGEgbmFtZT0ndHdpdHRlcjpjYXJkJyBjb250ZW50PSdzdW1tYXJ5X2xhcmdlX2ltYWdlJyAvPlxuICAgICAgPG1ldGEgbmFtZT0ndHdpdHRlcjp0aXRsZScgY29udGVudD17dGl0bGV9IC8+XG4gICAgICA8bWV0YSBuYW1lPSd0d2l0dGVyOmRlc2NyaXB0aW9uJyBjb250ZW50PXtkZXNjcmlwdGlvbn0gLz5cbiAgICAgIDxtZXRhIG5hbWU9J3R3aXR0ZXI6aW1hZ2UnIGNvbnRlbnQ9e2Z1bGxJbWFnZVVybH0gLz5cblxuICAgICAgey8qIEFkZGl0aW9uYWwgU0VPIE1ldGEgVGFncyAqL31cbiAgICAgIDxtZXRhIG5hbWU9J3ZpZXdwb3J0JyBjb250ZW50PSd3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MS4wJyAvPlxuICAgICAgPG1ldGEgaHR0cEVxdWl2PSdDb250ZW50LVR5cGUnIGNvbnRlbnQ9J3RleHQvaHRtbDsgY2hhcnNldD11dGYtOCcgLz5cbiAgICAgIDxtZXRhIG5hbWU9J2xhbmd1YWdlJyBjb250ZW50PSdFbmdsaXNoJyAvPlxuICAgICAgPG1ldGEgbmFtZT0ncmV2aXNpdC1hZnRlcicgY29udGVudD0nNyBkYXlzJyAvPlxuXG4gICAgICB7LyogUHJlY29ubmVjdCB0byBleHRlcm5hbCBkb21haW5zIGZvciBwZXJmb3JtYW5jZSAqL31cbiAgICAgIDxsaW5rIHJlbD0ncHJlY29ubmVjdCcgaHJlZj0naHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbScgLz5cbiAgICAgIDxsaW5rXG4gICAgICAgIHJlbD0ncHJlY29ubmVjdCdcbiAgICAgICAgaHJlZj0naHR0cHM6Ly9mb250cy5nc3RhdGljLmNvbSdcbiAgICAgICAgY3Jvc3NPcmlnaW49J2Fub255bW91cydcbiAgICAgIC8+XG4gICAgPC9IZWxtZXQ+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBTRU87XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJIZWxtZXQiLCJTRU8iLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwia2V5d29yZHMiLCJpbWFnZSIsInVybCIsIndpbmRvdyIsImxvY2F0aW9uIiwiaHJlZiIsInR5cGUiLCJhdXRob3IiLCJwdWJsaXNoZWRUaW1lIiwibW9kaWZpZWRUaW1lIiwic2VjdGlvbiIsInRhZ3MiLCJub0luZGV4Iiwibm9Gb2xsb3ciLCJjYW5vbmljYWxVcmwiLCJmdWxsSW1hZ2VVcmwiLCJzdGFydHNXaXRoIiwib3JpZ2luIiwiY2Fub25pY2FsIiwia2V5d29yZHNTdHJpbmciLCJqb2luIiwicm9ib3RzQ29udGVudCIsIm1ldGEiLCJuYW1lIiwiY29udGVudCIsImxpbmsiLCJyZWwiLCJwcm9wZXJ0eSIsIm1hcCIsInRhZyIsImluZGV4IiwiaHR0cEVxdWl2IiwiY3Jvc3NPcmlnaW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLE9BQU9BLFdBQVcsUUFBUTtBQUMxQixTQUFTQyxNQUFNLFFBQVEscUJBQXFCO0FBbUI1QyxNQUFNQyxNQUEwQixDQUFDLEVBQy9CQyxRQUFRLGlEQUFpRCxFQUN6REMsY0FBYyw4SUFBOEksRUFDNUpDLFdBQVc7SUFDVDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7Q0FDRCxFQUNEQyxRQUFRLGdCQUFnQixFQUN4QkMsTUFBTSxPQUFPQyxXQUFXLGNBQWNBLE9BQU9DLFFBQVEsQ0FBQ0MsSUFBSSxHQUFHLEVBQUUsRUFDL0RDLE9BQU8sU0FBUyxFQUNoQkMsU0FBUyxpQkFBaUIsRUFDMUJDLGFBQWEsRUFDYkMsWUFBWSxFQUNaQyxPQUFPLEVBQ1BDLElBQUksRUFDSkMsVUFBVSxLQUFLLEVBQ2ZDLFdBQVcsS0FBSyxFQUNoQkMsWUFBWSxFQUNiO0lBQ0MsdURBQXVEO0lBQ3ZELE1BQU1DLGVBQWVkLE1BQU1lLFVBQVUsQ0FBQyxVQUNsQ2YsUUFDQSxHQUFHLE9BQU9FLFdBQVcsY0FBY0EsT0FBT0MsUUFBUSxDQUFDYSxNQUFNLEdBQUcsS0FBS2hCLE9BQU87SUFFNUUsMEJBQTBCO0lBQzFCLE1BQU1pQixZQUFZSixnQkFBZ0JaO0lBRWxDLG9DQUFvQztJQUNwQyxNQUFNaUIsaUJBQWlCbkIsU0FBU29CLElBQUksQ0FBQztJQUVyQyxzQkFBc0I7SUFDdEIsTUFBTUMsZ0JBQWdCLEdBQUdULFVBQVUsWUFBWSxRQUFRLENBQUMsRUFBRUMsV0FBVyxhQUFhLFVBQVU7SUFFNUYscUJBQ0UsUUFBQ2pCOzswQkFFQyxRQUFDRTswQkFBT0E7Ozs7OzswQkFDUixRQUFDd0I7Z0JBQUtDLE1BQUs7Z0JBQWNDLFNBQVN6Qjs7Ozs7OzBCQUNsQyxRQUFDdUI7Z0JBQUtDLE1BQUs7Z0JBQVdDLFNBQVNMOzs7Ozs7MEJBQy9CLFFBQUNHO2dCQUFLQyxNQUFLO2dCQUFTQyxTQUFTakI7Ozs7OzswQkFDN0IsUUFBQ2U7Z0JBQUtDLE1BQUs7Z0JBQVNDLFNBQVNIOzs7Ozs7WUFHNUJILDJCQUFhLFFBQUNPO2dCQUFLQyxLQUFJO2dCQUFZckIsTUFBTWE7Ozs7OzswQkFHMUMsUUFBQ0k7Z0JBQUtLLFVBQVM7Z0JBQVdILFNBQVMxQjs7Ozs7OzBCQUNuQyxRQUFDd0I7Z0JBQUtLLFVBQVM7Z0JBQWlCSCxTQUFTekI7Ozs7OzswQkFDekMsUUFBQ3VCO2dCQUFLSyxVQUFTO2dCQUFXSCxTQUFTVDs7Ozs7OzBCQUNuQyxRQUFDTztnQkFBS0ssVUFBUztnQkFBU0gsU0FBU3RCOzs7Ozs7MEJBQ2pDLFFBQUNvQjtnQkFBS0ssVUFBUztnQkFBVUgsU0FBU2xCOzs7Ozs7MEJBQ2xDLFFBQUNnQjtnQkFBS0ssVUFBUztnQkFBZUgsU0FBUTs7Ozs7O1lBR3JDbEIsU0FBUyxhQUFhRSwrQkFDckIsUUFBQ2M7Z0JBQUtLLFVBQVM7Z0JBQXlCSCxTQUFTaEI7Ozs7OztZQUVsREYsU0FBUyxhQUFhRyw4QkFDckIsUUFBQ2E7Z0JBQUtLLFVBQVM7Z0JBQXdCSCxTQUFTZjs7Ozs7O1lBRWpESCxTQUFTLGFBQWFDLHdCQUNyQixRQUFDZTtnQkFBS0ssVUFBUztnQkFBaUJILFNBQVNqQjs7Ozs7O1lBRTFDRCxTQUFTLGFBQWFJLHlCQUNyQixRQUFDWTtnQkFBS0ssVUFBUztnQkFBa0JILFNBQVNkOzs7Ozs7WUFFM0NKLFNBQVMsYUFDUkssUUFDQUEsS0FBS2lCLEdBQUcsQ0FBQyxDQUFDQyxLQUFLQyxzQkFDYixRQUFDUjtvQkFBaUJLLFVBQVM7b0JBQWNILFNBQVNLO21CQUF2Q0M7Ozs7OzBCQUlmLFFBQUNSO2dCQUFLQyxNQUFLO2dCQUFlQyxTQUFROzs7Ozs7MEJBQ2xDLFFBQUNGO2dCQUFLQyxNQUFLO2dCQUFnQkMsU0FBUzFCOzs7Ozs7MEJBQ3BDLFFBQUN3QjtnQkFBS0MsTUFBSztnQkFBc0JDLFNBQVN6Qjs7Ozs7OzBCQUMxQyxRQUFDdUI7Z0JBQUtDLE1BQUs7Z0JBQWdCQyxTQUFTVDs7Ozs7OzBCQUdwQyxRQUFDTztnQkFBS0MsTUFBSztnQkFBV0MsU0FBUTs7Ozs7OzBCQUM5QixRQUFDRjtnQkFBS1MsV0FBVTtnQkFBZVAsU0FBUTs7Ozs7OzBCQUN2QyxRQUFDRjtnQkFBS0MsTUFBSztnQkFBV0MsU0FBUTs7Ozs7OzBCQUM5QixRQUFDRjtnQkFBS0MsTUFBSztnQkFBZ0JDLFNBQVE7Ozs7OzswQkFHbkMsUUFBQ0M7Z0JBQUtDLEtBQUk7Z0JBQWFyQixNQUFLOzs7Ozs7MEJBQzVCLFFBQUNvQjtnQkFDQ0MsS0FBSTtnQkFDSnJCLE1BQUs7Z0JBQ0wyQixhQUFZOzs7Ozs7Ozs7Ozs7QUFJcEI7S0FqR01uQztBQW1HTixlQUFlQSxJQUFJIn0=