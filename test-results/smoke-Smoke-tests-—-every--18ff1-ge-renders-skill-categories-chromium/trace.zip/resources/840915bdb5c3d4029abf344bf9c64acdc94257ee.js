import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/seo/StructuredData.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/seo/StructuredData.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
import * as RefreshRuntime from "/@react-refresh";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { Helmet } from "/node_modules/.vite/deps/react-helmet-async.js?v=e72f996b";
import { generateJSONLD, validateSchema } from "/src/lib/structured-data.ts";
const StructuredData = ({ schema, validate = true }) => {
  if (validate && true) {
    if (!validateSchema(schema)) {
      console.warn("Invalid structured data schema:", schema);
    }
  }
  const jsonLdString = generateJSONLD(schema);
  return /* @__PURE__ */ _jsxDEV(Helmet, {
    children: /* @__PURE__ */ _jsxDEV("script", {
      type: "application/ld+json",
      children: jsonLdString
    }, void 0, false, {
      fileName: "D:/Projects/Portfolio-Web/src/components/seo/StructuredData.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, void 0)
  }, void 0, false, {
    fileName: "D:/Projects/Portfolio-Web/src/components/seo/StructuredData.tsx",
    lineNumber: 24,
    columnNumber: 5
  }, void 0);
};
_c = StructuredData;
export default StructuredData;
var _c;
$RefreshReg$(_c, "StructuredData");
window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;
RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/seo/StructuredData.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/seo/StructuredData.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0JDLHNCQUFzQjtBQU8vQyxNQUFNQyxpQkFBZ0QsQ0FBQyxFQUNyREMsUUFDQUMsV0FBVyxLQUFJLE1BQ2hCO0FBRUMsTUFBSUEsWUFBWUMsTUFBd0M7QUFDdEQsUUFBSSxDQUFDSixlQUFlRSxTQUFTO0FBQzNCRyxjQUFRQyxLQUFLLG1DQUFtQ0o7QUFBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBRUEsUUFBTUssZUFBZVIsZUFBZUc7QUFFcEMsU0FDRSx3QkFBQ0o7QUFBQUEsY0FDQyx3QkFBQ1U7QUFBQUEsTUFBT0MsTUFBSztBQUFBLGdCQUF1QkY7QUFBQUE7Ozs7Ozs7Ozs7QUFHMUM7S0FsQk1OO0FBb0JOLGVBQWVBIiwibmFtZXMiOlsiUmVhY3QiLCJIZWxtZXQiLCJnZW5lcmF0ZUpTT05MRCIsInZhbGlkYXRlU2NoZW1hIiwiU3RydWN0dXJlZERhdGEiLCJzY2hlbWEiLCJ2YWxpZGF0ZSIsInByb2Nlc3MiLCJjb25zb2xlIiwid2FybiIsImpzb25MZFN0cmluZyIsInNjcmlwdCIsInR5cGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU3RydWN0dXJlZERhdGEudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBIZWxtZXQgfSBmcm9tICdyZWFjdC1oZWxtZXQtYXN5bmMnO1xuaW1wb3J0IHsgZ2VuZXJhdGVKU09OTEQsIHZhbGlkYXRlU2NoZW1hIH0gZnJvbSAnQC9saWIvc3RydWN0dXJlZC1kYXRhJztcblxuaW50ZXJmYWNlIFN0cnVjdHVyZWREYXRhUHJvcHMge1xuICBzY2hlbWE6IFJlY29yZDxzdHJpbmcsIGFueT47XG4gIHZhbGlkYXRlPzogYm9vbGVhbjtcbn1cblxuY29uc3QgU3RydWN0dXJlZERhdGE6IFJlYWN0LkZDPFN0cnVjdHVyZWREYXRhUHJvcHM+ID0gKHtcbiAgc2NoZW1hLFxuICB2YWxpZGF0ZSA9IHRydWUsXG59KSA9PiB7XG4gIC8vIFZhbGlkYXRlIHNjaGVtYSBpbiBkZXZlbG9wbWVudFxuICBpZiAodmFsaWRhdGUgJiYgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICBpZiAoIXZhbGlkYXRlU2NoZW1hKHNjaGVtYSkpIHtcbiAgICAgIGNvbnNvbGUud2FybignSW52YWxpZCBzdHJ1Y3R1cmVkIGRhdGEgc2NoZW1hOicsIHNjaGVtYSk7XG4gICAgfVxuICB9XG5cbiAgY29uc3QganNvbkxkU3RyaW5nID0gZ2VuZXJhdGVKU09OTEQoc2NoZW1hKTtcblxuICByZXR1cm4gKFxuICAgIDxIZWxtZXQ+XG4gICAgICA8c2NyaXB0IHR5cGU9J2FwcGxpY2F0aW9uL2xkK2pzb24nPntqc29uTGRTdHJpbmd9PC9zY3JpcHQ+XG4gICAgPC9IZWxtZXQ+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBTdHJ1Y3R1cmVkRGF0YTtcbiJdLCJmaWxlIjoiRDovUHJvamVjdHMvUG9ydGZvbGlvLVdlYi9zcmMvY29tcG9uZW50cy9zZW8vU3RydWN0dXJlZERhdGEudHN4In0=