import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/atmosphere/ScrollSky.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/atmosphere/ScrollSky.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { motion, useScroll, useTransform } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
const isNarrow = ()=>typeof window !== 'undefined' && window.matchMedia('(max-width: 767px)').matches;
export default function ScrollSky() {
    _s();
    const { scrollYProgress } = useScroll();
    const y = useTransform(scrollYProgress, [
        0,
        1
    ], [
        '62%',
        '-8%'
    ]);
    const opacity = useTransform(scrollYProgress, [
        0,
        0.5,
        1
    ], [
        0.05,
        0.05,
        0.14
    ]);
    if (isNarrow()) return null;
    return /*#__PURE__*/ _jsxDEV(motion.div, {
        "aria-hidden": "true",
        className: "pointer-events-none fixed inset-0 z-[5] overflow-hidden hidden md:block",
        children: /*#__PURE__*/ _jsxDEV(motion.div, {
            className: "scrollsky-sun absolute left-1/2 h-[72vh] w-[95vw]",
            style: {
                y,
                opacity,
                x: '-50%',
                background: 'radial-gradient(ellipse at 50% 100%, hsl(42 58% 64% / 0.9), transparent 62%)',
                filter: 'blur(70px)'
            }
        }, void 0, false, {
            fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/ScrollSky.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/ScrollSky.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_s(ScrollSky, "WFlg/MhXKsEIZi7PDrccRYby1NY=", false, function() {
    return [
        useScroll,
        useTransform,
        useTransform
    ];
});
_c = ScrollSky;
var _c;
$RefreshReg$(_c, "ScrollSky");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/atmosphere/ScrollSky.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/atmosphere/ScrollSky.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNjcm9sbFNreS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbW90aW9uLCB1c2VTY3JvbGwsIHVzZVRyYW5zZm9ybSB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuXG5jb25zdCBpc05hcnJvdyA9ICgpID0+XG4gIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXG4gIHdpbmRvdy5tYXRjaE1lZGlhKCcobWF4LXdpZHRoOiA3NjdweCknKS5tYXRjaGVzO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTY3JvbGxTa3koKSB7XG4gIGNvbnN0IHsgc2Nyb2xsWVByb2dyZXNzIH0gPSB1c2VTY3JvbGwoKTtcbiAgY29uc3QgeSA9IHVzZVRyYW5zZm9ybShzY3JvbGxZUHJvZ3Jlc3MsIFswLCAxXSwgWyc2MiUnLCAnLTglJ10pO1xuICBjb25zdCBvcGFjaXR5ID0gdXNlVHJhbnNmb3JtKFxuICAgIHNjcm9sbFlQcm9ncmVzcyxcbiAgICBbMCwgMC41LCAxXSxcbiAgICBbMC4wNSwgMC4wNSwgMC4xNF1cbiAgKTtcblxuICBpZiAoaXNOYXJyb3coKSkgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8bW90aW9uLmRpdlxuICAgICAgYXJpYS1oaWRkZW49J3RydWUnXG4gICAgICBjbGFzc05hbWU9J3BvaW50ZXItZXZlbnRzLW5vbmUgZml4ZWQgaW5zZXQtMCB6LVs1XSBvdmVyZmxvdy1oaWRkZW4gaGlkZGVuIG1kOmJsb2NrJ1xuICAgID5cbiAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgIGNsYXNzTmFtZT0nc2Nyb2xsc2t5LXN1biBhYnNvbHV0ZSBsZWZ0LTEvMiBoLVs3MnZoXSB3LVs5NXZ3XSdcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICB5LFxuICAgICAgICAgIG9wYWNpdHksXG4gICAgICAgICAgeDogJy01MCUnLFxuICAgICAgICAgIGJhY2tncm91bmQ6XG4gICAgICAgICAgICAncmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgNTAlIDEwMCUsIGhzbCg0MiA1OCUgNjQlIC8gMC45KSwgdHJhbnNwYXJlbnQgNjIlKScsXG4gICAgICAgICAgZmlsdGVyOiAnYmx1cig3MHB4KScsXG4gICAgICAgIH19XG4gICAgICAvPlxuICAgIDwvbW90aW9uLmRpdj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJtb3Rpb24iLCJ1c2VTY3JvbGwiLCJ1c2VUcmFuc2Zvcm0iLCJpc05hcnJvdyIsIndpbmRvdyIsIm1hdGNoTWVkaWEiLCJtYXRjaGVzIiwiU2Nyb2xsU2t5Iiwic2Nyb2xsWVByb2dyZXNzIiwieSIsIm9wYWNpdHkiLCJkaXYiLCJhcmlhLWhpZGRlbiIsImNsYXNzTmFtZSIsInN0eWxlIiwieCIsImJhY2tncm91bmQiLCJmaWx0ZXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxTQUFTQSxNQUFNLEVBQUVDLFNBQVMsRUFBRUMsWUFBWSxRQUFRLGdCQUFnQjtBQUVoRSxNQUFNQyxXQUFXLElBQ2YsT0FBT0MsV0FBVyxlQUNsQkEsT0FBT0MsVUFBVSxDQUFDLHNCQUFzQkMsT0FBTztBQUVqRCxlQUFlLFNBQVNDOztJQUN0QixNQUFNLEVBQUVDLGVBQWUsRUFBRSxHQUFHUDtJQUM1QixNQUFNUSxJQUFJUCxhQUFhTSxpQkFBaUI7UUFBQztRQUFHO0tBQUUsRUFBRTtRQUFDO1FBQU87S0FBTTtJQUM5RCxNQUFNRSxVQUFVUixhQUNkTSxpQkFDQTtRQUFDO1FBQUc7UUFBSztLQUFFLEVBQ1g7UUFBQztRQUFNO1FBQU07S0FBSztJQUdwQixJQUFJTCxZQUFZLE9BQU87SUFFdkIscUJBQ0UsUUFBQ0gsT0FBT1csR0FBRztRQUNUQyxlQUFZO1FBQ1pDLFdBQVU7a0JBRVYsY0FBQSxRQUFDYixPQUFPVyxHQUFHO1lBQ1RFLFdBQVU7WUFDVkMsT0FBTztnQkFDTEw7Z0JBQ0FDO2dCQUNBSyxHQUFHO2dCQUNIQyxZQUNFO2dCQUNGQyxRQUFRO1lBQ1Y7Ozs7Ozs7Ozs7O0FBSVI7R0E3QndCVjs7UUFDTU47UUFDbEJDO1FBQ01BOzs7S0FITUsifQ==