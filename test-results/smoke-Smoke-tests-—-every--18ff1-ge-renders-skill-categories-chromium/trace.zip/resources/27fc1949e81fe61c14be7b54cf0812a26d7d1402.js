import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/LoadingFallback.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
const LoadingFallback = ({ message = 'Loading...' })=>{
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "min-h-screen flex items-center justify-center bg-background",
        children: /*#__PURE__*/ _jsxDEV(motion.div, {
            initial: {
                opacity: 0,
                scale: 0.9
            },
            animate: {
                opacity: 1,
                scale: 1
            },
            transition: {
                duration: 0.3
            },
            className: "text-center space-y-4",
            children: [
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "relative",
                    children: [
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "w-16 h-16 border-4 border-border rounded-full animate-spin border-t-primary mx-auto"
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx",
                            lineNumber: 21,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "absolute inset-0 w-16 h-16 border-4 border-transparent rounded-full animate-pulse border-t-primary/20 mx-auto"
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx",
                            lineNumber: 22,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV(motion.p, {
                    initial: {
                        opacity: 0,
                        y: 10
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    transition: {
                        delay: 0.2,
                        duration: 0.3
                    },
                    className: "text-muted-foreground font-medium",
                    children: message
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV(motion.div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    transition: {
                        delay: 0.4,
                        duration: 0.3
                    },
                    className: "flex justify-center space-x-1",
                    children: [
                        0,
                        1,
                        2
                    ].map((i)=>/*#__PURE__*/ _jsxDEV(motion.div, {
                            className: "w-2 h-2 bg-primary rounded-full",
                            animate: {
                                scale: [
                                    1,
                                    1.2,
                                    1
                                ],
                                opacity: [
                                    0.5,
                                    1,
                                    0.5
                                ]
                            },
                            transition: {
                                duration: 1.5,
                                repeat: Infinity,
                                delay: i * 0.2
                            }
                        }, i, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx",
                            lineNumber: 43,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx",
                    lineNumber: 36,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
};
_c = LoadingFallback;
export default LoadingFallback;
var _c;
$RefreshReg$(_c, "LoadingFallback");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/layout/LoadingFallback.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkxvYWRpbmdGYWxsYmFjay50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuXG5pbnRlcmZhY2UgTG9hZGluZ0ZhbGxiYWNrUHJvcHMge1xuICBtZXNzYWdlPzogc3RyaW5nO1xufVxuXG5jb25zdCBMb2FkaW5nRmFsbGJhY2s6IFJlYWN0LkZDPExvYWRpbmdGYWxsYmFja1Byb3BzPiA9ICh7XG4gIG1lc3NhZ2UgPSAnTG9hZGluZy4uLicsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9J21pbi1oLXNjcmVlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1iYWNrZ3JvdW5kJz5cbiAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgc2NhbGU6IDAuOSB9fVxuICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHNjYWxlOiAxIH19XG4gICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMyB9fVxuICAgICAgICBjbGFzc05hbWU9J3RleHQtY2VudGVyIHNwYWNlLXktNCdcbiAgICAgID5cbiAgICAgICAgey8qIExvYWRpbmcgU3Bpbm5lciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J3JlbGF0aXZlJz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ndy0xNiBoLTE2IGJvcmRlci00IGJvcmRlci1ib3JkZXIgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpbiBib3JkZXItdC1wcmltYXJ5IG14LWF1dG8nIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Fic29sdXRlIGluc2V0LTAgdy0xNiBoLTE2IGJvcmRlci00IGJvcmRlci10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZSBib3JkZXItdC1wcmltYXJ5LzIwIG14LWF1dG8nIC8+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBMb2FkaW5nIFRleHQgKi99XG4gICAgICAgIDxtb3Rpb24ucFxuICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMTAgfX1cbiAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjIsIGR1cmF0aW9uOiAwLjMgfX1cbiAgICAgICAgICBjbGFzc05hbWU9J3RleHQtbXV0ZWQtZm9yZWdyb3VuZCBmb250LW1lZGl1bSdcbiAgICAgICAgPlxuICAgICAgICAgIHttZXNzYWdlfVxuICAgICAgICA8L21vdGlvbi5wPlxuXG4gICAgICAgIHsvKiBMb2FkaW5nIERvdHMgQW5pbWF0aW9uICovfVxuICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fVxuICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxuICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuNCwgZHVyYXRpb246IDAuMyB9fVxuICAgICAgICAgIGNsYXNzTmFtZT0nZmxleCBqdXN0aWZ5LWNlbnRlciBzcGFjZS14LTEnXG4gICAgICAgID5cbiAgICAgICAgICB7WzAsIDEsIDJdLm1hcChpID0+IChcbiAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgIGtleT17aX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSd3LTIgaC0yIGJnLXByaW1hcnkgcm91bmRlZC1mdWxsJ1xuICAgICAgICAgICAgICBhbmltYXRlPXt7XG4gICAgICAgICAgICAgICAgc2NhbGU6IFsxLCAxLjIsIDFdLFxuICAgICAgICAgICAgICAgIG9wYWNpdHk6IFswLjUsIDEsIDAuNV0sXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIHRyYW5zaXRpb249e3tcbiAgICAgICAgICAgICAgICBkdXJhdGlvbjogMS41LFxuICAgICAgICAgICAgICAgIHJlcGVhdDogSW5maW5pdHksXG4gICAgICAgICAgICAgICAgZGVsYXk6IGkgKiAwLjIsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICA8L21vdGlvbi5kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBMb2FkaW5nRmFsbGJhY2s7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJtb3Rpb24iLCJMb2FkaW5nRmFsbGJhY2siLCJtZXNzYWdlIiwiZGl2IiwiY2xhc3NOYW1lIiwiaW5pdGlhbCIsIm9wYWNpdHkiLCJzY2FsZSIsImFuaW1hdGUiLCJ0cmFuc2l0aW9uIiwiZHVyYXRpb24iLCJwIiwieSIsImRlbGF5IiwibWFwIiwiaSIsInJlcGVhdCIsIkluZmluaXR5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxPQUFPQSxXQUFXLFFBQVE7QUFDMUIsU0FBU0MsTUFBTSxRQUFRLGdCQUFnQjtBQU12QyxNQUFNQyxrQkFBa0QsQ0FBQyxFQUN2REMsVUFBVSxZQUFZLEVBQ3ZCO0lBQ0MscUJBQ0UsUUFBQ0M7UUFBSUMsV0FBVTtrQkFDYixjQUFBLFFBQUNKLE9BQU9HLEdBQUc7WUFDVEUsU0FBUztnQkFBRUMsU0FBUztnQkFBR0MsT0FBTztZQUFJO1lBQ2xDQyxTQUFTO2dCQUFFRixTQUFTO2dCQUFHQyxPQUFPO1lBQUU7WUFDaENFLFlBQVk7Z0JBQUVDLFVBQVU7WUFBSTtZQUM1Qk4sV0FBVTs7OEJBR1YsUUFBQ0Q7b0JBQUlDLFdBQVU7O3NDQUNiLFFBQUNEOzRCQUFJQyxXQUFVOzs7Ozs7c0NBQ2YsUUFBQ0Q7NEJBQUlDLFdBQVU7Ozs7Ozs7Ozs7Ozs4QkFJakIsUUFBQ0osT0FBT1csQ0FBQztvQkFDUE4sU0FBUzt3QkFBRUMsU0FBUzt3QkFBR00sR0FBRztvQkFBRztvQkFDN0JKLFNBQVM7d0JBQUVGLFNBQVM7d0JBQUdNLEdBQUc7b0JBQUU7b0JBQzVCSCxZQUFZO3dCQUFFSSxPQUFPO3dCQUFLSCxVQUFVO29CQUFJO29CQUN4Q04sV0FBVTs4QkFFVEY7Ozs7Ozs4QkFJSCxRQUFDRixPQUFPRyxHQUFHO29CQUNURSxTQUFTO3dCQUFFQyxTQUFTO29CQUFFO29CQUN0QkUsU0FBUzt3QkFBRUYsU0FBUztvQkFBRTtvQkFDdEJHLFlBQVk7d0JBQUVJLE9BQU87d0JBQUtILFVBQVU7b0JBQUk7b0JBQ3hDTixXQUFVOzhCQUVUO3dCQUFDO3dCQUFHO3dCQUFHO3FCQUFFLENBQUNVLEdBQUcsQ0FBQ0MsQ0FBQUEsa0JBQ2IsUUFBQ2YsT0FBT0csR0FBRzs0QkFFVEMsV0FBVTs0QkFDVkksU0FBUztnQ0FDUEQsT0FBTztvQ0FBQztvQ0FBRztvQ0FBSztpQ0FBRTtnQ0FDbEJELFNBQVM7b0NBQUM7b0NBQUs7b0NBQUc7aUNBQUk7NEJBQ3hCOzRCQUNBRyxZQUFZO2dDQUNWQyxVQUFVO2dDQUNWTSxRQUFRQztnQ0FDUkosT0FBT0UsSUFBSTs0QkFDYjsyQkFWS0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWlCbkI7S0FyRE1kO0FBdUROLGVBQWVBLGdCQUFnQiJ9