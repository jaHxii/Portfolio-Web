import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/RouteErrorBoundary.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_EMAILJS_PUBLIC_KEY": "0k9GNy3_VgCGbgb6p", "VITE_EMAILJS_SERVICE_ID": "service_69vleyd", "VITE_EMAILJS_TEMPLATE_ID": "template_yltgudd"};import * as RefreshRuntime from "/@react-refresh";

function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const Component = __vite__cjsImport2_react["Component"];
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { AlertTriangle, RefreshCw, Home } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Button } from "/src/components/ui/button.tsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=e72f996b";
class RouteErrorBoundary extends Component {
    static getDerivedStateFromError(error) {
        return {
            hasError: true,
            error
        };
    }
    componentDidCatch(error, errorInfo) {
        this.setState({
            error,
            errorInfo
        });
        // Log error to monitoring service
        console.error('Route Error Boundary caught an error:', error, errorInfo);
    // In production, you would send this to your error tracking service
    // Example: Sentry.captureException(error, { extra: errorInfo });
    }
    render() {
        if (this.state.hasError) {
            if (this.props.fallback) {
                return this.props.fallback;
            }
            return /*#__PURE__*/ _jsxDEV("div", {
                className: "min-h-screen flex items-center justify-center bg-background p-4",
                children: /*#__PURE__*/ _jsxDEV(motion.div, {
                    initial: {
                        opacity: 0,
                        y: 20
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    transition: {
                        duration: 0.5
                    },
                    className: "text-center max-w-md mx-auto space-y-6",
                    children: [
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                scale: 0
                            },
                            animate: {
                                scale: 1
                            },
                            transition: {
                                delay: 0.2,
                                type: 'spring',
                                stiffness: 200
                            },
                            className: "flex justify-center",
                            children: /*#__PURE__*/ _jsxDEV("div", {
                                className: "w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center",
                                children: /*#__PURE__*/ _jsxDEV(AlertTriangle, {
                                    className: "w-10 h-10 text-destructive"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                    lineNumber: 76,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                lineNumber: 75,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                            lineNumber: 69,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "space-y-2",
                            children: [
                                /*#__PURE__*/ _jsxDEV("h1", {
                                    className: "text-2xl font-bold text-foreground",
                                    children: "Oops! Something went wrong"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                    lineNumber: 82,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "text-muted-foreground",
                                    children: "We encountered an error while loading this page. This might be a temporary issue."
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                    lineNumber: 85,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                            lineNumber: 81,
                            columnNumber: 13
                        }, this),
                        import.meta.env.DEV && this.state.error && /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                height: 0
                            },
                            animate: {
                                opacity: 1,
                                height: 'auto'
                            },
                            transition: {
                                delay: 0.4
                            },
                            className: "bg-destructive/5 border border-destructive/20 rounded-lg p-4 text-left",
                            children: [
                                /*#__PURE__*/ _jsxDEV("h3", {
                                    className: "font-semibold text-destructive mb-2",
                                    children: "Error Details:"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                    lineNumber: 99,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ _jsxDEV("pre", {
                                    className: "text-xs text-muted-foreground overflow-auto max-h-32",
                                    children: [
                                        this.state.error.message,
                                        this.state.errorInfo?.componentStack
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                    lineNumber: 102,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                            lineNumber: 93,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 10
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.6
                            },
                            className: "flex flex-col sm:flex-row gap-3 justify-center",
                            children: [
                                /*#__PURE__*/ _jsxDEV(Button, {
                                    onClick: this.handleRetry,
                                    className: "flex items-center gap-2",
                                    variant: "outline",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV(RefreshCw, {
                                            className: "w-4 h-4"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                            lineNumber: 121,
                                            columnNumber: 17
                                        }, this),
                                        "Try Again"
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                    lineNumber: 116,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV(Button, {
                                    onClick: this.handleGoHome,
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV(Home, {
                                            className: "w-4 h-4"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                            lineNumber: 129,
                                            columnNumber: 17
                                        }, this),
                                        "Go Home"
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                    lineNumber: 125,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                            lineNumber: 110,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.p, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            transition: {
                                delay: 0.8
                            },
                            className: "text-sm text-muted-foreground",
                            children: [
                                "If the problem persists, please",
                                ' ',
                                /*#__PURE__*/ _jsxDEV(Link, {
                                    to: "/contact",
                                    className: "text-primary hover:underline",
                                    children: "contact support"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                                    lineNumber: 142,
                                    columnNumber: 15
                                }, this),
                                "."
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                            lineNumber: 135,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                    lineNumber: 62,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx",
                lineNumber: 61,
                columnNumber: 9
            }, this);
        }
        return this.props.children;
    }
    constructor(props){
        super(props), _define_property(this, "handleRetry", ()=>{
            this.setState({
                hasError: false,
                error: undefined,
                errorInfo: undefined
            });
        }), _define_property(this, "handleGoHome", ()=>{
            if (this.props.navigate) {
                this.props.navigate('/');
            } else {
                window.location.href = '/';
            }
        });
        this.state = {
            hasError: false
        };
    }
}
export default RouteErrorBoundary;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/layout/RouteErrorBoundary.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlJvdXRlRXJyb3JCb3VuZGFyeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCwgRXJyb3JJbmZvLCBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IEFsZXJ0VHJpYW5nbGUsIFJlZnJlc2hDdywgSG9tZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJztcbmltcG9ydCB7IExpbmssIE5hdmlnYXRlRnVuY3Rpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcbiAgZmFsbGJhY2s/OiBSZWFjdE5vZGU7XG4gIG5hdmlnYXRlPzogTmF2aWdhdGVGdW5jdGlvbjtcbn1cblxuaW50ZXJmYWNlIFN0YXRlIHtcbiAgaGFzRXJyb3I6IGJvb2xlYW47XG4gIGVycm9yPzogRXJyb3I7XG4gIGVycm9ySW5mbz86IEVycm9ySW5mbztcbn1cblxuY2xhc3MgUm91dGVFcnJvckJvdW5kYXJ5IGV4dGVuZHMgQ29tcG9uZW50PFByb3BzLCBTdGF0ZT4ge1xuICBjb25zdHJ1Y3Rvcihwcm9wczogUHJvcHMpIHtcbiAgICBzdXBlcihwcm9wcyk7XG4gICAgdGhpcy5zdGF0ZSA9IHsgaGFzRXJyb3I6IGZhbHNlIH07XG4gIH1cblxuICBzdGF0aWMgZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yKGVycm9yOiBFcnJvcik6IFN0YXRlIHtcbiAgICByZXR1cm4geyBoYXNFcnJvcjogdHJ1ZSwgZXJyb3IgfTtcbiAgfVxuXG4gIGNvbXBvbmVudERpZENhdGNoKGVycm9yOiBFcnJvciwgZXJyb3JJbmZvOiBFcnJvckluZm8pIHtcbiAgICB0aGlzLnNldFN0YXRlKHtcbiAgICAgIGVycm9yLFxuICAgICAgZXJyb3JJbmZvLFxuICAgIH0pO1xuXG4gICAgLy8gTG9nIGVycm9yIHRvIG1vbml0b3Jpbmcgc2VydmljZVxuICAgIGNvbnNvbGUuZXJyb3IoJ1JvdXRlIEVycm9yIEJvdW5kYXJ5IGNhdWdodCBhbiBlcnJvcjonLCBlcnJvciwgZXJyb3JJbmZvKTtcblxuICAgIC8vIEluIHByb2R1Y3Rpb24sIHlvdSB3b3VsZCBzZW5kIHRoaXMgdG8geW91ciBlcnJvciB0cmFja2luZyBzZXJ2aWNlXG4gICAgLy8gRXhhbXBsZTogU2VudHJ5LmNhcHR1cmVFeGNlcHRpb24oZXJyb3IsIHsgZXh0cmE6IGVycm9ySW5mbyB9KTtcbiAgfVxuXG4gIGhhbmRsZVJldHJ5ID0gKCkgPT4ge1xuICAgIHRoaXMuc2V0U3RhdGUoeyBoYXNFcnJvcjogZmFsc2UsIGVycm9yOiB1bmRlZmluZWQsIGVycm9ySW5mbzogdW5kZWZpbmVkIH0pO1xuICB9O1xuXG4gIGhhbmRsZUdvSG9tZSA9ICgpID0+IHtcbiAgICBpZiAodGhpcy5wcm9wcy5uYXZpZ2F0ZSkge1xuICAgICAgdGhpcy5wcm9wcy5uYXZpZ2F0ZSgnLycpO1xuICAgIH0gZWxzZSB7XG4gICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9ICcvJztcbiAgICB9XG4gIH07XG5cbiAgcmVuZGVyKCkge1xuICAgIGlmICh0aGlzLnN0YXRlLmhhc0Vycm9yKSB7XG4gICAgICBpZiAodGhpcy5wcm9wcy5mYWxsYmFjaykge1xuICAgICAgICByZXR1cm4gdGhpcy5wcm9wcy5mYWxsYmFjaztcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J21pbi1oLXNjcmVlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1iYWNrZ3JvdW5kIHAtNCc+XG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMjAgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC41IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J3RleHQtY2VudGVyIG1heC13LW1kIG14LWF1dG8gc3BhY2UteS02J1xuICAgICAgICAgID5cbiAgICAgICAgICAgIHsvKiBFcnJvciBJY29uICovfVxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBzY2FsZTogMCB9fVxuICAgICAgICAgICAgICBhbmltYXRlPXt7IHNjYWxlOiAxIH19XG4gICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuMiwgdHlwZTogJ3NwcmluZycsIHN0aWZmbmVzczogMjAwIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT0nZmxleCBqdXN0aWZ5LWNlbnRlcidcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3ctMjAgaC0yMCBiZy1kZXN0cnVjdGl2ZS8xMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXInPlxuICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT0ndy0xMCBoLTEwIHRleHQtZGVzdHJ1Y3RpdmUnIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICAgICAgICB7LyogRXJyb3IgTWVzc2FnZSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdzcGFjZS15LTInPlxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPSd0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kJz5cbiAgICAgICAgICAgICAgICBPb3BzISBTb21ldGhpbmcgd2VudCB3cm9uZ1xuICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtbXV0ZWQtZm9yZWdyb3VuZCc+XG4gICAgICAgICAgICAgICAgV2UgZW5jb3VudGVyZWQgYW4gZXJyb3Igd2hpbGUgbG9hZGluZyB0aGlzIHBhZ2UuIFRoaXMgbWlnaHQgYmUgYVxuICAgICAgICAgICAgICAgIHRlbXBvcmFyeSBpc3N1ZS5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBFcnJvciBEZXRhaWxzIChEZXZlbG9wbWVudCBPbmx5KSAqL31cbiAgICAgICAgICAgIHtpbXBvcnQubWV0YS5lbnYuREVWICYmIHRoaXMuc3RhdGUuZXJyb3IgJiYgKFxuICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgaGVpZ2h0OiAwIH19XG4gICAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCBoZWlnaHQ6ICdhdXRvJyB9fVxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuNCB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nYmctZGVzdHJ1Y3RpdmUvNSBib3JkZXIgYm9yZGVyLWRlc3RydWN0aXZlLzIwIHJvdW5kZWQtbGcgcC00IHRleHQtbGVmdCdcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9J2ZvbnQtc2VtaWJvbGQgdGV4dC1kZXN0cnVjdGl2ZSBtYi0yJz5cbiAgICAgICAgICAgICAgICAgIEVycm9yIERldGFpbHM6XG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8cHJlIGNsYXNzTmFtZT0ndGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgb3ZlcmZsb3ctYXV0byBtYXgtaC0zMic+XG4gICAgICAgICAgICAgICAgICB7dGhpcy5zdGF0ZS5lcnJvci5tZXNzYWdlfVxuICAgICAgICAgICAgICAgICAge3RoaXMuc3RhdGUuZXJyb3JJbmZvPy5jb21wb25lbnRTdGFja31cbiAgICAgICAgICAgICAgICA8L3ByZT5cbiAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAxMCB9fVxuICAgICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC42IH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT0nZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBnYXAtMyBqdXN0aWZ5LWNlbnRlcidcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RoaXMuaGFuZGxlUmV0cnl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMidcbiAgICAgICAgICAgICAgICB2YXJpYW50PSdvdXRsaW5lJ1xuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9J3ctNCBoLTQnIC8+XG4gICAgICAgICAgICAgICAgVHJ5IEFnYWluXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXt0aGlzLmhhbmRsZUdvSG9tZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGdhcC0yJ1xuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEhvbWUgY2xhc3NOYW1lPSd3LTQgaC00JyAvPlxuICAgICAgICAgICAgICAgIEdvIEhvbWVcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L21vdGlvbi5kaXY+XG5cbiAgICAgICAgICAgIHsvKiBIZWxwIFRleHQgKi99XG4gICAgICAgICAgICA8bW90aW9uLnBcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwIH19XG4gICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjggfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSd0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCdcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgSWYgdGhlIHByb2JsZW0gcGVyc2lzdHMsIHBsZWFzZXsnICd9XG4gICAgICAgICAgICAgIDxMaW5rIHRvPScvY29udGFjdCcgY2xhc3NOYW1lPSd0ZXh0LXByaW1hcnkgaG92ZXI6dW5kZXJsaW5lJz5cbiAgICAgICAgICAgICAgICBjb250YWN0IHN1cHBvcnRcbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAuXG4gICAgICAgICAgICA8L21vdGlvbi5wPlxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLnByb3BzLmNoaWxkcmVuO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFJvdXRlRXJyb3JCb3VuZGFyeTtcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIkNvbXBvbmVudCIsIm1vdGlvbiIsIkFsZXJ0VHJpYW5nbGUiLCJSZWZyZXNoQ3ciLCJIb21lIiwiQnV0dG9uIiwiTGluayIsIlJvdXRlRXJyb3JCb3VuZGFyeSIsImdldERlcml2ZWRTdGF0ZUZyb21FcnJvciIsImVycm9yIiwiaGFzRXJyb3IiLCJjb21wb25lbnREaWRDYXRjaCIsImVycm9ySW5mbyIsInNldFN0YXRlIiwiY29uc29sZSIsInJlbmRlciIsInN0YXRlIiwicHJvcHMiLCJmYWxsYmFjayIsImRpdiIsImNsYXNzTmFtZSIsImluaXRpYWwiLCJvcGFjaXR5IiwieSIsImFuaW1hdGUiLCJ0cmFuc2l0aW9uIiwiZHVyYXRpb24iLCJzY2FsZSIsImRlbGF5IiwidHlwZSIsInN0aWZmbmVzcyIsImgxIiwicCIsImVudiIsIkRFViIsImhlaWdodCIsImgzIiwicHJlIiwibWVzc2FnZSIsImNvbXBvbmVudFN0YWNrIiwib25DbGljayIsImhhbmRsZVJldHJ5IiwidmFyaWFudCIsImhhbmRsZUdvSG9tZSIsInRvIiwiY2hpbGRyZW4iLCJjb25zdHJ1Y3RvciIsInVuZGVmaW5lZCIsIm5hdmlnYXRlIiwid2luZG93IiwibG9jYXRpb24iLCJocmVmIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsU0FBUyxRQUE4QixRQUFRO0FBQy9ELFNBQVNDLE1BQU0sUUFBUSxnQkFBZ0I7QUFDdkMsU0FBU0MsYUFBYSxFQUFFQyxTQUFTLEVBQUVDLElBQUksUUFBUSxlQUFlO0FBQzlELFNBQVNDLE1BQU0sUUFBUSx5QkFBeUI7QUFDaEQsU0FBU0MsSUFBSSxRQUEwQixtQkFBbUI7QUFjMUQsTUFBTUMsMkJBQTJCUDtJQU0vQixPQUFPUSx5QkFBeUJDLEtBQVksRUFBUztRQUNuRCxPQUFPO1lBQUVDLFVBQVU7WUFBTUQ7UUFBTTtJQUNqQztJQUVBRSxrQkFBa0JGLEtBQVksRUFBRUcsU0FBb0IsRUFBRTtRQUNwRCxJQUFJLENBQUNDLFFBQVEsQ0FBQztZQUNaSjtZQUNBRztRQUNGO1FBRUEsa0NBQWtDO1FBQ2xDRSxRQUFRTCxLQUFLLENBQUMseUNBQXlDQSxPQUFPRztJQUU5RCxvRUFBb0U7SUFDcEUsaUVBQWlFO0lBQ25FO0lBY0FHLFNBQVM7UUFDUCxJQUFJLElBQUksQ0FBQ0MsS0FBSyxDQUFDTixRQUFRLEVBQUU7WUFDdkIsSUFBSSxJQUFJLENBQUNPLEtBQUssQ0FBQ0MsUUFBUSxFQUFFO2dCQUN2QixPQUFPLElBQUksQ0FBQ0QsS0FBSyxDQUFDQyxRQUFRO1lBQzVCO1lBRUEscUJBQ0UsUUFBQ0M7Z0JBQUlDLFdBQVU7MEJBQ2IsY0FBQSxRQUFDbkIsT0FBT2tCLEdBQUc7b0JBQ1RFLFNBQVM7d0JBQUVDLFNBQVM7d0JBQUdDLEdBQUc7b0JBQUc7b0JBQzdCQyxTQUFTO3dCQUFFRixTQUFTO3dCQUFHQyxHQUFHO29CQUFFO29CQUM1QkUsWUFBWTt3QkFBRUMsVUFBVTtvQkFBSTtvQkFDNUJOLFdBQVU7O3NDQUdWLFFBQUNuQixPQUFPa0IsR0FBRzs0QkFDVEUsU0FBUztnQ0FBRU0sT0FBTzs0QkFBRTs0QkFDcEJILFNBQVM7Z0NBQUVHLE9BQU87NEJBQUU7NEJBQ3BCRixZQUFZO2dDQUFFRyxPQUFPO2dDQUFLQyxNQUFNO2dDQUFVQyxXQUFXOzRCQUFJOzRCQUN6RFYsV0FBVTtzQ0FFVixjQUFBLFFBQUNEO2dDQUFJQyxXQUFVOzBDQUNiLGNBQUEsUUFBQ2xCO29DQUFja0IsV0FBVTs7Ozs7Ozs7Ozs7Ozs7OztzQ0FLN0IsUUFBQ0Q7NEJBQUlDLFdBQVU7OzhDQUNiLFFBQUNXO29DQUFHWCxXQUFVOzhDQUFxQzs7Ozs7OzhDQUduRCxRQUFDWTtvQ0FBRVosV0FBVTs4Q0FBd0I7Ozs7Ozs7Ozs7Ozt3QkFPdEMsWUFBWWEsR0FBRyxDQUFDQyxHQUFHLElBQUksSUFBSSxDQUFDbEIsS0FBSyxDQUFDUCxLQUFLLGtCQUN0QyxRQUFDUixPQUFPa0IsR0FBRzs0QkFDVEUsU0FBUztnQ0FBRUMsU0FBUztnQ0FBR2EsUUFBUTs0QkFBRTs0QkFDakNYLFNBQVM7Z0NBQUVGLFNBQVM7Z0NBQUdhLFFBQVE7NEJBQU87NEJBQ3RDVixZQUFZO2dDQUFFRyxPQUFPOzRCQUFJOzRCQUN6QlIsV0FBVTs7OENBRVYsUUFBQ2dCO29DQUFHaEIsV0FBVTs4Q0FBc0M7Ozs7Ozs4Q0FHcEQsUUFBQ2lCO29DQUFJakIsV0FBVTs7d0NBQ1osSUFBSSxDQUFDSixLQUFLLENBQUNQLEtBQUssQ0FBQzZCLE9BQU87d0NBQ3hCLElBQUksQ0FBQ3RCLEtBQUssQ0FBQ0osU0FBUyxFQUFFMkI7Ozs7Ozs7Ozs7Ozs7c0NBTTdCLFFBQUN0QyxPQUFPa0IsR0FBRzs0QkFDVEUsU0FBUztnQ0FBRUMsU0FBUztnQ0FBR0MsR0FBRzs0QkFBRzs0QkFDN0JDLFNBQVM7Z0NBQUVGLFNBQVM7Z0NBQUdDLEdBQUc7NEJBQUU7NEJBQzVCRSxZQUFZO2dDQUFFRyxPQUFPOzRCQUFJOzRCQUN6QlIsV0FBVTs7OENBRVYsUUFBQ2Y7b0NBQ0NtQyxTQUFTLElBQUksQ0FBQ0MsV0FBVztvQ0FDekJyQixXQUFVO29DQUNWc0IsU0FBUTs7c0RBRVIsUUFBQ3ZDOzRDQUFVaUIsV0FBVTs7Ozs7O3dDQUFZOzs7Ozs7OzhDQUluQyxRQUFDZjtvQ0FDQ21DLFNBQVMsSUFBSSxDQUFDRyxZQUFZO29DQUMxQnZCLFdBQVU7O3NEQUVWLFFBQUNoQjs0Q0FBS2dCLFdBQVU7Ozs7Ozt3Q0FBWTs7Ozs7Ozs7Ozs7OztzQ0FNaEMsUUFBQ25CLE9BQU8rQixDQUFDOzRCQUNQWCxTQUFTO2dDQUFFQyxTQUFTOzRCQUFFOzRCQUN0QkUsU0FBUztnQ0FBRUYsU0FBUzs0QkFBRTs0QkFDdEJHLFlBQVk7Z0NBQUVHLE9BQU87NEJBQUk7NEJBQ3pCUixXQUFVOztnQ0FDWDtnQ0FDaUM7OENBQ2hDLFFBQUNkO29DQUFLc0MsSUFBRztvQ0FBV3hCLFdBQVU7OENBQStCOzs7Ozs7Z0NBRXREOzs7Ozs7Ozs7Ozs7Ozs7Ozs7UUFNakI7UUFFQSxPQUFPLElBQUksQ0FBQ0gsS0FBSyxDQUFDNEIsUUFBUTtJQUM1QjtJQXJJQUMsWUFBWTdCLEtBQVksQ0FBRTtRQUN4QixLQUFLLENBQUNBLFFBcUJSd0IsdUJBQUFBLGVBQWM7WUFDWixJQUFJLENBQUM1QixRQUFRLENBQUM7Z0JBQUVILFVBQVU7Z0JBQU9ELE9BQU9zQztnQkFBV25DLFdBQVdtQztZQUFVO1FBQzFFLElBRUFKLHVCQUFBQSxnQkFBZTtZQUNiLElBQUksSUFBSSxDQUFDMUIsS0FBSyxDQUFDK0IsUUFBUSxFQUFFO2dCQUN2QixJQUFJLENBQUMvQixLQUFLLENBQUMrQixRQUFRLENBQUM7WUFDdEIsT0FBTztnQkFDTEMsT0FBT0MsUUFBUSxDQUFDQyxJQUFJLEdBQUc7WUFDekI7UUFDRjtRQTlCRSxJQUFJLENBQUNuQyxLQUFLLEdBQUc7WUFBRU4sVUFBVTtRQUFNO0lBQ2pDO0FBbUlGO0FBRUEsZUFBZUgsbUJBQW1CIn0=