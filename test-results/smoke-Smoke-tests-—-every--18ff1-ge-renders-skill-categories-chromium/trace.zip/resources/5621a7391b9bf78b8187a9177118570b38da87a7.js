import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const useMemo = __vite__cjsImport0_react["useMemo"];
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=e72f996b";
const defaultSEO = {
    title: 'Ermias Lemesa - Computer Engineer | IT Support Specialist | Hardware Engineer',
    description: 'Computer Engineer and Senior IT Support Specialist with hands-on experience in hardware, networking, helpdesk, and AI/ML. Skilled in Python, SQL, web applications, and process automation.',
    keywords: [
        'computer engineer',
        'it support',
        'hardware engineer',
        'python',
        'machine learning',
        'web development',
        'addis ababa',
        'ethiopia'
    ],
    image: '/portfolio.png',
    type: 'website',
    author: 'Ermias Lemesa'
};
const pageSEOConfig = {
    '/': {
        title: 'Home - Ermias Lemesa | Computer Engineer & IT Support Specialist',
        description: 'Welcome to my portfolio. I am a Computer Engineer and Senior IT Support Specialist based in Addis Ababa, Ethiopia, specializing in hardware, networking, helpdesk, and AI/ML.',
        keywords: [
            'portfolio',
            'computer engineer',
            'it support',
            'hardware engineer',
            'addis ababa',
            'home'
        ],
        type: 'website'
    },
    '/projects': {
        title: 'Projects - Portfolio Showcase',
        description: 'Explore my real projects: KIRAY rental management, MESOB IT helpdesk ticketing, analytics dashboards, printer asset monitoring, and Melala Coffee.',
        keywords: [
            'projects',
            'portfolio',
            'kiray',
            'it helpdesk',
            'analytics dashboard',
            'melala coffee'
        ],
        type: 'website',
        section: 'Projects'
    },
    '/skills': {
        title: 'Skills & Technologies - Technical Expertise',
        description: 'Discover my technical skills in IT infrastructure support, system troubleshooting, Python programming, machine learning fundamentals, database design, and web application development.',
        keywords: [
            'skills',
            'technologies',
            'it infrastructure',
            'system troubleshooting',
            'python',
            'sql',
            'machine learning'
        ],
        type: 'website',
        section: 'Skills'
    },
    '/experience': {
        title: 'Professional Experience - Career Journey',
        description: 'Learn about my professional experience as a Senior IT Support Specialist at ROTECH, Hardware Engineer at Addis Mesob, and AI/ML Intern at the Ethiopian Artificial Intelligence Institute.',
        keywords: [
            'experience',
            'career',
            'professional',
            'it support',
            'hardware engineer',
            'ai/ml intern'
        ],
        type: 'website',
        section: 'Experience'
    },
    '/contact': {
        title: 'Contact - Get In Touch',
        description: "Get in touch for IT support, collaboration opportunities, or professional discussions. Let's build something amazing together.",
        keywords: [
            'contact',
            'collaboration',
            'hire',
            'freelance',
            'consultation'
        ],
        type: 'website',
        section: 'Contact'
    },
    '/resume': {
        title: 'Resume - Ermias Lemesa',
        description: 'Resume of Ermias Lemesa - Computer Engineer and Senior IT Support Specialist. Education, skills, experience, and certifications.',
        keywords: [
            'resume',
            'cv',
            'curriculum vitae',
            'computer engineer',
            'it support'
        ],
        type: 'website',
        section: 'Resume'
    }
};
export const useSEO = (customSEO)=>{
    const location = useLocation();
    return useMemo(()=>{
        const origin = window.location.origin;
        const pageSEO = pageSEOConfig[location.pathname] || {};
        const currentUrl = `${origin}${location.pathname}`;
        return {
            ...defaultSEO,
            ...pageSEO,
            ...customSEO,
            url: currentUrl,
            canonicalUrl: currentUrl
        };
    }, [
        location.pathname,
        location.origin,
        customSEO
    ]);
};
export default useSEO;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZS1zZW8udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUxvY2F0aW9uIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBTRU9Qcm9wcyB9IGZyb20gJ0AvY29tcG9uZW50cy9zZW8vU0VPJztcblxuaW50ZXJmYWNlIFBhZ2VTRU9Db25maWcge1xuICBba2V5OiBzdHJpbmddOiBQYXJ0aWFsPFNFT1Byb3BzPjtcbn1cblxuY29uc3QgZGVmYXVsdFNFTzogU0VPUHJvcHMgPSB7XG4gIHRpdGxlOlxuICAgICdFcm1pYXMgTGVtZXNhIC0gQ29tcHV0ZXIgRW5naW5lZXIgfCBJVCBTdXBwb3J0IFNwZWNpYWxpc3QgfCBIYXJkd2FyZSBFbmdpbmVlcicsXG4gIGRlc2NyaXB0aW9uOlxuICAgICdDb21wdXRlciBFbmdpbmVlciBhbmQgU2VuaW9yIElUIFN1cHBvcnQgU3BlY2lhbGlzdCB3aXRoIGhhbmRzLW9uIGV4cGVyaWVuY2UgaW4gaGFyZHdhcmUsIG5ldHdvcmtpbmcsIGhlbHBkZXNrLCBhbmQgQUkvTUwuIFNraWxsZWQgaW4gUHl0aG9uLCBTUUwsIHdlYiBhcHBsaWNhdGlvbnMsIGFuZCBwcm9jZXNzIGF1dG9tYXRpb24uJyxcbiAga2V5d29yZHM6IFtcbiAgICAnY29tcHV0ZXIgZW5naW5lZXInLFxuICAgICdpdCBzdXBwb3J0JyxcbiAgICAnaGFyZHdhcmUgZW5naW5lZXInLFxuICAgICdweXRob24nLFxuICAgICdtYWNoaW5lIGxlYXJuaW5nJyxcbiAgICAnd2ViIGRldmVsb3BtZW50JyxcbiAgICAnYWRkaXMgYWJhYmEnLFxuICAgICdldGhpb3BpYScsXG4gIF0sXG4gIGltYWdlOiAnL3BvcnRmb2xpby5wbmcnLFxuICB0eXBlOiAnd2Vic2l0ZScsXG4gIGF1dGhvcjogJ0VybWlhcyBMZW1lc2EnLFxufTtcblxuY29uc3QgcGFnZVNFT0NvbmZpZzogUGFnZVNFT0NvbmZpZyA9IHtcbiAgJy8nOiB7XG4gICAgdGl0bGU6ICdIb21lIC0gRXJtaWFzIExlbWVzYSB8IENvbXB1dGVyIEVuZ2luZWVyICYgSVQgU3VwcG9ydCBTcGVjaWFsaXN0JyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdXZWxjb21lIHRvIG15IHBvcnRmb2xpby4gSSBhbSBhIENvbXB1dGVyIEVuZ2luZWVyIGFuZCBTZW5pb3IgSVQgU3VwcG9ydCBTcGVjaWFsaXN0IGJhc2VkIGluIEFkZGlzIEFiYWJhLCBFdGhpb3BpYSwgc3BlY2lhbGl6aW5nIGluIGhhcmR3YXJlLCBuZXR3b3JraW5nLCBoZWxwZGVzaywgYW5kIEFJL01MLicsXG4gICAga2V5d29yZHM6IFtcbiAgICAgICdwb3J0Zm9saW8nLFxuICAgICAgJ2NvbXB1dGVyIGVuZ2luZWVyJyxcbiAgICAgICdpdCBzdXBwb3J0JyxcbiAgICAgICdoYXJkd2FyZSBlbmdpbmVlcicsXG4gICAgICAnYWRkaXMgYWJhYmEnLFxuICAgICAgJ2hvbWUnLFxuICAgIF0sXG4gICAgdHlwZTogJ3dlYnNpdGUnLFxuICB9LFxuICAnL3Byb2plY3RzJzoge1xuICAgIHRpdGxlOiAnUHJvamVjdHMgLSBQb3J0Zm9saW8gU2hvd2Nhc2UnLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0V4cGxvcmUgbXkgcmVhbCBwcm9qZWN0czogS0lSQVkgcmVudGFsIG1hbmFnZW1lbnQsIE1FU09CIElUIGhlbHBkZXNrIHRpY2tldGluZywgYW5hbHl0aWNzIGRhc2hib2FyZHMsIHByaW50ZXIgYXNzZXQgbW9uaXRvcmluZywgYW5kIE1lbGFsYSBDb2ZmZWUuJyxcbiAgICBrZXl3b3JkczogW1xuICAgICAgJ3Byb2plY3RzJyxcbiAgICAgICdwb3J0Zm9saW8nLFxuICAgICAgJ2tpcmF5JyxcbiAgICAgICdpdCBoZWxwZGVzaycsXG4gICAgICAnYW5hbHl0aWNzIGRhc2hib2FyZCcsXG4gICAgICAnbWVsYWxhIGNvZmZlZScsXG4gICAgXSxcbiAgICB0eXBlOiAnd2Vic2l0ZScsXG4gICAgc2VjdGlvbjogJ1Byb2plY3RzJyxcbiAgfSxcbiAgJy9za2lsbHMnOiB7XG4gICAgdGl0bGU6ICdTa2lsbHMgJiBUZWNobm9sb2dpZXMgLSBUZWNobmljYWwgRXhwZXJ0aXNlJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgICdEaXNjb3ZlciBteSB0ZWNobmljYWwgc2tpbGxzIGluIElUIGluZnJhc3RydWN0dXJlIHN1cHBvcnQsIHN5c3RlbSB0cm91Ymxlc2hvb3RpbmcsIFB5dGhvbiBwcm9ncmFtbWluZywgbWFjaGluZSBsZWFybmluZyBmdW5kYW1lbnRhbHMsIGRhdGFiYXNlIGRlc2lnbiwgYW5kIHdlYiBhcHBsaWNhdGlvbiBkZXZlbG9wbWVudC4nLFxuICAgIGtleXdvcmRzOiBbXG4gICAgICAnc2tpbGxzJyxcbiAgICAgICd0ZWNobm9sb2dpZXMnLFxuICAgICAgJ2l0IGluZnJhc3RydWN0dXJlJyxcbiAgICAgICdzeXN0ZW0gdHJvdWJsZXNob290aW5nJyxcbiAgICAgICdweXRob24nLFxuICAgICAgJ3NxbCcsXG4gICAgICAnbWFjaGluZSBsZWFybmluZycsXG4gICAgXSxcbiAgICB0eXBlOiAnd2Vic2l0ZScsXG4gICAgc2VjdGlvbjogJ1NraWxscycsXG4gIH0sXG4gICcvZXhwZXJpZW5jZSc6IHtcbiAgICB0aXRsZTogJ1Byb2Zlc3Npb25hbCBFeHBlcmllbmNlIC0gQ2FyZWVyIEpvdXJuZXknLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgJ0xlYXJuIGFib3V0IG15IHByb2Zlc3Npb25hbCBleHBlcmllbmNlIGFzIGEgU2VuaW9yIElUIFN1cHBvcnQgU3BlY2lhbGlzdCBhdCBST1RFQ0gsIEhhcmR3YXJlIEVuZ2luZWVyIGF0IEFkZGlzIE1lc29iLCBhbmQgQUkvTUwgSW50ZXJuIGF0IHRoZSBFdGhpb3BpYW4gQXJ0aWZpY2lhbCBJbnRlbGxpZ2VuY2UgSW5zdGl0dXRlLicsXG4gICAga2V5d29yZHM6IFtcbiAgICAgICdleHBlcmllbmNlJyxcbiAgICAgICdjYXJlZXInLFxuICAgICAgJ3Byb2Zlc3Npb25hbCcsXG4gICAgICAnaXQgc3VwcG9ydCcsXG4gICAgICAnaGFyZHdhcmUgZW5naW5lZXInLFxuICAgICAgJ2FpL21sIGludGVybicsXG4gICAgXSxcbiAgICB0eXBlOiAnd2Vic2l0ZScsXG4gICAgc2VjdGlvbjogJ0V4cGVyaWVuY2UnLFxuICB9LFxuICAnL2NvbnRhY3QnOiB7XG4gICAgdGl0bGU6ICdDb250YWN0IC0gR2V0IEluIFRvdWNoJyxcbiAgICBkZXNjcmlwdGlvbjpcbiAgICAgIFwiR2V0IGluIHRvdWNoIGZvciBJVCBzdXBwb3J0LCBjb2xsYWJvcmF0aW9uIG9wcG9ydHVuaXRpZXMsIG9yIHByb2Zlc3Npb25hbCBkaXNjdXNzaW9ucy4gTGV0J3MgYnVpbGQgc29tZXRoaW5nIGFtYXppbmcgdG9nZXRoZXIuXCIsXG4gICAga2V5d29yZHM6IFsnY29udGFjdCcsICdjb2xsYWJvcmF0aW9uJywgJ2hpcmUnLCAnZnJlZWxhbmNlJywgJ2NvbnN1bHRhdGlvbiddLFxuICAgIHR5cGU6ICd3ZWJzaXRlJyxcbiAgICBzZWN0aW9uOiAnQ29udGFjdCcsXG4gIH0sXG4gICcvcmVzdW1lJzoge1xuICAgIHRpdGxlOiAnUmVzdW1lIC0gRXJtaWFzIExlbWVzYScsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnUmVzdW1lIG9mIEVybWlhcyBMZW1lc2EgLSBDb21wdXRlciBFbmdpbmVlciBhbmQgU2VuaW9yIElUIFN1cHBvcnQgU3BlY2lhbGlzdC4gRWR1Y2F0aW9uLCBza2lsbHMsIGV4cGVyaWVuY2UsIGFuZCBjZXJ0aWZpY2F0aW9ucy4nLFxuICAgIGtleXdvcmRzOiBbXG4gICAgICAncmVzdW1lJyxcbiAgICAgICdjdicsXG4gICAgICAnY3VycmljdWx1bSB2aXRhZScsXG4gICAgICAnY29tcHV0ZXIgZW5naW5lZXInLFxuICAgICAgJ2l0IHN1cHBvcnQnLFxuICAgIF0sXG4gICAgdHlwZTogJ3dlYnNpdGUnLFxuICAgIHNlY3Rpb246ICdSZXN1bWUnLFxuICB9LFxufTtcblxuZXhwb3J0IGNvbnN0IHVzZVNFTyA9IChjdXN0b21TRU8/OiBQYXJ0aWFsPFNFT1Byb3BzPik6IFNFT1Byb3BzID0+IHtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuXG4gIHJldHVybiB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBvcmlnaW4gPSB3aW5kb3cubG9jYXRpb24ub3JpZ2luO1xuICAgIGNvbnN0IHBhZ2VTRU8gPSBwYWdlU0VPQ29uZmlnW2xvY2F0aW9uLnBhdGhuYW1lXSB8fCB7fTtcbiAgICBjb25zdCBjdXJyZW50VXJsID0gYCR7b3JpZ2lufSR7bG9jYXRpb24ucGF0aG5hbWV9YDtcblxuICAgIHJldHVybiB7XG4gICAgICAuLi5kZWZhdWx0U0VPLFxuICAgICAgLi4ucGFnZVNFTyxcbiAgICAgIC4uLmN1c3RvbVNFTyxcbiAgICAgIHVybDogY3VycmVudFVybCxcbiAgICAgIGNhbm9uaWNhbFVybDogY3VycmVudFVybCxcbiAgICB9O1xuICB9LCBbbG9jYXRpb24ucGF0aG5hbWUsIGxvY2F0aW9uLm9yaWdpbiwgY3VzdG9tU0VPXSk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCB1c2VTRU87XG4iXSwibmFtZXMiOlsidXNlTWVtbyIsInVzZUxvY2F0aW9uIiwiZGVmYXVsdFNFTyIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJrZXl3b3JkcyIsImltYWdlIiwidHlwZSIsImF1dGhvciIsInBhZ2VTRU9Db25maWciLCJzZWN0aW9uIiwidXNlU0VPIiwiY3VzdG9tU0VPIiwibG9jYXRpb24iLCJvcmlnaW4iLCJ3aW5kb3ciLCJwYWdlU0VPIiwicGF0aG5hbWUiLCJjdXJyZW50VXJsIiwidXJsIiwiY2Fub25pY2FsVXJsIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTQSxPQUFPLFFBQVEsUUFBUTtBQUNoQyxTQUFTQyxXQUFXLFFBQVEsbUJBQW1CO0FBTy9DLE1BQU1DLGFBQXVCO0lBQzNCQyxPQUNFO0lBQ0ZDLGFBQ0U7SUFDRkMsVUFBVTtRQUNSO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7S0FDRDtJQUNEQyxPQUFPO0lBQ1BDLE1BQU07SUFDTkMsUUFBUTtBQUNWO0FBRUEsTUFBTUMsZ0JBQStCO0lBQ25DLEtBQUs7UUFDSE4sT0FBTztRQUNQQyxhQUNFO1FBQ0ZDLFVBQVU7WUFDUjtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7U0FDRDtRQUNERSxNQUFNO0lBQ1I7SUFDQSxhQUFhO1FBQ1hKLE9BQU87UUFDUEMsYUFDRTtRQUNGQyxVQUFVO1lBQ1I7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1NBQ0Q7UUFDREUsTUFBTTtRQUNORyxTQUFTO0lBQ1g7SUFDQSxXQUFXO1FBQ1RQLE9BQU87UUFDUEMsYUFDRTtRQUNGQyxVQUFVO1lBQ1I7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7U0FDRDtRQUNERSxNQUFNO1FBQ05HLFNBQVM7SUFDWDtJQUNBLGVBQWU7UUFDYlAsT0FBTztRQUNQQyxhQUNFO1FBQ0ZDLFVBQVU7WUFDUjtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7U0FDRDtRQUNERSxNQUFNO1FBQ05HLFNBQVM7SUFDWDtJQUNBLFlBQVk7UUFDVlAsT0FBTztRQUNQQyxhQUNFO1FBQ0ZDLFVBQVU7WUFBQztZQUFXO1lBQWlCO1lBQVE7WUFBYTtTQUFlO1FBQzNFRSxNQUFNO1FBQ05HLFNBQVM7SUFDWDtJQUNBLFdBQVc7UUFDVFAsT0FBTztRQUNQQyxhQUNFO1FBQ0ZDLFVBQVU7WUFDUjtZQUNBO1lBQ0E7WUFDQTtZQUNBO1NBQ0Q7UUFDREUsTUFBTTtRQUNORyxTQUFTO0lBQ1g7QUFDRjtBQUVBLE9BQU8sTUFBTUMsU0FBUyxDQUFDQztJQUNyQixNQUFNQyxXQUFXWjtJQUVqQixPQUFPRCxRQUFRO1FBQ2IsTUFBTWMsU0FBU0MsT0FBT0YsUUFBUSxDQUFDQyxNQUFNO1FBQ3JDLE1BQU1FLFVBQVVQLGFBQWEsQ0FBQ0ksU0FBU0ksUUFBUSxDQUFDLElBQUksQ0FBQztRQUNyRCxNQUFNQyxhQUFhLEdBQUdKLFNBQVNELFNBQVNJLFFBQVEsRUFBRTtRQUVsRCxPQUFPO1lBQ0wsR0FBR2YsVUFBVTtZQUNiLEdBQUdjLE9BQU87WUFDVixHQUFHSixTQUFTO1lBQ1pPLEtBQUtEO1lBQ0xFLGNBQWNGO1FBQ2hCO0lBQ0YsR0FBRztRQUFDTCxTQUFTSSxRQUFRO1FBQUVKLFNBQVNDLE1BQU07UUFBRUY7S0FBVTtBQUNwRCxFQUFFO0FBRUYsZUFBZUQsT0FBTyJ9