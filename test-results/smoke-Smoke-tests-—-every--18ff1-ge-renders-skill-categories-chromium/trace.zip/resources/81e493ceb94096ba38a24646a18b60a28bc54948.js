import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/confirm-code-link.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useState = __vite__cjsImport2_react["useState"];
import { Github } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Button } from "/src/components/ui/button.tsx";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "/src/components/ui/dialog.tsx";
const ConfirmCodeLink = ({ href, projectName, className })=>{
    _s();
    const [open, setOpen] = useState(false);
    const depart = ()=>{
        window.open(href, '_blank', 'noopener=yes,noreferrer=yes');
        setOpen(false);
    };
    return /*#__PURE__*/ _jsxDEV(Dialog, {
        open: open,
        onOpenChange: setOpen,
        children: [
            /*#__PURE__*/ _jsxDEV(Button, {
                type: "button",
                variant: "outline",
                size: "sm",
                className: className,
                onClick: ()=>setOpen(true),
                children: [
                    /*#__PURE__*/ _jsxDEV(Github, {
                        className: "h-4 w-4 mr-2"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, this),
                    "Code"
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(DialogContent, {
                className: "border-gold/20",
                children: [
                    /*#__PURE__*/ _jsxDEV(DialogHeader, {
                        children: [
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "flex items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-gold/70 mb-1",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        className: "relative flex h-1.5 w-1.5",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "absolute inline-flex h-full w-full rounded-full bg-gold/50 motion-safe:animate-ping"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                                lineNumber: 47,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "relative inline-flex h-1.5 w-1.5 rounded-full bg-gold"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                                lineNumber: 48,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                        lineNumber: 46,
                                        columnNumber: 13
                                    }, this),
                                    "WAYPOINT · EXTERNAL"
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                lineNumber: 45,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV(DialogTitle, {
                                className: "font-heading text-xl",
                                children: "Open flight to GitHub?"
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                lineNumber: 52,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV(DialogDescription, {
                                className: "leading-relaxed",
                                children: [
                                    "You're leaving the control tower and heading to the",
                                    projectName ? /*#__PURE__*/ _jsxDEV(_Fragment, {
                                        children: [
                                            ' ',
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "text-foreground font-medium",
                                                children: [
                                                    '"',
                                                    projectName,
                                                    '"'
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                                lineNumber: 60,
                                                columnNumber: 17
                                            }, this),
                                            ' ',
                                            "repository"
                                        ]
                                    }, void 0, true) : ' external ',
                                    "on GitHub. Confirm departure?"
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                lineNumber: 55,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                        lineNumber: 44,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(DialogFooter, {
                        children: [
                            /*#__PURE__*/ _jsxDEV(Button, {
                                type: "button",
                                variant: "outline",
                                className: "glass text-mist-soft",
                                onClick: ()=>setOpen(false),
                                children: "Stay"
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                lineNumber: 72,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV(Button, {
                                type: "button",
                                className: "bg-mist text-storm-deep hover:bg-mist/90",
                                onClick: depart,
                                children: [
                                    /*#__PURE__*/ _jsxDEV(Github, {
                                        className: "h-4 w-4 mr-2"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                        lineNumber: 85,
                                        columnNumber: 13
                                    }, this),
                                    "Depart"
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                                lineNumber: 80,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                        lineNumber: 71,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx",
        lineNumber: 32,
        columnNumber: 5
    }, this);
};
_s(ConfirmCodeLink, "xG1TONbKtDWtdOTrXaTAsNhPg/Q=");
_c = ConfirmCodeLink;
export default ConfirmCodeLink;
var _c;
$RefreshReg$(_c, "ConfirmCodeLink");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/confirm-code-link.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbmZpcm0tY29kZS1saW5rLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBHaXRodWIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5pbXBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0NvbnRlbnQsXG4gIERpYWxvZ0Rlc2NyaXB0aW9uLFxuICBEaWFsb2dGb290ZXIsXG4gIERpYWxvZ0hlYWRlcixcbiAgRGlhbG9nVGl0bGUsXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS9kaWFsb2cnO1xuXG5pbnRlcmZhY2UgQ29uZmlybUNvZGVMaW5rUHJvcHMge1xuICBocmVmOiBzdHJpbmc7XG4gIHByb2plY3ROYW1lPzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmNvbnN0IENvbmZpcm1Db2RlTGluayA9ICh7XG4gIGhyZWYsXG4gIHByb2plY3ROYW1lLFxuICBjbGFzc05hbWUsXG59OiBDb25maXJtQ29kZUxpbmtQcm9wcykgPT4ge1xuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgZGVwYXJ0ID0gKCkgPT4ge1xuICAgIHdpbmRvdy5vcGVuKGhyZWYsICdfYmxhbmsnLCAnbm9vcGVuZXI9eWVzLG5vcmVmZXJyZXI9eWVzJyk7XG4gICAgc2V0T3BlbihmYWxzZSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8RGlhbG9nIG9wZW49e29wZW59IG9uT3BlbkNoYW5nZT17c2V0T3Blbn0+XG4gICAgICA8QnV0dG9uXG4gICAgICAgIHR5cGU9J2J1dHRvbidcbiAgICAgICAgdmFyaWFudD0nb3V0bGluZSdcbiAgICAgICAgc2l6ZT0nc20nXG4gICAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lfVxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfVxuICAgICAgPlxuICAgICAgICA8R2l0aHViIGNsYXNzTmFtZT0naC00IHctNCBtci0yJyAvPlxuICAgICAgICBDb2RlXG4gICAgICA8L0J1dHRvbj5cbiAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT0nYm9yZGVyLWdvbGQvMjAnPlxuICAgICAgICA8RGlhbG9nSGVhZGVyPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmb250LW1vbm8gdGV4dC1bMTBweF0gdHJhY2tpbmctWzAuM2VtXSB0ZXh0LWdvbGQvNzAgbWItMSc+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J3JlbGF0aXZlIGZsZXggaC0xLjUgdy0xLjUnPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2Fic29sdXRlIGlubGluZS1mbGV4IGgtZnVsbCB3LWZ1bGwgcm91bmRlZC1mdWxsIGJnLWdvbGQvNTAgbW90aW9uLXNhZmU6YW5pbWF0ZS1waW5nJyAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J3JlbGF0aXZlIGlubGluZS1mbGV4IGgtMS41IHctMS41IHJvdW5kZWQtZnVsbCBiZy1nb2xkJyAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgV0FZUE9JTlQgwrcgRVhURVJOQUxcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8RGlhbG9nVGl0bGUgY2xhc3NOYW1lPSdmb250LWhlYWRpbmcgdGV4dC14bCc+XG4gICAgICAgICAgICBPcGVuIGZsaWdodCB0byBHaXRIdWI/XG4gICAgICAgICAgPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24gY2xhc3NOYW1lPSdsZWFkaW5nLXJlbGF4ZWQnPlxuICAgICAgICAgICAgWW91JmFwb3M7cmUgbGVhdmluZyB0aGUgY29udHJvbCB0b3dlciBhbmQgaGVhZGluZyB0byB0aGVcbiAgICAgICAgICAgIHtwcm9qZWN0TmFtZSA/IChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICB7JyAnfVxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0ndGV4dC1mb3JlZ3JvdW5kIGZvbnQtbWVkaXVtJz5cbiAgICAgICAgICAgICAgICAgICZxdW90O3twcm9qZWN0TmFtZX0mcXVvdDtcbiAgICAgICAgICAgICAgICA8L3NwYW4+eycgJ31cbiAgICAgICAgICAgICAgICByZXBvc2l0b3J5XG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgJyBleHRlcm5hbCAnXG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgb24gR2l0SHViLiBDb25maXJtIGRlcGFydHVyZT9cbiAgICAgICAgICA8L0RpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICA8L0RpYWxvZ0hlYWRlcj5cbiAgICAgICAgPERpYWxvZ0Zvb3Rlcj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0eXBlPSdidXR0b24nXG4gICAgICAgICAgICB2YXJpYW50PSdvdXRsaW5lJ1xuICAgICAgICAgICAgY2xhc3NOYW1lPSdnbGFzcyB0ZXh0LW1pc3Qtc29mdCdcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oZmFsc2UpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIFN0YXlcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0eXBlPSdidXR0b24nXG4gICAgICAgICAgICBjbGFzc05hbWU9J2JnLW1pc3QgdGV4dC1zdG9ybS1kZWVwIGhvdmVyOmJnLW1pc3QvOTAnXG4gICAgICAgICAgICBvbkNsaWNrPXtkZXBhcnR9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEdpdGh1YiBjbGFzc05hbWU9J2gtNCB3LTQgbXItMicgLz5cbiAgICAgICAgICAgIERlcGFydFxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L0RpYWxvZ0Zvb3Rlcj5cbiAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICA8L0RpYWxvZz5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IENvbmZpcm1Db2RlTGluaztcbiJdLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiR2l0aHViIiwiQnV0dG9uIiwiRGlhbG9nIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0Rlc2NyaXB0aW9uIiwiRGlhbG9nRm9vdGVyIiwiRGlhbG9nSGVhZGVyIiwiRGlhbG9nVGl0bGUiLCJDb25maXJtQ29kZUxpbmsiLCJocmVmIiwicHJvamVjdE5hbWUiLCJjbGFzc05hbWUiLCJvcGVuIiwic2V0T3BlbiIsImRlcGFydCIsIndpbmRvdyIsIm9uT3BlbkNoYW5nZSIsInR5cGUiLCJ2YXJpYW50Iiwic2l6ZSIsIm9uQ2xpY2siLCJkaXYiLCJzcGFuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsUUFBUSxRQUFRLFFBQVE7QUFDeEMsU0FBU0MsTUFBTSxRQUFRLGVBQWU7QUFDdEMsU0FBU0MsTUFBTSxRQUFRLHlCQUF5QjtBQUNoRCxTQUNFQyxNQUFNLEVBQ05DLGFBQWEsRUFDYkMsaUJBQWlCLEVBQ2pCQyxZQUFZLEVBQ1pDLFlBQVksRUFDWkMsV0FBVyxRQUNOLHlCQUF5QjtBQVFoQyxNQUFNQyxrQkFBa0IsQ0FBQyxFQUN2QkMsSUFBSSxFQUNKQyxXQUFXLEVBQ1hDLFNBQVMsRUFDWTs7SUFDckIsTUFBTSxDQUFDQyxNQUFNQyxRQUFRLEdBQUdkLFNBQVM7SUFFakMsTUFBTWUsU0FBUztRQUNiQyxPQUFPSCxJQUFJLENBQUNILE1BQU0sVUFBVTtRQUM1QkksUUFBUTtJQUNWO0lBRUEscUJBQ0UsUUFBQ1g7UUFBT1UsTUFBTUE7UUFBTUksY0FBY0g7OzBCQUNoQyxRQUFDWjtnQkFDQ2dCLE1BQUs7Z0JBQ0xDLFNBQVE7Z0JBQ1JDLE1BQUs7Z0JBQ0xSLFdBQVdBO2dCQUNYUyxTQUFTLElBQU1QLFFBQVE7O2tDQUV2QixRQUFDYjt3QkFBT1csV0FBVTs7Ozs7O29CQUFpQjs7Ozs7OzswQkFHckMsUUFBQ1I7Z0JBQWNRLFdBQVU7O2tDQUN2QixRQUFDTDs7MENBQ0MsUUFBQ2U7Z0NBQUlWLFdBQVU7O2tEQUNiLFFBQUNXO3dDQUFLWCxXQUFVOzswREFDZCxRQUFDVztnREFBS1gsV0FBVTs7Ozs7OzBEQUNoQixRQUFDVztnREFBS1gsV0FBVTs7Ozs7Ozs7Ozs7O29DQUNYOzs7Ozs7OzBDQUdULFFBQUNKO2dDQUFZSSxXQUFVOzBDQUF1Qjs7Ozs7OzBDQUc5QyxRQUFDUDtnQ0FBa0JPLFdBQVU7O29DQUFrQjtvQ0FFNUNELDRCQUNDOzs0Q0FDRzswREFDRCxRQUFDWTtnREFBS1gsV0FBVTs7b0RBQThCO29EQUNyQ0Q7b0RBQVk7Ozs7Ozs7NENBQ2I7NENBQUk7O3VEQUlkO29DQUNBOzs7Ozs7Ozs7Ozs7O2tDQUlOLFFBQUNMOzswQ0FDQyxRQUFDSjtnQ0FDQ2dCLE1BQUs7Z0NBQ0xDLFNBQVE7Z0NBQ1JQLFdBQVU7Z0NBQ1ZTLFNBQVMsSUFBTVAsUUFBUTswQ0FDeEI7Ozs7OzswQ0FHRCxRQUFDWjtnQ0FDQ2dCLE1BQUs7Z0NBQ0xOLFdBQVU7Z0NBQ1ZTLFNBQVNOOztrREFFVCxRQUFDZDt3Q0FBT1csV0FBVTs7Ozs7O29DQUFpQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU8vQztHQXpFTUg7S0FBQUE7QUEyRU4sZUFBZUEsZ0JBQWdCIn0=