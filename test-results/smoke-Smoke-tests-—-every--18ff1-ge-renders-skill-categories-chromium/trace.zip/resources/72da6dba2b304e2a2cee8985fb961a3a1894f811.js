import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/atmosphere/CloudField.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useEffect = __vite__cjsImport2_react["useEffect"]; const useRef = __vite__cjsImport2_react["useRef"];
import { motion, useMotionValue, useScroll, useSpring, useTransform } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { Plane } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
const prefersReducedMotion = ()=>typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const isNarrow = ()=>typeof window !== 'undefined' && window.matchMedia('(max-width: 767px)').matches;
const CloudField = ()=>{
    _s();
    const { scrollYProgress } = useScroll();
    // Parallax clouds — rise gently through the viewport as you descend
    const cloudAY = useTransform(scrollYProgress, [
        0,
        1
    ], [
        0,
        -120
    ]);
    const cloudBY = useTransform(scrollYProgress, [
        0,
        1
    ], [
        0,
        -210
    ]);
    const lightY = useTransform(scrollYProgress, [
        0,
        1
    ], [
        0,
        -50
    ]);
    // Window banking — clouds drift horizontally with the mouse
    const normX = useMotionValue(0.5);
    const bank = useSpring(normX, {
        stiffness: 45,
        damping: 16
    });
    const cloudAOffsetX = useTransform(bank, [
        0,
        1
    ], [
        -10,
        10
    ]);
    const cloudBOffsetX = useTransform(bank, [
        0,
        1
    ], [
        -16,
        16
    ]);
    // Tiny airplane — glides after the pointer, banking toward its heading
    const cursorX = useMotionValue(-100);
    const cursorY = useMotionValue(-100);
    const planeX = useSpring(cursorX, {
        stiffness: 220,
        damping: 30
    });
    const planeY = useSpring(cursorY, {
        stiffness: 220,
        damping: 30
    });
    const heading = useMotionValue(0);
    const headingSpring = useSpring(heading, {
        stiffness: 120,
        damping: 18
    });
    // Wake left behind the plane (extra lag)
    const wake1x = useSpring(cursorX, {
        stiffness: 140,
        damping: 26
    });
    const wake1y = useSpring(cursorY, {
        stiffness: 140,
        damping: 26
    });
    const wake2x = useSpring(cursorX, {
        stiffness: 70,
        damping: 22
    });
    const wake2y = useSpring(cursorY, {
        stiffness: 70,
        damping: 22
    });
    const lastCursor = useRef({
        x: 0,
        y: 0
    });
    useEffect(()=>{
        const onMouseMove = (event)=>{
            const x = event.clientX;
            const y = event.clientY;
            cursorX.set(x);
            cursorY.set(y);
            normX.set(x / window.innerWidth);
            // Bank the plane toward its direction of travel (Plane icon points NE by default → +45°)
            const dx = x - lastCursor.current.x;
            const dy = y - lastCursor.current.y;
            if (Math.abs(dx) + Math.abs(dy) > 1) {
                heading.set(Math.atan2(dy, dx) * (180 / Math.PI) + 45);
            }
            lastCursor.current = {
                x,
                y
            };
        };
        window.addEventListener('mousemove', onMouseMove, {
            passive: true
        });
        return ()=>window.removeEventListener('mousemove', onMouseMove);
    }, [
        cursorX,
        cursorY,
        heading,
        normX
    ]);
    if (prefersReducedMotion() || isNarrow()) return null;
    return /*#__PURE__*/ _jsxDEV("div", {
        "aria-hidden": "true",
        className: "pointer-events-none fixed inset-0 z-[4] overflow-hidden hidden md:block",
        children: [
            /*#__PURE__*/ _jsxDEV(motion.div, {
                style: {
                    y: cloudAY,
                    x: cloudAOffsetX
                },
                className: "absolute inset-0",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "absolute -top-32 right-[-8%] h-[60vh] w-[75vw] motion-safe:animate-cloud-drift",
                        style: {
                            opacity: 0.05,
                            background: 'radial-gradient(circle at 60% 40%, hsl(var(--mist)), transparent 65%)',
                            filter: 'blur(90px)'
                        }
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                        lineNumber: 80,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "absolute top-[10%] left-[-12%] h-[45vh] w-[60vw]",
                        style: {
                            opacity: 0.045,
                            background: 'radial-gradient(circle at 40% 50%, hsl(var(--mist)), transparent 65%)',
                            filter: 'blur(100px)'
                        }
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                        lineNumber: 89,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(motion.div, {
                style: {
                    y: cloudBY,
                    x: cloudBOffsetX
                },
                className: "absolute inset-0",
                children: [
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "absolute left-[-10%] top-[42%] h-[40vh] w-[110vw] motion-safe:animate-cloud-drift",
                        style: {
                            opacity: 0.06,
                            background: 'radial-gradient(circle at 50% 50%, hsl(var(--mist)), transparent 70%)',
                            filter: 'blur(70px)',
                            animationDelay: '5s'
                        }
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                        lineNumber: 105,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "absolute inset-x-[-10%] bottom-[-10%] h-[40vh]",
                        style: {
                            opacity: 0.08,
                            background: 'linear-gradient(180deg, transparent, hsl(var(--mist)))',
                            filter: 'blur(60px)'
                        }
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                        lineNumber: 115,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(motion.div, {
                style: {
                    y: lightY,
                    x: '-50%'
                },
                className: "absolute bottom-[-10%] left-1/2 h-[55vh] w-[75vw]",
                children: /*#__PURE__*/ _jsxDEV("div", {
                    className: "absolute inset-0 motion-safe:animate-sun-breathe",
                    style: {
                        background: 'radial-gradient(ellipse at 50% 100%, hsl(var(--primary) / 0.22), transparent 60%)',
                        filter: 'blur(70px)'
                    }
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                    lineNumber: 131,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                lineNumber: 127,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "hidden md:block",
                children: [
                    /*#__PURE__*/ _jsxDEV(motion.div, {
                        style: {
                            x: planeX,
                            y: planeY,
                            rotate: headingSpring
                        },
                        className: "absolute left-0 top-0",
                        children: /*#__PURE__*/ _jsxDEV("div", {
                            className: "-translate-x-1/2 -translate-y-1/2",
                            children: /*#__PURE__*/ _jsxDEV(Plane, {
                                className: "h-4 w-4 text-gold/70",
                                strokeWidth: 1.75,
                                style: {
                                    filter: 'drop-shadow(0 0 6px hsl(var(--sunlight) / 0.45))'
                                }
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                                lineNumber: 148,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                            lineNumber: 147,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                        lineNumber: 143,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(motion.div, {
                        style: {
                            x: wake1x,
                            y: wake1y
                        },
                        className: "absolute left-0 top-0",
                        children: /*#__PURE__*/ _jsxDEV("div", {
                            className: "h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-mist/20 blur-[2px]"
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                            lineNumber: 161,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                        lineNumber: 157,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(motion.div, {
                        style: {
                            x: wake2x,
                            y: wake2y
                        },
                        className: "absolute left-0 top-0",
                        children: /*#__PURE__*/ _jsxDEV("div", {
                            className: "h-1 w-1 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold/15 blur-[2px]"
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                            lineNumber: 167,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                        lineNumber: 163,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
                lineNumber: 142,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx",
        lineNumber: 71,
        columnNumber: 5
    }, this);
};
_s(CloudField, "mAO6ezvQuzIiQ7vglzuQdSLX8bM=", false, function() {
    return [
        useScroll,
        useTransform,
        useTransform,
        useTransform,
        useMotionValue,
        useSpring,
        useTransform,
        useTransform,
        useMotionValue,
        useMotionValue,
        useSpring,
        useSpring,
        useMotionValue,
        useSpring,
        useSpring,
        useSpring,
        useSpring,
        useSpring
    ];
});
_c = CloudField;
export default CloudField;
var _c;
$RefreshReg$(_c, "CloudField");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/atmosphere/CloudField.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkNsb3VkRmllbGQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7XG4gIG1vdGlvbixcbiAgdXNlTW90aW9uVmFsdWUsXG4gIHVzZVNjcm9sbCxcbiAgdXNlU3ByaW5nLFxuICB1c2VUcmFuc2Zvcm0sXG59IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgUGxhbmUgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5jb25zdCBwcmVmZXJzUmVkdWNlZE1vdGlvbiA9ICgpID0+XG4gIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXG4gIHdpbmRvdy5tYXRjaE1lZGlhKCcocHJlZmVycy1yZWR1Y2VkLW1vdGlvbjogcmVkdWNlKScpLm1hdGNoZXM7XG5cbmNvbnN0IGlzTmFycm93ID0gKCkgPT5cbiAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgd2luZG93Lm1hdGNoTWVkaWEoJyhtYXgtd2lkdGg6IDc2N3B4KScpLm1hdGNoZXM7XG5cbmNvbnN0IENsb3VkRmllbGQgPSAoKSA9PiB7XG4gIGNvbnN0IHsgc2Nyb2xsWVByb2dyZXNzIH0gPSB1c2VTY3JvbGwoKTtcblxuICAvLyBQYXJhbGxheCBjbG91ZHMg4oCUIHJpc2UgZ2VudGx5IHRocm91Z2ggdGhlIHZpZXdwb3J0IGFzIHlvdSBkZXNjZW5kXG4gIGNvbnN0IGNsb3VkQVkgPSB1c2VUcmFuc2Zvcm0oc2Nyb2xsWVByb2dyZXNzLCBbMCwgMV0sIFswLCAtMTIwXSk7XG4gIGNvbnN0IGNsb3VkQlkgPSB1c2VUcmFuc2Zvcm0oc2Nyb2xsWVByb2dyZXNzLCBbMCwgMV0sIFswLCAtMjEwXSk7XG4gIGNvbnN0IGxpZ2h0WSA9IHVzZVRyYW5zZm9ybShzY3JvbGxZUHJvZ3Jlc3MsIFswLCAxXSwgWzAsIC01MF0pO1xuXG4gIC8vIFdpbmRvdyBiYW5raW5nIOKAlCBjbG91ZHMgZHJpZnQgaG9yaXpvbnRhbGx5IHdpdGggdGhlIG1vdXNlXG4gIGNvbnN0IG5vcm1YID0gdXNlTW90aW9uVmFsdWUoMC41KTtcbiAgY29uc3QgYmFuayA9IHVzZVNwcmluZyhub3JtWCwgeyBzdGlmZm5lc3M6IDQ1LCBkYW1waW5nOiAxNiB9KTtcbiAgY29uc3QgY2xvdWRBT2Zmc2V0WCA9IHVzZVRyYW5zZm9ybShiYW5rLCBbMCwgMV0sIFstMTAsIDEwXSk7XG4gIGNvbnN0IGNsb3VkQk9mZnNldFggPSB1c2VUcmFuc2Zvcm0oYmFuaywgWzAsIDFdLCBbLTE2LCAxNl0pO1xuXG4gIC8vIFRpbnkgYWlycGxhbmUg4oCUIGdsaWRlcyBhZnRlciB0aGUgcG9pbnRlciwgYmFua2luZyB0b3dhcmQgaXRzIGhlYWRpbmdcbiAgY29uc3QgY3Vyc29yWCA9IHVzZU1vdGlvblZhbHVlKC0xMDApO1xuICBjb25zdCBjdXJzb3JZID0gdXNlTW90aW9uVmFsdWUoLTEwMCk7XG4gIGNvbnN0IHBsYW5lWCA9IHVzZVNwcmluZyhjdXJzb3JYLCB7IHN0aWZmbmVzczogMjIwLCBkYW1waW5nOiAzMCB9KTtcbiAgY29uc3QgcGxhbmVZID0gdXNlU3ByaW5nKGN1cnNvclksIHsgc3RpZmZuZXNzOiAyMjAsIGRhbXBpbmc6IDMwIH0pO1xuICBjb25zdCBoZWFkaW5nID0gdXNlTW90aW9uVmFsdWUoMCk7XG4gIGNvbnN0IGhlYWRpbmdTcHJpbmcgPSB1c2VTcHJpbmcoaGVhZGluZywgeyBzdGlmZm5lc3M6IDEyMCwgZGFtcGluZzogMTggfSk7XG4gIC8vIFdha2UgbGVmdCBiZWhpbmQgdGhlIHBsYW5lIChleHRyYSBsYWcpXG4gIGNvbnN0IHdha2UxeCA9IHVzZVNwcmluZyhjdXJzb3JYLCB7IHN0aWZmbmVzczogMTQwLCBkYW1waW5nOiAyNiB9KTtcbiAgY29uc3Qgd2FrZTF5ID0gdXNlU3ByaW5nKGN1cnNvclksIHsgc3RpZmZuZXNzOiAxNDAsIGRhbXBpbmc6IDI2IH0pO1xuICBjb25zdCB3YWtlMnggPSB1c2VTcHJpbmcoY3Vyc29yWCwgeyBzdGlmZm5lc3M6IDcwLCBkYW1waW5nOiAyMiB9KTtcbiAgY29uc3Qgd2FrZTJ5ID0gdXNlU3ByaW5nKGN1cnNvclksIHsgc3RpZmZuZXNzOiA3MCwgZGFtcGluZzogMjIgfSk7XG5cbiAgY29uc3QgbGFzdEN1cnNvciA9IHVzZVJlZih7IHg6IDAsIHk6IDAgfSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBvbk1vdXNlTW92ZSA9IChldmVudDogTW91c2VFdmVudCkgPT4ge1xuICAgICAgY29uc3QgeCA9IGV2ZW50LmNsaWVudFg7XG4gICAgICBjb25zdCB5ID0gZXZlbnQuY2xpZW50WTtcbiAgICAgIGN1cnNvclguc2V0KHgpO1xuICAgICAgY3Vyc29yWS5zZXQoeSk7XG4gICAgICBub3JtWC5zZXQoeCAvIHdpbmRvdy5pbm5lcldpZHRoKTtcblxuICAgICAgLy8gQmFuayB0aGUgcGxhbmUgdG93YXJkIGl0cyBkaXJlY3Rpb24gb2YgdHJhdmVsIChQbGFuZSBpY29uIHBvaW50cyBORSBieSBkZWZhdWx0IOKGkiArNDXCsClcbiAgICAgIGNvbnN0IGR4ID0geCAtIGxhc3RDdXJzb3IuY3VycmVudC54O1xuICAgICAgY29uc3QgZHkgPSB5IC0gbGFzdEN1cnNvci5jdXJyZW50Lnk7XG4gICAgICBpZiAoTWF0aC5hYnMoZHgpICsgTWF0aC5hYnMoZHkpID4gMSkge1xuICAgICAgICBoZWFkaW5nLnNldChNYXRoLmF0YW4yKGR5LCBkeCkgKiAoMTgwIC8gTWF0aC5QSSkgKyA0NSk7XG4gICAgICB9XG4gICAgICBsYXN0Q3Vyc29yLmN1cnJlbnQgPSB7IHgsIHkgfTtcbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZW1vdmUnLCBvbk1vdXNlTW92ZSwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2Vtb3ZlJywgb25Nb3VzZU1vdmUpO1xuICB9LCBbY3Vyc29yWCwgY3Vyc29yWSwgaGVhZGluZywgbm9ybVhdKTtcblxuICBpZiAocHJlZmVyc1JlZHVjZWRNb3Rpb24oKSB8fCBpc05hcnJvdygpKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGFyaWEtaGlkZGVuPSd0cnVlJ1xuICAgICAgY2xhc3NOYW1lPSdwb2ludGVyLWV2ZW50cy1ub25lIGZpeGVkIGluc2V0LTAgei1bNF0gb3ZlcmZsb3ctaGlkZGVuIGhpZGRlbiBtZDpibG9jaydcbiAgICA+XG4gICAgICB7LyogRGlzdGFudCBjbG91ZCBzaWxob3VldHRlcyAqL31cbiAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgIHN0eWxlPXt7IHk6IGNsb3VkQVksIHg6IGNsb3VkQU9mZnNldFggfX1cbiAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSBpbnNldC0wJ1xuICAgICAgPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSAtdG9wLTMyIHJpZ2h0LVstOCVdIGgtWzYwdmhdIHctWzc1dnddIG1vdGlvbi1zYWZlOmFuaW1hdGUtY2xvdWQtZHJpZnQnXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuMDUsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOlxuICAgICAgICAgICAgICAncmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCA2MCUgNDAlLCBoc2wodmFyKC0tbWlzdCkpLCB0cmFuc3BhcmVudCA2NSUpJyxcbiAgICAgICAgICAgIGZpbHRlcjogJ2JsdXIoOTBweCknLFxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9J2Fic29sdXRlIHRvcC1bMTAlXSBsZWZ0LVstMTIlXSBoLVs0NXZoXSB3LVs2MHZ3XSdcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgb3BhY2l0eTogMC4wNDUsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOlxuICAgICAgICAgICAgICAncmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCA0MCUgNTAlLCBoc2wodmFyKC0tbWlzdCkpLCB0cmFuc3BhcmVudCA2NSUpJyxcbiAgICAgICAgICAgIGZpbHRlcjogJ2JsdXIoMTAwcHgpJyxcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICB7LyogTWlkZ3JvdW5kIGNsb3VkIGJhbmQgKyBsb3cgbWlzdCAqL31cbiAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgIHN0eWxlPXt7IHk6IGNsb3VkQlksIHg6IGNsb3VkQk9mZnNldFggfX1cbiAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSBpbnNldC0wJ1xuICAgICAgPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSBsZWZ0LVstMTAlXSB0b3AtWzQyJV0gaC1bNDB2aF0gdy1bMTEwdnddIG1vdGlvbi1zYWZlOmFuaW1hdGUtY2xvdWQtZHJpZnQnXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuMDYsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOlxuICAgICAgICAgICAgICAncmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCA1MCUgNTAlLCBoc2wodmFyKC0tbWlzdCkpLCB0cmFuc3BhcmVudCA3MCUpJyxcbiAgICAgICAgICAgIGZpbHRlcjogJ2JsdXIoNzBweCknLFxuICAgICAgICAgICAgYW5pbWF0aW9uRGVsYXk6ICc1cycsXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT0nYWJzb2x1dGUgaW5zZXQteC1bLTEwJV0gYm90dG9tLVstMTAlXSBoLVs0MHZoXSdcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgb3BhY2l0eTogMC4wOCxcbiAgICAgICAgICAgIGJhY2tncm91bmQ6XG4gICAgICAgICAgICAgICdsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCB0cmFuc3BhcmVudCwgaHNsKHZhcigtLW1pc3QpKSknLFxuICAgICAgICAgICAgZmlsdGVyOiAnYmx1cig2MHB4KScsXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgey8qIEdvbGRlbiB2b2x1bWV0cmljIGxpZ2h0ICovfVxuICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgc3R5bGU9e3sgeTogbGlnaHRZLCB4OiAnLTUwJScgfX1cbiAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSBib3R0b20tWy0xMCVdIGxlZnQtMS8yIGgtWzU1dmhdIHctWzc1dnddJ1xuICAgICAgPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSBpbnNldC0wIG1vdGlvbi1zYWZlOmFuaW1hdGUtc3VuLWJyZWF0aGUnXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGJhY2tncm91bmQ6XG4gICAgICAgICAgICAgICdyYWRpYWwtZ3JhZGllbnQoZWxsaXBzZSBhdCA1MCUgMTAwJSwgaHNsKHZhcigtLXByaW1hcnkpIC8gMC4yMiksIHRyYW5zcGFyZW50IDYwJSknLFxuICAgICAgICAgICAgZmlsdGVyOiAnYmx1cig3MHB4KScsXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgey8qIFRpbnkgYWlycGxhbmUgKyB3YWtlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9J2hpZGRlbiBtZDpibG9jayc+XG4gICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgc3R5bGU9e3sgeDogcGxhbmVYLCB5OiBwbGFuZVksIHJvdGF0ZTogaGVhZGluZ1NwcmluZyB9fVxuICAgICAgICAgIGNsYXNzTmFtZT0nYWJzb2x1dGUgbGVmdC0wIHRvcC0wJ1xuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9Jy10cmFuc2xhdGUteC0xLzIgLXRyYW5zbGF0ZS15LTEvMic+XG4gICAgICAgICAgICA8UGxhbmVcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSdoLTQgdy00IHRleHQtZ29sZC83MCdcbiAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezEuNzV9XG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgZmlsdGVyOiAnZHJvcC1zaGFkb3coMCAwIDZweCBoc2wodmFyKC0tc3VubGlnaHQpIC8gMC40NSkpJyxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICBzdHlsZT17eyB4OiB3YWtlMXgsIHk6IHdha2UxeSB9fVxuICAgICAgICAgIGNsYXNzTmFtZT0nYWJzb2x1dGUgbGVmdC0wIHRvcC0wJ1xuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2gtMS41IHctMS41IC10cmFuc2xhdGUteC0xLzIgLXRyYW5zbGF0ZS15LTEvMiByb3VuZGVkLWZ1bGwgYmctbWlzdC8yMCBibHVyLVsycHhdJyAvPlxuICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgc3R5bGU9e3sgeDogd2FrZTJ4LCB5OiB3YWtlMnkgfX1cbiAgICAgICAgICBjbGFzc05hbWU9J2Fic29sdXRlIGxlZnQtMCB0b3AtMCdcbiAgICAgICAgPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdoLTEgdy0xIC10cmFuc2xhdGUteC0xLzIgLXRyYW5zbGF0ZS15LTEvMiByb3VuZGVkLWZ1bGwgYmctZ29sZC8xNSBibHVyLVsycHhdJyAvPlxuICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IENsb3VkRmllbGQ7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJtb3Rpb24iLCJ1c2VNb3Rpb25WYWx1ZSIsInVzZVNjcm9sbCIsInVzZVNwcmluZyIsInVzZVRyYW5zZm9ybSIsIlBsYW5lIiwicHJlZmVyc1JlZHVjZWRNb3Rpb24iLCJ3aW5kb3ciLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsImlzTmFycm93IiwiQ2xvdWRGaWVsZCIsInNjcm9sbFlQcm9ncmVzcyIsImNsb3VkQVkiLCJjbG91ZEJZIiwibGlnaHRZIiwibm9ybVgiLCJiYW5rIiwic3RpZmZuZXNzIiwiZGFtcGluZyIsImNsb3VkQU9mZnNldFgiLCJjbG91ZEJPZmZzZXRYIiwiY3Vyc29yWCIsImN1cnNvclkiLCJwbGFuZVgiLCJwbGFuZVkiLCJoZWFkaW5nIiwiaGVhZGluZ1NwcmluZyIsIndha2UxeCIsIndha2UxeSIsIndha2UyeCIsIndha2UyeSIsImxhc3RDdXJzb3IiLCJ4IiwieSIsIm9uTW91c2VNb3ZlIiwiZXZlbnQiLCJjbGllbnRYIiwiY2xpZW50WSIsInNldCIsImlubmVyV2lkdGgiLCJkeCIsImN1cnJlbnQiLCJkeSIsIk1hdGgiLCJhYnMiLCJhdGFuMiIsIlBJIiwiYWRkRXZlbnRMaXN0ZW5lciIsInBhc3NpdmUiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiZGl2IiwiYXJpYS1oaWRkZW4iLCJjbGFzc05hbWUiLCJzdHlsZSIsIm9wYWNpdHkiLCJiYWNrZ3JvdW5kIiwiZmlsdGVyIiwiYW5pbWF0aW9uRGVsYXkiLCJyb3RhdGUiLCJzdHJva2VXaWR0aCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFNBQVMsRUFBRUMsTUFBTSxRQUFRLFFBQVE7QUFDakQsU0FDRUMsTUFBTSxFQUNOQyxjQUFjLEVBQ2RDLFNBQVMsRUFDVEMsU0FBUyxFQUNUQyxZQUFZLFFBQ1AsZ0JBQWdCO0FBQ3ZCLFNBQVNDLEtBQUssUUFBUSxlQUFlO0FBRXJDLE1BQU1DLHVCQUF1QixJQUMzQixPQUFPQyxXQUFXLGVBQ2xCQSxPQUFPQyxVQUFVLENBQUMsb0NBQW9DQyxPQUFPO0FBRS9ELE1BQU1DLFdBQVcsSUFDZixPQUFPSCxXQUFXLGVBQ2xCQSxPQUFPQyxVQUFVLENBQUMsc0JBQXNCQyxPQUFPO0FBRWpELE1BQU1FLGFBQWE7O0lBQ2pCLE1BQU0sRUFBRUMsZUFBZSxFQUFFLEdBQUdWO0lBRTVCLG9FQUFvRTtJQUNwRSxNQUFNVyxVQUFVVCxhQUFhUSxpQkFBaUI7UUFBQztRQUFHO0tBQUUsRUFBRTtRQUFDO1FBQUcsQ0FBQztLQUFJO0lBQy9ELE1BQU1FLFVBQVVWLGFBQWFRLGlCQUFpQjtRQUFDO1FBQUc7S0FBRSxFQUFFO1FBQUM7UUFBRyxDQUFDO0tBQUk7SUFDL0QsTUFBTUcsU0FBU1gsYUFBYVEsaUJBQWlCO1FBQUM7UUFBRztLQUFFLEVBQUU7UUFBQztRQUFHLENBQUM7S0FBRztJQUU3RCw0REFBNEQ7SUFDNUQsTUFBTUksUUFBUWYsZUFBZTtJQUM3QixNQUFNZ0IsT0FBT2QsVUFBVWEsT0FBTztRQUFFRSxXQUFXO1FBQUlDLFNBQVM7SUFBRztJQUMzRCxNQUFNQyxnQkFBZ0JoQixhQUFhYSxNQUFNO1FBQUM7UUFBRztLQUFFLEVBQUU7UUFBQyxDQUFDO1FBQUk7S0FBRztJQUMxRCxNQUFNSSxnQkFBZ0JqQixhQUFhYSxNQUFNO1FBQUM7UUFBRztLQUFFLEVBQUU7UUFBQyxDQUFDO1FBQUk7S0FBRztJQUUxRCx1RUFBdUU7SUFDdkUsTUFBTUssVUFBVXJCLGVBQWUsQ0FBQztJQUNoQyxNQUFNc0IsVUFBVXRCLGVBQWUsQ0FBQztJQUNoQyxNQUFNdUIsU0FBU3JCLFVBQVVtQixTQUFTO1FBQUVKLFdBQVc7UUFBS0MsU0FBUztJQUFHO0lBQ2hFLE1BQU1NLFNBQVN0QixVQUFVb0IsU0FBUztRQUFFTCxXQUFXO1FBQUtDLFNBQVM7SUFBRztJQUNoRSxNQUFNTyxVQUFVekIsZUFBZTtJQUMvQixNQUFNMEIsZ0JBQWdCeEIsVUFBVXVCLFNBQVM7UUFBRVIsV0FBVztRQUFLQyxTQUFTO0lBQUc7SUFDdkUseUNBQXlDO0lBQ3pDLE1BQU1TLFNBQVN6QixVQUFVbUIsU0FBUztRQUFFSixXQUFXO1FBQUtDLFNBQVM7SUFBRztJQUNoRSxNQUFNVSxTQUFTMUIsVUFBVW9CLFNBQVM7UUFBRUwsV0FBVztRQUFLQyxTQUFTO0lBQUc7SUFDaEUsTUFBTVcsU0FBUzNCLFVBQVVtQixTQUFTO1FBQUVKLFdBQVc7UUFBSUMsU0FBUztJQUFHO0lBQy9ELE1BQU1ZLFNBQVM1QixVQUFVb0IsU0FBUztRQUFFTCxXQUFXO1FBQUlDLFNBQVM7SUFBRztJQUUvRCxNQUFNYSxhQUFhakMsT0FBTztRQUFFa0MsR0FBRztRQUFHQyxHQUFHO0lBQUU7SUFFdkNwQyxVQUFVO1FBQ1IsTUFBTXFDLGNBQWMsQ0FBQ0M7WUFDbkIsTUFBTUgsSUFBSUcsTUFBTUMsT0FBTztZQUN2QixNQUFNSCxJQUFJRSxNQUFNRSxPQUFPO1lBQ3ZCaEIsUUFBUWlCLEdBQUcsQ0FBQ047WUFDWlYsUUFBUWdCLEdBQUcsQ0FBQ0w7WUFDWmxCLE1BQU11QixHQUFHLENBQUNOLElBQUkxQixPQUFPaUMsVUFBVTtZQUUvQix5RkFBeUY7WUFDekYsTUFBTUMsS0FBS1IsSUFBSUQsV0FBV1UsT0FBTyxDQUFDVCxDQUFDO1lBQ25DLE1BQU1VLEtBQUtULElBQUlGLFdBQVdVLE9BQU8sQ0FBQ1IsQ0FBQztZQUNuQyxJQUFJVSxLQUFLQyxHQUFHLENBQUNKLE1BQU1HLEtBQUtDLEdBQUcsQ0FBQ0YsTUFBTSxHQUFHO2dCQUNuQ2pCLFFBQVFhLEdBQUcsQ0FBQ0ssS0FBS0UsS0FBSyxDQUFDSCxJQUFJRixNQUFPLENBQUEsTUFBTUcsS0FBS0csRUFBRSxBQUFELElBQUs7WUFDckQ7WUFDQWYsV0FBV1UsT0FBTyxHQUFHO2dCQUFFVDtnQkFBR0M7WUFBRTtRQUM5QjtRQUNBM0IsT0FBT3lDLGdCQUFnQixDQUFDLGFBQWFiLGFBQWE7WUFBRWMsU0FBUztRQUFLO1FBQ2xFLE9BQU8sSUFBTTFDLE9BQU8yQyxtQkFBbUIsQ0FBQyxhQUFhZjtJQUN2RCxHQUFHO1FBQUNiO1FBQVNDO1FBQVNHO1FBQVNWO0tBQU07SUFFckMsSUFBSVYsMEJBQTBCSSxZQUFZLE9BQU87SUFFakQscUJBQ0UsUUFBQ3lDO1FBQ0NDLGVBQVk7UUFDWkMsV0FBVTs7MEJBR1YsUUFBQ3JELE9BQU9tRCxHQUFHO2dCQUNURyxPQUFPO29CQUFFcEIsR0FBR3JCO29CQUFTb0IsR0FBR2I7Z0JBQWM7Z0JBQ3RDaUMsV0FBVTs7a0NBRVYsUUFBQ0Y7d0JBQ0NFLFdBQVU7d0JBQ1ZDLE9BQU87NEJBQ0xDLFNBQVM7NEJBQ1RDLFlBQ0U7NEJBQ0ZDLFFBQVE7d0JBQ1Y7Ozs7OztrQ0FFRixRQUFDTjt3QkFDQ0UsV0FBVTt3QkFDVkMsT0FBTzs0QkFDTEMsU0FBUzs0QkFDVEMsWUFDRTs0QkFDRkMsUUFBUTt3QkFDVjs7Ozs7Ozs7Ozs7OzBCQUtKLFFBQUN6RCxPQUFPbUQsR0FBRztnQkFDVEcsT0FBTztvQkFBRXBCLEdBQUdwQjtvQkFBU21CLEdBQUdaO2dCQUFjO2dCQUN0Q2dDLFdBQVU7O2tDQUVWLFFBQUNGO3dCQUNDRSxXQUFVO3dCQUNWQyxPQUFPOzRCQUNMQyxTQUFTOzRCQUNUQyxZQUNFOzRCQUNGQyxRQUFROzRCQUNSQyxnQkFBZ0I7d0JBQ2xCOzs7Ozs7a0NBRUYsUUFBQ1A7d0JBQ0NFLFdBQVU7d0JBQ1ZDLE9BQU87NEJBQ0xDLFNBQVM7NEJBQ1RDLFlBQ0U7NEJBQ0ZDLFFBQVE7d0JBQ1Y7Ozs7Ozs7Ozs7OzswQkFLSixRQUFDekQsT0FBT21ELEdBQUc7Z0JBQ1RHLE9BQU87b0JBQUVwQixHQUFHbkI7b0JBQVFrQixHQUFHO2dCQUFPO2dCQUM5Qm9CLFdBQVU7MEJBRVYsY0FBQSxRQUFDRjtvQkFDQ0UsV0FBVTtvQkFDVkMsT0FBTzt3QkFDTEUsWUFDRTt3QkFDRkMsUUFBUTtvQkFDVjs7Ozs7Ozs7Ozs7MEJBS0osUUFBQ047Z0JBQUlFLFdBQVU7O2tDQUNiLFFBQUNyRCxPQUFPbUQsR0FBRzt3QkFDVEcsT0FBTzs0QkFBRXJCLEdBQUdUOzRCQUFRVSxHQUFHVDs0QkFBUWtDLFFBQVFoQzt3QkFBYzt3QkFDckQwQixXQUFVO2tDQUVWLGNBQUEsUUFBQ0Y7NEJBQUlFLFdBQVU7c0NBQ2IsY0FBQSxRQUFDaEQ7Z0NBQ0NnRCxXQUFVO2dDQUNWTyxhQUFhO2dDQUNiTixPQUFPO29DQUNMRyxRQUFRO2dDQUNWOzs7Ozs7Ozs7Ozs7Ozs7O2tDQUlOLFFBQUN6RCxPQUFPbUQsR0FBRzt3QkFDVEcsT0FBTzs0QkFBRXJCLEdBQUdMOzRCQUFRTSxHQUFHTDt3QkFBTzt3QkFDOUJ3QixXQUFVO2tDQUVWLGNBQUEsUUFBQ0Y7NEJBQUlFLFdBQVU7Ozs7Ozs7Ozs7O2tDQUVqQixRQUFDckQsT0FBT21ELEdBQUc7d0JBQ1RHLE9BQU87NEJBQUVyQixHQUFHSDs0QkFBUUksR0FBR0g7d0JBQU87d0JBQzlCc0IsV0FBVTtrQ0FFVixjQUFBLFFBQUNGOzRCQUFJRSxXQUFVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUt6QjtHQXpKTTFDOztRQUN3QlQ7UUFHWkU7UUFDQUE7UUFDREE7UUFHREg7UUFDREU7UUFDU0M7UUFDQUE7UUFHTkg7UUFDQUE7UUFDREU7UUFDQUE7UUFDQ0Y7UUFDTUU7UUFFUEE7UUFDQUE7UUFDQUE7UUFDQUE7OztLQXpCWFE7QUEySk4sZUFBZUEsV0FBVyJ9