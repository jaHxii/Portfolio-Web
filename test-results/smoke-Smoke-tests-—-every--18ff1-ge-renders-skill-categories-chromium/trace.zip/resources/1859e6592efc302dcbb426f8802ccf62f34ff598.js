import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/DemoGallery.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useEffect = __vite__cjsImport2_react["useEffect"]; const useRef = __vite__cjsImport2_react["useRef"]; const useState = __vite__cjsImport2_react["useState"];
import { ChevronLeft, ChevronRight, Maximize, Minimize, RotateCcw, ZoomIn, ZoomOut } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "/src/components/ui/dialog.tsx";
import { cn } from "/src/lib/utils.ts";
const MIN_SCALE = 1;
const MAX_SCALE = 5;
const ZOOM_STEP = 1.4;
const DemoGallery = ({ open, onOpenChange, title, images })=>{
    _s();
    const [index, setIndex] = useState(0);
    const [scale, setScale] = useState(MIN_SCALE);
    const [translate, setTranslate] = useState({
        x: 0,
        y: 0
    });
    const [isDragging, setIsDragging] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const containerRef = useRef(null);
    const dragStart = useRef({
        x: 0,
        y: 0,
        tx: 0,
        ty: 0
    });
    useEffect(()=>{
        const onChange = ()=>setIsFullscreen(Boolean(document.fullscreenElement));
        document.addEventListener('fullscreenchange', onChange);
        return ()=>document.removeEventListener('fullscreenchange', onChange);
    }, []);
    const toggleFullscreen = ()=>{
        if (document.fullscreenElement) {
            void document.exitFullscreen();
        } else {
            containerRef.current?.requestFullscreen().catch(()=>{});
        }
    };
    useEffect(()=>{
        if (open) {
            setIndex(0);
            setScale(MIN_SCALE);
            setTranslate({
                x: 0,
                y: 0
            });
        }
    }, [
        open
    ]);
    useEffect(()=>{
        setScale(MIN_SCALE);
        setTranslate({
            x: 0,
            y: 0
        });
    }, [
        index
    ]);
    const current = images[index] ?? images[0];
    const go = (dir)=>{
        if (images.length === 0) return;
        setIndex((prev)=>(prev + dir + images.length) % images.length);
    };
    const select = (i)=>setIndex(i);
    const zoomIn = ()=>setScale((s)=>Math.min(MAX_SCALE, +(s * ZOOM_STEP).toFixed(3)));
    const zoomOut = ()=>setScale((s)=>{
            const next = Math.max(MIN_SCALE, +(s / ZOOM_STEP).toFixed(3));
            if (next === MIN_SCALE) setTranslate({
                x: 0,
                y: 0
            });
            return next;
        });
    const resetZoom = ()=>{
        setScale(MIN_SCALE);
        setTranslate({
            x: 0,
            y: 0
        });
    };
    const toggleZoom = ()=>{
        if (scale > MIN_SCALE) resetZoom();
        else setScale(2);
    };
    const onWheel = (e)=>{
        e.preventDefault();
        if (e.deltaY < 0) zoomIn();
        else zoomOut();
    };
    const onPointerDown = (e)=>{
        if (scale <= MIN_SCALE) return;
        setIsDragging(true);
        dragStart.current = {
            x: e.clientX,
            y: e.clientY,
            tx: translate.x,
            ty: translate.y
        };
        e.currentTarget.setPointerCapture(e.pointerId);
    };
    const onPointerMove = (e)=>{
        if (!isDragging) return;
        const { x, y, tx, ty } = dragStart.current;
        setTranslate({
            x: tx + (e.clientX - x),
            y: ty + (e.clientY - y)
        });
    };
    const onPointerUp = ()=>setIsDragging(false);
    return /*#__PURE__*/ _jsxDEV(Dialog, {
        open: open,
        onOpenChange: onOpenChange,
        children: /*#__PURE__*/ _jsxDEV(DialogContent, {
            className: "max-w-4xl p-4 sm:p-6",
            children: [
                /*#__PURE__*/ _jsxDEV(DialogHeader, {
                    children: [
                        /*#__PURE__*/ _jsxDEV(DialogTitle, {
                            children: [
                                title,
                                " - Screenshots"
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                            lineNumber: 131,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(DialogDescription, {
                            children: [
                                index + 1,
                                " of ",
                                images.length,
                                " · Scroll to zoom, drag to pan, or view fullscreen"
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                            lineNumber: 132,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                    lineNumber: 130,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("div", {
                    ref: containerRef,
                    className: "relative rounded-lg overflow-hidden bg-background border border-border select-none",
                    style: {
                        touchAction: 'none'
                    },
                    onWheel: onWheel,
                    onDoubleClick: toggleZoom,
                    onPointerDown: onPointerDown,
                    onPointerMove: onPointerMove,
                    onPointerUp: onPointerUp,
                    onPointerCancel: onPointerUp,
                    children: [
                        current ? /*#__PURE__*/ _jsxDEV("div", {
                            className: "w-full h-64 sm:h-[28rem] flex items-center justify-center overflow-hidden cursor-zoom-in",
                            children: /*#__PURE__*/ _jsxDEV("img", {
                                src: current,
                                alt: `${title} screenshot ${index + 1}`,
                                draggable: false,
                                className: cn('max-w-full max-h-full object-contain', isDragging ? '' : 'transition-transform duration-200 ease-out'),
                                style: {
                                    transform: `translate(${translate.x}px, ${translate.y}px) scale(${scale})`
                                }
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                lineNumber: 151,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                            lineNumber: 150,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ _jsxDEV("div", {
                            className: "w-full h-64 sm:h-[28rem] flex items-center justify-center text-muted-foreground",
                            children: "No screenshots available."
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                            lineNumber: 165,
                            columnNumber: 13
                        }, this),
                        images.length > 1 && /*#__PURE__*/ _jsxDEV(_Fragment, {
                            children: [
                                /*#__PURE__*/ _jsxDEV("button", {
                                    onClick: ()=>go(-1),
                                    "aria-label": "Previous screenshot",
                                    className: "absolute left-2 top-1/2 -translate-y-1/2 p-2 glass rounded-full hover:shadow-glow transition-all",
                                    children: /*#__PURE__*/ _jsxDEV(ChevronLeft, {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                        lineNumber: 177,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                    lineNumber: 172,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV("button", {
                                    onClick: ()=>go(1),
                                    "aria-label": "Next screenshot",
                                    className: "absolute right-2 top-1/2 -translate-y-1/2 p-2 glass rounded-full hover:shadow-glow transition-all",
                                    children: /*#__PURE__*/ _jsxDEV(ChevronRight, {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                        lineNumber: 184,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                    lineNumber: 179,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "absolute bottom-3 right-3 flex items-center gap-1",
                            children: [
                                /*#__PURE__*/ _jsxDEV("button", {
                                    onClick: toggleFullscreen,
                                    "aria-label": isFullscreen ? 'Exit fullscreen' : 'View fullscreen',
                                    className: "p-2 glass rounded-full hover:shadow-glow transition-all",
                                    children: isFullscreen ? /*#__PURE__*/ _jsxDEV(Minimize, {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                        lineNumber: 196,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ _jsxDEV(Maximize, {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                        lineNumber: 198,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                    lineNumber: 190,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("button", {
                                    onClick: zoomOut,
                                    "aria-label": "Zoom out",
                                    className: "p-2 glass rounded-full hover:shadow-glow transition-all",
                                    children: /*#__PURE__*/ _jsxDEV(ZoomOut, {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                        lineNumber: 206,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                    lineNumber: 201,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("button", {
                                    onClick: zoomIn,
                                    "aria-label": "Zoom in",
                                    className: "p-2 glass rounded-full hover:shadow-glow transition-all",
                                    children: /*#__PURE__*/ _jsxDEV(ZoomIn, {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                        lineNumber: 213,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                    lineNumber: 208,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("button", {
                                    onClick: resetZoom,
                                    "aria-label": "Reset zoom",
                                    className: "p-2 glass rounded-full hover:shadow-glow transition-all",
                                    children: /*#__PURE__*/ _jsxDEV(RotateCcw, {
                                        className: "h-4 w-4"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                        lineNumber: 220,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                    lineNumber: 215,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                            lineNumber: 189,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                    lineNumber: 138,
                    columnNumber: 9
                }, this),
                images.length > 1 && /*#__PURE__*/ _jsxDEV("div", {
                    className: "flex gap-2 overflow-x-auto pb-1",
                    children: images.map((src, i)=>/*#__PURE__*/ _jsxDEV("button", {
                            onClick: ()=>select(i),
                            "aria-label": `Go to screenshot ${i + 1}`,
                            className: cn('relative flex-none w-20 h-12 rounded-md overflow-hidden border-2 transition-colors', i === index ? 'border-primary' : 'border-border hover:border-primary/50'),
                            children: /*#__PURE__*/ _jsxDEV("img", {
                                src: src,
                                alt: "",
                                className: "w-full h-full object-cover"
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                                lineNumber: 239,
                                columnNumber: 17
                            }, this)
                        }, src, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                            lineNumber: 228,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
                    lineNumber: 226,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
            lineNumber: 129,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx",
        lineNumber: 128,
        columnNumber: 5
    }, this);
};
_s(DemoGallery, "wz8Gh9ijkX3vJqlAAwhLVNvlPnk=");
_c = DemoGallery;
export default DemoGallery;
var _c;
$RefreshReg$(_c, "DemoGallery");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/sections/DemoGallery.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkRlbW9HYWxsZXJ5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgQ2hldnJvbkxlZnQsXG4gIENoZXZyb25SaWdodCxcbiAgTWF4aW1pemUsXG4gIE1pbmltaXplLFxuICBSb3RhdGVDY3csXG4gIFpvb21JbixcbiAgWm9vbU91dCxcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7XG4gIERpYWxvZyxcbiAgRGlhbG9nQ29udGVudCxcbiAgRGlhbG9nRGVzY3JpcHRpb24sXG4gIERpYWxvZ0hlYWRlcixcbiAgRGlhbG9nVGl0bGUsXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS9kaWFsb2cnO1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscyc7XG5cbmludGVyZmFjZSBEZW1vR2FsbGVyeVByb3BzIHtcbiAgb3BlbjogYm9vbGVhbjtcbiAgb25PcGVuQ2hhbmdlOiAob3BlbjogYm9vbGVhbikgPT4gdm9pZDtcbiAgdGl0bGU6IHN0cmluZztcbiAgaW1hZ2VzOiBzdHJpbmdbXTtcbn1cblxuY29uc3QgTUlOX1NDQUxFID0gMTtcbmNvbnN0IE1BWF9TQ0FMRSA9IDU7XG5jb25zdCBaT09NX1NURVAgPSAxLjQ7XG5cbmNvbnN0IERlbW9HYWxsZXJ5ID0gKHtcbiAgb3BlbixcbiAgb25PcGVuQ2hhbmdlLFxuICB0aXRsZSxcbiAgaW1hZ2VzLFxufTogRGVtb0dhbGxlcnlQcm9wcykgPT4ge1xuICBjb25zdCBbaW5kZXgsIHNldEluZGV4XSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbc2NhbGUsIHNldFNjYWxlXSA9IHVzZVN0YXRlKE1JTl9TQ0FMRSk7XG4gIGNvbnN0IFt0cmFuc2xhdGUsIHNldFRyYW5zbGF0ZV0gPSB1c2VTdGF0ZSh7IHg6IDAsIHk6IDAgfSk7XG4gIGNvbnN0IFtpc0RyYWdnaW5nLCBzZXRJc0RyYWdnaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzRnVsbHNjcmVlbiwgc2V0SXNGdWxsc2NyZWVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgY29udGFpbmVyUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgY29uc3QgZHJhZ1N0YXJ0ID0gdXNlUmVmKHsgeDogMCwgeTogMCwgdHg6IDAsIHR5OiAwIH0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgb25DaGFuZ2UgPSAoKSA9PiBzZXRJc0Z1bGxzY3JlZW4oQm9vbGVhbihkb2N1bWVudC5mdWxsc2NyZWVuRWxlbWVudCkpO1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2Z1bGxzY3JlZW5jaGFuZ2UnLCBvbkNoYW5nZSk7XG4gICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2Z1bGxzY3JlZW5jaGFuZ2UnLCBvbkNoYW5nZSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCB0b2dnbGVGdWxsc2NyZWVuID0gKCkgPT4ge1xuICAgIGlmIChkb2N1bWVudC5mdWxsc2NyZWVuRWxlbWVudCkge1xuICAgICAgdm9pZCBkb2N1bWVudC5leGl0RnVsbHNjcmVlbigpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb250YWluZXJSZWYuY3VycmVudD8ucmVxdWVzdEZ1bGxzY3JlZW4oKS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgfVxuICB9O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKG9wZW4pIHtcbiAgICAgIHNldEluZGV4KDApO1xuICAgICAgc2V0U2NhbGUoTUlOX1NDQUxFKTtcbiAgICAgIHNldFRyYW5zbGF0ZSh7IHg6IDAsIHk6IDAgfSk7XG4gICAgfVxuICB9LCBbb3Blbl0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0U2NhbGUoTUlOX1NDQUxFKTtcbiAgICBzZXRUcmFuc2xhdGUoeyB4OiAwLCB5OiAwIH0pO1xuICB9LCBbaW5kZXhdKTtcblxuICBjb25zdCBjdXJyZW50ID0gaW1hZ2VzW2luZGV4XSA/PyBpbWFnZXNbMF07XG5cbiAgY29uc3QgZ28gPSAoZGlyOiBudW1iZXIpID0+IHtcbiAgICBpZiAoaW1hZ2VzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAgIHNldEluZGV4KHByZXYgPT4gKHByZXYgKyBkaXIgKyBpbWFnZXMubGVuZ3RoKSAlIGltYWdlcy5sZW5ndGgpO1xuICB9O1xuXG4gIGNvbnN0IHNlbGVjdCA9IChpOiBudW1iZXIpID0+IHNldEluZGV4KGkpO1xuXG4gIGNvbnN0IHpvb21JbiA9ICgpID0+XG4gICAgc2V0U2NhbGUocyA9PiBNYXRoLm1pbihNQVhfU0NBTEUsICsocyAqIFpPT01fU1RFUCkudG9GaXhlZCgzKSkpO1xuXG4gIGNvbnN0IHpvb21PdXQgPSAoKSA9PlxuICAgIHNldFNjYWxlKHMgPT4ge1xuICAgICAgY29uc3QgbmV4dCA9IE1hdGgubWF4KE1JTl9TQ0FMRSwgKyhzIC8gWk9PTV9TVEVQKS50b0ZpeGVkKDMpKTtcbiAgICAgIGlmIChuZXh0ID09PSBNSU5fU0NBTEUpIHNldFRyYW5zbGF0ZSh7IHg6IDAsIHk6IDAgfSk7XG4gICAgICByZXR1cm4gbmV4dDtcbiAgICB9KTtcblxuICBjb25zdCByZXNldFpvb20gPSAoKSA9PiB7XG4gICAgc2V0U2NhbGUoTUlOX1NDQUxFKTtcbiAgICBzZXRUcmFuc2xhdGUoeyB4OiAwLCB5OiAwIH0pO1xuICB9O1xuXG4gIGNvbnN0IHRvZ2dsZVpvb20gPSAoKSA9PiB7XG4gICAgaWYgKHNjYWxlID4gTUlOX1NDQUxFKSByZXNldFpvb20oKTtcbiAgICBlbHNlIHNldFNjYWxlKDIpO1xuICB9O1xuXG4gIGNvbnN0IG9uV2hlZWwgPSAoZTogUmVhY3QuV2hlZWxFdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoZS5kZWx0YVkgPCAwKSB6b29tSW4oKTtcbiAgICBlbHNlIHpvb21PdXQoKTtcbiAgfTtcblxuICBjb25zdCBvblBvaW50ZXJEb3duID0gKGU6IFJlYWN0LlBvaW50ZXJFdmVudDxIVE1MRGl2RWxlbWVudD4pID0+IHtcbiAgICBpZiAoc2NhbGUgPD0gTUlOX1NDQUxFKSByZXR1cm47XG4gICAgc2V0SXNEcmFnZ2luZyh0cnVlKTtcbiAgICBkcmFnU3RhcnQuY3VycmVudCA9IHtcbiAgICAgIHg6IGUuY2xpZW50WCxcbiAgICAgIHk6IGUuY2xpZW50WSxcbiAgICAgIHR4OiB0cmFuc2xhdGUueCxcbiAgICAgIHR5OiB0cmFuc2xhdGUueSxcbiAgICB9O1xuICAgIGUuY3VycmVudFRhcmdldC5zZXRQb2ludGVyQ2FwdHVyZShlLnBvaW50ZXJJZCk7XG4gIH07XG5cbiAgY29uc3Qgb25Qb2ludGVyTW92ZSA9IChlOiBSZWFjdC5Qb2ludGVyRXZlbnQ8SFRNTERpdkVsZW1lbnQ+KSA9PiB7XG4gICAgaWYgKCFpc0RyYWdnaW5nKSByZXR1cm47XG4gICAgY29uc3QgeyB4LCB5LCB0eCwgdHkgfSA9IGRyYWdTdGFydC5jdXJyZW50O1xuICAgIHNldFRyYW5zbGF0ZSh7IHg6IHR4ICsgKGUuY2xpZW50WCAtIHgpLCB5OiB0eSArIChlLmNsaWVudFkgLSB5KSB9KTtcbiAgfTtcblxuICBjb25zdCBvblBvaW50ZXJVcCA9ICgpID0+IHNldElzRHJhZ2dpbmcoZmFsc2UpO1xuXG4gIHJldHVybiAoXG4gICAgPERpYWxvZyBvcGVuPXtvcGVufSBvbk9wZW5DaGFuZ2U9e29uT3BlbkNoYW5nZX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9J21heC13LTR4bCBwLTQgc206cC02Jz5cbiAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICA8RGlhbG9nVGl0bGU+e3RpdGxlfSAtIFNjcmVlbnNob3RzPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgICB7aW5kZXggKyAxfSBvZiB7aW1hZ2VzLmxlbmd0aH0gwrcgU2Nyb2xsIHRvIHpvb20sIGRyYWcgdG8gcGFuLCBvclxuICAgICAgICAgICAgdmlldyBmdWxsc2NyZWVuXG4gICAgICAgICAgPC9EaWFsb2dEZXNjcmlwdGlvbj5cbiAgICAgICAgPC9EaWFsb2dIZWFkZXI+XG5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIHJlZj17Y29udGFpbmVyUmVmfVxuICAgICAgICAgIGNsYXNzTmFtZT0ncmVsYXRpdmUgcm91bmRlZC1sZyBvdmVyZmxvdy1oaWRkZW4gYmctYmFja2dyb3VuZCBib3JkZXIgYm9yZGVyLWJvcmRlciBzZWxlY3Qtbm9uZSdcbiAgICAgICAgICBzdHlsZT17eyB0b3VjaEFjdGlvbjogJ25vbmUnIH19XG4gICAgICAgICAgb25XaGVlbD17b25XaGVlbH1cbiAgICAgICAgICBvbkRvdWJsZUNsaWNrPXt0b2dnbGVab29tfVxuICAgICAgICAgIG9uUG9pbnRlckRvd249e29uUG9pbnRlckRvd259XG4gICAgICAgICAgb25Qb2ludGVyTW92ZT17b25Qb2ludGVyTW92ZX1cbiAgICAgICAgICBvblBvaW50ZXJVcD17b25Qb2ludGVyVXB9XG4gICAgICAgICAgb25Qb2ludGVyQ2FuY2VsPXtvblBvaW50ZXJVcH1cbiAgICAgICAgPlxuICAgICAgICAgIHtjdXJyZW50ID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3ctZnVsbCBoLTY0IHNtOmgtWzI4cmVtXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gY3Vyc29yLXpvb20taW4nPlxuICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgc3JjPXtjdXJyZW50fVxuICAgICAgICAgICAgICAgIGFsdD17YCR7dGl0bGV9IHNjcmVlbnNob3QgJHtpbmRleCArIDF9YH1cbiAgICAgICAgICAgICAgICBkcmFnZ2FibGU9e2ZhbHNlfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAnbWF4LXctZnVsbCBtYXgtaC1mdWxsIG9iamVjdC1jb250YWluJyxcbiAgICAgICAgICAgICAgICAgIGlzRHJhZ2dpbmcgPyAnJyA6ICd0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDAgZWFzZS1vdXQnXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiBgdHJhbnNsYXRlKCR7dHJhbnNsYXRlLnh9cHgsICR7dHJhbnNsYXRlLnl9cHgpIHNjYWxlKCR7c2NhbGV9KWAsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ndy1mdWxsIGgtNjQgc206aC1bMjhyZW1dIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCc+XG4gICAgICAgICAgICAgIE5vIHNjcmVlbnNob3RzIGF2YWlsYWJsZS5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7aW1hZ2VzLmxlbmd0aCA+IDEgJiYgKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGdvKC0xKX1cbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPSdQcmV2aW91cyBzY3JlZW5zaG90J1xuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nYWJzb2x1dGUgbGVmdC0yIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBwLTIgZ2xhc3Mgcm91bmRlZC1mdWxsIGhvdmVyOnNoYWRvdy1nbG93IHRyYW5zaXRpb24tYWxsJ1xuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENoZXZyb25MZWZ0IGNsYXNzTmFtZT0naC00IHctNCcgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBnbygxKX1cbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPSdOZXh0IHNjcmVlbnNob3QnXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSByaWdodC0yIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBwLTIgZ2xhc3Mgcm91bmRlZC1mdWxsIGhvdmVyOnNoYWRvdy1nbG93IHRyYW5zaXRpb24tYWxsJ1xuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9J2gtNCB3LTQnIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdhYnNvbHV0ZSBib3R0b20tMyByaWdodC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xJz5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlRnVsbHNjcmVlbn1cbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17aXNGdWxsc2NyZWVuID8gJ0V4aXQgZnVsbHNjcmVlbicgOiAnVmlldyBmdWxsc2NyZWVuJ31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSdwLTIgZ2xhc3Mgcm91bmRlZC1mdWxsIGhvdmVyOnNoYWRvdy1nbG93IHRyYW5zaXRpb24tYWxsJ1xuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7aXNGdWxsc2NyZWVuID8gKFxuICAgICAgICAgICAgICAgIDxNaW5pbWl6ZSBjbGFzc05hbWU9J2gtNCB3LTQnIC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPE1heGltaXplIGNsYXNzTmFtZT0naC00IHctNCcgLz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXt6b29tT3V0fVxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPSdab29tIG91dCdcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSdwLTIgZ2xhc3Mgcm91bmRlZC1mdWxsIGhvdmVyOnNoYWRvdy1nbG93IHRyYW5zaXRpb24tYWxsJ1xuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Wm9vbU91dCBjbGFzc05hbWU9J2gtNCB3LTQnIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17em9vbUlufVxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPSdab29tIGluJ1xuICAgICAgICAgICAgICBjbGFzc05hbWU9J3AtMiBnbGFzcyByb3VuZGVkLWZ1bGwgaG92ZXI6c2hhZG93LWdsb3cgdHJhbnNpdGlvbi1hbGwnXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxab29tSW4gY2xhc3NOYW1lPSdoLTQgdy00JyAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3Jlc2V0Wm9vbX1cbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD0nUmVzZXQgem9vbSdcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSdwLTIgZ2xhc3Mgcm91bmRlZC1mdWxsIGhvdmVyOnNoYWRvdy1nbG93IHRyYW5zaXRpb24tYWxsJ1xuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT0naC00IHctNCcgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7aW1hZ2VzLmxlbmd0aCA+IDEgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGdhcC0yIG92ZXJmbG93LXgtYXV0byBwYi0xJz5cbiAgICAgICAgICAgIHtpbWFnZXMubWFwKChzcmMsIGkpID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17c3JjfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNlbGVjdChpKX1cbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgR28gdG8gc2NyZWVuc2hvdCAke2kgKyAxfWB9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICdyZWxhdGl2ZSBmbGV4LW5vbmUgdy0yMCBoLTEyIHJvdW5kZWQtbWQgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlci0yIHRyYW5zaXRpb24tY29sb3JzJyxcbiAgICAgICAgICAgICAgICAgIGkgPT09IGluZGV4XG4gICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1wcmltYXJ5J1xuICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItYm9yZGVyIGhvdmVyOmJvcmRlci1wcmltYXJ5LzUwJ1xuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8aW1nIHNyYz17c3JjfSBhbHQ9JycgY2xhc3NOYW1lPSd3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlcicgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICA8L0RpYWxvZz5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IERlbW9HYWxsZXJ5O1xuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJDaGV2cm9uTGVmdCIsIkNoZXZyb25SaWdodCIsIk1heGltaXplIiwiTWluaW1pemUiLCJSb3RhdGVDY3ciLCJab29tSW4iLCJab29tT3V0IiwiRGlhbG9nIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0Rlc2NyaXB0aW9uIiwiRGlhbG9nSGVhZGVyIiwiRGlhbG9nVGl0bGUiLCJjbiIsIk1JTl9TQ0FMRSIsIk1BWF9TQ0FMRSIsIlpPT01fU1RFUCIsIkRlbW9HYWxsZXJ5Iiwib3BlbiIsIm9uT3BlbkNoYW5nZSIsInRpdGxlIiwiaW1hZ2VzIiwiaW5kZXgiLCJzZXRJbmRleCIsInNjYWxlIiwic2V0U2NhbGUiLCJ0cmFuc2xhdGUiLCJzZXRUcmFuc2xhdGUiLCJ4IiwieSIsImlzRHJhZ2dpbmciLCJzZXRJc0RyYWdnaW5nIiwiaXNGdWxsc2NyZWVuIiwic2V0SXNGdWxsc2NyZWVuIiwiY29udGFpbmVyUmVmIiwiZHJhZ1N0YXJ0IiwidHgiLCJ0eSIsIm9uQ2hhbmdlIiwiQm9vbGVhbiIsImRvY3VtZW50IiwiZnVsbHNjcmVlbkVsZW1lbnQiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsInRvZ2dsZUZ1bGxzY3JlZW4iLCJleGl0RnVsbHNjcmVlbiIsImN1cnJlbnQiLCJyZXF1ZXN0RnVsbHNjcmVlbiIsImNhdGNoIiwiZ28iLCJkaXIiLCJsZW5ndGgiLCJwcmV2Iiwic2VsZWN0IiwiaSIsInpvb21JbiIsInMiLCJNYXRoIiwibWluIiwidG9GaXhlZCIsInpvb21PdXQiLCJuZXh0IiwibWF4IiwicmVzZXRab29tIiwidG9nZ2xlWm9vbSIsIm9uV2hlZWwiLCJlIiwicHJldmVudERlZmF1bHQiLCJkZWx0YVkiLCJvblBvaW50ZXJEb3duIiwiY2xpZW50WCIsImNsaWVudFkiLCJjdXJyZW50VGFyZ2V0Iiwic2V0UG9pbnRlckNhcHR1cmUiLCJwb2ludGVySWQiLCJvblBvaW50ZXJNb3ZlIiwib25Qb2ludGVyVXAiLCJjbGFzc05hbWUiLCJkaXYiLCJyZWYiLCJzdHlsZSIsInRvdWNoQWN0aW9uIiwib25Eb3VibGVDbGljayIsIm9uUG9pbnRlckNhbmNlbCIsImltZyIsInNyYyIsImFsdCIsImRyYWdnYWJsZSIsInRyYW5zZm9ybSIsImJ1dHRvbiIsIm9uQ2xpY2siLCJhcmlhLWxhYmVsIiwibWFwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsU0FBUyxFQUFFQyxNQUFNLEVBQUVDLFFBQVEsUUFBUSxRQUFRO0FBQzNELFNBQ0VDLFdBQVcsRUFDWEMsWUFBWSxFQUNaQyxRQUFRLEVBQ1JDLFFBQVEsRUFDUkMsU0FBUyxFQUNUQyxNQUFNLEVBQ05DLE9BQU8sUUFDRixlQUFlO0FBQ3RCLFNBQ0VDLE1BQU0sRUFDTkMsYUFBYSxFQUNiQyxpQkFBaUIsRUFDakJDLFlBQVksRUFDWkMsV0FBVyxRQUNOLHlCQUF5QjtBQUNoQyxTQUFTQyxFQUFFLFFBQVEsY0FBYztBQVNqQyxNQUFNQyxZQUFZO0FBQ2xCLE1BQU1DLFlBQVk7QUFDbEIsTUFBTUMsWUFBWTtBQUVsQixNQUFNQyxjQUFjLENBQUMsRUFDbkJDLElBQUksRUFDSkMsWUFBWSxFQUNaQyxLQUFLLEVBQ0xDLE1BQU0sRUFDVzs7SUFDakIsTUFBTSxDQUFDQyxPQUFPQyxTQUFTLEdBQUd2QixTQUFTO0lBQ25DLE1BQU0sQ0FBQ3dCLE9BQU9DLFNBQVMsR0FBR3pCLFNBQVNjO0lBQ25DLE1BQU0sQ0FBQ1ksV0FBV0MsYUFBYSxHQUFHM0IsU0FBUztRQUFFNEIsR0FBRztRQUFHQyxHQUFHO0lBQUU7SUFDeEQsTUFBTSxDQUFDQyxZQUFZQyxjQUFjLEdBQUcvQixTQUFTO0lBQzdDLE1BQU0sQ0FBQ2dDLGNBQWNDLGdCQUFnQixHQUFHakMsU0FBUztJQUNqRCxNQUFNa0MsZUFBZW5DLE9BQXVCO0lBQzVDLE1BQU1vQyxZQUFZcEMsT0FBTztRQUFFNkIsR0FBRztRQUFHQyxHQUFHO1FBQUdPLElBQUk7UUFBR0MsSUFBSTtJQUFFO0lBRXBEdkMsVUFBVTtRQUNSLE1BQU13QyxXQUFXLElBQU1MLGdCQUFnQk0sUUFBUUMsU0FBU0MsaUJBQWlCO1FBQ3pFRCxTQUFTRSxnQkFBZ0IsQ0FBQyxvQkFBb0JKO1FBQzlDLE9BQU8sSUFBTUUsU0FBU0csbUJBQW1CLENBQUMsb0JBQW9CTDtJQUNoRSxHQUFHLEVBQUU7SUFFTCxNQUFNTSxtQkFBbUI7UUFDdkIsSUFBSUosU0FBU0MsaUJBQWlCLEVBQUU7WUFDOUIsS0FBS0QsU0FBU0ssY0FBYztRQUM5QixPQUFPO1lBQ0xYLGFBQWFZLE9BQU8sRUFBRUMsb0JBQW9CQyxNQUFNLEtBQU87UUFDekQ7SUFDRjtJQUVBbEQsVUFBVTtRQUNSLElBQUlvQixNQUFNO1lBQ1JLLFNBQVM7WUFDVEUsU0FBU1g7WUFDVGEsYUFBYTtnQkFBRUMsR0FBRztnQkFBR0MsR0FBRztZQUFFO1FBQzVCO0lBQ0YsR0FBRztRQUFDWDtLQUFLO0lBRVRwQixVQUFVO1FBQ1IyQixTQUFTWDtRQUNUYSxhQUFhO1lBQUVDLEdBQUc7WUFBR0MsR0FBRztRQUFFO0lBQzVCLEdBQUc7UUFBQ1A7S0FBTTtJQUVWLE1BQU13QixVQUFVekIsTUFBTSxDQUFDQyxNQUFNLElBQUlELE1BQU0sQ0FBQyxFQUFFO0lBRTFDLE1BQU00QixLQUFLLENBQUNDO1FBQ1YsSUFBSTdCLE9BQU84QixNQUFNLEtBQUssR0FBRztRQUN6QjVCLFNBQVM2QixDQUFBQSxPQUFRLEFBQUNBLENBQUFBLE9BQU9GLE1BQU03QixPQUFPOEIsTUFBTSxBQUFELElBQUs5QixPQUFPOEIsTUFBTTtJQUMvRDtJQUVBLE1BQU1FLFNBQVMsQ0FBQ0MsSUFBYy9CLFNBQVMrQjtJQUV2QyxNQUFNQyxTQUFTLElBQ2I5QixTQUFTK0IsQ0FBQUEsSUFBS0MsS0FBS0MsR0FBRyxDQUFDM0MsV0FBVyxDQUFDLEFBQUN5QyxDQUFBQSxJQUFJeEMsU0FBUSxFQUFHMkMsT0FBTyxDQUFDO0lBRTdELE1BQU1DLFVBQVUsSUFDZG5DLFNBQVMrQixDQUFBQTtZQUNQLE1BQU1LLE9BQU9KLEtBQUtLLEdBQUcsQ0FBQ2hELFdBQVcsQ0FBQyxBQUFDMEMsQ0FBQUEsSUFBSXhDLFNBQVEsRUFBRzJDLE9BQU8sQ0FBQztZQUMxRCxJQUFJRSxTQUFTL0MsV0FBV2EsYUFBYTtnQkFBRUMsR0FBRztnQkFBR0MsR0FBRztZQUFFO1lBQ2xELE9BQU9nQztRQUNUO0lBRUYsTUFBTUUsWUFBWTtRQUNoQnRDLFNBQVNYO1FBQ1RhLGFBQWE7WUFBRUMsR0FBRztZQUFHQyxHQUFHO1FBQUU7SUFDNUI7SUFFQSxNQUFNbUMsYUFBYTtRQUNqQixJQUFJeEMsUUFBUVYsV0FBV2lEO2FBQ2xCdEMsU0FBUztJQUNoQjtJQUVBLE1BQU13QyxVQUFVLENBQUNDO1FBQ2ZBLEVBQUVDLGNBQWM7UUFDaEIsSUFBSUQsRUFBRUUsTUFBTSxHQUFHLEdBQUdiO2FBQ2JLO0lBQ1A7SUFFQSxNQUFNUyxnQkFBZ0IsQ0FBQ0g7UUFDckIsSUFBSTFDLFNBQVNWLFdBQVc7UUFDeEJpQixjQUFjO1FBQ2RJLFVBQVVXLE9BQU8sR0FBRztZQUNsQmxCLEdBQUdzQyxFQUFFSSxPQUFPO1lBQ1p6QyxHQUFHcUMsRUFBRUssT0FBTztZQUNabkMsSUFBSVYsVUFBVUUsQ0FBQztZQUNmUyxJQUFJWCxVQUFVRyxDQUFDO1FBQ2pCO1FBQ0FxQyxFQUFFTSxhQUFhLENBQUNDLGlCQUFpQixDQUFDUCxFQUFFUSxTQUFTO0lBQy9DO0lBRUEsTUFBTUMsZ0JBQWdCLENBQUNUO1FBQ3JCLElBQUksQ0FBQ3BDLFlBQVk7UUFDakIsTUFBTSxFQUFFRixDQUFDLEVBQUVDLENBQUMsRUFBRU8sRUFBRSxFQUFFQyxFQUFFLEVBQUUsR0FBR0YsVUFBVVcsT0FBTztRQUMxQ25CLGFBQWE7WUFBRUMsR0FBR1EsS0FBTThCLENBQUFBLEVBQUVJLE9BQU8sR0FBRzFDLENBQUFBO1lBQUlDLEdBQUdRLEtBQU02QixDQUFBQSxFQUFFSyxPQUFPLEdBQUcxQyxDQUFBQTtRQUFHO0lBQ2xFO0lBRUEsTUFBTStDLGNBQWMsSUFBTTdDLGNBQWM7SUFFeEMscUJBQ0UsUUFBQ3ZCO1FBQU9VLE1BQU1BO1FBQU1DLGNBQWNBO2tCQUNoQyxjQUFBLFFBQUNWO1lBQWNvRSxXQUFVOzs4QkFDdkIsUUFBQ2xFOztzQ0FDQyxRQUFDQzs7Z0NBQWFRO2dDQUFNOzs7Ozs7O3NDQUNwQixRQUFDVjs7Z0NBQ0VZLFFBQVE7Z0NBQUU7Z0NBQUtELE9BQU84QixNQUFNO2dDQUFDOzs7Ozs7Ozs7Ozs7OzhCQUtsQyxRQUFDMkI7b0JBQ0NDLEtBQUs3QztvQkFDTDJDLFdBQVU7b0JBQ1ZHLE9BQU87d0JBQUVDLGFBQWE7b0JBQU87b0JBQzdCaEIsU0FBU0E7b0JBQ1RpQixlQUFlbEI7b0JBQ2ZLLGVBQWVBO29CQUNmTSxlQUFlQTtvQkFDZkMsYUFBYUE7b0JBQ2JPLGlCQUFpQlA7O3dCQUVoQjlCLHdCQUNDLFFBQUNnQzs0QkFBSUQsV0FBVTtzQ0FDYixjQUFBLFFBQUNPO2dDQUNDQyxLQUFLdkM7Z0NBQ0x3QyxLQUFLLEdBQUdsRSxNQUFNLFlBQVksRUFBRUUsUUFBUSxHQUFHO2dDQUN2Q2lFLFdBQVc7Z0NBQ1hWLFdBQVdoRSxHQUNULHdDQUNBaUIsYUFBYSxLQUFLO2dDQUVwQmtELE9BQU87b0NBQ0xRLFdBQVcsQ0FBQyxVQUFVLEVBQUU5RCxVQUFVRSxDQUFDLENBQUMsSUFBSSxFQUFFRixVQUFVRyxDQUFDLENBQUMsVUFBVSxFQUFFTCxNQUFNLENBQUMsQ0FBQztnQ0FDNUU7Ozs7Ozs7Ozs7aURBSUosUUFBQ3NEOzRCQUFJRCxXQUFVO3NDQUFrRjs7Ozs7O3dCQUtsR3hELE9BQU84QixNQUFNLEdBQUcsbUJBQ2Y7OzhDQUNFLFFBQUNzQztvQ0FDQ0MsU0FBUyxJQUFNekMsR0FBRyxDQUFDO29DQUNuQjBDLGNBQVc7b0NBQ1hkLFdBQVU7OENBRVYsY0FBQSxRQUFDNUU7d0NBQVk0RSxXQUFVOzs7Ozs7Ozs7Ozs4Q0FFekIsUUFBQ1k7b0NBQ0NDLFNBQVMsSUFBTXpDLEdBQUc7b0NBQ2xCMEMsY0FBVztvQ0FDWGQsV0FBVTs4Q0FFVixjQUFBLFFBQUMzRTt3Q0FBYTJFLFdBQVU7Ozs7Ozs7Ozs7Ozs7c0NBSzlCLFFBQUNDOzRCQUFJRCxXQUFVOzs4Q0FDYixRQUFDWTtvQ0FDQ0MsU0FBUzlDO29DQUNUK0MsY0FBWTNELGVBQWUsb0JBQW9CO29DQUMvQzZDLFdBQVU7OENBRVQ3Qyw2QkFDQyxRQUFDNUI7d0NBQVN5RSxXQUFVOzs7Ozs2REFFcEIsUUFBQzFFO3dDQUFTMEUsV0FBVTs7Ozs7Ozs7Ozs7OENBR3hCLFFBQUNZO29DQUNDQyxTQUFTOUI7b0NBQ1QrQixjQUFXO29DQUNYZCxXQUFVOzhDQUVWLGNBQUEsUUFBQ3RFO3dDQUFRc0UsV0FBVTs7Ozs7Ozs7Ozs7OENBRXJCLFFBQUNZO29DQUNDQyxTQUFTbkM7b0NBQ1RvQyxjQUFXO29DQUNYZCxXQUFVOzhDQUVWLGNBQUEsUUFBQ3ZFO3dDQUFPdUUsV0FBVTs7Ozs7Ozs7Ozs7OENBRXBCLFFBQUNZO29DQUNDQyxTQUFTM0I7b0NBQ1Q0QixjQUFXO29DQUNYZCxXQUFVOzhDQUVWLGNBQUEsUUFBQ3hFO3dDQUFVd0UsV0FBVTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0JBSzFCeEQsT0FBTzhCLE1BQU0sR0FBRyxtQkFDZixRQUFDMkI7b0JBQUlELFdBQVU7OEJBQ1p4RCxPQUFPdUUsR0FBRyxDQUFDLENBQUNQLEtBQUsvQixrQkFDaEIsUUFBQ21DOzRCQUVDQyxTQUFTLElBQU1yQyxPQUFPQzs0QkFDdEJxQyxjQUFZLENBQUMsaUJBQWlCLEVBQUVyQyxJQUFJLEdBQUc7NEJBQ3ZDdUIsV0FBV2hFLEdBQ1Qsc0ZBQ0F5QyxNQUFNaEMsUUFDRixtQkFDQTtzQ0FHTixjQUFBLFFBQUM4RDtnQ0FBSUMsS0FBS0E7Z0NBQUtDLEtBQUk7Z0NBQUdULFdBQVU7Ozs7OzsyQkFWM0JROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQnJCO0dBeE5NcEU7S0FBQUE7QUEwTk4sZUFBZUEsWUFBWSJ9