import {
  Primitive
} from "/node_modules/.vite/deps/chunk-EB6MHUD6.js?v=e72f996b";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-S725DACQ.js?v=e72f996b";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-RLJ2RCJQ.js?v=e72f996b";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-DC5AMYBS.js?v=e72f996b";

// node_modules/@radix-ui/react-visually-hidden/dist/index.mjs
var React = __toESM(require_react(), 1);
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var NAME = "VisuallyHidden";
var VisuallyHidden = React.forwardRef(
  (props, forwardedRef) => {
    return (0, import_jsx_runtime.jsx)(
      Primitive.span,
      {
        ...props,
        ref: forwardedRef,
        style: {
          // See: https://github.com/twbs/bootstrap/blob/master/scss/mixins/_screen-reader.scss
          position: "absolute",
          border: 0,
          width: 1,
          height: 1,
          padding: 0,
          margin: -1,
          overflow: "hidden",
          clip: "rect(0, 0, 0, 0)",
          whiteSpace: "nowrap",
          wordWrap: "normal",
          ...props.style
        }
      }
    );
  }
);
VisuallyHidden.displayName = NAME;
var Root = VisuallyHidden;

export {
  VisuallyHidden,
  Root
};
//# sourceMappingURL=chunk-ZH4JFCF5.js.map
