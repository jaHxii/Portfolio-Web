import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Contact.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_EMAILJS_PUBLIC_KEY": "0k9GNy3_VgCGbgb6p", "VITE_EMAILJS_SERVICE_ID": "service_69vleyd", "VITE_EMAILJS_TEMPLATE_ID": "template_yltgudd"};if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/pages/Contact.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useState = __vite__cjsImport2_react["useState"]; const useRef = __vite__cjsImport2_react["useRef"];
import emailjs from "/node_modules/.vite/deps/@emailjs_browser.js?v=e72f996b";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { useInView } from "/node_modules/.vite/deps/react-intersection-observer.js?v=e72f996b";
import { Mail, Phone, MapPin, Github, MessageSquare, Send, Copy, Check, Clock, Loader2, Plane } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Card, CardContent, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
import Navigation from "/src/components/layout/Navigation.tsx";
import Footer from "/src/components/layout/Footer.tsx";
import Atmosphere from "/src/components/atmosphere/Atmosphere.tsx";
import FlightLog from "/src/components/ui/flight-log.tsx";
import SEO from "/src/components/seo/SEO.tsx";
import StructuredData from "/src/components/seo/StructuredData.tsx";
import { useSEO } from "/src/hooks/use-seo.ts";
import { useStructuredData } from "/src/hooks/use-structured-data.ts";
import { useToast } from "/src/components/ui/use-toast.ts";
const Contact = ()=>{
    _s();
    const seoProps = useSEO();
    const { breadcrumbSchema } = useStructuredData();
    const formRef = useRef(null);
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    });
    const { toast } = useToast();
    const [copied, setCopied] = useState(null);
    const [isSending, setIsSending] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: '',
        website: ''
    });
    const [formErrors, setFormErrors] = useState({});
    const contactMethods = [
        {
            icon: Mail,
            label: 'Email',
            value: 'ermias.xii@gmail.com',
            href: 'mailto:ermias.xii@gmail.com',
            description: 'Best for detailed inquiries',
            copyable: true
        },
        {
            icon: Phone,
            label: 'Phone',
            value: '+251921615244',
            href: 'tel:+251921615244',
            description: 'Available Mon-Fri, 9AM-6PM EAT',
            copyable: true
        },
        {
            icon: MessageSquare,
            label: 'Telegram',
            value: '@cloudx69',
            href: 'https://t.me/cloudx69',
            description: 'Quick responses & file sharing',
            copyable: false
        },
        {
            icon: MapPin,
            label: 'Location',
            value: 'Addis Ababa, Ethiopia',
            href: '#',
            description: 'Available for remote work globally',
            copyable: false
        }
    ];
    const socialLinks = [
        {
            icon: Github,
            label: 'GitHub',
            href: 'https://github.com/jaHxii',
            description: 'View my code & contributions'
        },
        {
            icon: MessageSquare,
            label: 'Telegram',
            href: 'https://t.me/cloudx69',
            description: 'Quick responses & file sharing'
        }
    ];
    const workingHours = [
        {
            day: 'Monday - Friday',
            time: '9:00 AM - 6:00 PM EAT'
        },
        {
            day: 'Saturday',
            time: '10:00 AM - 2:00 PM EAT'
        },
        {
            day: 'Sunday',
            time: 'Emergency only'
        }
    ];
    const copyToClipboard = async (text, label)=>{
        try {
            await navigator.clipboard.writeText(text);
            setCopied(label);
            toast({
                title: 'Copied!',
                description: `${label} copied to clipboard`
            });
            setTimeout(()=>setCopied(null), 2000);
        } catch  {
            toast({
                title: 'Error',
                description: 'Failed to copy to clipboard',
                variant: 'destructive'
            });
        }
    };
    const validateForm = ()=>{
        const errors = {};
        // Honeypot check
        if (formData.website) {
            return false; // silently reject bots
        }
        const name = formData.name.trim();
        if (name.length < 2) {
            errors.name = 'Name must be at least 2 characters.';
        }
        const email = formData.email.trim();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            errors.email = 'Please enter a valid email address.';
        }
        const subject = formData.subject.trim();
        if (subject.length < 3) {
            errors.subject = 'Subject must be at least 3 characters.';
        }
        const message = formData.message.trim();
        if (message.length < 10) {
            errors.message = 'Message must be at least 10 characters.';
        } else if (message.length > 2000) {
            errors.message = 'Message must be under 2000 characters.';
        }
        setFormErrors(errors);
        return Object.keys(errors).length === 0;
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!validateForm()) return;
        const serviceId = import.meta.env.VITE_EMAILJS_SERVICE_ID;
        const templateId = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
        const publicKey = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;
        if (!serviceId || !templateId || !publicKey) {
            toast({
                title: 'Form not configured',
                description: 'EmailJS is not set up yet. Please email me directly at ermias.xii@gmail.com',
                variant: 'destructive'
            });
            return;
        }
        setIsSending(true);
        try {
            await emailjs.send(serviceId, templateId, {
                from_name: formData.name,
                from_email: formData.email,
                subject: formData.subject,
                message: formData.message,
                to_email: 'ermias.xii@gmail.com'
            }, publicKey);
            toast({
                title: '✅ Message sent!',
                description: "Thanks! I'll get back to you within 24 hours."
            });
            setFormData({
                name: '',
                email: '',
                subject: '',
                message: ''
            });
        } catch (err) {
            console.error('EmailJS error:', err);
            toast({
                title: '❌ Send failed',
                description: 'Please try again or email me directly at ermias.xii@gmail.com',
                variant: 'destructive'
            });
        } finally{
            setIsSending(false);
        }
    };
    const handleInputChange = (e)=>{
        setFormData((prev)=>({
                ...prev,
                [e.target.name]: e.target.value
            }));
    };
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "min-h-screen bg-background",
        children: [
            /*#__PURE__*/ _jsxDEV(SEO, {
                ...seoProps
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                lineNumber: 224,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(StructuredData, {
                schema: breadcrumbSchema
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                lineNumber: 225,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(Navigation, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                lineNumber: 226,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("section", {
                className: "relative pt-36 pb-24 overflow-hidden",
                children: [
                    /*#__PURE__*/ _jsxDEV(Atmosphere, {
                        variant: "horizon"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                        lineNumber: 230,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "relative z-10 container mx-auto px-4",
                        children: /*#__PURE__*/ _jsxDEV(motion.div, {
                            ref: ref,
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: inView ? {
                                opacity: 1,
                                y: 0
                            } : {},
                            transition: {
                                duration: 0.8
                            },
                            className: "max-w-3xl mx-auto text-center",
                            children: [
                                /*#__PURE__*/ _jsxDEV(FlightLog, {
                                    entries: [
                                        'HORIZON / CONTACT',
                                        'CLEARED FOR LANDING',
                                        'APPROACH · FINAL',
                                        'ON THE GROUND · CHAT'
                                    ]
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                    lineNumber: 239,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("h1", {
                                    className: "text-4xl md:text-6xl font-bold font-heading tracking-tight leading-tight",
                                    children: [
                                        "Let's Build Something",
                                        ' ',
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "gold-text",
                                            children: "Reliable."
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                            lineNumber: 249,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                    lineNumber: 247,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "mt-6 text-lg text-mist-soft leading-relaxed font-light max-w-2xl mx-auto",
                                    children: "Whether you need technical support, infrastructure work, software development, or an engineering-minded problem solver - let's talk."
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                    lineNumber: 251,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV(motion.div, {
                                    initial: {
                                        width: 0
                                    },
                                    animate: inView ? {
                                        width: 120
                                    } : {},
                                    transition: {
                                        delay: 0.5,
                                        duration: 0.8
                                    },
                                    className: "h-px bg-gradient-gold mx-auto rounded-full mt-8"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                    lineNumber: 256,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                            lineNumber: 232,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                        lineNumber: 231,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                lineNumber: 229,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("section", {
                className: "relative pb-16 overflow-hidden",
                children: /*#__PURE__*/ _jsxDEV("div", {
                    className: "container mx-auto px-4 max-w-6xl",
                    children: [
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "grid lg:grid-cols-3 gap-8",
                            children: [
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "lg:col-span-1 space-y-6",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                opacity: 0,
                                                x: -30
                                            },
                                            animate: inView ? {
                                                opacity: 1,
                                                x: 0
                                            } : {},
                                            transition: {
                                                delay: 0.8,
                                                duration: 0.6
                                            },
                                            children: /*#__PURE__*/ _jsxDEV(Card, {
                                                className: "glass-cloud",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV(CardHeader, {
                                                        children: /*#__PURE__*/ _jsxDEV(CardTitle, {
                                                            className: "font-heading",
                                                            children: "Contact Information"
                                                        }, void 0, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                            lineNumber: 279,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 278,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV(CardContent, {
                                                        className: "space-y-4",
                                                        children: contactMethods.map((method, index)=>/*#__PURE__*/ _jsxDEV(motion.div, {
                                                                initial: {
                                                                    opacity: 0,
                                                                    y: 20
                                                                },
                                                                animate: inView ? {
                                                                    opacity: 1,
                                                                    y: 0
                                                                } : {},
                                                                transition: {
                                                                    delay: 1.0 + index * 0.08,
                                                                    duration: 0.5
                                                                },
                                                                className: "flex items-start gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors group",
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                                        className: "p-2 bg-gold/10 rounded-lg shrink-0",
                                                                        children: /*#__PURE__*/ _jsxDEV(method.icon, {
                                                                            className: "h-4 w-4 gold-text"
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                            lineNumber: 296,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 295,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                                        className: "flex-1 min-w-0",
                                                                        children: [
                                                                            /*#__PURE__*/ _jsxDEV("div", {
                                                                                className: "flex items-center gap-2",
                                                                                children: [
                                                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                                                        className: "font-medium text-sm",
                                                                                        children: method.label
                                                                                    }, void 0, false, {
                                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                                        lineNumber: 300,
                                                                                        columnNumber: 29
                                                                                    }, this),
                                                                                    method.copyable && /*#__PURE__*/ _jsxDEV(Button, {
                                                                                        size: "sm",
                                                                                        variant: "ghost",
                                                                                        className: "h-6 w-6 p-0 hover:bg-gold/10",
                                                                                        onClick: ()=>copyToClipboard(method.value, method.label),
                                                                                        "aria-label": `Copy ${method.label}`,
                                                                                        children: copied === method.label ? /*#__PURE__*/ _jsxDEV(Check, {
                                                                                            className: "h-3 w-3 text-gold"
                                                                                        }, void 0, false, {
                                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                                            lineNumber: 314,
                                                                                            columnNumber: 35
                                                                                        }, this) : /*#__PURE__*/ _jsxDEV(Copy, {
                                                                                            className: "h-3 w-3"
                                                                                        }, void 0, false, {
                                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                                            lineNumber: 316,
                                                                                            columnNumber: 35
                                                                                        }, this)
                                                                                    }, void 0, false, {
                                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                                        lineNumber: 304,
                                                                                        columnNumber: 31
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                                lineNumber: 299,
                                                                                columnNumber: 27
                                                                            }, this),
                                                                            /*#__PURE__*/ _jsxDEV("p", {
                                                                                className: "text-sm text-mist-soft mb-1",
                                                                                children: method.value
                                                                            }, void 0, false, {
                                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                                lineNumber: 321,
                                                                                columnNumber: 27
                                                                            }, this),
                                                                            /*#__PURE__*/ _jsxDEV("p", {
                                                                                className: "text-xs text-mist-soft/70",
                                                                                children: method.description
                                                                            }, void 0, false, {
                                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                                lineNumber: 324,
                                                                                columnNumber: 27
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 298,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, method.label, true, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 285,
                                                                columnNumber: 23
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 283,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                lineNumber: 277,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                            lineNumber: 272,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                opacity: 0,
                                                x: -30
                                            },
                                            animate: inView ? {
                                                opacity: 1,
                                                x: 0
                                            } : {},
                                            transition: {
                                                delay: 1.1,
                                                duration: 0.6
                                            },
                                            children: /*#__PURE__*/ _jsxDEV(Card, {
                                                className: "glass-cloud",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV(CardHeader, {
                                                        children: /*#__PURE__*/ _jsxDEV(CardTitle, {
                                                            className: "font-heading",
                                                            children: "Connect Online"
                                                        }, void 0, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                            lineNumber: 341,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 340,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV(CardContent, {
                                                        className: "space-y-3",
                                                        children: socialLinks.map((social, index)=>/*#__PURE__*/ _jsxDEV(motion.a, {
                                                                href: social.href,
                                                                target: "_blank",
                                                                rel: "noopener noreferrer",
                                                                initial: {
                                                                    opacity: 0,
                                                                    y: 20
                                                                },
                                                                animate: inView ? {
                                                                    opacity: 1,
                                                                    y: 0
                                                                } : {},
                                                                transition: {
                                                                    delay: 1.3 + index * 0.08,
                                                                    duration: 0.5
                                                                },
                                                                className: "flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-all duration-300 group",
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                                        className: "p-2 bg-gold/10 rounded-lg shrink-0",
                                                                        children: /*#__PURE__*/ _jsxDEV(social.icon, {
                                                                            className: "h-4 w-4 gold-text"
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                            lineNumber: 361,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 360,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                                        children: [
                                                                            /*#__PURE__*/ _jsxDEV("p", {
                                                                                className: "font-medium text-sm group-hover:text-gold transition-colors",
                                                                                children: social.label
                                                                            }, void 0, false, {
                                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                                lineNumber: 364,
                                                                                columnNumber: 27
                                                                            }, this),
                                                                            /*#__PURE__*/ _jsxDEV("p", {
                                                                                className: "text-xs text-mist-soft",
                                                                                children: social.description
                                                                            }, void 0, false, {
                                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                                lineNumber: 367,
                                                                                columnNumber: 27
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 363,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, social.label, true, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 347,
                                                                columnNumber: 23
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 345,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                lineNumber: 339,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                            lineNumber: 334,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                opacity: 0,
                                                x: -30
                                            },
                                            animate: inView ? {
                                                opacity: 1,
                                                x: 0
                                            } : {},
                                            transition: {
                                                delay: 1.4,
                                                duration: 0.6
                                            },
                                            children: /*#__PURE__*/ _jsxDEV(Card, {
                                                className: "glass-cloud",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV(CardHeader, {
                                                        children: /*#__PURE__*/ _jsxDEV(CardTitle, {
                                                            className: "font-heading flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV(Clock, {
                                                                    className: "h-5 w-5 gold-text"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 385,
                                                                    columnNumber: 23
                                                                }, this),
                                                                "Working Hours"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                            lineNumber: 384,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 383,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV(CardContent, {
                                                        className: "space-y-2",
                                                        children: workingHours.map((schedule, index)=>/*#__PURE__*/ _jsxDEV("div", {
                                                                className: "flex justify-between items-center text-sm",
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "text-mist-soft",
                                                                        children: schedule.day
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 395,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "glass px-2.5 py-0.5 rounded-md text-xs text-mist-soft",
                                                                        children: schedule.time
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 396,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, index, true, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 391,
                                                                columnNumber: 23
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 389,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                lineNumber: 382,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                            lineNumber: 377,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                opacity: 0,
                                                x: -30
                                            },
                                            animate: inView ? {
                                                opacity: 1,
                                                x: 0
                                            } : {},
                                            transition: {
                                                delay: 1.5,
                                                duration: 0.6
                                            },
                                            "aria-label": "Boarding pass",
                                            children: /*#__PURE__*/ _jsxDEV("div", {
                                                className: "glass-cloud rounded-2xl overflow-hidden",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                        className: "flex items-center justify-between px-5 py-3 border-b border-dashed border-border/60",
                                                        children: [
                                                            /*#__PURE__*/ _jsxDEV("span", {
                                                                className: "font-mono text-[10px] tracking-[0.25em] text-mist-soft",
                                                                children: "BOARDING PASS"
                                                            }, void 0, false, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 413,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ _jsxDEV(Plane, {
                                                                className: "h-4 w-4 gold-text",
                                                                "aria-hidden": "true"
                                                            }, void 0, false, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 416,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 412,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                        className: "px-5 py-4 space-y-2.5",
                                                        children: [
                                                            /*#__PURE__*/ _jsxDEV("div", {
                                                                className: "flex justify-between",
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "font-mono text-[10px] tracking-[0.2em] text-mist-soft/70",
                                                                        children: "PASSENGER"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 420,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "text-sm font-medium",
                                                                        children: "ERMIAS LEMESA"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 423,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 419,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ _jsxDEV("div", {
                                                                className: "flex justify-between",
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "font-mono text-[10px] tracking-[0.2em] text-mist-soft/70",
                                                                        children: "FROM"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 426,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "text-sm",
                                                                        children: "ADDIS ABABA"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 429,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 425,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ _jsxDEV("div", {
                                                                className: "flex justify-between",
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "font-mono text-[10px] tracking-[0.2em] text-mist-soft/70",
                                                                        children: "TO"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 432,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "text-sm",
                                                                        children: "REMOTE · WORLDWIDE"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 435,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 431,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ _jsxDEV("div", {
                                                                className: "flex justify-between",
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "font-mono text-[10px] tracking-[0.2em] text-mist-soft/70",
                                                                        children: "CLASS"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 438,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "text-sm",
                                                                        children: "SENIOR IT"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 441,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 437,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ _jsxDEV("div", {
                                                                className: "flex justify-between items-center border-t border-dashed border-border/60 pt-2.5",
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "font-mono text-[10px] tracking-[0.2em] text-mist-soft/70",
                                                                        children: "SEAT"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 444,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "font-mono text-xs gold-text",
                                                                        children: "01A"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 447,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                lineNumber: 443,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 418,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                lineNumber: 411,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                            lineNumber: 405,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                    lineNumber: 271,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV(motion.div, {
                                    initial: {
                                        opacity: 0,
                                        x: 30
                                    },
                                    animate: inView ? {
                                        opacity: 1,
                                        x: 0
                                    } : {},
                                    transition: {
                                        delay: 0.8,
                                        duration: 0.6
                                    },
                                    className: "lg:col-span-2",
                                    children: /*#__PURE__*/ _jsxDEV(Card, {
                                        className: "glass-cloud",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV(CardHeader, {
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV(CardTitle, {
                                                        className: "font-heading",
                                                        children: "Send me a message"
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 463,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        className: "text-mist-soft",
                                                        children: "Have a project in mind? Let's discuss how we can work together."
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                        lineNumber: 466,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                lineNumber: 462,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV(CardContent, {
                                                children: /*#__PURE__*/ _jsxDEV("form", {
                                                    ref: formRef,
                                                    onSubmit: handleSubmit,
                                                    className: "space-y-6",
                                                    noValidate: true,
                                                    children: [
                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                            className: "absolute opacity-0 h-0 overflow-hidden",
                                                            "aria-hidden": "true",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("label", {
                                                                    htmlFor: "website",
                                                                    children: "Leave this empty"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 480,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV(Input, {
                                                                    id: "website",
                                                                    name: "website",
                                                                    value: formData.website,
                                                                    onChange: handleInputChange,
                                                                    tabIndex: -1,
                                                                    autoComplete: "off"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 481,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                            lineNumber: 479,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                            className: "grid md:grid-cols-2 gap-4",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "space-y-2",
                                                                    children: [
                                                                        /*#__PURE__*/ _jsxDEV("label", {
                                                                            htmlFor: "name",
                                                                            className: "text-sm font-medium",
                                                                            children: "Full Name *"
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                            lineNumber: 492,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ _jsxDEV(Input, {
                                                                            id: "name",
                                                                            name: "name",
                                                                            value: formData.name,
                                                                            onChange: handleInputChange,
                                                                            placeholder: "John Doe",
                                                                            required: true,
                                                                            disabled: isSending,
                                                                            "aria-invalid": !!formErrors.name,
                                                                            className: "bg-white/[0.02] border-border focus:border-gold/50"
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                            lineNumber: 495,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        formErrors.name && /*#__PURE__*/ _jsxDEV("p", {
                                                                            className: "text-xs text-destructive",
                                                                            children: formErrors.name
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                            lineNumber: 507,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 491,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "space-y-2",
                                                                    children: [
                                                                        /*#__PURE__*/ _jsxDEV("label", {
                                                                            htmlFor: "email",
                                                                            className: "text-sm font-medium",
                                                                            children: "Email Address *"
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                            lineNumber: 511,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ _jsxDEV(Input, {
                                                                            id: "email",
                                                                            name: "email",
                                                                            type: "email",
                                                                            value: formData.email,
                                                                            onChange: handleInputChange,
                                                                            placeholder: "john@example.com",
                                                                            required: true,
                                                                            disabled: isSending,
                                                                            "aria-invalid": !!formErrors.email,
                                                                            className: "bg-white/[0.02] border-border focus:border-gold/50"
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                            lineNumber: 514,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        formErrors.email && /*#__PURE__*/ _jsxDEV("p", {
                                                                            className: "text-xs text-destructive",
                                                                            children: formErrors.email
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                            lineNumber: 527,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 510,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                            lineNumber: 490,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                            className: "space-y-2",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("label", {
                                                                    htmlFor: "subject",
                                                                    className: "text-sm font-medium",
                                                                    children: "Subject *"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 533,
                                                                    columnNumber: 23
                                                                }, this),
                                                                "                        ",
                                                                /*#__PURE__*/ _jsxDEV(Input, {
                                                                    id: "subject",
                                                                    name: "subject",
                                                                    value: formData.subject,
                                                                    onChange: handleInputChange,
                                                                    placeholder: "Project inquiry, collaboration, etc.",
                                                                    required: true,
                                                                    disabled: isSending,
                                                                    "aria-invalid": !!formErrors.subject,
                                                                    className: "bg-white/[0.02] border-border focus:border-gold/50"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 535,
                                                                    columnNumber: 55
                                                                }, this),
                                                                formErrors.subject && /*#__PURE__*/ _jsxDEV("p", {
                                                                    className: "text-xs text-destructive",
                                                                    children: formErrors.subject
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 547,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                            lineNumber: 532,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                            className: "space-y-2",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("label", {
                                                                    htmlFor: "message",
                                                                    className: "text-sm font-medium",
                                                                    children: "Message *"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 552,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV(Textarea, {
                                                                    id: "message",
                                                                    name: "message",
                                                                    value: formData.message,
                                                                    onChange: handleInputChange,
                                                                    placeholder: "Tell me about your project, timeline, budget, and any specific requirements...",
                                                                    rows: 6,
                                                                    required: true,
                                                                    disabled: isSending,
                                                                    "aria-invalid": !!formErrors.message,
                                                                    className: "bg-white/[0.03] border-white/10 focus:border-gold/50 resize-none"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 555,
                                                                    columnNumber: 23
                                                                }, this),
                                                                formErrors.message && /*#__PURE__*/ _jsxDEV("p", {
                                                                    className: "text-xs text-destructive",
                                                                    children: formErrors.message
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 568,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("p", {
                                                                    className: "text-xs text-mist-soft/60 text-right",
                                                                    children: [
                                                                        formData.message.length,
                                                                        "/2000"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                    lineNumber: 570,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                            lineNumber: 551,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ _jsxDEV(Button, {
                                                            type: "submit",
                                                            disabled: isSending,
                                                            className: "w-full bg-mist text-storm-deep hover:bg-mist/90 hover:shadow-glow-strong transition-all duration-300 disabled:opacity-70",
                                                            children: isSending ? /*#__PURE__*/ _jsxDEV(_Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV(Loader2, {
                                                                        className: "mr-2 h-4 w-4 animate-spin"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 582,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    ' ',
                                                                    "Sending…"
                                                                ]
                                                            }, void 0, true) : /*#__PURE__*/ _jsxDEV(_Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ _jsxDEV(Send, {
                                                                        className: "mr-2 h-4 w-4"
                                                                    }, void 0, false, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                                        lineNumber: 587,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    " Send Message"
                                                                ]
                                                            }, void 0, true)
                                                        }, void 0, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                            lineNumber: 575,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                    lineNumber: 472,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                lineNumber: 471,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                        lineNumber: 461,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                    lineNumber: 455,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                            lineNumber: 269,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: inView ? {
                                opacity: 1,
                                y: 0
                            } : {},
                            transition: {
                                delay: 1.6,
                                duration: 0.6
                            },
                            className: "mt-12 text-center",
                            children: /*#__PURE__*/ _jsxDEV(Card, {
                                className: "glass-cloud max-w-2xl mx-auto",
                                children: /*#__PURE__*/ _jsxDEV(CardContent, {
                                    className: "p-6",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("h3", {
                                            className: "font-heading font-semibold mb-2",
                                            children: "Quick Response Guarantee"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                            lineNumber: 606,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            className: "text-mist-soft text-sm",
                                            children: [
                                                "I typically respond to all inquiries within",
                                                ' ',
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "gold-text font-medium",
                                                    children: "24 hours"
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                                    lineNumber: 611,
                                                    columnNumber: 19
                                                }, this),
                                                ". For urgent matters, please use Telegram or call directly."
                                            ]
                                        }, void 0, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                            lineNumber: 609,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                    lineNumber: 605,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                                lineNumber: 604,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                            lineNumber: 598,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                    lineNumber: 268,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                lineNumber: 267,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(Footer, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
                lineNumber: 619,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/Contact.tsx",
        lineNumber: 223,
        columnNumber: 5
    }, this);
};
_s(Contact, "6c8Lt/ahV1Sn2uydB8+5F7c1Oow=", false, function() {
    return [
        useSEO,
        useStructuredData,
        useInView,
        useToast
    ];
});
_c = Contact;
export default Contact;
var _c;
$RefreshReg$(_c, "Contact");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/pages/Contact.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/pages/Contact.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkNvbnRhY3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGVtYWlsanMgZnJvbSAnQGVtYWlsanMvYnJvd3Nlcic7XG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IHVzZUluVmlldyB9IGZyb20gJ3JlYWN0LWludGVyc2VjdGlvbi1vYnNlcnZlcic7XG5pbXBvcnQge1xuICBNYWlsLFxuICBQaG9uZSxcbiAgTWFwUGluLFxuICBHaXRodWIsXG4gIE1lc3NhZ2VTcXVhcmUsXG4gIFNlbmQsXG4gIENvcHksXG4gIENoZWNrLFxuICBDbG9jayxcbiAgTG9hZGVyMixcbiAgUGxhbmUsXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCc7XG5pbXBvcnQgeyBUZXh0YXJlYSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS90ZXh0YXJlYSc7XG5pbXBvcnQgTmF2aWdhdGlvbiBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L05hdmlnYXRpb24nO1xuaW1wb3J0IEZvb3RlciBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L0Zvb3Rlcic7XG5pbXBvcnQgQXRtb3NwaGVyZSBmcm9tICdAL2NvbXBvbmVudHMvYXRtb3NwaGVyZS9BdG1vc3BoZXJlJztcbmltcG9ydCBGbGlnaHRMb2cgZnJvbSAnQC9jb21wb25lbnRzL3VpL2ZsaWdodC1sb2cnO1xuaW1wb3J0IFNFTyBmcm9tICdAL2NvbXBvbmVudHMvc2VvL1NFTyc7XG5pbXBvcnQgU3RydWN0dXJlZERhdGEgZnJvbSAnQC9jb21wb25lbnRzL3Nlby9TdHJ1Y3R1cmVkRGF0YSc7XG5pbXBvcnQgeyB1c2VTRU8gfSBmcm9tICdAL2hvb2tzL3VzZS1zZW8nO1xuaW1wb3J0IHsgdXNlU3RydWN0dXJlZERhdGEgfSBmcm9tICdAL2hvb2tzL3VzZS1zdHJ1Y3R1cmVkLWRhdGEnO1xuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvdXNlLXRvYXN0JztcblxuY29uc3QgQ29udGFjdCA9ICgpID0+IHtcbiAgY29uc3Qgc2VvUHJvcHMgPSB1c2VTRU8oKTtcbiAgY29uc3QgeyBicmVhZGNydW1iU2NoZW1hIH0gPSB1c2VTdHJ1Y3R1cmVkRGF0YSgpO1xuICBjb25zdCBmb3JtUmVmID0gdXNlUmVmPEhUTUxGb3JtRWxlbWVudD4obnVsbCk7XG5cbiAgY29uc3QgW3JlZiwgaW5WaWV3XSA9IHVzZUluVmlldyh7XG4gICAgdHJpZ2dlck9uY2U6IHRydWUsXG4gICAgdGhyZXNob2xkOiAwLjEsXG4gIH0pO1xuXG4gIGNvbnN0IHsgdG9hc3QgfSA9IHVzZVRvYXN0KCk7XG4gIGNvbnN0IFtjb3BpZWQsIHNldENvcGllZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2lzU2VuZGluZywgc2V0SXNTZW5kaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XG4gICAgbmFtZTogJycsXG4gICAgZW1haWw6ICcnLFxuICAgIHN1YmplY3Q6ICcnLFxuICAgIG1lc3NhZ2U6ICcnLFxuICAgIHdlYnNpdGU6ICcnLCAvLyBob25leXBvdCDigJQgYm90cyBmaWxsIHRoaXNcbiAgfSk7XG4gIGNvbnN0IFtmb3JtRXJyb3JzLCBzZXRGb3JtRXJyb3JzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHN0cmluZz4+KHt9KTtcblxuICBjb25zdCBjb250YWN0TWV0aG9kcyA9IFtcbiAgICB7XG4gICAgICBpY29uOiBNYWlsLFxuICAgICAgbGFiZWw6ICdFbWFpbCcsXG4gICAgICB2YWx1ZTogJ2VybWlhcy54aWlAZ21haWwuY29tJyxcbiAgICAgIGhyZWY6ICdtYWlsdG86ZXJtaWFzLnhpaUBnbWFpbC5jb20nLFxuICAgICAgZGVzY3JpcHRpb246ICdCZXN0IGZvciBkZXRhaWxlZCBpbnF1aXJpZXMnLFxuICAgICAgY29weWFibGU6IHRydWUsXG4gICAgfSxcbiAgICB7XG4gICAgICBpY29uOiBQaG9uZSxcbiAgICAgIGxhYmVsOiAnUGhvbmUnLFxuICAgICAgdmFsdWU6ICcrMjUxOTIxNjE1MjQ0JyxcbiAgICAgIGhyZWY6ICd0ZWw6KzI1MTkyMTYxNTI0NCcsXG4gICAgICBkZXNjcmlwdGlvbjogJ0F2YWlsYWJsZSBNb24tRnJpLCA5QU0tNlBNIEVBVCcsXG4gICAgICBjb3B5YWJsZTogdHJ1ZSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGljb246IE1lc3NhZ2VTcXVhcmUsXG4gICAgICBsYWJlbDogJ1RlbGVncmFtJyxcbiAgICAgIHZhbHVlOiAnQGNsb3VkeDY5JyxcbiAgICAgIGhyZWY6ICdodHRwczovL3QubWUvY2xvdWR4NjknLFxuICAgICAgZGVzY3JpcHRpb246ICdRdWljayByZXNwb25zZXMgJiBmaWxlIHNoYXJpbmcnLFxuICAgICAgY29weWFibGU6IGZhbHNlLFxuICAgIH0sXG4gICAge1xuICAgICAgaWNvbjogTWFwUGluLFxuICAgICAgbGFiZWw6ICdMb2NhdGlvbicsXG4gICAgICB2YWx1ZTogJ0FkZGlzIEFiYWJhLCBFdGhpb3BpYScsXG4gICAgICBocmVmOiAnIycsXG4gICAgICBkZXNjcmlwdGlvbjogJ0F2YWlsYWJsZSBmb3IgcmVtb3RlIHdvcmsgZ2xvYmFsbHknLFxuICAgICAgY29weWFibGU6IGZhbHNlLFxuICAgIH0sXG4gIF07XG5cbiAgY29uc3Qgc29jaWFsTGlua3MgPSBbXG4gICAge1xuICAgICAgaWNvbjogR2l0aHViLFxuICAgICAgbGFiZWw6ICdHaXRIdWInLFxuICAgICAgaHJlZjogJ2h0dHBzOi8vZ2l0aHViLmNvbS9qYUh4aWknLFxuICAgICAgZGVzY3JpcHRpb246ICdWaWV3IG15IGNvZGUgJiBjb250cmlidXRpb25zJyxcbiAgICB9LFxuICAgIHtcbiAgICAgIGljb246IE1lc3NhZ2VTcXVhcmUsXG4gICAgICBsYWJlbDogJ1RlbGVncmFtJyxcbiAgICAgIGhyZWY6ICdodHRwczovL3QubWUvY2xvdWR4NjknLFxuICAgICAgZGVzY3JpcHRpb246ICdRdWljayByZXNwb25zZXMgJiBmaWxlIHNoYXJpbmcnLFxuICAgIH0sXG4gIF07XG5cbiAgY29uc3Qgd29ya2luZ0hvdXJzID0gW1xuICAgIHsgZGF5OiAnTW9uZGF5IC0gRnJpZGF5JywgdGltZTogJzk6MDAgQU0gLSA2OjAwIFBNIEVBVCcgfSxcbiAgICB7IGRheTogJ1NhdHVyZGF5JywgdGltZTogJzEwOjAwIEFNIC0gMjowMCBQTSBFQVQnIH0sXG4gICAgeyBkYXk6ICdTdW5kYXknLCB0aW1lOiAnRW1lcmdlbmN5IG9ubHknIH0sXG4gIF07XG5cbiAgY29uc3QgY29weVRvQ2xpcGJvYXJkID0gYXN5bmMgKHRleHQ6IHN0cmluZywgbGFiZWw6IHN0cmluZykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh0ZXh0KTtcbiAgICAgIHNldENvcGllZChsYWJlbCk7XG4gICAgICB0b2FzdCh7XG4gICAgICAgIHRpdGxlOiAnQ29waWVkIScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBgJHtsYWJlbH0gY29waWVkIHRvIGNsaXBib2FyZGAsXG4gICAgICB9KTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkKG51bGwpLCAyMDAwKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRvYXN0KHtcbiAgICAgICAgdGl0bGU6ICdFcnJvcicsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnRmFpbGVkIHRvIGNvcHkgdG8gY2xpcGJvYXJkJyxcbiAgICAgICAgdmFyaWFudDogJ2Rlc3RydWN0aXZlJyxcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKTogYm9vbGVhbiA9PiB7XG4gICAgY29uc3QgZXJyb3JzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG5cbiAgICAvLyBIb25leXBvdCBjaGVja1xuICAgIGlmIChmb3JtRGF0YS53ZWJzaXRlKSB7XG4gICAgICByZXR1cm4gZmFsc2U7IC8vIHNpbGVudGx5IHJlamVjdCBib3RzXG4gICAgfVxuXG4gICAgY29uc3QgbmFtZSA9IGZvcm1EYXRhLm5hbWUudHJpbSgpO1xuICAgIGlmIChuYW1lLmxlbmd0aCA8IDIpIHtcbiAgICAgIGVycm9ycy5uYW1lID0gJ05hbWUgbXVzdCBiZSBhdCBsZWFzdCAyIGNoYXJhY3RlcnMuJztcbiAgICB9XG5cbiAgICBjb25zdCBlbWFpbCA9IGZvcm1EYXRhLmVtYWlsLnRyaW0oKTtcbiAgICBpZiAoIS9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLnRlc3QoZW1haWwpKSB7XG4gICAgICBlcnJvcnMuZW1haWwgPSAnUGxlYXNlIGVudGVyIGEgdmFsaWQgZW1haWwgYWRkcmVzcy4nO1xuICAgIH1cblxuICAgIGNvbnN0IHN1YmplY3QgPSBmb3JtRGF0YS5zdWJqZWN0LnRyaW0oKTtcbiAgICBpZiAoc3ViamVjdC5sZW5ndGggPCAzKSB7XG4gICAgICBlcnJvcnMuc3ViamVjdCA9ICdTdWJqZWN0IG11c3QgYmUgYXQgbGVhc3QgMyBjaGFyYWN0ZXJzLic7XG4gICAgfVxuXG4gICAgY29uc3QgbWVzc2FnZSA9IGZvcm1EYXRhLm1lc3NhZ2UudHJpbSgpO1xuICAgIGlmIChtZXNzYWdlLmxlbmd0aCA8IDEwKSB7XG4gICAgICBlcnJvcnMubWVzc2FnZSA9ICdNZXNzYWdlIG11c3QgYmUgYXQgbGVhc3QgMTAgY2hhcmFjdGVycy4nO1xuICAgIH0gZWxzZSBpZiAobWVzc2FnZS5sZW5ndGggPiAyMDAwKSB7XG4gICAgICBlcnJvcnMubWVzc2FnZSA9ICdNZXNzYWdlIG11c3QgYmUgdW5kZXIgMjAwMCBjaGFyYWN0ZXJzLic7XG4gICAgfVxuXG4gICAgc2V0Rm9ybUVycm9ycyhlcnJvcnMpO1xuICAgIHJldHVybiBPYmplY3Qua2V5cyhlcnJvcnMpLmxlbmd0aCA9PT0gMDtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgaWYgKCF2YWxpZGF0ZUZvcm0oKSkgcmV0dXJuO1xuXG4gICAgY29uc3Qgc2VydmljZUlkID0gaW1wb3J0Lm1ldGEuZW52LlZJVEVfRU1BSUxKU19TRVJWSUNFX0lEO1xuICAgIGNvbnN0IHRlbXBsYXRlSWQgPSBpbXBvcnQubWV0YS5lbnYuVklURV9FTUFJTEpTX1RFTVBMQVRFX0lEO1xuICAgIGNvbnN0IHB1YmxpY0tleSA9IGltcG9ydC5tZXRhLmVudi5WSVRFX0VNQUlMSlNfUFVCTElDX0tFWTtcblxuICAgIGlmICghc2VydmljZUlkIHx8ICF0ZW1wbGF0ZUlkIHx8ICFwdWJsaWNLZXkpIHtcbiAgICAgIHRvYXN0KHtcbiAgICAgICAgdGl0bGU6ICdGb3JtIG5vdCBjb25maWd1cmVkJyxcbiAgICAgICAgZGVzY3JpcHRpb246XG4gICAgICAgICAgJ0VtYWlsSlMgaXMgbm90IHNldCB1cCB5ZXQuIFBsZWFzZSBlbWFpbCBtZSBkaXJlY3RseSBhdCBlcm1pYXMueGlpQGdtYWlsLmNvbScsXG4gICAgICAgIHZhcmlhbnQ6ICdkZXN0cnVjdGl2ZScsXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRJc1NlbmRpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGVtYWlsanMuc2VuZChcbiAgICAgICAgc2VydmljZUlkLFxuICAgICAgICB0ZW1wbGF0ZUlkLFxuICAgICAgICB7XG4gICAgICAgICAgZnJvbV9uYW1lOiBmb3JtRGF0YS5uYW1lLFxuICAgICAgICAgIGZyb21fZW1haWw6IGZvcm1EYXRhLmVtYWlsLFxuICAgICAgICAgIHN1YmplY3Q6IGZvcm1EYXRhLnN1YmplY3QsXG4gICAgICAgICAgbWVzc2FnZTogZm9ybURhdGEubWVzc2FnZSxcbiAgICAgICAgICB0b19lbWFpbDogJ2VybWlhcy54aWlAZ21haWwuY29tJyxcbiAgICAgICAgfSxcbiAgICAgICAgcHVibGljS2V5XG4gICAgICApO1xuICAgICAgdG9hc3Qoe1xuICAgICAgICB0aXRsZTogJ+KchSBNZXNzYWdlIHNlbnQhJyxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiVGhhbmtzISBJJ2xsIGdldCBiYWNrIHRvIHlvdSB3aXRoaW4gMjQgaG91cnMuXCIsXG4gICAgICB9KTtcbiAgICAgIHNldEZvcm1EYXRhKHsgbmFtZTogJycsIGVtYWlsOiAnJywgc3ViamVjdDogJycsIG1lc3NhZ2U6ICcnIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignRW1haWxKUyBlcnJvcjonLCBlcnIpO1xuICAgICAgdG9hc3Qoe1xuICAgICAgICB0aXRsZTogJ+KdjCBTZW5kIGZhaWxlZCcsXG4gICAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICAgICdQbGVhc2UgdHJ5IGFnYWluIG9yIGVtYWlsIG1lIGRpcmVjdGx5IGF0IGVybWlhcy54aWlAZ21haWwuY29tJyxcbiAgICAgICAgdmFyaWFudDogJ2Rlc3RydWN0aXZlJyxcbiAgICAgIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1NlbmRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChcbiAgICBlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50IHwgSFRNTFRleHRBcmVhRWxlbWVudD5cbiAgKSA9PiB7XG4gICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIFtlLnRhcmdldC5uYW1lXTogZS50YXJnZXQudmFsdWUsXG4gICAgfSkpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9J21pbi1oLXNjcmVlbiBiZy1iYWNrZ3JvdW5kJz5cbiAgICAgIDxTRU8gey4uLnNlb1Byb3BzfSAvPlxuICAgICAgPFN0cnVjdHVyZWREYXRhIHNjaGVtYT17YnJlYWRjcnVtYlNjaGVtYX0gLz5cbiAgICAgIDxOYXZpZ2F0aW9uIC8+XG5cbiAgICAgIHsvKiBIZXJvIOKAlCBzdW5saXQgaG9yaXpvbiAqL31cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT0ncmVsYXRpdmUgcHQtMzYgcGItMjQgb3ZlcmZsb3ctaGlkZGVuJz5cbiAgICAgICAgPEF0bW9zcGhlcmUgdmFyaWFudD0naG9yaXpvbicgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J3JlbGF0aXZlIHotMTAgY29udGFpbmVyIG14LWF1dG8gcHgtNCc+XG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIHJlZj17cmVmfVxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAzMCB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB5OiAwIH0gOiB7fX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuOCB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPSdtYXgtdy0zeGwgbXgtYXV0byB0ZXh0LWNlbnRlcidcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RmxpZ2h0TG9nXG4gICAgICAgICAgICAgIGVudHJpZXM9e1tcbiAgICAgICAgICAgICAgICAnSE9SSVpPTiAvIENPTlRBQ1QnLFxuICAgICAgICAgICAgICAgICdDTEVBUkVEIEZPUiBMQU5ESU5HJyxcbiAgICAgICAgICAgICAgICAnQVBQUk9BQ0ggwrcgRklOQUwnLFxuICAgICAgICAgICAgICAgICdPTiBUSEUgR1JPVU5EIMK3IENIQVQnLFxuICAgICAgICAgICAgICBdfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9J3RleHQtNHhsIG1kOnRleHQtNnhsIGZvbnQtYm9sZCBmb250LWhlYWRpbmcgdHJhY2tpbmctdGlnaHQgbGVhZGluZy10aWdodCc+XG4gICAgICAgICAgICAgIExldCZhcG9zO3MgQnVpbGQgU29tZXRoaW5neycgJ31cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdnb2xkLXRleHQnPlJlbGlhYmxlLjwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9J210LTYgdGV4dC1sZyB0ZXh0LW1pc3Qtc29mdCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1saWdodCBtYXgtdy0yeGwgbXgtYXV0byc+XG4gICAgICAgICAgICAgIFdoZXRoZXIgeW91IG5lZWQgdGVjaG5pY2FsIHN1cHBvcnQsIGluZnJhc3RydWN0dXJlIHdvcmssIHNvZnR3YXJlXG4gICAgICAgICAgICAgIGRldmVsb3BtZW50LCBvciBhbiBlbmdpbmVlcmluZy1taW5kZWQgcHJvYmxlbSBzb2x2ZXIgLSBsZXQmYXBvcztzXG4gICAgICAgICAgICAgIHRhbGsuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICBpbml0aWFsPXt7IHdpZHRoOiAwIH19XG4gICAgICAgICAgICAgIGFuaW1hdGU9e2luVmlldyA/IHsgd2lkdGg6IDEyMCB9IDoge319XG4gICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuNSwgZHVyYXRpb246IDAuOCB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9J2gtcHggYmctZ3JhZGllbnQtZ29sZCBteC1hdXRvIHJvdW5kZWQtZnVsbCBtdC04J1xuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogQ29udGVudCAqL31cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT0ncmVsYXRpdmUgcGItMTYgb3ZlcmZsb3ctaGlkZGVuJz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J2NvbnRhaW5lciBteC1hdXRvIHB4LTQgbWF4LXctNnhsJz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZ3JpZCBsZzpncmlkLWNvbHMtMyBnYXAtOCc+XG4gICAgICAgICAgICB7LyogQ29udGFjdCBJbmZvcm1hdGlvbiAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdsZzpjb2wtc3Bhbi0xIHNwYWNlLXktNic+XG4gICAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB4OiAtMzAgfX1cbiAgICAgICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHg6IDAgfSA6IHt9fVxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuOCwgZHVyYXRpb246IDAuNiB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPSdnbGFzcy1jbG91ZCc+XG4gICAgICAgICAgICAgICAgICA8Q2FyZEhlYWRlcj5cbiAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZSBjbGFzc05hbWU9J2ZvbnQtaGVhZGluZyc+XG4gICAgICAgICAgICAgICAgICAgICAgQ29udGFjdCBJbmZvcm1hdGlvblxuICAgICAgICAgICAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICAgICAgICAgIDwvQ2FyZEhlYWRlcj5cbiAgICAgICAgICAgICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9J3NwYWNlLXktNCc+XG4gICAgICAgICAgICAgICAgICAgIHtjb250YWN0TWV0aG9kcy5tYXAoKG1ldGhvZCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXttZXRob2QubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHk6IDAgfSA6IHt9fVxuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxheTogMS4wICsgaW5kZXggKiAwLjA4LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBkdXJhdGlvbjogMC41LFxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZmxleCBpdGVtcy1zdGFydCBnYXAtMyBwLTMgcm91bmRlZC1sZyBob3ZlcjpiZy13aGl0ZS81IHRyYW5zaXRpb24tY29sb3JzIGdyb3VwJ1xuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdwLTIgYmctZ29sZC8xMCByb3VuZGVkLWxnIHNocmluay0wJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG1ldGhvZC5pY29uIGNsYXNzTmFtZT0naC00IHctNCBnb2xkLXRleHQnIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4LTEgbWluLXctMCc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMic+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSdmb250LW1lZGl1bSB0ZXh0LXNtJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttZXRob2QubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttZXRob2QuY29weWFibGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPSdzbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD0nZ2hvc3QnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0naC02IHctNiBwLTAgaG92ZXI6YmctZ29sZC8xMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3B5VG9DbGlwYm9hcmQobWV0aG9kLnZhbHVlLCBtZXRob2QubGFiZWwpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YENvcHkgJHttZXRob2QubGFiZWx9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvcGllZCA9PT0gbWV0aG9kLmxhYmVsID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9J2gtMyB3LTMgdGV4dC1nb2xkJyAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDb3B5IGNsYXNzTmFtZT0naC0zIHctMycgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtc20gdGV4dC1taXN0LXNvZnQgbWItMSc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge21ldGhvZC52YWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQteHMgdGV4dC1taXN0LXNvZnQvNzAnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttZXRob2QuZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB4OiAtMzAgfX1cbiAgICAgICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHg6IDAgfSA6IHt9fVxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDEuMSwgZHVyYXRpb246IDAuNiB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPSdnbGFzcy1jbG91ZCc+XG4gICAgICAgICAgICAgICAgICA8Q2FyZEhlYWRlcj5cbiAgICAgICAgICAgICAgICAgICAgPENhcmRUaXRsZSBjbGFzc05hbWU9J2ZvbnQtaGVhZGluZyc+XG4gICAgICAgICAgICAgICAgICAgICAgQ29ubmVjdCBPbmxpbmVcbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgICAgICAgICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICAgICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPSdzcGFjZS15LTMnPlxuICAgICAgICAgICAgICAgICAgICB7c29jaWFsTGlua3MubWFwKChzb2NpYWwsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPG1vdGlvbi5hXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3NvY2lhbC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3NvY2lhbC5ocmVmfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PSdfYmxhbmsnXG4gICAgICAgICAgICAgICAgICAgICAgICByZWw9J25vb3BlbmVyIG5vcmVmZXJyZXInXG4gICAgICAgICAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgICAgICAgICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHk6IDAgfSA6IHt9fVxuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17e1xuICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxheTogMS4zICsgaW5kZXggKiAwLjA4LFxuICAgICAgICAgICAgICAgICAgICAgICAgICBkdXJhdGlvbjogMC41LFxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC0zIHJvdW5kZWQtbGcgaG92ZXI6Ymctd2hpdGUvNSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZ3JvdXAnXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3AtMiBiZy1nb2xkLzEwIHJvdW5kZWQtbGcgc2hyaW5rLTAnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c29jaWFsLmljb24gY2xhc3NOYW1lPSdoLTQgdy00IGdvbGQtdGV4dCcgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSdmb250LW1lZGl1bSB0ZXh0LXNtIGdyb3VwLWhvdmVyOnRleHQtZ29sZCB0cmFuc2l0aW9uLWNvbG9ycyc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3NvY2lhbC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQteHMgdGV4dC1taXN0LXNvZnQnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzb2NpYWwuZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvbW90aW9uLmE+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cbiAgICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeDogLTMwIH19XG4gICAgICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB4OiAwIH0gOiB7fX1cbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAxLjQsIGR1cmF0aW9uOiAwLjYgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT0nZ2xhc3MtY2xvdWQnPlxuICAgICAgICAgICAgICAgICAgPENhcmRIZWFkZXI+XG4gICAgICAgICAgICAgICAgICAgIDxDYXJkVGl0bGUgY2xhc3NOYW1lPSdmb250LWhlYWRpbmcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTInPlxuICAgICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9J2gtNSB3LTUgZ29sZC10ZXh0JyAvPlxuICAgICAgICAgICAgICAgICAgICAgIFdvcmtpbmcgSG91cnNcbiAgICAgICAgICAgICAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgICAgICAgICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICAgICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPSdzcGFjZS15LTInPlxuICAgICAgICAgICAgICAgICAgICB7d29ya2luZ0hvdXJzLm1hcCgoc2NoZWR1bGUsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHRleHQtc20nXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSd0ZXh0LW1pc3Qtc29mdCc+e3NjaGVkdWxlLmRheX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2dsYXNzIHB4LTIuNSBweS0wLjUgcm91bmRlZC1tZCB0ZXh0LXhzIHRleHQtbWlzdC1zb2Z0Jz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NjaGVkdWxlLnRpbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cbiAgICAgICAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeDogLTMwIH19XG4gICAgICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB4OiAwIH0gOiB7fX1cbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAxLjUsIGR1cmF0aW9uOiAwLjYgfX1cbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPSdCb2FyZGluZyBwYXNzJ1xuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2dsYXNzLWNsb3VkIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbic+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTUgcHktMyBib3JkZXItYiBib3JkZXItZGFzaGVkIGJvcmRlci1ib3JkZXIvNjAnPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LVsxMHB4XSB0cmFja2luZy1bMC4yNWVtXSB0ZXh0LW1pc3Qtc29mdCc+XG4gICAgICAgICAgICAgICAgICAgICAgQk9BUkRJTkcgUEFTU1xuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxQbGFuZSBjbGFzc05hbWU9J2gtNCB3LTQgZ29sZC10ZXh0JyBhcmlhLWhpZGRlbj0ndHJ1ZScgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3B4LTUgcHktNCBzcGFjZS15LTIuNSc+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGp1c3RpZnktYmV0d2Vlbic+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdmb250LW1vbm8gdGV4dC1bMTBweF0gdHJhY2tpbmctWzAuMmVtXSB0ZXh0LW1pc3Qtc29mdC83MCc+XG4gICAgICAgICAgICAgICAgICAgICAgICBQQVNTRU5HRVJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSd0ZXh0LXNtIGZvbnQtbWVkaXVtJz5FUk1JQVMgTEVNRVNBPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXgganVzdGlmeS1iZXR3ZWVuJz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LVsxMHB4XSB0cmFja2luZy1bMC4yZW1dIHRleHQtbWlzdC1zb2Z0LzcwJz5cbiAgICAgICAgICAgICAgICAgICAgICAgIEZST01cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSd0ZXh0LXNtJz5BRERJUyBBQkFCQTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGp1c3RpZnktYmV0d2Vlbic+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdmb250LW1vbm8gdGV4dC1bMTBweF0gdHJhY2tpbmctWzAuMmVtXSB0ZXh0LW1pc3Qtc29mdC83MCc+XG4gICAgICAgICAgICAgICAgICAgICAgICBUT1xuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J3RleHQtc20nPlJFTU9URSDCtyBXT1JMRFdJREU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBqdXN0aWZ5LWJldHdlZW4nPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQtWzEwcHhdIHRyYWNraW5nLVswLjJlbV0gdGV4dC1taXN0LXNvZnQvNzAnPlxuICAgICAgICAgICAgICAgICAgICAgICAgQ0xBU1NcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSd0ZXh0LXNtJz5TRU5JT1IgSVQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIGJvcmRlci10IGJvcmRlci1kYXNoZWQgYm9yZGVyLWJvcmRlci82MCBwdC0yLjUnPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQtWzEwcHhdIHRyYWNraW5nLVswLjJlbV0gdGV4dC1taXN0LXNvZnQvNzAnPlxuICAgICAgICAgICAgICAgICAgICAgICAgU0VBVFxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIGdvbGQtdGV4dCc+MDFBPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIENvbnRhY3QgRm9ybSAqL31cbiAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeDogMzAgfX1cbiAgICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB4OiAwIH0gOiB7fX1cbiAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC44LCBkdXJhdGlvbjogMC42IH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT0nbGc6Y29sLXNwYW4tMidcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPSdnbGFzcy1jbG91ZCc+XG4gICAgICAgICAgICAgICAgPENhcmRIZWFkZXI+XG4gICAgICAgICAgICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT0nZm9udC1oZWFkaW5nJz5cbiAgICAgICAgICAgICAgICAgICAgU2VuZCBtZSBhIG1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSd0ZXh0LW1pc3Qtc29mdCc+XG4gICAgICAgICAgICAgICAgICAgIEhhdmUgYSBwcm9qZWN0IGluIG1pbmQ/IExldCZhcG9zO3MgZGlzY3VzcyBob3cgd2UgY2FuIHdvcmtcbiAgICAgICAgICAgICAgICAgICAgdG9nZXRoZXIuXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgICAgICAgICAgIDxDYXJkQ29udGVudD5cbiAgICAgICAgICAgICAgICAgIDxmb3JtXG4gICAgICAgICAgICAgICAgICAgIHJlZj17Zm9ybVJlZn1cbiAgICAgICAgICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdzcGFjZS15LTYnXG4gICAgICAgICAgICAgICAgICAgIG5vVmFsaWRhdGVcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgey8qIEhvbmV5cG90IOKAlCBoaWRkZW4gZnJvbSBodW1hbnMsIHZpc2libGUgdG8gYm90cyAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Fic29sdXRlIG9wYWNpdHktMCBoLTAgb3ZlcmZsb3ctaGlkZGVuJyBhcmlhLWhpZGRlbj0ndHJ1ZSc+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9J3dlYnNpdGUnPkxlYXZlIHRoaXMgZW1wdHk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9J3dlYnNpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSd3ZWJzaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLndlYnNpdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJJbmRleD17LTF9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9J29mZidcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2dyaWQgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTQnPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdzcGFjZS15LTInPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9J25hbWUnIGNsYXNzTmFtZT0ndGV4dC1zbSBmb250LW1lZGl1bSc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIEZ1bGwgTmFtZSAqXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPSduYW1lJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSduYW1lJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj0nSm9obiBEb2UnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1NlbmRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtaW52YWxpZD17ISFmb3JtRXJyb3JzLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nYmctd2hpdGUvWzAuMDJdIGJvcmRlci1ib3JkZXIgZm9jdXM6Ym9yZGVyLWdvbGQvNTAnXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1FcnJvcnMubmFtZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0ndGV4dC14cyB0ZXh0LWRlc3RydWN0aXZlJz57Zm9ybUVycm9ycy5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3NwYWNlLXktMic+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj0nZW1haWwnIGNsYXNzTmFtZT0ndGV4dC1zbSBmb250LW1lZGl1bSc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVtYWlsIEFkZHJlc3MgKlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZD0nZW1haWwnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J2VtYWlsJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPSdlbWFpbCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVtYWlsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPSdqb2huQGV4YW1wbGUuY29tJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTZW5kaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWludmFsaWQ9eyEhZm9ybUVycm9ycy5lbWFpbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdiZy13aGl0ZS9bMC4wMl0gYm9yZGVyLWJvcmRlciBmb2N1czpib3JkZXItZ29sZC81MCdcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybUVycm9ycy5lbWFpbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0ndGV4dC14cyB0ZXh0LWRlc3RydWN0aXZlJz57Zm9ybUVycm9ycy5lbWFpbH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nc3BhY2UteS0yJz5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj0nc3ViamVjdCcgY2xhc3NOYW1lPSd0ZXh0LXNtIGZvbnQtbWVkaXVtJz5cbiAgICAgICAgICAgICAgICAgICAgICAgIFN1YmplY3QgKlxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+ICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPSdzdWJqZWN0J1xuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdzdWJqZWN0J1xuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc3ViamVjdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj0nUHJvamVjdCBpbnF1aXJ5LCBjb2xsYWJvcmF0aW9uLCBldGMuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTZW5kaW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWludmFsaWQ9eyEhZm9ybUVycm9ycy5zdWJqZWN0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2JnLXdoaXRlL1swLjAyXSBib3JkZXItYm9yZGVyIGZvY3VzOmJvcmRlci1nb2xkLzUwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRXJyb3JzLnN1YmplY3QgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQteHMgdGV4dC1kZXN0cnVjdGl2ZSc+e2Zvcm1FcnJvcnMuc3ViamVjdH08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nc3BhY2UteS0yJz5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj0nbWVzc2FnZScgY2xhc3NOYW1lPSd0ZXh0LXNtIGZvbnQtbWVkaXVtJz5cbiAgICAgICAgICAgICAgICAgICAgICAgIE1lc3NhZ2UgKlxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPFRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD0nbWVzc2FnZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J21lc3NhZ2UnXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPSdUZWxsIG1lIGFib3V0IHlvdXIgcHJvamVjdCwgdGltZWxpbmUsIGJ1ZGdldCwgYW5kIGFueSBzcGVjaWZpYyByZXF1aXJlbWVudHMuLi4nXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dzPXs2fVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1NlbmRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWludmFsaWQ9eyEhZm9ybUVycm9ycy5tZXNzYWdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdiZy13aGl0ZS9bMC4wM10gYm9yZGVyLXdoaXRlLzEwIGZvY3VzOmJvcmRlci1nb2xkLzUwIHJlc2l6ZS1ub25lJ1xuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAge2Zvcm1FcnJvcnMubWVzc2FnZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQteHMgdGV4dC1kZXN0cnVjdGl2ZSc+e2Zvcm1FcnJvcnMubWVzc2FnZX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQteHMgdGV4dC1taXN0LXNvZnQvNjAgdGV4dC1yaWdodCc+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEubWVzc2FnZS5sZW5ndGh9LzIwMDBcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPSdzdWJtaXQnXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2VuZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J3ctZnVsbCBiZy1taXN0IHRleHQtc3Rvcm0tZGVlcCBob3ZlcjpiZy1taXN0LzkwIGhvdmVyOnNoYWRvdy1nbG93LXN0cm9uZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZGlzYWJsZWQ6b3BhY2l0eS03MCdcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtpc1NlbmRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9J21yLTIgaC00IHctNCBhbmltYXRlLXNwaW4nIC8+eycgJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgU2VuZGluZ+KAplxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT0nbXItMiBoLTQgdy00JyAvPiBTZW5kIE1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBSZXNwb25zZSBUaW1lIE5vdGljZSAqL31cbiAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAzMCB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB5OiAwIH0gOiB7fX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDEuNiwgZHVyYXRpb246IDAuNiB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPSdtdC0xMiB0ZXh0LWNlbnRlcidcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9J2dsYXNzLWNsb3VkIG1heC13LTJ4bCBteC1hdXRvJz5cbiAgICAgICAgICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT0ncC02Jz5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPSdmb250LWhlYWRpbmcgZm9udC1zZW1pYm9sZCBtYi0yJz5cbiAgICAgICAgICAgICAgICAgIFF1aWNrIFJlc3BvbnNlIEd1YXJhbnRlZVxuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSd0ZXh0LW1pc3Qtc29mdCB0ZXh0LXNtJz5cbiAgICAgICAgICAgICAgICAgIEkgdHlwaWNhbGx5IHJlc3BvbmQgdG8gYWxsIGlucXVpcmllcyB3aXRoaW57JyAnfVxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdnb2xkLXRleHQgZm9udC1tZWRpdW0nPjI0IGhvdXJzPC9zcGFuPi4gRm9yXG4gICAgICAgICAgICAgICAgICB1cmdlbnQgbWF0dGVycywgcGxlYXNlIHVzZSBUZWxlZ3JhbSBvciBjYWxsIGRpcmVjdGx5LlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9DYXJkQ29udGVudD5cbiAgICAgICAgICAgIDwvQ2FyZD5cbiAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuICAgICAgPEZvb3RlciAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQ29udGFjdDtcbiJdLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlUmVmIiwiZW1haWxqcyIsIm1vdGlvbiIsInVzZUluVmlldyIsIk1haWwiLCJQaG9uZSIsIk1hcFBpbiIsIkdpdGh1YiIsIk1lc3NhZ2VTcXVhcmUiLCJTZW5kIiwiQ29weSIsIkNoZWNrIiwiQ2xvY2siLCJMb2FkZXIyIiwiUGxhbmUiLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiQnV0dG9uIiwiSW5wdXQiLCJUZXh0YXJlYSIsIk5hdmlnYXRpb24iLCJGb290ZXIiLCJBdG1vc3BoZXJlIiwiRmxpZ2h0TG9nIiwiU0VPIiwiU3RydWN0dXJlZERhdGEiLCJ1c2VTRU8iLCJ1c2VTdHJ1Y3R1cmVkRGF0YSIsInVzZVRvYXN0IiwiQ29udGFjdCIsInNlb1Byb3BzIiwiYnJlYWRjcnVtYlNjaGVtYSIsImZvcm1SZWYiLCJyZWYiLCJpblZpZXciLCJ0cmlnZ2VyT25jZSIsInRocmVzaG9sZCIsInRvYXN0IiwiY29waWVkIiwic2V0Q29waWVkIiwiaXNTZW5kaW5nIiwic2V0SXNTZW5kaW5nIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsIm5hbWUiLCJlbWFpbCIsInN1YmplY3QiLCJtZXNzYWdlIiwid2Vic2l0ZSIsImZvcm1FcnJvcnMiLCJzZXRGb3JtRXJyb3JzIiwiY29udGFjdE1ldGhvZHMiLCJpY29uIiwibGFiZWwiLCJ2YWx1ZSIsImhyZWYiLCJkZXNjcmlwdGlvbiIsImNvcHlhYmxlIiwic29jaWFsTGlua3MiLCJ3b3JraW5nSG91cnMiLCJkYXkiLCJ0aW1lIiwiY29weVRvQ2xpcGJvYXJkIiwidGV4dCIsIm5hdmlnYXRvciIsImNsaXBib2FyZCIsIndyaXRlVGV4dCIsInRpdGxlIiwic2V0VGltZW91dCIsInZhcmlhbnQiLCJ2YWxpZGF0ZUZvcm0iLCJlcnJvcnMiLCJ0cmltIiwibGVuZ3RoIiwidGVzdCIsIk9iamVjdCIsImtleXMiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJzZXJ2aWNlSWQiLCJlbnYiLCJWSVRFX0VNQUlMSlNfU0VSVklDRV9JRCIsInRlbXBsYXRlSWQiLCJWSVRFX0VNQUlMSlNfVEVNUExBVEVfSUQiLCJwdWJsaWNLZXkiLCJWSVRFX0VNQUlMSlNfUFVCTElDX0tFWSIsInNlbmQiLCJmcm9tX25hbWUiLCJmcm9tX2VtYWlsIiwidG9fZW1haWwiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJoYW5kbGVJbnB1dENoYW5nZSIsInByZXYiLCJ0YXJnZXQiLCJkaXYiLCJjbGFzc05hbWUiLCJzY2hlbWEiLCJzZWN0aW9uIiwiaW5pdGlhbCIsIm9wYWNpdHkiLCJ5IiwiYW5pbWF0ZSIsInRyYW5zaXRpb24iLCJkdXJhdGlvbiIsImVudHJpZXMiLCJoMSIsInNwYW4iLCJwIiwid2lkdGgiLCJkZWxheSIsIngiLCJtYXAiLCJtZXRob2QiLCJpbmRleCIsInNpemUiLCJvbkNsaWNrIiwiYXJpYS1sYWJlbCIsInNvY2lhbCIsImEiLCJyZWwiLCJzY2hlZHVsZSIsImFyaWEtaGlkZGVuIiwiZm9ybSIsIm9uU3VibWl0Iiwibm9WYWxpZGF0ZSIsImh0bWxGb3IiLCJpZCIsIm9uQ2hhbmdlIiwidGFiSW5kZXgiLCJhdXRvQ29tcGxldGUiLCJwbGFjZWhvbGRlciIsInJlcXVpcmVkIiwiZGlzYWJsZWQiLCJhcmlhLWludmFsaWQiLCJ0eXBlIiwicm93cyIsImgzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsUUFBUSxFQUFFQyxNQUFNLFFBQVEsUUFBUTtBQUNoRCxPQUFPQyxhQUFhLG1CQUFtQjtBQUN2QyxTQUFTQyxNQUFNLFFBQVEsZ0JBQWdCO0FBQ3ZDLFNBQVNDLFNBQVMsUUFBUSw4QkFBOEI7QUFDeEQsU0FDRUMsSUFBSSxFQUNKQyxLQUFLLEVBQ0xDLE1BQU0sRUFDTkMsTUFBTSxFQUNOQyxhQUFhLEVBQ2JDLElBQUksRUFDSkMsSUFBSSxFQUNKQyxLQUFLLEVBQ0xDLEtBQUssRUFDTEMsT0FBTyxFQUNQQyxLQUFLLFFBQ0EsZUFBZTtBQUN0QixTQUFTQyxJQUFJLEVBQUVDLFdBQVcsRUFBRUMsVUFBVSxFQUFFQyxTQUFTLFFBQVEsdUJBQXVCO0FBQ2hGLFNBQVNDLE1BQU0sUUFBUSx5QkFBeUI7QUFDaEQsU0FBU0MsS0FBSyxRQUFRLHdCQUF3QjtBQUM5QyxTQUFTQyxRQUFRLFFBQVEsMkJBQTJCO0FBQ3BELE9BQU9DLGdCQUFnQixpQ0FBaUM7QUFDeEQsT0FBT0MsWUFBWSw2QkFBNkI7QUFDaEQsT0FBT0MsZ0JBQWdCLHFDQUFxQztBQUM1RCxPQUFPQyxlQUFlLDZCQUE2QjtBQUNuRCxPQUFPQyxTQUFTLHVCQUF1QjtBQUN2QyxPQUFPQyxvQkFBb0Isa0NBQWtDO0FBQzdELFNBQVNDLE1BQU0sUUFBUSxrQkFBa0I7QUFDekMsU0FBU0MsaUJBQWlCLFFBQVEsOEJBQThCO0FBQ2hFLFNBQVNDLFFBQVEsUUFBUSw0QkFBNEI7QUFFckQsTUFBTUMsVUFBVTs7SUFDZCxNQUFNQyxXQUFXSjtJQUNqQixNQUFNLEVBQUVLLGdCQUFnQixFQUFFLEdBQUdKO0lBQzdCLE1BQU1LLFVBQVVsQyxPQUF3QjtJQUV4QyxNQUFNLENBQUNtQyxLQUFLQyxPQUFPLEdBQUdqQyxVQUFVO1FBQzlCa0MsYUFBYTtRQUNiQyxXQUFXO0lBQ2I7SUFFQSxNQUFNLEVBQUVDLEtBQUssRUFBRSxHQUFHVDtJQUNsQixNQUFNLENBQUNVLFFBQVFDLFVBQVUsR0FBRzFDLFNBQXdCO0lBQ3BELE1BQU0sQ0FBQzJDLFdBQVdDLGFBQWEsR0FBRzVDLFNBQVM7SUFDM0MsTUFBTSxDQUFDNkMsVUFBVUMsWUFBWSxHQUFHOUMsU0FBUztRQUN2QytDLE1BQU07UUFDTkMsT0FBTztRQUNQQyxTQUFTO1FBQ1RDLFNBQVM7UUFDVEMsU0FBUztJQUNYO0lBQ0EsTUFBTSxDQUFDQyxZQUFZQyxjQUFjLEdBQUdyRCxTQUFpQyxDQUFDO0lBRXRFLE1BQU1zRCxpQkFBaUI7UUFDckI7WUFDRUMsTUFBTWxEO1lBQ05tRCxPQUFPO1lBQ1BDLE9BQU87WUFDUEMsTUFBTTtZQUNOQyxhQUFhO1lBQ2JDLFVBQVU7UUFDWjtRQUNBO1lBQ0VMLE1BQU1qRDtZQUNOa0QsT0FBTztZQUNQQyxPQUFPO1lBQ1BDLE1BQU07WUFDTkMsYUFBYTtZQUNiQyxVQUFVO1FBQ1o7UUFDQTtZQUNFTCxNQUFNOUM7WUFDTitDLE9BQU87WUFDUEMsT0FBTztZQUNQQyxNQUFNO1lBQ05DLGFBQWE7WUFDYkMsVUFBVTtRQUNaO1FBQ0E7WUFDRUwsTUFBTWhEO1lBQ05pRCxPQUFPO1lBQ1BDLE9BQU87WUFDUEMsTUFBTTtZQUNOQyxhQUFhO1lBQ2JDLFVBQVU7UUFDWjtLQUNEO0lBRUQsTUFBTUMsY0FBYztRQUNsQjtZQUNFTixNQUFNL0M7WUFDTmdELE9BQU87WUFDUEUsTUFBTTtZQUNOQyxhQUFhO1FBQ2Y7UUFDQTtZQUNFSixNQUFNOUM7WUFDTitDLE9BQU87WUFDUEUsTUFBTTtZQUNOQyxhQUFhO1FBQ2Y7S0FDRDtJQUVELE1BQU1HLGVBQWU7UUFDbkI7WUFBRUMsS0FBSztZQUFtQkMsTUFBTTtRQUF3QjtRQUN4RDtZQUFFRCxLQUFLO1lBQVlDLE1BQU07UUFBeUI7UUFDbEQ7WUFBRUQsS0FBSztZQUFVQyxNQUFNO1FBQWlCO0tBQ3pDO0lBRUQsTUFBTUMsa0JBQWtCLE9BQU9DLE1BQWNWO1FBQzNDLElBQUk7WUFDRixNQUFNVyxVQUFVQyxTQUFTLENBQUNDLFNBQVMsQ0FBQ0g7WUFDcEN4QixVQUFVYztZQUNWaEIsTUFBTTtnQkFDSjhCLE9BQU87Z0JBQ1BYLGFBQWEsR0FBR0gsTUFBTSxvQkFBb0IsQ0FBQztZQUM3QztZQUNBZSxXQUFXLElBQU03QixVQUFVLE9BQU87UUFDcEMsRUFBRSxPQUFNO1lBQ05GLE1BQU07Z0JBQ0o4QixPQUFPO2dCQUNQWCxhQUFhO2dCQUNiYSxTQUFTO1lBQ1g7UUFDRjtJQUNGO0lBRUEsTUFBTUMsZUFBZTtRQUNuQixNQUFNQyxTQUFpQyxDQUFDO1FBRXhDLGlCQUFpQjtRQUNqQixJQUFJN0IsU0FBU00sT0FBTyxFQUFFO1lBQ3BCLE9BQU8sT0FBTyx1QkFBdUI7UUFDdkM7UUFFQSxNQUFNSixPQUFPRixTQUFTRSxJQUFJLENBQUM0QixJQUFJO1FBQy9CLElBQUk1QixLQUFLNkIsTUFBTSxHQUFHLEdBQUc7WUFDbkJGLE9BQU8zQixJQUFJLEdBQUc7UUFDaEI7UUFFQSxNQUFNQyxRQUFRSCxTQUFTRyxLQUFLLENBQUMyQixJQUFJO1FBQ2pDLElBQUksQ0FBQyw2QkFBNkJFLElBQUksQ0FBQzdCLFFBQVE7WUFDN0MwQixPQUFPMUIsS0FBSyxHQUFHO1FBQ2pCO1FBRUEsTUFBTUMsVUFBVUosU0FBU0ksT0FBTyxDQUFDMEIsSUFBSTtRQUNyQyxJQUFJMUIsUUFBUTJCLE1BQU0sR0FBRyxHQUFHO1lBQ3RCRixPQUFPekIsT0FBTyxHQUFHO1FBQ25CO1FBRUEsTUFBTUMsVUFBVUwsU0FBU0ssT0FBTyxDQUFDeUIsSUFBSTtRQUNyQyxJQUFJekIsUUFBUTBCLE1BQU0sR0FBRyxJQUFJO1lBQ3ZCRixPQUFPeEIsT0FBTyxHQUFHO1FBQ25CLE9BQU8sSUFBSUEsUUFBUTBCLE1BQU0sR0FBRyxNQUFNO1lBQ2hDRixPQUFPeEIsT0FBTyxHQUFHO1FBQ25CO1FBRUFHLGNBQWNxQjtRQUNkLE9BQU9JLE9BQU9DLElBQUksQ0FBQ0wsUUFBUUUsTUFBTSxLQUFLO0lBQ3hDO0lBRUEsTUFBTUksZUFBZSxPQUFPQztRQUMxQkEsRUFBRUMsY0FBYztRQUVoQixJQUFJLENBQUNULGdCQUFnQjtRQUVyQixNQUFNVSxZQUFZLFlBQVlDLEdBQUcsQ0FBQ0MsdUJBQXVCO1FBQ3pELE1BQU1DLGFBQWEsWUFBWUYsR0FBRyxDQUFDRyx3QkFBd0I7UUFDM0QsTUFBTUMsWUFBWSxZQUFZSixHQUFHLENBQUNLLHVCQUF1QjtRQUV6RCxJQUFJLENBQUNOLGFBQWEsQ0FBQ0csY0FBYyxDQUFDRSxXQUFXO1lBQzNDaEQsTUFBTTtnQkFDSjhCLE9BQU87Z0JBQ1BYLGFBQ0U7Z0JBQ0ZhLFNBQVM7WUFDWDtZQUNBO1FBQ0Y7UUFFQTVCLGFBQWE7UUFDYixJQUFJO1lBQ0YsTUFBTTFDLFFBQVF3RixJQUFJLENBQ2hCUCxXQUNBRyxZQUNBO2dCQUNFSyxXQUFXOUMsU0FBU0UsSUFBSTtnQkFDeEI2QyxZQUFZL0MsU0FBU0csS0FBSztnQkFDMUJDLFNBQVNKLFNBQVNJLE9BQU87Z0JBQ3pCQyxTQUFTTCxTQUFTSyxPQUFPO2dCQUN6QjJDLFVBQVU7WUFDWixHQUNBTDtZQUVGaEQsTUFBTTtnQkFDSjhCLE9BQU87Z0JBQ1BYLGFBQWE7WUFDZjtZQUNBYixZQUFZO2dCQUFFQyxNQUFNO2dCQUFJQyxPQUFPO2dCQUFJQyxTQUFTO2dCQUFJQyxTQUFTO1lBQUc7UUFDOUQsRUFBRSxPQUFPNEMsS0FBSztZQUNaQyxRQUFRQyxLQUFLLENBQUMsa0JBQWtCRjtZQUNoQ3RELE1BQU07Z0JBQ0o4QixPQUFPO2dCQUNQWCxhQUNFO2dCQUNGYSxTQUFTO1lBQ1g7UUFDRixTQUFVO1lBQ1I1QixhQUFhO1FBQ2Y7SUFDRjtJQUVBLE1BQU1xRCxvQkFBb0IsQ0FDeEJoQjtRQUVBbkMsWUFBWW9ELENBQUFBLE9BQVMsQ0FBQTtnQkFDbkIsR0FBR0EsSUFBSTtnQkFDUCxDQUFDakIsRUFBRWtCLE1BQU0sQ0FBQ3BELElBQUksQ0FBQyxFQUFFa0MsRUFBRWtCLE1BQU0sQ0FBQzFDLEtBQUs7WUFDakMsQ0FBQTtJQUNGO0lBRUEscUJBQ0UsUUFBQzJDO1FBQUlDLFdBQVU7OzBCQUNiLFFBQUMxRTtnQkFBSyxHQUFHTSxRQUFROzs7Ozs7MEJBQ2pCLFFBQUNMO2dCQUFlMEUsUUFBUXBFOzs7Ozs7MEJBQ3hCLFFBQUNYOzs7OzswQkFHRCxRQUFDZ0Y7Z0JBQVFGLFdBQVU7O2tDQUNqQixRQUFDNUU7d0JBQVcrQyxTQUFROzs7Ozs7a0NBQ3BCLFFBQUM0Qjt3QkFBSUMsV0FBVTtrQ0FDYixjQUFBLFFBQUNsRyxPQUFPaUcsR0FBRzs0QkFDVGhFLEtBQUtBOzRCQUNMb0UsU0FBUztnQ0FBRUMsU0FBUztnQ0FBR0MsR0FBRzs0QkFBRzs0QkFDN0JDLFNBQVN0RSxTQUFTO2dDQUFFb0UsU0FBUztnQ0FBR0MsR0FBRzs0QkFBRSxJQUFJLENBQUM7NEJBQzFDRSxZQUFZO2dDQUFFQyxVQUFVOzRCQUFJOzRCQUM1QlIsV0FBVTs7OENBRVYsUUFBQzNFO29DQUNDb0YsU0FBUzt3Q0FDUDt3Q0FDQTt3Q0FDQTt3Q0FDQTtxQ0FDRDs7Ozs7OzhDQUVILFFBQUNDO29DQUFHVixXQUFVOzt3Q0FBMkU7d0NBQzVEO3NEQUMzQixRQUFDVzs0Q0FBS1gsV0FBVTtzREFBWTs7Ozs7Ozs7Ozs7OzhDQUU5QixRQUFDWTtvQ0FBRVosV0FBVTs4Q0FBMkU7Ozs7Ozs4Q0FLeEYsUUFBQ2xHLE9BQU9pRyxHQUFHO29DQUNUSSxTQUFTO3dDQUFFVSxPQUFPO29DQUFFO29DQUNwQlAsU0FBU3RFLFNBQVM7d0NBQUU2RSxPQUFPO29DQUFJLElBQUksQ0FBQztvQ0FDcENOLFlBQVk7d0NBQUVPLE9BQU87d0NBQUtOLFVBQVU7b0NBQUk7b0NBQ3hDUixXQUFVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswQkFPbEIsUUFBQ0U7Z0JBQVFGLFdBQVU7MEJBQ2pCLGNBQUEsUUFBQ0Q7b0JBQUlDLFdBQVU7O3NDQUNiLFFBQUNEOzRCQUFJQyxXQUFVOzs4Q0FFYixRQUFDRDtvQ0FBSUMsV0FBVTs7c0RBQ2IsUUFBQ2xHLE9BQU9pRyxHQUFHOzRDQUNUSSxTQUFTO2dEQUFFQyxTQUFTO2dEQUFHVyxHQUFHLENBQUM7NENBQUc7NENBQzlCVCxTQUFTdEUsU0FBUztnREFBRW9FLFNBQVM7Z0RBQUdXLEdBQUc7NENBQUUsSUFBSSxDQUFDOzRDQUMxQ1IsWUFBWTtnREFBRU8sT0FBTztnREFBS04sVUFBVTs0Q0FBSTtzREFFeEMsY0FBQSxRQUFDN0Y7Z0RBQUtxRixXQUFVOztrRUFDZCxRQUFDbkY7a0VBQ0MsY0FBQSxRQUFDQzs0REFBVWtGLFdBQVU7c0VBQWU7Ozs7Ozs7Ozs7O2tFQUl0QyxRQUFDcEY7d0RBQVlvRixXQUFVO2tFQUNwQi9DLGVBQWUrRCxHQUFHLENBQUMsQ0FBQ0MsUUFBUUMsc0JBQzNCLFFBQUNwSCxPQUFPaUcsR0FBRztnRUFFVEksU0FBUztvRUFBRUMsU0FBUztvRUFBR0MsR0FBRztnRUFBRztnRUFDN0JDLFNBQVN0RSxTQUFTO29FQUFFb0UsU0FBUztvRUFBR0MsR0FBRztnRUFBRSxJQUFJLENBQUM7Z0VBQzFDRSxZQUFZO29FQUNWTyxPQUFPLE1BQU1JLFFBQVE7b0VBQ3JCVixVQUFVO2dFQUNaO2dFQUNBUixXQUFVOztrRkFFVixRQUFDRDt3RUFBSUMsV0FBVTtrRkFDYixjQUFBLFFBQUNpQixPQUFPL0QsSUFBSTs0RUFBQzhDLFdBQVU7Ozs7Ozs7Ozs7O2tGQUV6QixRQUFDRDt3RUFBSUMsV0FBVTs7MEZBQ2IsUUFBQ0Q7Z0ZBQUlDLFdBQVU7O2tHQUNiLFFBQUNZO3dGQUFFWixXQUFVO2tHQUNWaUIsT0FBTzlELEtBQUs7Ozs7OztvRkFFZDhELE9BQU8xRCxRQUFRLGtCQUNkLFFBQUN4Qzt3RkFDQ29HLE1BQUs7d0ZBQ0xoRCxTQUFRO3dGQUNSNkIsV0FBVTt3RkFDVm9CLFNBQVMsSUFDUHhELGdCQUFnQnFELE9BQU83RCxLQUFLLEVBQUU2RCxPQUFPOUQsS0FBSzt3RkFFNUNrRSxjQUFZLENBQUMsS0FBSyxFQUFFSixPQUFPOUQsS0FBSyxFQUFFO2tHQUVqQ2YsV0FBVzZFLE9BQU85RCxLQUFLLGlCQUN0QixRQUFDNUM7NEZBQU15RixXQUFVOzs7OztpSEFFakIsUUFBQzFGOzRGQUFLMEYsV0FBVTs7Ozs7Ozs7Ozs7Ozs7Ozs7MEZBS3hCLFFBQUNZO2dGQUFFWixXQUFVOzBGQUNWaUIsT0FBTzdELEtBQUs7Ozs7OzswRkFFZixRQUFDd0Q7Z0ZBQUVaLFdBQVU7MEZBQ1ZpQixPQUFPM0QsV0FBVzs7Ozs7Ozs7Ozs7OzsrREF2Q2xCMkQsT0FBTzlELEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztzREFnRDNCLFFBQUNyRCxPQUFPaUcsR0FBRzs0Q0FDVEksU0FBUztnREFBRUMsU0FBUztnREFBR1csR0FBRyxDQUFDOzRDQUFHOzRDQUM5QlQsU0FBU3RFLFNBQVM7Z0RBQUVvRSxTQUFTO2dEQUFHVyxHQUFHOzRDQUFFLElBQUksQ0FBQzs0Q0FDMUNSLFlBQVk7Z0RBQUVPLE9BQU87Z0RBQUtOLFVBQVU7NENBQUk7c0RBRXhDLGNBQUEsUUFBQzdGO2dEQUFLcUYsV0FBVTs7a0VBQ2QsUUFBQ25GO2tFQUNDLGNBQUEsUUFBQ0M7NERBQVVrRixXQUFVO3NFQUFlOzs7Ozs7Ozs7OztrRUFJdEMsUUFBQ3BGO3dEQUFZb0YsV0FBVTtrRUFDcEJ4QyxZQUFZd0QsR0FBRyxDQUFDLENBQUNNLFFBQVFKLHNCQUN4QixRQUFDcEgsT0FBT3lILENBQUM7Z0VBRVBsRSxNQUFNaUUsT0FBT2pFLElBQUk7Z0VBQ2pCeUMsUUFBTztnRUFDUDBCLEtBQUk7Z0VBQ0pyQixTQUFTO29FQUFFQyxTQUFTO29FQUFHQyxHQUFHO2dFQUFHO2dFQUM3QkMsU0FBU3RFLFNBQVM7b0VBQUVvRSxTQUFTO29FQUFHQyxHQUFHO2dFQUFFLElBQUksQ0FBQztnRUFDMUNFLFlBQVk7b0VBQ1ZPLE9BQU8sTUFBTUksUUFBUTtvRUFDckJWLFVBQVU7Z0VBQ1o7Z0VBQ0FSLFdBQVU7O2tGQUVWLFFBQUNEO3dFQUFJQyxXQUFVO2tGQUNiLGNBQUEsUUFBQ3NCLE9BQU9wRSxJQUFJOzRFQUFDOEMsV0FBVTs7Ozs7Ozs7Ozs7a0ZBRXpCLFFBQUNEOzswRkFDQyxRQUFDYTtnRkFBRVosV0FBVTswRkFDVnNCLE9BQU9uRSxLQUFLOzs7Ozs7MEZBRWYsUUFBQ3lEO2dGQUFFWixXQUFVOzBGQUNWc0IsT0FBT2hFLFdBQVc7Ozs7Ozs7Ozs7Ozs7K0RBcEJsQmdFLE9BQU9uRSxLQUFLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0RBNkIzQixRQUFDckQsT0FBT2lHLEdBQUc7NENBQ1RJLFNBQVM7Z0RBQUVDLFNBQVM7Z0RBQUdXLEdBQUcsQ0FBQzs0Q0FBRzs0Q0FDOUJULFNBQVN0RSxTQUFTO2dEQUFFb0UsU0FBUztnREFBR1csR0FBRzs0Q0FBRSxJQUFJLENBQUM7NENBQzFDUixZQUFZO2dEQUFFTyxPQUFPO2dEQUFLTixVQUFVOzRDQUFJO3NEQUV4QyxjQUFBLFFBQUM3RjtnREFBS3FGLFdBQVU7O2tFQUNkLFFBQUNuRjtrRUFDQyxjQUFBLFFBQUNDOzREQUFVa0YsV0FBVTs7OEVBQ25CLFFBQUN4RjtvRUFBTXdGLFdBQVU7Ozs7OztnRUFBc0I7Ozs7Ozs7Ozs7OztrRUFJM0MsUUFBQ3BGO3dEQUFZb0YsV0FBVTtrRUFDcEJ2QyxhQUFhdUQsR0FBRyxDQUFDLENBQUNTLFVBQVVQLHNCQUMzQixRQUFDbkI7Z0VBRUNDLFdBQVU7O2tGQUVWLFFBQUNXO3dFQUFLWCxXQUFVO2tGQUFrQnlCLFNBQVMvRCxHQUFHOzs7Ozs7a0ZBQzlDLFFBQUNpRDt3RUFBS1gsV0FBVTtrRkFDYnlCLFNBQVM5RCxJQUFJOzs7Ozs7OytEQUxYdUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztzREFhZixRQUFDcEgsT0FBT2lHLEdBQUc7NENBQ1RJLFNBQVM7Z0RBQUVDLFNBQVM7Z0RBQUdXLEdBQUcsQ0FBQzs0Q0FBRzs0Q0FDOUJULFNBQVN0RSxTQUFTO2dEQUFFb0UsU0FBUztnREFBR1csR0FBRzs0Q0FBRSxJQUFJLENBQUM7NENBQzFDUixZQUFZO2dEQUFFTyxPQUFPO2dEQUFLTixVQUFVOzRDQUFJOzRDQUN4Q2EsY0FBVztzREFFWCxjQUFBLFFBQUN0QjtnREFBSUMsV0FBVTs7a0VBQ2IsUUFBQ0Q7d0RBQUlDLFdBQVU7OzBFQUNiLFFBQUNXO2dFQUFLWCxXQUFVOzBFQUF5RDs7Ozs7OzBFQUd6RSxRQUFDdEY7Z0VBQU1zRixXQUFVO2dFQUFvQjBCLGVBQVk7Ozs7Ozs7Ozs7OztrRUFFbkQsUUFBQzNCO3dEQUFJQyxXQUFVOzswRUFDYixRQUFDRDtnRUFBSUMsV0FBVTs7a0ZBQ2IsUUFBQ1c7d0VBQUtYLFdBQVU7a0ZBQTJEOzs7Ozs7a0ZBRzNFLFFBQUNXO3dFQUFLWCxXQUFVO2tGQUFzQjs7Ozs7Ozs7Ozs7OzBFQUV4QyxRQUFDRDtnRUFBSUMsV0FBVTs7a0ZBQ2IsUUFBQ1c7d0VBQUtYLFdBQVU7a0ZBQTJEOzs7Ozs7a0ZBRzNFLFFBQUNXO3dFQUFLWCxXQUFVO2tGQUFVOzs7Ozs7Ozs7Ozs7MEVBRTVCLFFBQUNEO2dFQUFJQyxXQUFVOztrRkFDYixRQUFDVzt3RUFBS1gsV0FBVTtrRkFBMkQ7Ozs7OztrRkFHM0UsUUFBQ1c7d0VBQUtYLFdBQVU7a0ZBQVU7Ozs7Ozs7Ozs7OzswRUFFNUIsUUFBQ0Q7Z0VBQUlDLFdBQVU7O2tGQUNiLFFBQUNXO3dFQUFLWCxXQUFVO2tGQUEyRDs7Ozs7O2tGQUczRSxRQUFDVzt3RUFBS1gsV0FBVTtrRkFBVTs7Ozs7Ozs7Ozs7OzBFQUU1QixRQUFDRDtnRUFBSUMsV0FBVTs7a0ZBQ2IsUUFBQ1c7d0VBQUtYLFdBQVU7a0ZBQTJEOzs7Ozs7a0ZBRzNFLFFBQUNXO3dFQUFLWCxXQUFVO2tGQUE4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OENBUXhELFFBQUNsRyxPQUFPaUcsR0FBRztvQ0FDVEksU0FBUzt3Q0FBRUMsU0FBUzt3Q0FBR1csR0FBRztvQ0FBRztvQ0FDN0JULFNBQVN0RSxTQUFTO3dDQUFFb0UsU0FBUzt3Q0FBR1csR0FBRztvQ0FBRSxJQUFJLENBQUM7b0NBQzFDUixZQUFZO3dDQUFFTyxPQUFPO3dDQUFLTixVQUFVO29DQUFJO29DQUN4Q1IsV0FBVTs4Q0FFVixjQUFBLFFBQUNyRjt3Q0FBS3FGLFdBQVU7OzBEQUNkLFFBQUNuRjs7a0VBQ0MsUUFBQ0M7d0RBQVVrRixXQUFVO2tFQUFlOzs7Ozs7a0VBR3BDLFFBQUNZO3dEQUFFWixXQUFVO2tFQUFpQjs7Ozs7Ozs7Ozs7OzBEQUtoQyxRQUFDcEY7MERBQ0MsY0FBQSxRQUFDK0c7b0RBQ0M1RixLQUFLRDtvREFDTDhGLFVBQVVqRDtvREFDVnFCLFdBQVU7b0RBQ1Y2QixVQUFVOztzRUFHVixRQUFDOUI7NERBQUlDLFdBQVU7NERBQXlDMEIsZUFBWTs7OEVBQ2xFLFFBQUN2RTtvRUFBTTJFLFNBQVE7OEVBQVU7Ozs7Ozs4RUFDekIsUUFBQzlHO29FQUNDK0csSUFBRztvRUFDSHJGLE1BQUs7b0VBQ0xVLE9BQU9aLFNBQVNNLE9BQU87b0VBQ3ZCa0YsVUFBVXBDO29FQUNWcUMsVUFBVSxDQUFDO29FQUNYQyxjQUFhOzs7Ozs7Ozs7Ozs7c0VBR2pCLFFBQUNuQzs0REFBSUMsV0FBVTs7OEVBQ2IsUUFBQ0Q7b0VBQUlDLFdBQVU7O3NGQUNiLFFBQUM3Qzs0RUFBTTJFLFNBQVE7NEVBQU85QixXQUFVO3NGQUFzQjs7Ozs7O3NGQUd0RCxRQUFDaEY7NEVBQ0MrRyxJQUFHOzRFQUNIckYsTUFBSzs0RUFDTFUsT0FBT1osU0FBU0UsSUFBSTs0RUFDcEJzRixVQUFVcEM7NEVBQ1Z1QyxhQUFZOzRFQUNaQyxRQUFROzRFQUNSQyxVQUFVL0Y7NEVBQ1ZnRyxnQkFBYyxDQUFDLENBQUN2RixXQUFXTCxJQUFJOzRFQUMvQnNELFdBQVU7Ozs7Ozt3RUFFWGpELFdBQVdMLElBQUksa0JBQ2QsUUFBQ2tFOzRFQUFFWixXQUFVO3NGQUE0QmpELFdBQVdMLElBQUk7Ozs7Ozs7Ozs7Ozs4RUFHNUQsUUFBQ3FEO29FQUFJQyxXQUFVOztzRkFDYixRQUFDN0M7NEVBQU0yRSxTQUFROzRFQUFROUIsV0FBVTtzRkFBc0I7Ozs7OztzRkFHdkQsUUFBQ2hGOzRFQUNDK0csSUFBRzs0RUFDSHJGLE1BQUs7NEVBQ0w2RixNQUFLOzRFQUNMbkYsT0FBT1osU0FBU0csS0FBSzs0RUFDckJxRixVQUFVcEM7NEVBQ1Z1QyxhQUFZOzRFQUNaQyxRQUFROzRFQUNSQyxVQUFVL0Y7NEVBQ1ZnRyxnQkFBYyxDQUFDLENBQUN2RixXQUFXSixLQUFLOzRFQUNoQ3FELFdBQVU7Ozs7Ozt3RUFFWGpELFdBQVdKLEtBQUssa0JBQ2YsUUFBQ2lFOzRFQUFFWixXQUFVO3NGQUE0QmpELFdBQVdKLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7OztzRUFLL0QsUUFBQ29EOzREQUFJQyxXQUFVOzs4RUFDYixRQUFDN0M7b0VBQU0yRSxTQUFRO29FQUFVOUIsV0FBVTs4RUFBc0I7Ozs7OztnRUFFakQ7OEVBQXdCLFFBQUNoRjtvRUFDN0IrRyxJQUFHO29FQUNIckYsTUFBSztvRUFDTFUsT0FBT1osU0FBU0ksT0FBTztvRUFDdkJvRixVQUFVcEM7b0VBQ1Z1QyxhQUFZO29FQUNaQyxRQUFRO29FQUNSQyxVQUFVL0Y7b0VBQ1ZnRyxnQkFBYyxDQUFDLENBQUN2RixXQUFXSCxPQUFPO29FQUNsQ29ELFdBQVU7Ozs7OztnRUFFWGpELFdBQVdILE9BQU8sa0JBQ2pCLFFBQUNnRTtvRUFBRVosV0FBVTs4RUFBNEJqRCxXQUFXSCxPQUFPOzs7Ozs7Ozs7Ozs7c0VBSWpFLFFBQUNtRDs0REFBSUMsV0FBVTs7OEVBQ2IsUUFBQzdDO29FQUFNMkUsU0FBUTtvRUFBVTlCLFdBQVU7OEVBQXNCOzs7Ozs7OEVBR3pELFFBQUMvRTtvRUFDQzhHLElBQUc7b0VBQ0hyRixNQUFLO29FQUNMVSxPQUFPWixTQUFTSyxPQUFPO29FQUN2Qm1GLFVBQVVwQztvRUFDVnVDLGFBQVk7b0VBQ1pLLE1BQU07b0VBQ05KLFFBQVE7b0VBQ1JDLFVBQVUvRjtvRUFDVmdHLGdCQUFjLENBQUMsQ0FBQ3ZGLFdBQVdGLE9BQU87b0VBQ2xDbUQsV0FBVTs7Ozs7O2dFQUVYakQsV0FBV0YsT0FBTyxrQkFDakIsUUFBQytEO29FQUFFWixXQUFVOzhFQUE0QmpELFdBQVdGLE9BQU87Ozs7Ozs4RUFFN0QsUUFBQytEO29FQUFFWixXQUFVOzt3RUFDVnhELFNBQVNLLE9BQU8sQ0FBQzBCLE1BQU07d0VBQUM7Ozs7Ozs7Ozs7Ozs7c0VBSTdCLFFBQUN4RDs0REFDQ3dILE1BQUs7NERBQ0xGLFVBQVUvRjs0REFDVjBELFdBQVU7c0VBRVQxRCwwQkFDQzs7a0ZBQ0UsUUFBQzdCO3dFQUFRdUYsV0FBVTs7Ozs7O29FQUErQjtvRUFBSTs7NkZBSXhEOztrRkFDRSxRQUFDM0Y7d0VBQUsyRixXQUFVOzs7Ozs7b0VBQWlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0NBV2pELFFBQUNsRyxPQUFPaUcsR0FBRzs0QkFDVEksU0FBUztnQ0FBRUMsU0FBUztnQ0FBR0MsR0FBRzs0QkFBRzs0QkFDN0JDLFNBQVN0RSxTQUFTO2dDQUFFb0UsU0FBUztnQ0FBR0MsR0FBRzs0QkFBRSxJQUFJLENBQUM7NEJBQzFDRSxZQUFZO2dDQUFFTyxPQUFPO2dDQUFLTixVQUFVOzRCQUFJOzRCQUN4Q1IsV0FBVTtzQ0FFVixjQUFBLFFBQUNyRjtnQ0FBS3FGLFdBQVU7MENBQ2QsY0FBQSxRQUFDcEY7b0NBQVlvRixXQUFVOztzREFDckIsUUFBQ3lDOzRDQUFHekMsV0FBVTtzREFBa0M7Ozs7OztzREFHaEQsUUFBQ1k7NENBQUVaLFdBQVU7O2dEQUF5QjtnREFDUTs4REFDNUMsUUFBQ1c7b0RBQUtYLFdBQVU7OERBQXdCOzs7Ozs7Z0RBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBUW5FLFFBQUM3RTs7Ozs7Ozs7Ozs7QUFHUDtHQTlrQk1ROztRQUNhSDtRQUNZQztRQUdQMUI7UUFLSjJCOzs7S0FWZEM7QUFnbEJOLGVBQWVBLFFBQVEifQ==