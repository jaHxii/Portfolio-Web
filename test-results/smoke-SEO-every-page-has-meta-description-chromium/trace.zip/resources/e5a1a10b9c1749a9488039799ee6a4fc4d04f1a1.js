import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Resume.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/pages/Resume.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { Download, Printer } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Button } from "/src/components/ui/button.tsx";
import Navigation from "/src/components/layout/Navigation.tsx";
import Footer from "/src/components/layout/Footer.tsx";
import SEO from "/src/components/seo/SEO.tsx";
import StructuredData from "/src/components/seo/StructuredData.tsx";
import { useSEO } from "/src/hooks/use-seo.ts";
import { useStructuredData } from "/src/hooks/use-structured-data.ts";
/* ─── Real data from Ermias's CV ─────────────────── */ const INFO = {
    name: 'ERMIAS LEMESA BAYISA',
    title: 'Computer Engineer | IT Support Specialist | Hardware Engineer',
    location: 'Addis Ababa, Ethiopia',
    phone: '+251921615244',
    email: 'ermias.xii@gmail.com',
    github: 'github.com/jaHxii',
    telegram: 't.me/cloudx69'
};
const SUMMARY = 'Proactive and detail-oriented IT Support Technician (B.Sc. Computer Engineering, CGPA: 3.42) with hands-on enterprise IT support experience. Currently serving as a Senior IT Support specialist, adept at installing/configuring hardware/OS, diagnosing complex network faults, managing user accounts/permissions, and resolving helpdesk tickets within SLAs. Proven track record of providing clear remote, chat, and in-person end-user support, ensuring smooth daily operations for multi-floor office environments. Experienced in creating detailed technical documentation, system diagrams, and user training materials. Developed an automated IT Helpdesk Ticketing System, demonstrating strong decision-making and workflow prioritization skills. Highly empathetic and collaborative, with a strong ability to understand end-user perspectives while maintaining professionalism under pressure.';
const EDUCATION = {
    period: 'Aug 2021 - Aug 2025',
    school: 'University of Gondar',
    degree: 'B.Sc. in Computer Engineering',
    cgpa: '3.42'
};
const PROJECTS = [
    {
        title: 'KIRAY - Rental & Building Management System',
        note: 'Final Year Project',
        bullets: [
            'Designed and developed a full-stack rental management platform',
            'Implemented tenant management, payment tracking, and reporting modules',
            'Designed relational database schema for structured data management',
            'Integrated authentication and user role control',
            'Focused on automation of rental operations and record-keeping'
        ]
    },
    {
        title: 'MESOB IT Helpdesk Ticketing System',
        bullets: [
            'Developed an automated IT support ticketing platform',
            'Implemented issue tracking, prioritization, and lifecycle management',
            'Designed backend logic for handling support workflows',
            'Improved coordination between technical staff and users'
        ]
    },
    {
        title: 'Real-Time Analytics Dashboard',
        bullets: [
            'Developed a real-time data monitoring dashboard',
            'Implemented live data streaming using WebSocket integration',
            'Optimized data rendering performance',
            'Built interactive visualization components for operational metrics'
        ]
    },
    {
        title: 'Local Network Printer Information Collector',
        bullets: [
            'Developed a Windows executable tool for scanning printers on a local network',
            'Automated device discovery and configuration reporting',
            'Designed for IT asset monitoring'
        ]
    }
];
const EXPERIENCE = [
    {
        company: 'ROTECH Information Technology',
        role: 'Senior IT Support',
        period: 'Present',
        bullets: [
            'Diagnose and resolve network, printer, and hardware issues across multiple office locations',
            'Configure VPNs, cross-network folder sharing, and Wi-Fi troubleshooting for multi-floor environments',
            'Manage IT procurement, hardware evaluation, and vendor coordination',
            'Deliver end-user training, technical documentation, and weekly reporting'
        ]
    },
    {
        company: 'Addis Mesob - Bole Branch',
        role: 'Hardware Engineer',
        period: 'Past',
        bullets: [
            'Install, configure, and maintain computer hardware systems',
            'Diagnose and troubleshoot hardware and peripheral issues',
            'Support printer setup, network connectivity, and system maintenance',
            'Ensure operational continuity of IT equipment',
            'Assist in technical documentation and system monitoring'
        ]
    },
    {
        company: 'Ethiopian Artificial Intelligence Institute (EAII)',
        role: 'AI/ML Intern',
        period: 'Past',
        bullets: [
            'Assisted in data collection, cleaning, and preprocessing for AI model development',
            'Participated in training and evaluation of machine learning models',
            'Contributed to AI-based chatbot development and deployment',
            'Prepared technical documentation and research summaries',
            'Collaborated with cross-functional technical teams'
        ]
    }
];
const TECH_SKILLS = [
    {
        label: 'IT & Infrastructure',
        value: 'IT Infrastructure Support, System Troubleshooting, Process Automation, Technical Documentation'
    },
    {
        label: 'Programming & Data',
        value: 'Python Programming, Machine Learning Fundamentals, Database Design & SQL'
    },
    {
        label: 'Development',
        value: 'Web Application Development, Strong Written & Verbal Communication'
    }
];
const ATTRIBUTES = [
    'Strong analytical mindset',
    'High accountability and professionalism',
    'Respect for confidentiality',
    'Team collaboration and adaptability',
    'Digital learning agility'
];
const REFERENCE = {
    name: 'Kumneger Sitotaw (MSc)',
    role: 'Head, Department of Digitization | Addis Mesob - Bole Branch',
    phone: '+251 92 043 8072'
};
/* ─── Component ──────────────────────────────────── */ const Resume = ()=>{
    _s();
    const handlePrint = ()=>window.print();
    const seoProps = useSEO({
        title: 'Resume - Ermias Lemesa Bayisa',
        description: 'Resume of Ermias Lemesa Bayisa - Computer Engineer, IT Support Specialist and Hardware Engineer based in Addis Ababa, Ethiopia.',
        keywords: [
            'resume',
            'CV',
            'Ermias Lemesa',
            'Computer Engineer',
            'IT Support',
            'Hardware Engineer'
        ],
        section: 'Resume'
    });
    const { breadcrumbSchema } = useStructuredData();
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "min-h-screen bg-background",
        children: [
            /*#__PURE__*/ _jsxDEV(SEO, {
                ...seoProps
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 165,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(StructuredData, {
                schema: breadcrumbSchema
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "print:hidden",
                children: /*#__PURE__*/ _jsxDEV(Navigation, {}, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                    lineNumber: 170,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 169,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "print:hidden fixed top-16 left-0 right-0 z-40 bg-background/90 backdrop-blur border-b border-border",
                children: /*#__PURE__*/ _jsxDEV("div", {
                    className: "max-w-4xl mx-auto px-4 py-3 flex items-center justify-between gap-4",
                    children: [
                        /*#__PURE__*/ _jsxDEV("span", {
                            className: "text-xs text-muted-foreground hidden sm:block",
                            children: [
                                "Use ",
                                /*#__PURE__*/ _jsxDEV("strong", {
                                    children: "Print → Save as PDF"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                    lineNumber: 176,
                                    columnNumber: 17
                                }, this),
                                ", or download my CV."
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                            lineNumber: 175,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ _jsxDEV(Button, {
                                    variant: "outline",
                                    size: "sm",
                                    asChild: true,
                                    className: "flex items-center gap-2",
                                    children: /*#__PURE__*/ _jsxDEV("a", {
                                        href: "/Ermias.L_cv.pdf",
                                        download: true,
                                        children: [
                                            /*#__PURE__*/ _jsxDEV(Download, {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                lineNumber: 186,
                                                columnNumber: 17
                                            }, this),
                                            "Download PDF"
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                        lineNumber: 185,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                    lineNumber: 179,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV(Button, {
                                    onClick: handlePrint,
                                    size: "sm",
                                    className: "ml-auto flex items-center gap-2 btn-glow",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV(Printer, {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                            lineNumber: 195,
                                            columnNumber: 15
                                        }, this),
                                        "Print"
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                    lineNumber: 190,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                            lineNumber: 178,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                    lineNumber: 174,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 173,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "min-h-screen bg-background pt-28 pb-20 print:pt-0 print:pb-0 print:bg-white",
                children: /*#__PURE__*/ _jsxDEV(motion.article, {
                    initial: {
                        opacity: 0,
                        y: 16
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    transition: {
                        duration: 0.5
                    },
                    className: "max-w-4xl mx-auto px-6 print:px-0 bg-card print:bg-white shadow-xl print:shadow-none rounded-2xl print:rounded-none border border-border/50 print:border-none",
                    style: {
                        fontFamily: "'Times New Roman', Times, serif"
                    },
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "p-10 print:p-8",
                        children: [
                            /*#__PURE__*/ _jsxDEV("header", {
                                className: "mb-5 print:mb-4",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("h1", {
                                        className: "text-3xl font-bold tracking-widest text-foreground print:text-black uppercase mb-1",
                                        children: [
                                            INFO.name,
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "block w-full h-px bg-primary mt-1 print:bg-blue-700"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                lineNumber: 220,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                        lineNumber: 218,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        className: "text-primary print:text-blue-700 font-semibold text-base mt-1",
                                        children: INFO.title
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                        lineNumber: 222,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        className: "text-sm text-muted-foreground print:text-gray-700 mt-1",
                                        children: [
                                            INFO.location,
                                            "  |   Phone: ",
                                            INFO.phone,
                                            "  |  ",
                                            INFO.email
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                        lineNumber: 225,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("p", {
                                        className: "text-sm text-muted-foreground print:text-gray-700",
                                        children: [
                                            "GitHub: ",
                                            INFO.github,
                                            "  |   Telegram: ",
                                            INFO.telegram
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                        lineNumber: 230,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                lineNumber: 217,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV(Section, {
                                title: "PROFESSIONAL SUMMARY:",
                                children: /*#__PURE__*/ _jsxDEV("blockquote", {
                                    className: "border-l-2 border-primary print:border-blue-700 pl-4 text-sm leading-relaxed text-foreground/90 print:text-gray-800",
                                    children: SUMMARY
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                    lineNumber: 238,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                lineNumber: 237,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV(Section, {
                                title: "EDUCATION:",
                                children: /*#__PURE__*/ _jsxDEV("div", {
                                    className: "text-sm space-y-0.5 text-foreground/90 print:text-gray-800",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            className: "font-medium",
                                            children: [
                                                EDUCATION.period,
                                                " | ",
                                                EDUCATION.school
                                            ]
                                        }, void 0, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                            lineNumber: 246,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            children: EDUCATION.degree
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                            lineNumber: 249,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            children: [
                                                "CGPA: ",
                                                EDUCATION.cgpa
                                            ]
                                        }, void 0, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                            lineNumber: 250,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                    lineNumber: 245,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                lineNumber: 244,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV(Section, {
                                title: "MAJOR PROJECTS:",
                                children: /*#__PURE__*/ _jsxDEV("div", {
                                    className: "space-y-4",
                                    children: PROJECTS.map((p)=>/*#__PURE__*/ _jsxDEV("div", {
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("p", {
                                                    className: "text-sm font-medium text-foreground print:text-black",
                                                    children: [
                                                        p.title,
                                                        p.note && /*#__PURE__*/ _jsxDEV("span", {
                                                            className: "font-mono text-[11px] tracking-wide text-muted-foreground print:text-gray-600",
                                                            children: [
                                                                ' ',
                                                                "(",
                                                                p.note,
                                                                ")"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                            lineNumber: 262,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                    lineNumber: 259,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("ul", {
                                                    className: "mt-1 space-y-0.5 list-disc list-inside",
                                                    children: p.bullets.map((b, i)=>/*#__PURE__*/ _jsxDEV("li", {
                                                            className: "text-sm text-muted-foreground print:text-gray-700 ml-2",
                                                            children: b
                                                        }, i, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                            lineNumber: 270,
                                                            columnNumber: 25
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                    lineNumber: 268,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, p.title, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                            lineNumber: 258,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                    lineNumber: 256,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                lineNumber: 255,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV(Section, {
                                title: "PROFESSIONAL EXPERIENCE:",
                                children: /*#__PURE__*/ _jsxDEV("div", {
                                    className: "space-y-5",
                                    children: EXPERIENCE.map((e)=>/*#__PURE__*/ _jsxDEV("div", {
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("p", {
                                                    className: "text-sm font-medium text-foreground print:text-black",
                                                    children: e.company
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                    lineNumber: 288,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("p", {
                                                    className: "text-sm text-muted-foreground print:text-gray-600",
                                                    children: [
                                                        e.role,
                                                        e.period ? ` | ${e.period}` : ''
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                    lineNumber: 291,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("ul", {
                                                    className: "mt-1 space-y-0.5 list-disc list-inside",
                                                    children: e.bullets.map((b, i)=>/*#__PURE__*/ _jsxDEV("li", {
                                                            className: "text-sm text-muted-foreground print:text-gray-700 ml-2",
                                                            children: b
                                                        }, i, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                            lineNumber: 297,
                                                            columnNumber: 25
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                    lineNumber: 295,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, e.company, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                            lineNumber: 287,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                    lineNumber: 285,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                lineNumber: 284,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 gap-8 mt-6 print:grid-cols-2",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        children: [
                                            /*#__PURE__*/ _jsxDEV(SectionTitle, {
                                                title: "TECHNICAL & ANALYTICAL SKILLS"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                lineNumber: 314,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("ul", {
                                                className: "space-y-1 mt-3",
                                                children: TECH_SKILLS.map((s)=>/*#__PURE__*/ _jsxDEV("li", {
                                                        className: "text-sm text-foreground/90 print:text-gray-800",
                                                        children: [
                                                            /*#__PURE__*/ _jsxDEV("span", {
                                                                className: "font-semibold",
                                                                children: [
                                                                    s.label,
                                                                    ":"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                                lineNumber: 321,
                                                                columnNumber: 23
                                                            }, this),
                                                            ' ',
                                                            s.value
                                                        ]
                                                    }, s.label, true, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                        lineNumber: 317,
                                                        columnNumber: 21
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                lineNumber: 315,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                        lineNumber: 313,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "space-y-6",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("div", {
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV(SectionTitle, {
                                                        title: "ADDITIONAL ATTRIBUTES:"
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                        lineNumber: 331,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("ul", {
                                                        className: "space-y-1 mt-3 list-disc list-inside",
                                                        children: ATTRIBUTES.map((a, i)=>/*#__PURE__*/ _jsxDEV("li", {
                                                                className: "text-sm text-muted-foreground print:text-gray-700",
                                                                children: a
                                                            }, i, false, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                                lineNumber: 334,
                                                                columnNumber: 23
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                        lineNumber: 332,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                lineNumber: 330,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("div", {
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV(SectionTitle, {
                                                        title: "REFERENCE:"
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                        lineNumber: 344,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        className: "text-sm text-foreground/90 print:text-gray-800 mt-3",
                                                        children: REFERENCE.name
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                        lineNumber: 345,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        className: "text-sm text-muted-foreground print:text-gray-700",
                                                        children: REFERENCE.role
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                        lineNumber: 348,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("p", {
                                                        className: "text-sm text-muted-foreground print:text-gray-700",
                                                        children: REFERENCE.phone
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                        lineNumber: 351,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                                lineNumber: 343,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                        lineNumber: 329,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                                lineNumber: 311,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                        lineNumber: 215,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                    lineNumber: 204,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 203,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("style", {
                children: `
        @media print {
          @page { margin: 1.2cm; size: A4; }
          body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .print\\:hidden { display: none !important; }
        }
      `
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 362,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "print:hidden",
                children: /*#__PURE__*/ _jsxDEV(Footer, {}, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                    lineNumber: 370,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 369,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
        lineNumber: 164,
        columnNumber: 5
    }, this);
};
_s(Resume, "MhAzYxBKrBSOhljJMIrvbHoj8KY=", false, function() {
    return [
        useSEO,
        useStructuredData
    ];
});
_c = Resume;
/* ── Helpers ── */ const SectionTitle = ({ title })=>/*#__PURE__*/ _jsxDEV("div", {
        children: [
            /*#__PURE__*/ _jsxDEV("h2", {
                className: "text-sm font-bold tracking-wide uppercase text-primary print:text-blue-700",
                children: title
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 379,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "h-px bg-primary/40 print:bg-blue-300 mt-1"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 382,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
        lineNumber: 378,
        columnNumber: 3
    }, this);
_c1 = SectionTitle;
const Section = ({ title, children })=>/*#__PURE__*/ _jsxDEV("div", {
        className: "mt-6 print:mt-4 print:break-inside-avoid",
        children: [
            /*#__PURE__*/ _jsxDEV(SectionTitle, {
                title: title
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 394,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "mt-3",
                children: children
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
                lineNumber: 395,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/Resume.tsx",
        lineNumber: 393,
        columnNumber: 3
    }, this);
_c2 = Section;
export default Resume;
var _c, _c1, _c2;
$RefreshReg$(_c, "Resume");
$RefreshReg$(_c1, "SectionTitle");
$RefreshReg$(_c2, "Section");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/pages/Resume.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/pages/Resume.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlJlc3VtZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgRG93bmxvYWQsIFByaW50ZXIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbic7XG5pbXBvcnQgTmF2aWdhdGlvbiBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L05hdmlnYXRpb24nO1xuaW1wb3J0IEZvb3RlciBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L0Zvb3Rlcic7XG5pbXBvcnQgU0VPIGZyb20gJ0AvY29tcG9uZW50cy9zZW8vU0VPJztcbmltcG9ydCBTdHJ1Y3R1cmVkRGF0YSBmcm9tICdAL2NvbXBvbmVudHMvc2VvL1N0cnVjdHVyZWREYXRhJztcbmltcG9ydCB7IHVzZVNFTyB9IGZyb20gJ0AvaG9va3MvdXNlLXNlbyc7XG5pbXBvcnQgeyB1c2VTdHJ1Y3R1cmVkRGF0YSB9IGZyb20gJ0AvaG9va3MvdXNlLXN0cnVjdHVyZWQtZGF0YSc7XG5cbi8qIOKUgOKUgOKUgCBSZWFsIGRhdGEgZnJvbSBFcm1pYXMncyBDViDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuY29uc3QgSU5GTyA9IHtcbiAgbmFtZTogJ0VSTUlBUyBMRU1FU0EgQkFZSVNBJyxcbiAgdGl0bGU6ICdDb21wdXRlciBFbmdpbmVlciB8IElUIFN1cHBvcnQgU3BlY2lhbGlzdCB8IEhhcmR3YXJlIEVuZ2luZWVyJyxcbiAgbG9jYXRpb246ICdBZGRpcyBBYmFiYSwgRXRoaW9waWEnLFxuICBwaG9uZTogJysyNTE5MjE2MTUyNDQnLFxuICBlbWFpbDogJ2VybWlhcy54aWlAZ21haWwuY29tJyxcbiAgZ2l0aHViOiAnZ2l0aHViLmNvbS9qYUh4aWknLFxuICB0ZWxlZ3JhbTogJ3QubWUvY2xvdWR4NjknLFxufTtcblxuY29uc3QgU1VNTUFSWSA9XG4gICdQcm9hY3RpdmUgYW5kIGRldGFpbC1vcmllbnRlZCBJVCBTdXBwb3J0IFRlY2huaWNpYW4gKEIuU2MuIENvbXB1dGVyIEVuZ2luZWVyaW5nLCBDR1BBOiAzLjQyKSB3aXRoIGhhbmRzLW9uIGVudGVycHJpc2UgSVQgc3VwcG9ydCBleHBlcmllbmNlLiBDdXJyZW50bHkgc2VydmluZyBhcyBhIFNlbmlvciBJVCBTdXBwb3J0IHNwZWNpYWxpc3QsIGFkZXB0IGF0IGluc3RhbGxpbmcvY29uZmlndXJpbmcgaGFyZHdhcmUvT1MsIGRpYWdub3NpbmcgY29tcGxleCBuZXR3b3JrIGZhdWx0cywgbWFuYWdpbmcgdXNlciBhY2NvdW50cy9wZXJtaXNzaW9ucywgYW5kIHJlc29sdmluZyBoZWxwZGVzayB0aWNrZXRzIHdpdGhpbiBTTEFzLiBQcm92ZW4gdHJhY2sgcmVjb3JkIG9mIHByb3ZpZGluZyBjbGVhciByZW1vdGUsIGNoYXQsIGFuZCBpbi1wZXJzb24gZW5kLXVzZXIgc3VwcG9ydCwgZW5zdXJpbmcgc21vb3RoIGRhaWx5IG9wZXJhdGlvbnMgZm9yIG11bHRpLWZsb29yIG9mZmljZSBlbnZpcm9ubWVudHMuIEV4cGVyaWVuY2VkIGluIGNyZWF0aW5nIGRldGFpbGVkIHRlY2huaWNhbCBkb2N1bWVudGF0aW9uLCBzeXN0ZW0gZGlhZ3JhbXMsIGFuZCB1c2VyIHRyYWluaW5nIG1hdGVyaWFscy4gRGV2ZWxvcGVkIGFuIGF1dG9tYXRlZCBJVCBIZWxwZGVzayBUaWNrZXRpbmcgU3lzdGVtLCBkZW1vbnN0cmF0aW5nIHN0cm9uZyBkZWNpc2lvbi1tYWtpbmcgYW5kIHdvcmtmbG93IHByaW9yaXRpemF0aW9uIHNraWxscy4gSGlnaGx5IGVtcGF0aGV0aWMgYW5kIGNvbGxhYm9yYXRpdmUsIHdpdGggYSBzdHJvbmcgYWJpbGl0eSB0byB1bmRlcnN0YW5kIGVuZC11c2VyIHBlcnNwZWN0aXZlcyB3aGlsZSBtYWludGFpbmluZyBwcm9mZXNzaW9uYWxpc20gdW5kZXIgcHJlc3N1cmUuJztcblxuY29uc3QgRURVQ0FUSU9OID0ge1xuICBwZXJpb2Q6ICdBdWcgMjAyMSAtIEF1ZyAyMDI1JyxcbiAgc2Nob29sOiAnVW5pdmVyc2l0eSBvZiBHb25kYXInLFxuICBkZWdyZWU6ICdCLlNjLiBpbiBDb21wdXRlciBFbmdpbmVlcmluZycsXG4gIGNncGE6ICczLjQyJyxcbn07XG5cbmNvbnN0IFBST0pFQ1RTID0gW1xuICB7XG4gICAgdGl0bGU6ICdLSVJBWSAtIFJlbnRhbCAmIEJ1aWxkaW5nIE1hbmFnZW1lbnQgU3lzdGVtJyxcbiAgICBub3RlOiAnRmluYWwgWWVhciBQcm9qZWN0JyxcbiAgICBidWxsZXRzOiBbXG4gICAgICAnRGVzaWduZWQgYW5kIGRldmVsb3BlZCBhIGZ1bGwtc3RhY2sgcmVudGFsIG1hbmFnZW1lbnQgcGxhdGZvcm0nLFxuICAgICAgJ0ltcGxlbWVudGVkIHRlbmFudCBtYW5hZ2VtZW50LCBwYXltZW50IHRyYWNraW5nLCBhbmQgcmVwb3J0aW5nIG1vZHVsZXMnLFxuICAgICAgJ0Rlc2lnbmVkIHJlbGF0aW9uYWwgZGF0YWJhc2Ugc2NoZW1hIGZvciBzdHJ1Y3R1cmVkIGRhdGEgbWFuYWdlbWVudCcsXG4gICAgICAnSW50ZWdyYXRlZCBhdXRoZW50aWNhdGlvbiBhbmQgdXNlciByb2xlIGNvbnRyb2wnLFxuICAgICAgJ0ZvY3VzZWQgb24gYXV0b21hdGlvbiBvZiByZW50YWwgb3BlcmF0aW9ucyBhbmQgcmVjb3JkLWtlZXBpbmcnLFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICB0aXRsZTogJ01FU09CIElUIEhlbHBkZXNrIFRpY2tldGluZyBTeXN0ZW0nLFxuICAgIGJ1bGxldHM6IFtcbiAgICAgICdEZXZlbG9wZWQgYW4gYXV0b21hdGVkIElUIHN1cHBvcnQgdGlja2V0aW5nIHBsYXRmb3JtJyxcbiAgICAgICdJbXBsZW1lbnRlZCBpc3N1ZSB0cmFja2luZywgcHJpb3JpdGl6YXRpb24sIGFuZCBsaWZlY3ljbGUgbWFuYWdlbWVudCcsXG4gICAgICAnRGVzaWduZWQgYmFja2VuZCBsb2dpYyBmb3IgaGFuZGxpbmcgc3VwcG9ydCB3b3JrZmxvd3MnLFxuICAgICAgJ0ltcHJvdmVkIGNvb3JkaW5hdGlvbiBiZXR3ZWVuIHRlY2huaWNhbCBzdGFmZiBhbmQgdXNlcnMnLFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICB0aXRsZTogJ1JlYWwtVGltZSBBbmFseXRpY3MgRGFzaGJvYXJkJyxcbiAgICBidWxsZXRzOiBbXG4gICAgICAnRGV2ZWxvcGVkIGEgcmVhbC10aW1lIGRhdGEgbW9uaXRvcmluZyBkYXNoYm9hcmQnLFxuICAgICAgJ0ltcGxlbWVudGVkIGxpdmUgZGF0YSBzdHJlYW1pbmcgdXNpbmcgV2ViU29ja2V0IGludGVncmF0aW9uJyxcbiAgICAgICdPcHRpbWl6ZWQgZGF0YSByZW5kZXJpbmcgcGVyZm9ybWFuY2UnLFxuICAgICAgJ0J1aWx0IGludGVyYWN0aXZlIHZpc3VhbGl6YXRpb24gY29tcG9uZW50cyBmb3Igb3BlcmF0aW9uYWwgbWV0cmljcycsXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIHRpdGxlOiAnTG9jYWwgTmV0d29yayBQcmludGVyIEluZm9ybWF0aW9uIENvbGxlY3RvcicsXG4gICAgYnVsbGV0czogW1xuICAgICAgJ0RldmVsb3BlZCBhIFdpbmRvd3MgZXhlY3V0YWJsZSB0b29sIGZvciBzY2FubmluZyBwcmludGVycyBvbiBhIGxvY2FsIG5ldHdvcmsnLFxuICAgICAgJ0F1dG9tYXRlZCBkZXZpY2UgZGlzY292ZXJ5IGFuZCBjb25maWd1cmF0aW9uIHJlcG9ydGluZycsXG4gICAgICAnRGVzaWduZWQgZm9yIElUIGFzc2V0IG1vbml0b3JpbmcnLFxuICAgIF0sXG4gIH0sXG5dO1xuXG5jb25zdCBFWFBFUklFTkNFID0gW1xuICB7XG4gICAgY29tcGFueTogJ1JPVEVDSCBJbmZvcm1hdGlvbiBUZWNobm9sb2d5JyxcbiAgICByb2xlOiAnU2VuaW9yIElUIFN1cHBvcnQnLFxuICAgIHBlcmlvZDogJ1ByZXNlbnQnLFxuICAgIGJ1bGxldHM6IFtcbiAgICAgICdEaWFnbm9zZSBhbmQgcmVzb2x2ZSBuZXR3b3JrLCBwcmludGVyLCBhbmQgaGFyZHdhcmUgaXNzdWVzIGFjcm9zcyBtdWx0aXBsZSBvZmZpY2UgbG9jYXRpb25zJyxcbiAgICAgICdDb25maWd1cmUgVlBOcywgY3Jvc3MtbmV0d29yayBmb2xkZXIgc2hhcmluZywgYW5kIFdpLUZpIHRyb3VibGVzaG9vdGluZyBmb3IgbXVsdGktZmxvb3IgZW52aXJvbm1lbnRzJyxcbiAgICAgICdNYW5hZ2UgSVQgcHJvY3VyZW1lbnQsIGhhcmR3YXJlIGV2YWx1YXRpb24sIGFuZCB2ZW5kb3IgY29vcmRpbmF0aW9uJyxcbiAgICAgICdEZWxpdmVyIGVuZC11c2VyIHRyYWluaW5nLCB0ZWNobmljYWwgZG9jdW1lbnRhdGlvbiwgYW5kIHdlZWtseSByZXBvcnRpbmcnLFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBjb21wYW55OiAnQWRkaXMgTWVzb2IgLSBCb2xlIEJyYW5jaCcsXG4gICAgcm9sZTogJ0hhcmR3YXJlIEVuZ2luZWVyJyxcbiAgICBwZXJpb2Q6ICdQYXN0JyxcbiAgICBidWxsZXRzOiBbXG4gICAgICAnSW5zdGFsbCwgY29uZmlndXJlLCBhbmQgbWFpbnRhaW4gY29tcHV0ZXIgaGFyZHdhcmUgc3lzdGVtcycsXG4gICAgICAnRGlhZ25vc2UgYW5kIHRyb3VibGVzaG9vdCBoYXJkd2FyZSBhbmQgcGVyaXBoZXJhbCBpc3N1ZXMnLFxuICAgICAgJ1N1cHBvcnQgcHJpbnRlciBzZXR1cCwgbmV0d29yayBjb25uZWN0aXZpdHksIGFuZCBzeXN0ZW0gbWFpbnRlbmFuY2UnLFxuICAgICAgJ0Vuc3VyZSBvcGVyYXRpb25hbCBjb250aW51aXR5IG9mIElUIGVxdWlwbWVudCcsXG4gICAgICAnQXNzaXN0IGluIHRlY2huaWNhbCBkb2N1bWVudGF0aW9uIGFuZCBzeXN0ZW0gbW9uaXRvcmluZycsXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGNvbXBhbnk6ICdFdGhpb3BpYW4gQXJ0aWZpY2lhbCBJbnRlbGxpZ2VuY2UgSW5zdGl0dXRlIChFQUlJKScsXG4gICAgcm9sZTogJ0FJL01MIEludGVybicsXG4gICAgcGVyaW9kOiAnUGFzdCcsXG4gICAgYnVsbGV0czogW1xuICAgICAgJ0Fzc2lzdGVkIGluIGRhdGEgY29sbGVjdGlvbiwgY2xlYW5pbmcsIGFuZCBwcmVwcm9jZXNzaW5nIGZvciBBSSBtb2RlbCBkZXZlbG9wbWVudCcsXG4gICAgICAnUGFydGljaXBhdGVkIGluIHRyYWluaW5nIGFuZCBldmFsdWF0aW9uIG9mIG1hY2hpbmUgbGVhcm5pbmcgbW9kZWxzJyxcbiAgICAgICdDb250cmlidXRlZCB0byBBSS1iYXNlZCBjaGF0Ym90IGRldmVsb3BtZW50IGFuZCBkZXBsb3ltZW50JyxcbiAgICAgICdQcmVwYXJlZCB0ZWNobmljYWwgZG9jdW1lbnRhdGlvbiBhbmQgcmVzZWFyY2ggc3VtbWFyaWVzJyxcbiAgICAgICdDb2xsYWJvcmF0ZWQgd2l0aCBjcm9zcy1mdW5jdGlvbmFsIHRlY2huaWNhbCB0ZWFtcycsXG4gICAgXSxcbiAgfSxcbl07XG5cbmNvbnN0IFRFQ0hfU0tJTExTID0gW1xuICB7XG4gICAgbGFiZWw6ICdJVCAmIEluZnJhc3RydWN0dXJlJyxcbiAgICB2YWx1ZTpcbiAgICAgICdJVCBJbmZyYXN0cnVjdHVyZSBTdXBwb3J0LCBTeXN0ZW0gVHJvdWJsZXNob290aW5nLCBQcm9jZXNzIEF1dG9tYXRpb24sIFRlY2huaWNhbCBEb2N1bWVudGF0aW9uJyxcbiAgfSxcbiAge1xuICAgIGxhYmVsOiAnUHJvZ3JhbW1pbmcgJiBEYXRhJyxcbiAgICB2YWx1ZTpcbiAgICAgICdQeXRob24gUHJvZ3JhbW1pbmcsIE1hY2hpbmUgTGVhcm5pbmcgRnVuZGFtZW50YWxzLCBEYXRhYmFzZSBEZXNpZ24gJiBTUUwnLFxuICB9LFxuICB7XG4gICAgbGFiZWw6ICdEZXZlbG9wbWVudCcsXG4gICAgdmFsdWU6ICdXZWIgQXBwbGljYXRpb24gRGV2ZWxvcG1lbnQsIFN0cm9uZyBXcml0dGVuICYgVmVyYmFsIENvbW11bmljYXRpb24nLFxuICB9LFxuXTtcblxuY29uc3QgQVRUUklCVVRFUyA9IFtcbiAgJ1N0cm9uZyBhbmFseXRpY2FsIG1pbmRzZXQnLFxuICAnSGlnaCBhY2NvdW50YWJpbGl0eSBhbmQgcHJvZmVzc2lvbmFsaXNtJyxcbiAgJ1Jlc3BlY3QgZm9yIGNvbmZpZGVudGlhbGl0eScsXG4gICdUZWFtIGNvbGxhYm9yYXRpb24gYW5kIGFkYXB0YWJpbGl0eScsXG4gICdEaWdpdGFsIGxlYXJuaW5nIGFnaWxpdHknLFxuXTtcblxuY29uc3QgUkVGRVJFTkNFID0ge1xuICBuYW1lOiAnS3VtbmVnZXIgU2l0b3RhdyAoTVNjKScsXG4gIHJvbGU6ICdIZWFkLCBEZXBhcnRtZW50IG9mIERpZ2l0aXphdGlvbiB8IEFkZGlzIE1lc29iIC0gQm9sZSBCcmFuY2gnLFxuICBwaG9uZTogJysyNTEgOTIgMDQzIDgwNzInLFxufTtcblxuLyog4pSA4pSA4pSAIENvbXBvbmVudCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuY29uc3QgUmVzdW1lID0gKCkgPT4ge1xuICBjb25zdCBoYW5kbGVQcmludCA9ICgpID0+IHdpbmRvdy5wcmludCgpO1xuICBjb25zdCBzZW9Qcm9wcyA9IHVzZVNFTyh7XG4gICAgdGl0bGU6ICdSZXN1bWUgLSBFcm1pYXMgTGVtZXNhIEJheWlzYScsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICAnUmVzdW1lIG9mIEVybWlhcyBMZW1lc2EgQmF5aXNhIC0gQ29tcHV0ZXIgRW5naW5lZXIsIElUIFN1cHBvcnQgU3BlY2lhbGlzdCBhbmQgSGFyZHdhcmUgRW5naW5lZXIgYmFzZWQgaW4gQWRkaXMgQWJhYmEsIEV0aGlvcGlhLicsXG4gICAga2V5d29yZHM6IFtcbiAgICAgICdyZXN1bWUnLFxuICAgICAgJ0NWJyxcbiAgICAgICdFcm1pYXMgTGVtZXNhJyxcbiAgICAgICdDb21wdXRlciBFbmdpbmVlcicsXG4gICAgICAnSVQgU3VwcG9ydCcsXG4gICAgICAnSGFyZHdhcmUgRW5naW5lZXInLFxuICAgIF0sXG4gICAgc2VjdGlvbjogJ1Jlc3VtZScsXG4gIH0pO1xuICBjb25zdCB7IGJyZWFkY3J1bWJTY2hlbWEgfSA9IHVzZVN0cnVjdHVyZWREYXRhKCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT0nbWluLWgtc2NyZWVuIGJnLWJhY2tncm91bmQnPlxuICAgICAgPFNFTyB7Li4uc2VvUHJvcHN9IC8+XG4gICAgICA8U3RydWN0dXJlZERhdGEgc2NoZW1hPXticmVhZGNydW1iU2NoZW1hfSAvPlxuXG4gICAgICB7Lyog4pSA4pSAIEFjdGlvbiBiYXIgKHNjcmVlbiBvbmx5KSDilIDilIAgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT0ncHJpbnQ6aGlkZGVuJz5cbiAgICAgICAgPE5hdmlnYXRpb24gLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT0ncHJpbnQ6aGlkZGVuIGZpeGVkIHRvcC0xNiBsZWZ0LTAgcmlnaHQtMCB6LTQwIGJnLWJhY2tncm91bmQvOTAgYmFja2Ryb3AtYmx1ciBib3JkZXItYiBib3JkZXItYm9yZGVyJz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J21heC13LTR4bCBteC1hdXRvIHB4LTQgcHktMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQnPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0ndGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgaGlkZGVuIHNtOmJsb2NrJz5cbiAgICAgICAgICAgIFVzZSA8c3Ryb25nPlByaW50IOKGkiBTYXZlIGFzIFBERjwvc3Ryb25nPiwgb3IgZG93bmxvYWQgbXkgQ1YuXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMic+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHZhcmlhbnQ9J291dGxpbmUnXG4gICAgICAgICAgICAgIHNpemU9J3NtJ1xuICAgICAgICAgICAgICBhc0NoaWxkXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT0nZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTInXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxhIGhyZWY9Jy9Fcm1pYXMuTF9jdi5wZGYnIGRvd25sb2FkPlxuICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9J2gtNCB3LTQnIC8+XG4gICAgICAgICAgICAgICAgRG93bmxvYWQgUERGXG4gICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcmludH1cbiAgICAgICAgICAgICAgc2l6ZT0nc20nXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT0nbWwtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBidG4tZ2xvdydcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPSdoLTQgdy00JyAvPlxuICAgICAgICAgICAgICBQcmludFxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiDilIDilIAgUmVzdW1lIHNoZWV0IOKUgOKUgCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdtaW4taC1zY3JlZW4gYmctYmFja2dyb3VuZCBwdC0yOCBwYi0yMCBwcmludDpwdC0wIHByaW50OnBiLTAgcHJpbnQ6Ymctd2hpdGUnPlxuICAgICAgICA8bW90aW9uLmFydGljbGVcbiAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDE2IH19XG4gICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC41IH19XG4gICAgICAgICAgY2xhc3NOYW1lPSdtYXgtdy00eGwgbXgtYXV0byBweC02IHByaW50OnB4LTBcbiAgICAgICAgICAgICAgICAgICAgIGJnLWNhcmQgcHJpbnQ6Ymctd2hpdGVcbiAgICAgICAgICAgICAgICAgICAgIHNoYWRvdy14bCBwcmludDpzaGFkb3ctbm9uZVxuICAgICAgICAgICAgICAgICAgICAgcm91bmRlZC0yeGwgcHJpbnQ6cm91bmRlZC1ub25lXG4gICAgICAgICAgICAgICAgICAgICBib3JkZXIgYm9yZGVyLWJvcmRlci81MCBwcmludDpib3JkZXItbm9uZSdcbiAgICAgICAgICBzdHlsZT17eyBmb250RmFtaWx5OiBcIidUaW1lcyBOZXcgUm9tYW4nLCBUaW1lcywgc2VyaWZcIiB9fVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3AtMTAgcHJpbnQ6cC04Jz5cbiAgICAgICAgICAgIHsvKiDilIDilIAgTmFtZSAmIGNvbnRhY3QgbGluZSDilIDilIAgKi99XG4gICAgICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT0nbWItNSBwcmludDptYi00Jz5cbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT0ndGV4dC0zeGwgZm9udC1ib2xkIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWZvcmVncm91bmQgcHJpbnQ6dGV4dC1ibGFjayB1cHBlcmNhc2UgbWItMSc+XG4gICAgICAgICAgICAgICAge0lORk8ubmFtZX1cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2Jsb2NrIHctZnVsbCBoLXB4IGJnLXByaW1hcnkgbXQtMSBwcmludDpiZy1ibHVlLTcwMCcgLz5cbiAgICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSd0ZXh0LXByaW1hcnkgcHJpbnQ6dGV4dC1ibHVlLTcwMCBmb250LXNlbWlib2xkIHRleHQtYmFzZSBtdC0xJz5cbiAgICAgICAgICAgICAgICB7SU5GTy50aXRsZX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHByaW50OnRleHQtZ3JheS03MDAgbXQtMSc+XG4gICAgICAgICAgICAgICAge0lORk8ubG9jYXRpb259Jm5ic3A7Jm5ic3A7fCZuYnNwOyZuYnNwOyBQaG9uZTombmJzcDtcbiAgICAgICAgICAgICAgICB7SU5GTy5waG9uZX0mbmJzcDsmbmJzcDt8Jm5ic3A7Jm5ic3A7XG4gICAgICAgICAgICAgICAge0lORk8uZW1haWx9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSd0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBwcmludDp0ZXh0LWdyYXktNzAwJz5cbiAgICAgICAgICAgICAgICBHaXRIdWI6Jm5ic3A7e0lORk8uZ2l0aHVifSZuYnNwOyZuYnNwO3wmbmJzcDsmbmJzcDtcbiAgICAgICAgICAgICAgICBUZWxlZ3JhbTombmJzcDt7SU5GTy50ZWxlZ3JhbX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9oZWFkZXI+XG5cbiAgICAgICAgICAgIHsvKiDilIDilIAgUHJvZmVzc2lvbmFsIFN1bW1hcnkg4pSA4pSAICovfVxuICAgICAgICAgICAgPFNlY3Rpb24gdGl0bGU9J1BST0ZFU1NJT05BTCBTVU1NQVJZOic+XG4gICAgICAgICAgICAgIDxibG9ja3F1b3RlIGNsYXNzTmFtZT0nYm9yZGVyLWwtMiBib3JkZXItcHJpbWFyeSBwcmludDpib3JkZXItYmx1ZS03MDAgcGwtNCB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWZvcmVncm91bmQvOTAgcHJpbnQ6dGV4dC1ncmF5LTgwMCc+XG4gICAgICAgICAgICAgICAge1NVTU1BUll9XG4gICAgICAgICAgICAgIDwvYmxvY2txdW90ZT5cbiAgICAgICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICAgICAgey8qIOKUgOKUgCBFZHVjYXRpb24g4pSA4pSAICovfVxuICAgICAgICAgICAgPFNlY3Rpb24gdGl0bGU9J0VEVUNBVElPTjonPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ndGV4dC1zbSBzcGFjZS15LTAuNSB0ZXh0LWZvcmVncm91bmQvOTAgcHJpbnQ6dGV4dC1ncmF5LTgwMCc+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSdmb250LW1lZGl1bSc+XG4gICAgICAgICAgICAgICAgICB7RURVQ0FUSU9OLnBlcmlvZH0gfCB7RURVQ0FUSU9OLnNjaG9vbH1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPHA+e0VEVUNBVElPTi5kZWdyZWV9PC9wPlxuICAgICAgICAgICAgICAgIDxwPkNHUEE6IHtFRFVDQVRJT04uY2dwYX08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICAgICAgICB7Lyog4pSA4pSAIE1ham9yIFByb2plY3RzIOKUgOKUgCAqL31cbiAgICAgICAgICAgIDxTZWN0aW9uIHRpdGxlPSdNQUpPUiBQUk9KRUNUUzonPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nc3BhY2UteS00Jz5cbiAgICAgICAgICAgICAgICB7UFJPSkVDVFMubWFwKHAgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e3AudGl0bGV9PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtc20gZm9udC1tZWRpdW0gdGV4dC1mb3JlZ3JvdW5kIHByaW50OnRleHQtYmxhY2snPlxuICAgICAgICAgICAgICAgICAgICAgIHtwLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgIHtwLm5vdGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdmb250LW1vbm8gdGV4dC1bMTFweF0gdHJhY2tpbmctd2lkZSB0ZXh0LW11dGVkLWZvcmVncm91bmQgcHJpbnQ6dGV4dC1ncmF5LTYwMCc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsnICd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICh7cC5ub3RlfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9J210LTEgc3BhY2UteS0wLjUgbGlzdC1kaXNjIGxpc3QtaW5zaWRlJz5cbiAgICAgICAgICAgICAgICAgICAgICB7cC5idWxsZXRzLm1hcCgoYiwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSd0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBwcmludDp0ZXh0LWdyYXktNzAwIG1sLTInXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtifVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICAgICAgey8qIOKUgOKUgCBQcm9mZXNzaW9uYWwgRXhwZXJpZW5jZSDilIDilIAgKi99XG4gICAgICAgICAgICA8U2VjdGlvbiB0aXRsZT0nUFJPRkVTU0lPTkFMIEVYUEVSSUVOQ0U6Jz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3NwYWNlLXktNSc+XG4gICAgICAgICAgICAgICAge0VYUEVSSUVOQ0UubWFwKGUgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2UuY29tcGFueX0+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0ndGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmQgcHJpbnQ6dGV4dC1ibGFjayc+XG4gICAgICAgICAgICAgICAgICAgICAge2UuY29tcGFueX1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHByaW50OnRleHQtZ3JheS02MDAnPlxuICAgICAgICAgICAgICAgICAgICAgIHtlLnJvbGV9XG4gICAgICAgICAgICAgICAgICAgICAge2UucGVyaW9kID8gYCB8ICR7ZS5wZXJpb2R9YCA6ICcnfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9J210LTEgc3BhY2UteS0wLjUgbGlzdC1kaXNjIGxpc3QtaW5zaWRlJz5cbiAgICAgICAgICAgICAgICAgICAgICB7ZS5idWxsZXRzLm1hcCgoYiwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSd0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBwcmludDp0ZXh0LWdyYXktNzAwIG1sLTInXG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtifVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICAgICAgey8qIOKUgOKUgCBTa2lsbHMgKyBBdHRyaWJ1dGVzIHNpZGUtYnktc2lkZSDilIDilIAgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtOCBtdC02IHByaW50OmdyaWQtY29scy0yJz5cbiAgICAgICAgICAgICAgey8qIFRlY2huaWNhbCBTa2lsbHMgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPFNlY3Rpb25UaXRsZSB0aXRsZT0nVEVDSE5JQ0FMICYgQU5BTFlUSUNBTCBTS0lMTFMnIC8+XG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT0nc3BhY2UteS0xIG10LTMnPlxuICAgICAgICAgICAgICAgICAge1RFQ0hfU0tJTExTLm1hcChzID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtzLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0ndGV4dC1zbSB0ZXh0LWZvcmVncm91bmQvOTAgcHJpbnQ6dGV4dC1ncmF5LTgwMCdcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1zZW1pYm9sZCc+e3MubGFiZWx9Ojwvc3Bhbj57JyAnfVxuICAgICAgICAgICAgICAgICAgICAgIHtzLnZhbHVlfVxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEFkZGl0aW9uYWwgQXR0cmlidXRlcyArIFJlZmVyZW5jZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3NwYWNlLXktNic+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxTZWN0aW9uVGl0bGUgdGl0bGU9J0FERElUSU9OQUwgQVRUUklCVVRFUzonIC8+XG4gICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPSdzcGFjZS15LTEgbXQtMyBsaXN0LWRpc2MgbGlzdC1pbnNpZGUnPlxuICAgICAgICAgICAgICAgICAgICB7QVRUUklCVVRFUy5tYXAoKGEsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8bGlcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0ndGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmQgcHJpbnQ6dGV4dC1ncmF5LTcwMCdcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxTZWN0aW9uVGl0bGUgdGl0bGU9J1JFRkVSRU5DRTonIC8+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtc20gdGV4dC1mb3JlZ3JvdW5kLzkwIHByaW50OnRleHQtZ3JheS04MDAgbXQtMyc+XG4gICAgICAgICAgICAgICAgICAgIHtSRUZFUkVOQ0UubmFtZX1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0ndGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmQgcHJpbnQ6dGV4dC1ncmF5LTcwMCc+XG4gICAgICAgICAgICAgICAgICAgIHtSRUZFUkVOQ0Uucm9sZX1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0ndGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmQgcHJpbnQ6dGV4dC1ncmF5LTcwMCc+XG4gICAgICAgICAgICAgICAgICAgIHtSRUZFUkVOQ0UucGhvbmV9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvbW90aW9uLmFydGljbGU+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFByaW50IHN0eWxlcyAqL31cbiAgICAgIDxzdHlsZT57YFxuICAgICAgICBAbWVkaWEgcHJpbnQge1xuICAgICAgICAgIEBwYWdlIHsgbWFyZ2luOiAxLjJjbTsgc2l6ZTogQTQ7IH1cbiAgICAgICAgICBib2R5IHsgLXdlYmtpdC1wcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0OyBwcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0OyB9XG4gICAgICAgICAgLnByaW50XFxcXDpoaWRkZW4geyBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7IH1cbiAgICAgICAgfVxuICAgICAgYH08L3N0eWxlPlxuICAgICAgPGRpdiBjbGFzc05hbWU9J3ByaW50OmhpZGRlbic+XG4gICAgICAgIDxGb290ZXIgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuLyog4pSA4pSAIEhlbHBlcnMg4pSA4pSAICovXG5jb25zdCBTZWN0aW9uVGl0bGUgPSAoeyB0aXRsZSB9OiB7IHRpdGxlOiBzdHJpbmcgfSkgPT4gKFxuICA8ZGl2PlxuICAgIDxoMiBjbGFzc05hbWU9J3RleHQtc20gZm9udC1ib2xkIHRyYWNraW5nLXdpZGUgdXBwZXJjYXNlIHRleHQtcHJpbWFyeSBwcmludDp0ZXh0LWJsdWUtNzAwJz5cbiAgICAgIHt0aXRsZX1cbiAgICA8L2gyPlxuICAgIDxkaXYgY2xhc3NOYW1lPSdoLXB4IGJnLXByaW1hcnkvNDAgcHJpbnQ6YmctYmx1ZS0zMDAgbXQtMScgLz5cbiAgPC9kaXY+XG4pO1xuXG5jb25zdCBTZWN0aW9uID0gKHtcbiAgdGl0bGUsXG4gIGNoaWxkcmVuLFxufToge1xuICB0aXRsZTogc3RyaW5nO1xuICBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlO1xufSkgPT4gKFxuICA8ZGl2IGNsYXNzTmFtZT0nbXQtNiBwcmludDptdC00IHByaW50OmJyZWFrLWluc2lkZS1hdm9pZCc+XG4gICAgPFNlY3Rpb25UaXRsZSB0aXRsZT17dGl0bGV9IC8+XG4gICAgPGRpdiBjbGFzc05hbWU9J210LTMnPntjaGlsZHJlbn08L2Rpdj5cbiAgPC9kaXY+XG4pO1xuXG5leHBvcnQgZGVmYXVsdCBSZXN1bWU7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJtb3Rpb24iLCJEb3dubG9hZCIsIlByaW50ZXIiLCJCdXR0b24iLCJOYXZpZ2F0aW9uIiwiRm9vdGVyIiwiU0VPIiwiU3RydWN0dXJlZERhdGEiLCJ1c2VTRU8iLCJ1c2VTdHJ1Y3R1cmVkRGF0YSIsIklORk8iLCJuYW1lIiwidGl0bGUiLCJsb2NhdGlvbiIsInBob25lIiwiZW1haWwiLCJnaXRodWIiLCJ0ZWxlZ3JhbSIsIlNVTU1BUlkiLCJFRFVDQVRJT04iLCJwZXJpb2QiLCJzY2hvb2wiLCJkZWdyZWUiLCJjZ3BhIiwiUFJPSkVDVFMiLCJub3RlIiwiYnVsbGV0cyIsIkVYUEVSSUVOQ0UiLCJjb21wYW55Iiwicm9sZSIsIlRFQ0hfU0tJTExTIiwibGFiZWwiLCJ2YWx1ZSIsIkFUVFJJQlVURVMiLCJSRUZFUkVOQ0UiLCJSZXN1bWUiLCJoYW5kbGVQcmludCIsIndpbmRvdyIsInByaW50Iiwic2VvUHJvcHMiLCJkZXNjcmlwdGlvbiIsImtleXdvcmRzIiwic2VjdGlvbiIsImJyZWFkY3J1bWJTY2hlbWEiLCJkaXYiLCJjbGFzc05hbWUiLCJzY2hlbWEiLCJzcGFuIiwic3Ryb25nIiwidmFyaWFudCIsInNpemUiLCJhc0NoaWxkIiwiYSIsImhyZWYiLCJkb3dubG9hZCIsIm9uQ2xpY2siLCJhcnRpY2xlIiwiaW5pdGlhbCIsIm9wYWNpdHkiLCJ5IiwiYW5pbWF0ZSIsInRyYW5zaXRpb24iLCJkdXJhdGlvbiIsInN0eWxlIiwiZm9udEZhbWlseSIsImhlYWRlciIsImgxIiwicCIsIlNlY3Rpb24iLCJibG9ja3F1b3RlIiwibWFwIiwidWwiLCJiIiwiaSIsImxpIiwiZSIsIlNlY3Rpb25UaXRsZSIsInMiLCJoMiIsImNoaWxkcmVuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsV0FBVyxRQUFRO0FBQzFCLFNBQVNDLE1BQU0sUUFBUSxnQkFBZ0I7QUFDdkMsU0FBU0MsUUFBUSxFQUFFQyxPQUFPLFFBQVEsZUFBZTtBQUNqRCxTQUFTQyxNQUFNLFFBQVEseUJBQXlCO0FBQ2hELE9BQU9DLGdCQUFnQixpQ0FBaUM7QUFDeEQsT0FBT0MsWUFBWSw2QkFBNkI7QUFDaEQsT0FBT0MsU0FBUyx1QkFBdUI7QUFDdkMsT0FBT0Msb0JBQW9CLGtDQUFrQztBQUM3RCxTQUFTQyxNQUFNLFFBQVEsa0JBQWtCO0FBQ3pDLFNBQVNDLGlCQUFpQixRQUFRLDhCQUE4QjtBQUVoRSxzREFBc0QsR0FFdEQsTUFBTUMsT0FBTztJQUNYQyxNQUFNO0lBQ05DLE9BQU87SUFDUEMsVUFBVTtJQUNWQyxPQUFPO0lBQ1BDLE9BQU87SUFDUEMsUUFBUTtJQUNSQyxVQUFVO0FBQ1o7QUFFQSxNQUFNQyxVQUNKO0FBRUYsTUFBTUMsWUFBWTtJQUNoQkMsUUFBUTtJQUNSQyxRQUFRO0lBQ1JDLFFBQVE7SUFDUkMsTUFBTTtBQUNSO0FBRUEsTUFBTUMsV0FBVztJQUNmO1FBQ0VaLE9BQU87UUFDUGEsTUFBTTtRQUNOQyxTQUFTO1lBQ1A7WUFDQTtZQUNBO1lBQ0E7WUFDQTtTQUNEO0lBQ0g7SUFDQTtRQUNFZCxPQUFPO1FBQ1BjLFNBQVM7WUFDUDtZQUNBO1lBQ0E7WUFDQTtTQUNEO0lBQ0g7SUFDQTtRQUNFZCxPQUFPO1FBQ1BjLFNBQVM7WUFDUDtZQUNBO1lBQ0E7WUFDQTtTQUNEO0lBQ0g7SUFDQTtRQUNFZCxPQUFPO1FBQ1BjLFNBQVM7WUFDUDtZQUNBO1lBQ0E7U0FDRDtJQUNIO0NBQ0Q7QUFFRCxNQUFNQyxhQUFhO0lBQ2pCO1FBQ0VDLFNBQVM7UUFDVEMsTUFBTTtRQUNOVCxRQUFRO1FBQ1JNLFNBQVM7WUFDUDtZQUNBO1lBQ0E7WUFDQTtTQUNEO0lBQ0g7SUFDQTtRQUNFRSxTQUFTO1FBQ1RDLE1BQU07UUFDTlQsUUFBUTtRQUNSTSxTQUFTO1lBQ1A7WUFDQTtZQUNBO1lBQ0E7WUFDQTtTQUNEO0lBQ0g7SUFDQTtRQUNFRSxTQUFTO1FBQ1RDLE1BQU07UUFDTlQsUUFBUTtRQUNSTSxTQUFTO1lBQ1A7WUFDQTtZQUNBO1lBQ0E7WUFDQTtTQUNEO0lBQ0g7Q0FDRDtBQUVELE1BQU1JLGNBQWM7SUFDbEI7UUFDRUMsT0FBTztRQUNQQyxPQUNFO0lBQ0o7SUFDQTtRQUNFRCxPQUFPO1FBQ1BDLE9BQ0U7SUFDSjtJQUNBO1FBQ0VELE9BQU87UUFDUEMsT0FBTztJQUNUO0NBQ0Q7QUFFRCxNQUFNQyxhQUFhO0lBQ2pCO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7Q0FDRDtBQUVELE1BQU1DLFlBQVk7SUFDaEJ2QixNQUFNO0lBQ05rQixNQUFNO0lBQ05mLE9BQU87QUFDVDtBQUVBLHNEQUFzRCxHQUV0RCxNQUFNcUIsU0FBUzs7SUFDYixNQUFNQyxjQUFjLElBQU1DLE9BQU9DLEtBQUs7SUFDdEMsTUFBTUMsV0FBVy9CLE9BQU87UUFDdEJJLE9BQU87UUFDUDRCLGFBQ0U7UUFDRkMsVUFBVTtZQUNSO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7WUFDQTtTQUNEO1FBQ0RDLFNBQVM7SUFDWDtJQUNBLE1BQU0sRUFBRUMsZ0JBQWdCLEVBQUUsR0FBR2xDO0lBRTdCLHFCQUNFLFFBQUNtQztRQUFJQyxXQUFVOzswQkFDYixRQUFDdkM7Z0JBQUssR0FBR2lDLFFBQVE7Ozs7OzswQkFDakIsUUFBQ2hDO2dCQUFldUMsUUFBUUg7Ozs7OzswQkFHeEIsUUFBQ0M7Z0JBQUlDLFdBQVU7MEJBQ2IsY0FBQSxRQUFDekM7Ozs7Ozs7Ozs7MEJBR0gsUUFBQ3dDO2dCQUFJQyxXQUFVOzBCQUNiLGNBQUEsUUFBQ0Q7b0JBQUlDLFdBQVU7O3NDQUNiLFFBQUNFOzRCQUFLRixXQUFVOztnQ0FBZ0Q7OENBQzFELFFBQUNHOzhDQUFPOzs7Ozs7Z0NBQTRCOzs7Ozs7O3NDQUUxQyxRQUFDSjs0QkFBSUMsV0FBVTs7OENBQ2IsUUFBQzFDO29DQUNDOEMsU0FBUTtvQ0FDUkMsTUFBSztvQ0FDTEMsT0FBTztvQ0FDUE4sV0FBVTs4Q0FFVixjQUFBLFFBQUNPO3dDQUFFQyxNQUFLO3dDQUFtQkMsUUFBUTs7MERBQ2pDLFFBQUNyRDtnREFBUzRDLFdBQVU7Ozs7Ozs0Q0FBWTs7Ozs7Ozs7Ozs7OzhDQUlwQyxRQUFDMUM7b0NBQ0NvRCxTQUFTbkI7b0NBQ1RjLE1BQUs7b0NBQ0xMLFdBQVU7O3NEQUVWLFFBQUMzQzs0Q0FBUTJDLFdBQVU7Ozs7Ozt3Q0FBWTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBCQVF2QyxRQUFDRDtnQkFBSUMsV0FBVTswQkFDYixjQUFBLFFBQUM3QyxPQUFPd0QsT0FBTztvQkFDYkMsU0FBUzt3QkFBRUMsU0FBUzt3QkFBR0MsR0FBRztvQkFBRztvQkFDN0JDLFNBQVM7d0JBQUVGLFNBQVM7d0JBQUdDLEdBQUc7b0JBQUU7b0JBQzVCRSxZQUFZO3dCQUFFQyxVQUFVO29CQUFJO29CQUM1QmpCLFdBQVU7b0JBS1ZrQixPQUFPO3dCQUFFQyxZQUFZO29CQUFrQzs4QkFFdkQsY0FBQSxRQUFDcEI7d0JBQUlDLFdBQVU7OzBDQUViLFFBQUNvQjtnQ0FBT3BCLFdBQVU7O2tEQUNoQixRQUFDcUI7d0NBQUdyQixXQUFVOzs0Q0FDWG5DLEtBQUtDLElBQUk7MERBQ1YsUUFBQ29DO2dEQUFLRixXQUFVOzs7Ozs7Ozs7Ozs7a0RBRWxCLFFBQUNzQjt3Q0FBRXRCLFdBQVU7a0RBQ1ZuQyxLQUFLRSxLQUFLOzs7Ozs7a0RBRWIsUUFBQ3VEO3dDQUFFdEIsV0FBVTs7NENBQ1ZuQyxLQUFLRyxRQUFROzRDQUFDOzRDQUNkSCxLQUFLSSxLQUFLOzRDQUFDOzRDQUNYSixLQUFLSyxLQUFLOzs7Ozs7O2tEQUViLFFBQUNvRDt3Q0FBRXRCLFdBQVU7OzRDQUFvRDs0Q0FDakRuQyxLQUFLTSxNQUFNOzRDQUFDOzRDQUNWTixLQUFLTyxRQUFROzs7Ozs7Ozs7Ozs7OzBDQUtqQyxRQUFDbUQ7Z0NBQVF4RCxPQUFNOzBDQUNiLGNBQUEsUUFBQ3lEO29DQUFXeEIsV0FBVTs4Q0FDbkIzQjs7Ozs7Ozs7Ozs7MENBS0wsUUFBQ2tEO2dDQUFReEQsT0FBTTswQ0FDYixjQUFBLFFBQUNnQztvQ0FBSUMsV0FBVTs7c0RBQ2IsUUFBQ3NCOzRDQUFFdEIsV0FBVTs7Z0RBQ1YxQixVQUFVQyxNQUFNO2dEQUFDO2dEQUFJRCxVQUFVRSxNQUFNOzs7Ozs7O3NEQUV4QyxRQUFDOEM7c0RBQUdoRCxVQUFVRyxNQUFNOzs7Ozs7c0RBQ3BCLFFBQUM2Qzs7Z0RBQUU7Z0RBQU9oRCxVQUFVSSxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7MENBSzVCLFFBQUM2QztnQ0FBUXhELE9BQU07MENBQ2IsY0FBQSxRQUFDZ0M7b0NBQUlDLFdBQVU7OENBQ1pyQixTQUFTOEMsR0FBRyxDQUFDSCxDQUFBQSxrQkFDWixRQUFDdkI7OzhEQUNDLFFBQUN1QjtvREFBRXRCLFdBQVU7O3dEQUNWc0IsRUFBRXZELEtBQUs7d0RBQ1B1RCxFQUFFMUMsSUFBSSxrQkFDTCxRQUFDc0I7NERBQUtGLFdBQVU7O2dFQUNiO2dFQUFJO2dFQUNIc0IsRUFBRTFDLElBQUk7Z0VBQUM7Ozs7Ozs7Ozs7Ozs7OERBSWYsUUFBQzhDO29EQUFHMUIsV0FBVTs4REFDWHNCLEVBQUV6QyxPQUFPLENBQUM0QyxHQUFHLENBQUMsQ0FBQ0UsR0FBR0Msa0JBQ2pCLFFBQUNDOzREQUVDN0IsV0FBVTtzRUFFVDJCOzJEQUhJQzs7Ozs7Ozs7Ozs7MkNBYkhOLEVBQUV2RCxLQUFLOzs7Ozs7Ozs7Ozs7Ozs7MENBMEJ2QixRQUFDd0Q7Z0NBQVF4RCxPQUFNOzBDQUNiLGNBQUEsUUFBQ2dDO29DQUFJQyxXQUFVOzhDQUNabEIsV0FBVzJDLEdBQUcsQ0FBQ0ssQ0FBQUEsa0JBQ2QsUUFBQy9COzs4REFDQyxRQUFDdUI7b0RBQUV0QixXQUFVOzhEQUNWOEIsRUFBRS9DLE9BQU87Ozs7Ozs4REFFWixRQUFDdUM7b0RBQUV0QixXQUFVOzt3REFDVjhCLEVBQUU5QyxJQUFJO3dEQUNOOEMsRUFBRXZELE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRXVELEVBQUV2RCxNQUFNLEVBQUUsR0FBRzs7Ozs7Ozs4REFFakMsUUFBQ21EO29EQUFHMUIsV0FBVTs4REFDWDhCLEVBQUVqRCxPQUFPLENBQUM0QyxHQUFHLENBQUMsQ0FBQ0UsR0FBR0Msa0JBQ2pCLFFBQUNDOzREQUVDN0IsV0FBVTtzRUFFVDJCOzJEQUhJQzs7Ozs7Ozs7Ozs7MkNBWEhFLEVBQUUvQyxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7MENBd0J6QixRQUFDZ0I7Z0NBQUlDLFdBQVU7O2tEQUViLFFBQUNEOzswREFDQyxRQUFDZ0M7Z0RBQWFoRSxPQUFNOzs7Ozs7MERBQ3BCLFFBQUMyRDtnREFBRzFCLFdBQVU7MERBQ1hmLFlBQVl3QyxHQUFHLENBQUNPLENBQUFBLGtCQUNmLFFBQUNIO3dEQUVDN0IsV0FBVTs7MEVBRVYsUUFBQ0U7Z0VBQUtGLFdBQVU7O29FQUFpQmdDLEVBQUU5QyxLQUFLO29FQUFDOzs7Ozs7OzREQUFTOzREQUNqRDhDLEVBQUU3QyxLQUFLOzt1REFKSDZDLEVBQUU5QyxLQUFLOzs7Ozs7Ozs7Ozs7Ozs7O2tEQVdwQixRQUFDYTt3Q0FBSUMsV0FBVTs7MERBQ2IsUUFBQ0Q7O2tFQUNDLFFBQUNnQzt3REFBYWhFLE9BQU07Ozs7OztrRUFDcEIsUUFBQzJEO3dEQUFHMUIsV0FBVTtrRUFDWFosV0FBV3FDLEdBQUcsQ0FBQyxDQUFDbEIsR0FBR3FCLGtCQUNsQixRQUFDQztnRUFFQzdCLFdBQVU7MEVBRVRPOytEQUhJcUI7Ozs7Ozs7Ozs7Ozs7Ozs7MERBUWIsUUFBQzdCOztrRUFDQyxRQUFDZ0M7d0RBQWFoRSxPQUFNOzs7Ozs7a0VBQ3BCLFFBQUN1RDt3REFBRXRCLFdBQVU7a0VBQ1ZYLFVBQVV2QixJQUFJOzs7Ozs7a0VBRWpCLFFBQUN3RDt3REFBRXRCLFdBQVU7a0VBQ1ZYLFVBQVVMLElBQUk7Ozs7OztrRUFFakIsUUFBQ3NDO3dEQUFFdEIsV0FBVTtrRUFDVlgsVUFBVXBCLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBVTlCLFFBQUNpRDswQkFBTyxDQUFDOzs7Ozs7TUFNVCxDQUFDOzs7Ozs7MEJBQ0QsUUFBQ25CO2dCQUFJQyxXQUFVOzBCQUNiLGNBQUEsUUFBQ3hDOzs7Ozs7Ozs7Ozs7Ozs7O0FBSVQ7R0FyT004Qjs7UUFFYTNCO1FBY1lDOzs7S0FoQnpCMEI7QUF1T04saUJBQWlCLEdBQ2pCLE1BQU15QyxlQUFlLENBQUMsRUFBRWhFLEtBQUssRUFBcUIsaUJBQ2hELFFBQUNnQzs7MEJBQ0MsUUFBQ2tDO2dCQUFHakMsV0FBVTswQkFDWGpDOzs7Ozs7MEJBRUgsUUFBQ2dDO2dCQUFJQyxXQUFVOzs7Ozs7Ozs7Ozs7TUFMYitCO0FBU04sTUFBTVIsVUFBVSxDQUFDLEVBQ2Z4RCxLQUFLLEVBQ0xtRSxRQUFRLEVBSVQsaUJBQ0MsUUFBQ25DO1FBQUlDLFdBQVU7OzBCQUNiLFFBQUMrQjtnQkFBYWhFLE9BQU9BOzs7Ozs7MEJBQ3JCLFFBQUNnQztnQkFBSUMsV0FBVTswQkFBUWtDOzs7Ozs7Ozs7Ozs7TUFUckJYO0FBYU4sZUFBZWpDLE9BQU8ifQ==