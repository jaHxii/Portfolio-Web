import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Experience.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/pages/Experience.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { useInView } from "/node_modules/.vite/deps/react-intersection-observer.js?v=e72f996b";
import { Award, Building, MapPin, TrendingUp } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import Navigation from "/src/components/layout/Navigation.tsx";
import Footer from "/src/components/layout/Footer.tsx";
import Atmosphere from "/src/components/atmosphere/Atmosphere.tsx";
import FlightLog from "/src/components/ui/flight-log.tsx";
import SEO from "/src/components/seo/SEO.tsx";
import StructuredData from "/src/components/seo/StructuredData.tsx";
import { useSEO } from "/src/hooks/use-seo.ts";
import { useStructuredData } from "/src/hooks/use-structured-data.ts";
import { createOrganizationSchema } from "/src/lib/structured-data.ts";
const Experience = ()=>{
    _s();
    const seoProps = useSEO();
    const { breadcrumbSchema } = useStructuredData();
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    });
    const experiences = [
        {
            role: 'Senior IT Support',
            company: 'ROTECH Information Technology',
            location: 'Addis Ababa, Ethiopia',
            period: 'Present',
            type: 'Full-time',
            startYear: undefined,
            endYear: undefined,
            description: 'Providing enterprise IT support across multiple office locations - diagnosing network, printer, and hardware faults and resolving helpdesk tickets within SLAs.',
            achievements: [
                'Diagnose and resolve network, printer, and hardware issues across multiple office locations',
                'Configure VPNs, cross-network folder sharing, and Wi-Fi troubleshooting for multi-floor environments',
                'Manage IT procurement, hardware evaluation, and vendor coordination',
                'Deliver end-user training, technical documentation, and weekly reporting'
            ],
            technologies: [
                'Network Troubleshooting',
                'VPN',
                'Wi-Fi',
                'Windows',
                'Hardware',
                'IT Procurement'
            ],
            impact: {
                coverage: 'Multiple office sites',
                support: 'Remote, chat & in-person'
            }
        },
        {
            role: 'Hardware Engineer',
            company: 'Addis Mesob - Bole Branch',
            location: 'Addis Ababa, Ethiopia',
            period: 'Previous role',
            type: 'Full-time',
            startYear: undefined,
            endYear: undefined,
            description: 'Installed, configured, and maintained computer hardware systems while supporting printer setup, network connectivity, and system maintenance.',
            achievements: [
                'Install, configure, and maintain computer hardware systems',
                'Diagnose and troubleshoot hardware and peripheral issues',
                'Support printer setup, network connectivity, and system maintenance',
                'Ensure operational continuity of IT equipment',
                'Assist in technical documentation and system monitoring'
            ],
            technologies: [
                'Hardware',
                'Peripherals',
                'Printers',
                'Networking',
                'Documentation'
            ],
            impact: {
                scope: 'End-to-end hardware maintenance',
                setup: 'Printer & network setup'
            }
        },
        {
            role: 'AI/ML Intern',
            company: 'Ethiopian Artificial Intelligence Institute (EAII)',
            location: 'Addis Ababa, Ethiopia',
            period: 'Internship',
            type: 'Internship',
            startYear: undefined,
            endYear: undefined,
            description: 'Supported AI model development through data preparation, model training and evaluation, and chatbot development.',
            achievements: [
                'Assisted in data collection, cleaning, and preprocessing for AI model development',
                'Participated in training and evaluation of machine learning models',
                'Contributed to AI-based chatbot development and deployment',
                'Prepared technical documentation and research summaries',
                'Collaborated with cross-functional technical teams'
            ],
            technologies: [
                'Python',
                'Data Preprocessing',
                'Machine Learning',
                'Chatbots'
            ],
            impact: {
                data: 'ML data pipelines',
                models: 'Training & evaluation'
            }
        }
    ];
    const education = [
        {
            degree: 'Bachelor of Science in Computer Engineering',
            school: 'University of Gondar',
            period: 'Aug 2021 - Aug 2025',
            gpa: '3.42/4.0',
            achievements: [
                'Graduated August 2025 with CGPA 3.42',
                'Strong foundation in computer engineering, systems, and software development'
            ]
        }
    ];
    // Create organization schemas for work experience
    const organizationSchemas = experiences.map((exp)=>createOrganizationSchema({
            name: exp.company,
            description: exp.description,
            address: {
                locality: exp.location.split(' / ')[1] || exp.location,
                country: 'Ethiopia'
            },
            employees: [
                {
                    name: 'Ermias Lemesa',
                    jobTitle: exp.role,
                    ...exp.startYear ? {
                        startDate: exp.startYear
                    } : {},
                    ...exp.endYear ? {
                        endDate: exp.endYear
                    } : {}
                }
            ]
        }));
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "min-h-screen bg-background",
        children: [
            /*#__PURE__*/ _jsxDEV(SEO, {
                ...seoProps
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                lineNumber: 148,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(StructuredData, {
                schema: breadcrumbSchema
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                lineNumber: 149,
                columnNumber: 7
            }, this),
            organizationSchemas.map((schema, index)=>/*#__PURE__*/ _jsxDEV(StructuredData, {
                    schema: schema
                }, index, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                    lineNumber: 151,
                    columnNumber: 9
                }, this)),
            /*#__PURE__*/ _jsxDEV(Navigation, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                lineNumber: 153,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("section", {
                className: "relative pt-36 pb-20 overflow-hidden",
                children: [
                    /*#__PURE__*/ _jsxDEV(Atmosphere, {}, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                        lineNumber: 157,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "relative z-10 container mx-auto px-4",
                        children: /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: 0.8
                            },
                            className: "max-w-3xl mx-auto text-center",
                            children: [
                                /*#__PURE__*/ _jsxDEV(FlightLog, {
                                    entries: [
                                        'FLIGHT PATH / CAREER',
                                        'WAYPOINT 03 · CLIMBING',
                                        'AUTOPILOT · ENGAGED',
                                        'EST. ARRIVAL · CLOUD-9'
                                    ]
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                    lineNumber: 165,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("h1", {
                                    className: "text-4xl md:text-5xl font-bold font-heading tracking-tight",
                                    children: /*#__PURE__*/ _jsxDEV("span", {
                                        className: "name-gradient",
                                        children: "Experience"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                        lineNumber: 174,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                    lineNumber: 173,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("p", {
                                    className: "mt-5 text-lg text-mist-soft leading-relaxed font-light max-w-2xl mx-auto",
                                    children: "A rising trajectory - from AI/ML intern to senior IT support, climbing through hardware and systems."
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                    lineNumber: 176,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                            lineNumber: 159,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                        lineNumber: 158,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                lineNumber: 156,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("section", {
                className: "relative pb-16 overflow-hidden",
                children: [
                    /*#__PURE__*/ _jsxDEV(Atmosphere, {
                        variant: "mist",
                        className: "opacity-70"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                        lineNumber: 186,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "relative z-10 container mx-auto px-4 max-w-6xl",
                        children: [
                            /*#__PURE__*/ _jsxDEV(motion.div, {
                                ref: ref,
                                initial: {
                                    opacity: 0,
                                    y: 30
                                },
                                animate: inView ? {
                                    opacity: 1,
                                    y: 0
                                } : {},
                                transition: {
                                    duration: 0.8
                                },
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "absolute left-5 md:left-1/3 md:-translate-x-px top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-gold/50 to-transparent"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                        lineNumber: 196,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "space-y-12 md:space-y-16",
                                        children: experiences.map((exp, index)=>/*#__PURE__*/ _jsxDEV(motion.div, {
                                                initial: {
                                                    opacity: 0,
                                                    x: -30
                                                },
                                                animate: inView ? {
                                                    opacity: 1,
                                                    x: 0
                                                } : {},
                                                transition: {
                                                    delay: 0.3 + index * 0.18,
                                                    duration: 0.6
                                                },
                                                className: "relative md:grid md:grid-cols-12 md:gap-10 items-start",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                        className: "absolute left-5 md:left-1/3 -translate-x-1/2 top-8",
                                                        children: /*#__PURE__*/ _jsxDEV("div", {
                                                            className: "relative",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "h-3 w-3 rounded-full bg-gold shadow-glow"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 210,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "absolute inset-0 rounded-full bg-gold/40 animate-pulse"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 211,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                            lineNumber: 209,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                        lineNumber: 208,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                        className: "hidden md:flex flex-col items-end gap-1 pt-8 md:col-span-4",
                                                        children: [
                                                            /*#__PURE__*/ _jsxDEV("span", {
                                                                className: "font-mono text-xs tracking-[0.3em] gold-text",
                                                                children: String(index + 1).padStart(2, '0')
                                                            }, void 0, false, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                lineNumber: 217,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ _jsxDEV("span", {
                                                                className: "font-heading font-semibold text-2xl tracking-tight",
                                                                children: exp.period
                                                            }, void 0, false, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                lineNumber: 220,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                        lineNumber: 216,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                        className: "pl-14 md:pl-0 pt-8 md:pt-0 md:col-span-8",
                                                        children: /*#__PURE__*/ _jsxDEV("div", {
                                                            className: "glass-cloud rounded-2xl p-7",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "flex items-center gap-2 md:hidden mb-3",
                                                                    children: /*#__PURE__*/ _jsxDEV("span", {
                                                                        className: "font-mono text-xs tracking-[0.3em] gold-text",
                                                                        children: [
                                                                            String(index + 1).padStart(2, '0'),
                                                                            " / ",
                                                                            exp.period
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                        lineNumber: 229,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 228,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("h3", {
                                                                    className: "font-heading font-bold text-xl tracking-tight",
                                                                    children: exp.role
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 234,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-sm text-mist-soft",
                                                                    children: [
                                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                                            className: "flex items-center gap-1.5",
                                                                            children: [
                                                                                /*#__PURE__*/ _jsxDEV(Building, {
                                                                                    className: "h-4 w-4 gold-text"
                                                                                }, void 0, false, {
                                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                    lineNumber: 239,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                /*#__PURE__*/ _jsxDEV("span", {
                                                                                    children: exp.company
                                                                                }, void 0, false, {
                                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                    lineNumber: 240,
                                                                                    columnNumber: 27
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                            lineNumber: 238,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                                            className: "flex items-center gap-1.5",
                                                                            children: [
                                                                                /*#__PURE__*/ _jsxDEV(MapPin, {
                                                                                    className: "h-4 w-4 gold-text"
                                                                                }, void 0, false, {
                                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                    lineNumber: 243,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                /*#__PURE__*/ _jsxDEV("span", {
                                                                                    children: exp.location
                                                                                }, void 0, false, {
                                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                    lineNumber: 244,
                                                                                    columnNumber: 27
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                            lineNumber: 242,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 237,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("p", {
                                                                    className: "text-mist-soft leading-relaxed mt-5 text-sm font-light",
                                                                    children: exp.description
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 248,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "mt-6",
                                                                    children: [
                                                                        /*#__PURE__*/ _jsxDEV("h4", {
                                                                            className: "font-semibold text-sm mb-3 flex items-center gap-2",
                                                                            children: [
                                                                                /*#__PURE__*/ _jsxDEV(Award, {
                                                                                    className: "h-4 w-4 gold-text"
                                                                                }, void 0, false, {
                                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                    lineNumber: 254,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                "Key Achievements"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                            lineNumber: 253,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ _jsxDEV("ul", {
                                                                            className: "space-y-2",
                                                                            children: exp.achievements.map((achievement, i)=>/*#__PURE__*/ _jsxDEV("li", {
                                                                                    className: "flex items-start gap-2.5 text-sm text-mist-soft",
                                                                                    children: [
                                                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                                                            className: "w-1 h-1 bg-gold rounded-full mt-2 flex-shrink-0"
                                                                                        }, void 0, false, {
                                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                            lineNumber: 263,
                                                                                            columnNumber: 31
                                                                                        }, this),
                                                                                        /*#__PURE__*/ _jsxDEV("span", {
                                                                                            children: achievement
                                                                                        }, void 0, false, {
                                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                            lineNumber: 264,
                                                                                            columnNumber: 31
                                                                                        }, this)
                                                                                    ]
                                                                                }, i, true, {
                                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                    lineNumber: 259,
                                                                                    columnNumber: 29
                                                                                }, this))
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                            lineNumber: 257,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 252,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "mt-6",
                                                                    children: [
                                                                        /*#__PURE__*/ _jsxDEV("h4", {
                                                                            className: "font-semibold text-sm mb-3 flex items-center gap-2",
                                                                            children: [
                                                                                /*#__PURE__*/ _jsxDEV(TrendingUp, {
                                                                                    className: "h-4 w-4 gold-text"
                                                                                }, void 0, false, {
                                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                    lineNumber: 272,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                "Impact"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                            lineNumber: 271,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                                            className: "flex flex-wrap gap-3",
                                                                            children: Object.entries(exp.impact).map(([key, value])=>/*#__PURE__*/ _jsxDEV("div", {
                                                                                    className: "glass rounded-md px-3 py-2",
                                                                                    children: [
                                                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                                                            className: "gold-text font-semibold text-sm",
                                                                                            children: value
                                                                                        }, void 0, false, {
                                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                            lineNumber: 281,
                                                                                            columnNumber: 31
                                                                                        }, this),
                                                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                                                            className: "text-xs text-mist-soft capitalize",
                                                                                            children: key
                                                                                        }, void 0, false, {
                                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                            lineNumber: 284,
                                                                                            columnNumber: 31
                                                                                        }, this)
                                                                                    ]
                                                                                }, key, true, {
                                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                    lineNumber: 277,
                                                                                    columnNumber: 29
                                                                                }, this))
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                            lineNumber: 275,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 270,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "mt-6",
                                                                    children: [
                                                                        /*#__PURE__*/ _jsxDEV("h4", {
                                                                            className: "font-semibold text-sm mb-3",
                                                                            children: "Technologies Used"
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                            lineNumber: 293,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                                            className: "flex flex-wrap gap-2",
                                                                            children: exp.technologies.map((tech)=>/*#__PURE__*/ _jsxDEV("span", {
                                                                                    className: "glass rounded-md px-2.5 py-1 font-mono text-xs text-mist-soft",
                                                                                    children: tech
                                                                                }, tech, false, {
                                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                                    lineNumber: 298,
                                                                                    columnNumber: 29
                                                                                }, this))
                                                                        }, void 0, false, {
                                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                            lineNumber: 296,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 292,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                            lineNumber: 227,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                        lineNumber: 226,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, `${exp.company}-${exp.period}`, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                lineNumber: 200,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                        lineNumber: 198,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                lineNumber: 188,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV(motion.div, {
                                initial: {
                                    opacity: 0,
                                    y: 30
                                },
                                animate: inView ? {
                                    opacity: 1,
                                    y: 0
                                } : {},
                                transition: {
                                    delay: 1.2,
                                    duration: 0.8
                                },
                                className: "mt-20",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "text-center mb-10",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "font-mono text-xs tracking-[0.3em] gold-text",
                                                children: "ORIGIN /"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                lineNumber: 322,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("h2", {
                                                className: "text-2xl md:text-3xl font-bold font-heading mt-2 tracking-tight",
                                                children: "Education"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                lineNumber: 325,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                        lineNumber: 321,
                                        columnNumber: 13
                                    }, this),
                                    education.map((edu, index)=>/*#__PURE__*/ _jsxDEV("div", {
                                            className: "glass-cloud rounded-2xl p-7 md:p-8 transition-all duration-300",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("div", {
                                                    className: "flex flex-col md:flex-row md:items-start md:justify-between gap-3 mb-4",
                                                    children: [
                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("h3", {
                                                                    className: "font-heading font-bold text-lg tracking-tight",
                                                                    children: edu.degree
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 336,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("p", {
                                                                    className: "text-mist-soft text-sm mt-1",
                                                                    children: edu.school
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 339,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                            lineNumber: 335,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ _jsxDEV("div", {
                                                            className: "flex items-center gap-3 md:flex-col md:items-end",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("span", {
                                                                    className: "font-mono text-xs text-mist-soft",
                                                                    children: edu.period
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 342,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("span", {
                                                                    className: "px-2.5 py-1 rounded-md border border-gold/40 text-gold font-mono text-xs",
                                                                    children: [
                                                                        "GPA: ",
                                                                        edu.gpa
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 345,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                            lineNumber: 341,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                    lineNumber: 334,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("ul", {
                                                    className: "space-y-2",
                                                    children: edu.achievements.map((achievement, i)=>/*#__PURE__*/ _jsxDEV("li", {
                                                            className: "flex items-start gap-2.5 text-sm text-mist-soft",
                                                            children: [
                                                                /*#__PURE__*/ _jsxDEV("div", {
                                                                    className: "w-1 h-1 bg-gold rounded-full mt-2 flex-shrink-0"
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 356,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ _jsxDEV("span", {
                                                                    children: achievement
                                                                }, void 0, false, {
                                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                                    lineNumber: 357,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, i, true, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                            lineNumber: 352,
                                                            columnNumber: 21
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                                    lineNumber: 350,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, index, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                            lineNumber: 330,
                                            columnNumber: 15
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                                lineNumber: 315,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                        lineNumber: 187,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                lineNumber: 185,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(Footer, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
                lineNumber: 366,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/Experience.tsx",
        lineNumber: 147,
        columnNumber: 5
    }, this);
};
_s(Experience, "UzxfgszjPNZMiyUoNSeIGAfAq4E=", false, function() {
    return [
        useSEO,
        useStructuredData,
        useInView
    ];
});
_c = Experience;
export default Experience;
var _c;
$RefreshReg$(_c, "Experience");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/pages/Experience.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/pages/Experience.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkV4cGVyaWVuY2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IHVzZUluVmlldyB9IGZyb20gJ3JlYWN0LWludGVyc2VjdGlvbi1vYnNlcnZlcic7XG5pbXBvcnQgeyBBd2FyZCwgQnVpbGRpbmcsIE1hcFBpbiwgVHJlbmRpbmdVcCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgTmF2aWdhdGlvbiBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L05hdmlnYXRpb24nO1xuaW1wb3J0IEZvb3RlciBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L0Zvb3Rlcic7XG5pbXBvcnQgQXRtb3NwaGVyZSBmcm9tICdAL2NvbXBvbmVudHMvYXRtb3NwaGVyZS9BdG1vc3BoZXJlJztcbmltcG9ydCBGbGlnaHRMb2cgZnJvbSAnQC9jb21wb25lbnRzL3VpL2ZsaWdodC1sb2cnO1xuaW1wb3J0IFNFTyBmcm9tICdAL2NvbXBvbmVudHMvc2VvL1NFTyc7XG5pbXBvcnQgU3RydWN0dXJlZERhdGEgZnJvbSAnQC9jb21wb25lbnRzL3Nlby9TdHJ1Y3R1cmVkRGF0YSc7XG5pbXBvcnQgeyB1c2VTRU8gfSBmcm9tICdAL2hvb2tzL3VzZS1zZW8nO1xuaW1wb3J0IHsgdXNlU3RydWN0dXJlZERhdGEgfSBmcm9tICdAL2hvb2tzL3VzZS1zdHJ1Y3R1cmVkLWRhdGEnO1xuaW1wb3J0IHsgY3JlYXRlT3JnYW5pemF0aW9uU2NoZW1hIH0gZnJvbSAnQC9saWIvc3RydWN0dXJlZC1kYXRhJztcblxuY29uc3QgRXhwZXJpZW5jZSA9ICgpID0+IHtcbiAgY29uc3Qgc2VvUHJvcHMgPSB1c2VTRU8oKTtcbiAgY29uc3QgeyBicmVhZGNydW1iU2NoZW1hIH0gPSB1c2VTdHJ1Y3R1cmVkRGF0YSgpO1xuXG4gIGNvbnN0IFtyZWYsIGluVmlld10gPSB1c2VJblZpZXcoe1xuICAgIHRyaWdnZXJPbmNlOiB0cnVlLFxuICAgIHRocmVzaG9sZDogMC4xLFxuICB9KTtcblxuICBjb25zdCBleHBlcmllbmNlcyA9IFtcbiAgICB7XG4gICAgICByb2xlOiAnU2VuaW9yIElUIFN1cHBvcnQnLFxuICAgICAgY29tcGFueTogJ1JPVEVDSCBJbmZvcm1hdGlvbiBUZWNobm9sb2d5JyxcbiAgICAgIGxvY2F0aW9uOiAnQWRkaXMgQWJhYmEsIEV0aGlvcGlhJyxcbiAgICAgIHBlcmlvZDogJ1ByZXNlbnQnLFxuICAgICAgdHlwZTogJ0Z1bGwtdGltZScsXG4gICAgICBzdGFydFllYXI6IHVuZGVmaW5lZCxcbiAgICAgIGVuZFllYXI6IHVuZGVmaW5lZCxcbiAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICAnUHJvdmlkaW5nIGVudGVycHJpc2UgSVQgc3VwcG9ydCBhY3Jvc3MgbXVsdGlwbGUgb2ZmaWNlIGxvY2F0aW9ucyAtIGRpYWdub3NpbmcgbmV0d29yaywgcHJpbnRlciwgYW5kIGhhcmR3YXJlIGZhdWx0cyBhbmQgcmVzb2x2aW5nIGhlbHBkZXNrIHRpY2tldHMgd2l0aGluIFNMQXMuJyxcbiAgICAgIGFjaGlldmVtZW50czogW1xuICAgICAgICAnRGlhZ25vc2UgYW5kIHJlc29sdmUgbmV0d29yaywgcHJpbnRlciwgYW5kIGhhcmR3YXJlIGlzc3VlcyBhY3Jvc3MgbXVsdGlwbGUgb2ZmaWNlIGxvY2F0aW9ucycsXG4gICAgICAgICdDb25maWd1cmUgVlBOcywgY3Jvc3MtbmV0d29yayBmb2xkZXIgc2hhcmluZywgYW5kIFdpLUZpIHRyb3VibGVzaG9vdGluZyBmb3IgbXVsdGktZmxvb3IgZW52aXJvbm1lbnRzJyxcbiAgICAgICAgJ01hbmFnZSBJVCBwcm9jdXJlbWVudCwgaGFyZHdhcmUgZXZhbHVhdGlvbiwgYW5kIHZlbmRvciBjb29yZGluYXRpb24nLFxuICAgICAgICAnRGVsaXZlciBlbmQtdXNlciB0cmFpbmluZywgdGVjaG5pY2FsIGRvY3VtZW50YXRpb24sIGFuZCB3ZWVrbHkgcmVwb3J0aW5nJyxcbiAgICAgIF0sXG4gICAgICB0ZWNobm9sb2dpZXM6IFtcbiAgICAgICAgJ05ldHdvcmsgVHJvdWJsZXNob290aW5nJyxcbiAgICAgICAgJ1ZQTicsXG4gICAgICAgICdXaS1GaScsXG4gICAgICAgICdXaW5kb3dzJyxcbiAgICAgICAgJ0hhcmR3YXJlJyxcbiAgICAgICAgJ0lUIFByb2N1cmVtZW50JyxcbiAgICAgIF0sXG4gICAgICBpbXBhY3Q6IHtcbiAgICAgICAgY292ZXJhZ2U6ICdNdWx0aXBsZSBvZmZpY2Ugc2l0ZXMnLFxuICAgICAgICBzdXBwb3J0OiAnUmVtb3RlLCBjaGF0ICYgaW4tcGVyc29uJyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB7XG4gICAgICByb2xlOiAnSGFyZHdhcmUgRW5naW5lZXInLFxuICAgICAgY29tcGFueTogJ0FkZGlzIE1lc29iIC0gQm9sZSBCcmFuY2gnLFxuICAgICAgbG9jYXRpb246ICdBZGRpcyBBYmFiYSwgRXRoaW9waWEnLFxuICAgICAgcGVyaW9kOiAnUHJldmlvdXMgcm9sZScsXG4gICAgICB0eXBlOiAnRnVsbC10aW1lJyxcbiAgICAgIHN0YXJ0WWVhcjogdW5kZWZpbmVkLFxuICAgICAgZW5kWWVhcjogdW5kZWZpbmVkLFxuICAgICAgZGVzY3JpcHRpb246XG4gICAgICAgICdJbnN0YWxsZWQsIGNvbmZpZ3VyZWQsIGFuZCBtYWludGFpbmVkIGNvbXB1dGVyIGhhcmR3YXJlIHN5c3RlbXMgd2hpbGUgc3VwcG9ydGluZyBwcmludGVyIHNldHVwLCBuZXR3b3JrIGNvbm5lY3Rpdml0eSwgYW5kIHN5c3RlbSBtYWludGVuYW5jZS4nLFxuICAgICAgYWNoaWV2ZW1lbnRzOiBbXG4gICAgICAgICdJbnN0YWxsLCBjb25maWd1cmUsIGFuZCBtYWludGFpbiBjb21wdXRlciBoYXJkd2FyZSBzeXN0ZW1zJyxcbiAgICAgICAgJ0RpYWdub3NlIGFuZCB0cm91Ymxlc2hvb3QgaGFyZHdhcmUgYW5kIHBlcmlwaGVyYWwgaXNzdWVzJyxcbiAgICAgICAgJ1N1cHBvcnQgcHJpbnRlciBzZXR1cCwgbmV0d29yayBjb25uZWN0aXZpdHksIGFuZCBzeXN0ZW0gbWFpbnRlbmFuY2UnLFxuICAgICAgICAnRW5zdXJlIG9wZXJhdGlvbmFsIGNvbnRpbnVpdHkgb2YgSVQgZXF1aXBtZW50JyxcbiAgICAgICAgJ0Fzc2lzdCBpbiB0ZWNobmljYWwgZG9jdW1lbnRhdGlvbiBhbmQgc3lzdGVtIG1vbml0b3JpbmcnLFxuICAgICAgXSxcbiAgICAgIHRlY2hub2xvZ2llczogW1xuICAgICAgICAnSGFyZHdhcmUnLFxuICAgICAgICAnUGVyaXBoZXJhbHMnLFxuICAgICAgICAnUHJpbnRlcnMnLFxuICAgICAgICAnTmV0d29ya2luZycsXG4gICAgICAgICdEb2N1bWVudGF0aW9uJyxcbiAgICAgIF0sXG4gICAgICBpbXBhY3Q6IHtcbiAgICAgICAgc2NvcGU6ICdFbmQtdG8tZW5kIGhhcmR3YXJlIG1haW50ZW5hbmNlJyxcbiAgICAgICAgc2V0dXA6ICdQcmludGVyICYgbmV0d29yayBzZXR1cCcsXG4gICAgICB9LFxuICAgIH0sXG4gICAge1xuICAgICAgcm9sZTogJ0FJL01MIEludGVybicsXG4gICAgICBjb21wYW55OiAnRXRoaW9waWFuIEFydGlmaWNpYWwgSW50ZWxsaWdlbmNlIEluc3RpdHV0ZSAoRUFJSSknLFxuICAgICAgbG9jYXRpb246ICdBZGRpcyBBYmFiYSwgRXRoaW9waWEnLFxuICAgICAgcGVyaW9kOiAnSW50ZXJuc2hpcCcsXG4gICAgICB0eXBlOiAnSW50ZXJuc2hpcCcsXG4gICAgICBzdGFydFllYXI6IHVuZGVmaW5lZCxcbiAgICAgIGVuZFllYXI6IHVuZGVmaW5lZCxcbiAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICAnU3VwcG9ydGVkIEFJIG1vZGVsIGRldmVsb3BtZW50IHRocm91Z2ggZGF0YSBwcmVwYXJhdGlvbiwgbW9kZWwgdHJhaW5pbmcgYW5kIGV2YWx1YXRpb24sIGFuZCBjaGF0Ym90IGRldmVsb3BtZW50LicsXG4gICAgICBhY2hpZXZlbWVudHM6IFtcbiAgICAgICAgJ0Fzc2lzdGVkIGluIGRhdGEgY29sbGVjdGlvbiwgY2xlYW5pbmcsIGFuZCBwcmVwcm9jZXNzaW5nIGZvciBBSSBtb2RlbCBkZXZlbG9wbWVudCcsXG4gICAgICAgICdQYXJ0aWNpcGF0ZWQgaW4gdHJhaW5pbmcgYW5kIGV2YWx1YXRpb24gb2YgbWFjaGluZSBsZWFybmluZyBtb2RlbHMnLFxuICAgICAgICAnQ29udHJpYnV0ZWQgdG8gQUktYmFzZWQgY2hhdGJvdCBkZXZlbG9wbWVudCBhbmQgZGVwbG95bWVudCcsXG4gICAgICAgICdQcmVwYXJlZCB0ZWNobmljYWwgZG9jdW1lbnRhdGlvbiBhbmQgcmVzZWFyY2ggc3VtbWFyaWVzJyxcbiAgICAgICAgJ0NvbGxhYm9yYXRlZCB3aXRoIGNyb3NzLWZ1bmN0aW9uYWwgdGVjaG5pY2FsIHRlYW1zJyxcbiAgICAgIF0sXG4gICAgICB0ZWNobm9sb2dpZXM6IFtcbiAgICAgICAgJ1B5dGhvbicsXG4gICAgICAgICdEYXRhIFByZXByb2Nlc3NpbmcnLFxuICAgICAgICAnTWFjaGluZSBMZWFybmluZycsXG4gICAgICAgICdDaGF0Ym90cycsXG4gICAgICBdLFxuICAgICAgaW1wYWN0OiB7XG4gICAgICAgIGRhdGE6ICdNTCBkYXRhIHBpcGVsaW5lcycsXG4gICAgICAgIG1vZGVsczogJ1RyYWluaW5nICYgZXZhbHVhdGlvbicsXG4gICAgICB9LFxuICAgIH0sXG4gIF07XG5cbiAgY29uc3QgZWR1Y2F0aW9uID0gW1xuICAgIHtcbiAgICAgIGRlZ3JlZTogJ0JhY2hlbG9yIG9mIFNjaWVuY2UgaW4gQ29tcHV0ZXIgRW5naW5lZXJpbmcnLFxuICAgICAgc2Nob29sOiAnVW5pdmVyc2l0eSBvZiBHb25kYXInLFxuICAgICAgcGVyaW9kOiAnQXVnIDIwMjEgLSBBdWcgMjAyNScsXG4gICAgICBncGE6ICczLjQyLzQuMCcsXG4gICAgICBhY2hpZXZlbWVudHM6IFtcbiAgICAgICAgJ0dyYWR1YXRlZCBBdWd1c3QgMjAyNSB3aXRoIENHUEEgMy40MicsXG4gICAgICAgICdTdHJvbmcgZm91bmRhdGlvbiBpbiBjb21wdXRlciBlbmdpbmVlcmluZywgc3lzdGVtcywgYW5kIHNvZnR3YXJlIGRldmVsb3BtZW50JyxcbiAgICAgIF0sXG4gICAgfSxcbiAgXTtcblxuICAvLyBDcmVhdGUgb3JnYW5pemF0aW9uIHNjaGVtYXMgZm9yIHdvcmsgZXhwZXJpZW5jZVxuICBjb25zdCBvcmdhbml6YXRpb25TY2hlbWFzID0gZXhwZXJpZW5jZXMubWFwKGV4cCA9PlxuICAgIGNyZWF0ZU9yZ2FuaXphdGlvblNjaGVtYSh7XG4gICAgICBuYW1lOiBleHAuY29tcGFueSxcbiAgICAgIGRlc2NyaXB0aW9uOiBleHAuZGVzY3JpcHRpb24sXG4gICAgICBhZGRyZXNzOiB7XG4gICAgICAgIGxvY2FsaXR5OiBleHAubG9jYXRpb24uc3BsaXQoJyAvICcpWzFdIHx8IGV4cC5sb2NhdGlvbixcbiAgICAgICAgY291bnRyeTogJ0V0aGlvcGlhJyxcbiAgICAgIH0sXG4gICAgICBlbXBsb3llZXM6IFtcbiAgICAgICAge1xuICAgICAgICAgIG5hbWU6ICdFcm1pYXMgTGVtZXNhJyxcbiAgICAgICAgICBqb2JUaXRsZTogZXhwLnJvbGUsXG4gICAgICAgICAgLi4uKGV4cC5zdGFydFllYXIgPyB7IHN0YXJ0RGF0ZTogZXhwLnN0YXJ0WWVhciB9IDoge30pLFxuICAgICAgICAgIC4uLihleHAuZW5kWWVhciA/IHsgZW5kRGF0ZTogZXhwLmVuZFllYXIgfSA6IHt9KSxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgfSlcbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPSdtaW4taC1zY3JlZW4gYmctYmFja2dyb3VuZCc+XG4gICAgICA8U0VPIHsuLi5zZW9Qcm9wc30gLz5cbiAgICAgIDxTdHJ1Y3R1cmVkRGF0YSBzY2hlbWE9e2JyZWFkY3J1bWJTY2hlbWF9IC8+XG4gICAgICB7b3JnYW5pemF0aW9uU2NoZW1hcy5tYXAoKHNjaGVtYSwgaW5kZXgpID0+IChcbiAgICAgICAgPFN0cnVjdHVyZWREYXRhIGtleT17aW5kZXh9IHNjaGVtYT17c2NoZW1hfSAvPlxuICAgICAgKSl9XG4gICAgICA8TmF2aWdhdGlvbiAvPlxuXG4gICAgICB7LyogSGVybyAqL31cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT0ncmVsYXRpdmUgcHQtMzYgcGItMjAgb3ZlcmZsb3ctaGlkZGVuJz5cbiAgICAgICAgPEF0bW9zcGhlcmUgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J3JlbGF0aXZlIHotMTAgY29udGFpbmVyIG14LWF1dG8gcHgtNCc+XG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMzAgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC44IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J21heC13LTN4bCBteC1hdXRvIHRleHQtY2VudGVyJ1xuICAgICAgICAgID5cbiAgICAgICAgICAgIDxGbGlnaHRMb2dcbiAgICAgICAgICAgICAgZW50cmllcz17W1xuICAgICAgICAgICAgICAgICdGTElHSFQgUEFUSCAvIENBUkVFUicsXG4gICAgICAgICAgICAgICAgJ1dBWVBPSU5UIDAzIMK3IENMSU1CSU5HJyxcbiAgICAgICAgICAgICAgICAnQVVUT1BJTE9UIMK3IEVOR0FHRUQnLFxuICAgICAgICAgICAgICAgICdFU1QuIEFSUklWQUwgwrcgQ0xPVUQtOScsXG4gICAgICAgICAgICAgIF19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT0ndGV4dC00eGwgbWQ6dGV4dC01eGwgZm9udC1ib2xkIGZvbnQtaGVhZGluZyB0cmFja2luZy10aWdodCc+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nbmFtZS1ncmFkaWVudCc+RXhwZXJpZW5jZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9J210LTUgdGV4dC1sZyB0ZXh0LW1pc3Qtc29mdCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1saWdodCBtYXgtdy0yeGwgbXgtYXV0byc+XG4gICAgICAgICAgICAgIEEgcmlzaW5nIHRyYWplY3RvcnkgLSBmcm9tIEFJL01MIGludGVybiB0byBzZW5pb3IgSVQgc3VwcG9ydCxcbiAgICAgICAgICAgICAgY2xpbWJpbmcgdGhyb3VnaCBoYXJkd2FyZSBhbmQgc3lzdGVtcy5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICB7LyogVGltZWxpbmUgKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9J3JlbGF0aXZlIHBiLTE2IG92ZXJmbG93LWhpZGRlbic+XG4gICAgICAgIDxBdG1vc3BoZXJlIHZhcmlhbnQ9J21pc3QnIGNsYXNzTmFtZT0nb3BhY2l0eS03MCcgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J3JlbGF0aXZlIHotMTAgY29udGFpbmVyIG14LWF1dG8gcHgtNCBtYXgtdy02eGwnPlxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICByZWY9e3JlZn1cbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMzAgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e2luVmlldyA/IHsgb3BhY2l0eTogMSwgeTogMCB9IDoge319XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjggfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT0ncmVsYXRpdmUnXG4gICAgICAgICAgPlxuICAgICAgICAgICAgey8qIEZsaWdodCBwYXRoIGxpbmUgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nYWJzb2x1dGUgbGVmdC01IG1kOmxlZnQtMS8zIG1kOi10cmFuc2xhdGUteC1weCB0b3AtMCBib3R0b20tMCB3LXB4IGJnLWdyYWRpZW50LXRvLWIgZnJvbS10cmFuc3BhcmVudCB2aWEtZ29sZC81MCB0by10cmFuc3BhcmVudCcgLz5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3NwYWNlLXktMTIgbWQ6c3BhY2UteS0xNic+XG4gICAgICAgICAgICAgIHtleHBlcmllbmNlcy5tYXAoKGV4cCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAga2V5PXtgJHtleHAuY29tcGFueX0tJHtleHAucGVyaW9kfWB9XG4gICAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHg6IC0zMCB9fVxuICAgICAgICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB4OiAwIH0gOiB7fX1cbiAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuMyArIGluZGV4ICogMC4xOCwgZHVyYXRpb246IDAuNiB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdyZWxhdGl2ZSBtZDpncmlkIG1kOmdyaWQtY29scy0xMiBtZDpnYXAtMTAgaXRlbXMtc3RhcnQnXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgey8qIFdheXBvaW50IG1hcmtlciAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdhYnNvbHV0ZSBsZWZ0LTUgbWQ6bGVmdC0xLzMgLXRyYW5zbGF0ZS14LTEvMiB0b3AtOCc+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdyZWxhdGl2ZSc+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2gtMyB3LTMgcm91bmRlZC1mdWxsIGJnLWdvbGQgc2hhZG93LWdsb3cnIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Fic29sdXRlIGluc2V0LTAgcm91bmRlZC1mdWxsIGJnLWdvbGQvNDAgYW5pbWF0ZS1wdWxzZScgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIE1ldGEgY29sdW1uICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2hpZGRlbiBtZDpmbGV4IGZsZXgtY29sIGl0ZW1zLWVuZCBnYXAtMSBwdC04IG1kOmNvbC1zcGFuLTQnPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIHRyYWNraW5nLVswLjNlbV0gZ29sZC10ZXh0Jz5cbiAgICAgICAgICAgICAgICAgICAgICB7U3RyaW5nKGluZGV4ICsgMSkucGFkU3RhcnQoMiwgJzAnKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtaGVhZGluZyBmb250LXNlbWlib2xkIHRleHQtMnhsIHRyYWNraW5nLXRpZ2h0Jz5cbiAgICAgICAgICAgICAgICAgICAgICB7ZXhwLnBlcmlvZH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBDYXJkIGNvbHVtbiAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdwbC0xNCBtZDpwbC0wIHB0LTggbWQ6cHQtMCBtZDpjb2wtc3Bhbi04Jz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2dsYXNzLWNsb3VkIHJvdW5kZWQtMnhsIHAtNyc+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1kOmhpZGRlbiBtYi0zJz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQteHMgdHJhY2tpbmctWzAuM2VtXSBnb2xkLXRleHQnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7U3RyaW5nKGluZGV4ICsgMSkucGFkU3RhcnQoMiwgJzAnKX0gLyB7ZXhwLnBlcmlvZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9J2ZvbnQtaGVhZGluZyBmb250LWJvbGQgdGV4dC14bCB0cmFja2luZy10aWdodCc+XG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXhwLnJvbGV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC14LTQgZ2FwLXktMSBtdC0yIHRleHQtc20gdGV4dC1taXN0LXNvZnQnPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QnVpbGRpbmcgY2xhc3NOYW1lPSdoLTQgdy00IGdvbGQtdGV4dCcgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2V4cC5jb21wYW55fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT0naC00IHctNCBnb2xkLXRleHQnIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntleHAubG9jYXRpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtbWlzdC1zb2Z0IGxlYWRpbmctcmVsYXhlZCBtdC01IHRleHQtc20gZm9udC1saWdodCc+XG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXhwLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdtdC02Jz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9J2ZvbnQtc2VtaWJvbGQgdGV4dC1zbSBtYi0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEF3YXJkIGNsYXNzTmFtZT0naC00IHctNCBnb2xkLXRleHQnIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIEtleSBBY2hpZXZlbWVudHNcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPSdzcGFjZS15LTInPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwLmFjaGlldmVtZW50cy5tYXAoKGFjaGlldmVtZW50LCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2ZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNSB0ZXh0LXNtIHRleHQtbWlzdC1zb2Z0J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd3LTEgaC0xIGJnLWdvbGQgcm91bmRlZC1mdWxsIG10LTIgZmxleC1zaHJpbmstMCcgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnthY2hpZXZlbWVudH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J210LTYnPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT0nZm9udC1zZW1pYm9sZCB0ZXh0LXNtIG1iLTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTInPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJlbmRpbmdVcCBjbGFzc05hbWU9J2gtNCB3LTQgZ29sZC10ZXh0JyAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBJbXBhY3RcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBmbGV4LXdyYXAgZ2FwLTMnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoZXhwLmltcGFjdCkubWFwKChba2V5LCB2YWx1ZV0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2tleX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZ2xhc3Mgcm91bmRlZC1tZCBweC0zIHB5LTInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2dvbGQtdGV4dCBmb250LXNlbWlib2xkIHRleHQtc20nPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd0ZXh0LXhzIHRleHQtbWlzdC1zb2Z0IGNhcGl0YWxpemUnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7a2V5fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nbXQtNic+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPSdmb250LXNlbWlib2xkIHRleHQtc20gbWItMyc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRlY2hub2xvZ2llcyBVc2VkXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggZmxleC13cmFwIGdhcC0yJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2V4cC50ZWNobm9sb2dpZXMubWFwKHRlY2ggPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3RlY2h9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2dsYXNzIHJvdW5kZWQtbWQgcHgtMi41IHB5LTEgZm9udC1tb25vIHRleHQteHMgdGV4dC1taXN0LXNvZnQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RlY2h9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L21vdGlvbi5kaXY+XG5cbiAgICAgICAgICB7LyogRWR1Y2F0aW9uICovfVxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDMwIH19XG4gICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHk6IDAgfSA6IHt9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMS4yLCBkdXJhdGlvbjogMC44IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J210LTIwJ1xuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd0ZXh0LWNlbnRlciBtYi0xMCc+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQteHMgdHJhY2tpbmctWzAuM2VtXSBnb2xkLXRleHQnPlxuICAgICAgICAgICAgICAgIE9SSUdJTiAvXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT0ndGV4dC0yeGwgbWQ6dGV4dC0zeGwgZm9udC1ib2xkIGZvbnQtaGVhZGluZyBtdC0yIHRyYWNraW5nLXRpZ2h0Jz5cbiAgICAgICAgICAgICAgICBFZHVjYXRpb25cbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAge2VkdWNhdGlvbi5tYXAoKGVkdSwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdnbGFzcy1jbG91ZCByb3VuZGVkLTJ4bCBwLTcgbWQ6cC04IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCdcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLXN0YXJ0IG1kOmp1c3RpZnktYmV0d2VlbiBnYXAtMyBtYi00Jz5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9J2ZvbnQtaGVhZGluZyBmb250LWJvbGQgdGV4dC1sZyB0cmFja2luZy10aWdodCc+XG4gICAgICAgICAgICAgICAgICAgICAge2VkdS5kZWdyZWV9XG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0ndGV4dC1taXN0LXNvZnQgdGV4dC1zbSBtdC0xJz57ZWR1LnNjaG9vbH08L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtZDpmbGV4LWNvbCBtZDppdGVtcy1lbmQnPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtbWlzdC1zb2Z0Jz5cbiAgICAgICAgICAgICAgICAgICAgICB7ZWR1LnBlcmlvZH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J3B4LTIuNSBweS0xIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1nb2xkLzQwIHRleHQtZ29sZCBmb250LW1vbm8gdGV4dC14cyc+XG4gICAgICAgICAgICAgICAgICAgICAgR1BBOiB7ZWR1LmdwYX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT0nc3BhY2UteS0yJz5cbiAgICAgICAgICAgICAgICAgIHtlZHUuYWNoaWV2ZW1lbnRzLm1hcCgoYWNoaWV2ZW1lbnQsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZmxleCBpdGVtcy1zdGFydCBnYXAtMi41IHRleHQtc20gdGV4dC1taXN0LXNvZnQnXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ndy0xIGgtMSBiZy1nb2xkIHJvdW5kZWQtZnVsbCBtdC0yIGZsZXgtc2hyaW5rLTAnIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2FjaGlldmVtZW50fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDxGb290ZXIgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEV4cGVyaWVuY2U7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJtb3Rpb24iLCJ1c2VJblZpZXciLCJBd2FyZCIsIkJ1aWxkaW5nIiwiTWFwUGluIiwiVHJlbmRpbmdVcCIsIk5hdmlnYXRpb24iLCJGb290ZXIiLCJBdG1vc3BoZXJlIiwiRmxpZ2h0TG9nIiwiU0VPIiwiU3RydWN0dXJlZERhdGEiLCJ1c2VTRU8iLCJ1c2VTdHJ1Y3R1cmVkRGF0YSIsImNyZWF0ZU9yZ2FuaXphdGlvblNjaGVtYSIsIkV4cGVyaWVuY2UiLCJzZW9Qcm9wcyIsImJyZWFkY3J1bWJTY2hlbWEiLCJyZWYiLCJpblZpZXciLCJ0cmlnZ2VyT25jZSIsInRocmVzaG9sZCIsImV4cGVyaWVuY2VzIiwicm9sZSIsImNvbXBhbnkiLCJsb2NhdGlvbiIsInBlcmlvZCIsInR5cGUiLCJzdGFydFllYXIiLCJ1bmRlZmluZWQiLCJlbmRZZWFyIiwiZGVzY3JpcHRpb24iLCJhY2hpZXZlbWVudHMiLCJ0ZWNobm9sb2dpZXMiLCJpbXBhY3QiLCJjb3ZlcmFnZSIsInN1cHBvcnQiLCJzY29wZSIsInNldHVwIiwiZGF0YSIsIm1vZGVscyIsImVkdWNhdGlvbiIsImRlZ3JlZSIsInNjaG9vbCIsImdwYSIsIm9yZ2FuaXphdGlvblNjaGVtYXMiLCJtYXAiLCJleHAiLCJuYW1lIiwiYWRkcmVzcyIsImxvY2FsaXR5Iiwic3BsaXQiLCJjb3VudHJ5IiwiZW1wbG95ZWVzIiwiam9iVGl0bGUiLCJzdGFydERhdGUiLCJlbmREYXRlIiwiZGl2IiwiY2xhc3NOYW1lIiwic2NoZW1hIiwiaW5kZXgiLCJzZWN0aW9uIiwiaW5pdGlhbCIsIm9wYWNpdHkiLCJ5IiwiYW5pbWF0ZSIsInRyYW5zaXRpb24iLCJkdXJhdGlvbiIsImVudHJpZXMiLCJoMSIsInNwYW4iLCJwIiwidmFyaWFudCIsIngiLCJkZWxheSIsIlN0cmluZyIsInBhZFN0YXJ0IiwiaDMiLCJoNCIsInVsIiwiYWNoaWV2ZW1lbnQiLCJpIiwibGkiLCJPYmplY3QiLCJrZXkiLCJ2YWx1ZSIsInRlY2giLCJoMiIsImVkdSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLE9BQU9BLFdBQVcsUUFBUTtBQUMxQixTQUFTQyxNQUFNLFFBQVEsZ0JBQWdCO0FBQ3ZDLFNBQVNDLFNBQVMsUUFBUSw4QkFBOEI7QUFDeEQsU0FBU0MsS0FBSyxFQUFFQyxRQUFRLEVBQUVDLE1BQU0sRUFBRUMsVUFBVSxRQUFRLGVBQWU7QUFDbkUsT0FBT0MsZ0JBQWdCLGlDQUFpQztBQUN4RCxPQUFPQyxZQUFZLDZCQUE2QjtBQUNoRCxPQUFPQyxnQkFBZ0IscUNBQXFDO0FBQzVELE9BQU9DLGVBQWUsNkJBQTZCO0FBQ25ELE9BQU9DLFNBQVMsdUJBQXVCO0FBQ3ZDLE9BQU9DLG9CQUFvQixrQ0FBa0M7QUFDN0QsU0FBU0MsTUFBTSxRQUFRLGtCQUFrQjtBQUN6QyxTQUFTQyxpQkFBaUIsUUFBUSw4QkFBOEI7QUFDaEUsU0FBU0Msd0JBQXdCLFFBQVEsd0JBQXdCO0FBRWpFLE1BQU1DLGFBQWE7O0lBQ2pCLE1BQU1DLFdBQVdKO0lBQ2pCLE1BQU0sRUFBRUssZ0JBQWdCLEVBQUUsR0FBR0o7SUFFN0IsTUFBTSxDQUFDSyxLQUFLQyxPQUFPLEdBQUdsQixVQUFVO1FBQzlCbUIsYUFBYTtRQUNiQyxXQUFXO0lBQ2I7SUFFQSxNQUFNQyxjQUFjO1FBQ2xCO1lBQ0VDLE1BQU07WUFDTkMsU0FBUztZQUNUQyxVQUFVO1lBQ1ZDLFFBQVE7WUFDUkMsTUFBTTtZQUNOQyxXQUFXQztZQUNYQyxTQUFTRDtZQUNURSxhQUNFO1lBQ0ZDLGNBQWM7Z0JBQ1o7Z0JBQ0E7Z0JBQ0E7Z0JBQ0E7YUFDRDtZQUNEQyxjQUFjO2dCQUNaO2dCQUNBO2dCQUNBO2dCQUNBO2dCQUNBO2dCQUNBO2FBQ0Q7WUFDREMsUUFBUTtnQkFDTkMsVUFBVTtnQkFDVkMsU0FBUztZQUNYO1FBQ0Y7UUFDQTtZQUNFYixNQUFNO1lBQ05DLFNBQVM7WUFDVEMsVUFBVTtZQUNWQyxRQUFRO1lBQ1JDLE1BQU07WUFDTkMsV0FBV0M7WUFDWEMsU0FBU0Q7WUFDVEUsYUFDRTtZQUNGQyxjQUFjO2dCQUNaO2dCQUNBO2dCQUNBO2dCQUNBO2dCQUNBO2FBQ0Q7WUFDREMsY0FBYztnQkFDWjtnQkFDQTtnQkFDQTtnQkFDQTtnQkFDQTthQUNEO1lBQ0RDLFFBQVE7Z0JBQ05HLE9BQU87Z0JBQ1BDLE9BQU87WUFDVDtRQUNGO1FBQ0E7WUFDRWYsTUFBTTtZQUNOQyxTQUFTO1lBQ1RDLFVBQVU7WUFDVkMsUUFBUTtZQUNSQyxNQUFNO1lBQ05DLFdBQVdDO1lBQ1hDLFNBQVNEO1lBQ1RFLGFBQ0U7WUFDRkMsY0FBYztnQkFDWjtnQkFDQTtnQkFDQTtnQkFDQTtnQkFDQTthQUNEO1lBQ0RDLGNBQWM7Z0JBQ1o7Z0JBQ0E7Z0JBQ0E7Z0JBQ0E7YUFDRDtZQUNEQyxRQUFRO2dCQUNOSyxNQUFNO2dCQUNOQyxRQUFRO1lBQ1Y7UUFDRjtLQUNEO0lBRUQsTUFBTUMsWUFBWTtRQUNoQjtZQUNFQyxRQUFRO1lBQ1JDLFFBQVE7WUFDUmpCLFFBQVE7WUFDUmtCLEtBQUs7WUFDTFosY0FBYztnQkFDWjtnQkFDQTthQUNEO1FBQ0g7S0FDRDtJQUVELGtEQUFrRDtJQUNsRCxNQUFNYSxzQkFBc0J2QixZQUFZd0IsR0FBRyxDQUFDQyxDQUFBQSxNQUMxQ2pDLHlCQUF5QjtZQUN2QmtDLE1BQU1ELElBQUl2QixPQUFPO1lBQ2pCTyxhQUFhZ0IsSUFBSWhCLFdBQVc7WUFDNUJrQixTQUFTO2dCQUNQQyxVQUFVSCxJQUFJdEIsUUFBUSxDQUFDMEIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUlKLElBQUl0QixRQUFRO2dCQUN0RDJCLFNBQVM7WUFDWDtZQUNBQyxXQUFXO2dCQUNUO29CQUNFTCxNQUFNO29CQUNOTSxVQUFVUCxJQUFJeEIsSUFBSTtvQkFDbEIsR0FBSXdCLElBQUluQixTQUFTLEdBQUc7d0JBQUUyQixXQUFXUixJQUFJbkIsU0FBUztvQkFBQyxJQUFJLENBQUMsQ0FBQztvQkFDckQsR0FBSW1CLElBQUlqQixPQUFPLEdBQUc7d0JBQUUwQixTQUFTVCxJQUFJakIsT0FBTztvQkFBQyxJQUFJLENBQUMsQ0FBQztnQkFDakQ7YUFDRDtRQUNIO0lBR0YscUJBQ0UsUUFBQzJCO1FBQUlDLFdBQVU7OzBCQUNiLFFBQUNoRDtnQkFBSyxHQUFHTSxRQUFROzs7Ozs7MEJBQ2pCLFFBQUNMO2dCQUFlZ0QsUUFBUTFDOzs7Ozs7WUFDdkI0QixvQkFBb0JDLEdBQUcsQ0FBQyxDQUFDYSxRQUFRQyxzQkFDaEMsUUFBQ2pEO29CQUEyQmdELFFBQVFBO21CQUFmQzs7Ozs7MEJBRXZCLFFBQUN0RDs7Ozs7MEJBR0QsUUFBQ3VEO2dCQUFRSCxXQUFVOztrQ0FDakIsUUFBQ2xEOzs7OztrQ0FDRCxRQUFDaUQ7d0JBQUlDLFdBQVU7a0NBQ2IsY0FBQSxRQUFDMUQsT0FBT3lELEdBQUc7NEJBQ1RLLFNBQVM7Z0NBQUVDLFNBQVM7Z0NBQUdDLEdBQUc7NEJBQUc7NEJBQzdCQyxTQUFTO2dDQUFFRixTQUFTO2dDQUFHQyxHQUFHOzRCQUFFOzRCQUM1QkUsWUFBWTtnQ0FBRUMsVUFBVTs0QkFBSTs0QkFDNUJULFdBQVU7OzhDQUVWLFFBQUNqRDtvQ0FDQzJELFNBQVM7d0NBQ1A7d0NBQ0E7d0NBQ0E7d0NBQ0E7cUNBQ0Q7Ozs7Ozs4Q0FFSCxRQUFDQztvQ0FBR1gsV0FBVTs4Q0FDWixjQUFBLFFBQUNZO3dDQUFLWixXQUFVO2tEQUFnQjs7Ozs7Ozs7Ozs7OENBRWxDLFFBQUNhO29DQUFFYixXQUFVOzhDQUEyRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBUzlGLFFBQUNHO2dCQUFRSCxXQUFVOztrQ0FDakIsUUFBQ2xEO3dCQUFXZ0UsU0FBUTt3QkFBT2QsV0FBVTs7Ozs7O2tDQUNyQyxRQUFDRDt3QkFBSUMsV0FBVTs7MENBQ2IsUUFBQzFELE9BQU95RCxHQUFHO2dDQUNUdkMsS0FBS0E7Z0NBQ0w0QyxTQUFTO29DQUFFQyxTQUFTO29DQUFHQyxHQUFHO2dDQUFHO2dDQUM3QkMsU0FBUzlDLFNBQVM7b0NBQUU0QyxTQUFTO29DQUFHQyxHQUFHO2dDQUFFLElBQUksQ0FBQztnQ0FDMUNFLFlBQVk7b0NBQUVDLFVBQVU7Z0NBQUk7Z0NBQzVCVCxXQUFVOztrREFHVixRQUFDRDt3Q0FBSUMsV0FBVTs7Ozs7O2tEQUVmLFFBQUNEO3dDQUFJQyxXQUFVO2tEQUNacEMsWUFBWXdCLEdBQUcsQ0FBQyxDQUFDQyxLQUFLYSxzQkFDckIsUUFBQzVELE9BQU95RCxHQUFHO2dEQUVUSyxTQUFTO29EQUFFQyxTQUFTO29EQUFHVSxHQUFHLENBQUM7Z0RBQUc7Z0RBQzlCUixTQUFTOUMsU0FBUztvREFBRTRDLFNBQVM7b0RBQUdVLEdBQUc7Z0RBQUUsSUFBSSxDQUFDO2dEQUMxQ1AsWUFBWTtvREFBRVEsT0FBTyxNQUFNZCxRQUFRO29EQUFNTyxVQUFVO2dEQUFJO2dEQUN2RFQsV0FBVTs7a0VBR1YsUUFBQ0Q7d0RBQUlDLFdBQVU7a0VBQ2IsY0FBQSxRQUFDRDs0REFBSUMsV0FBVTs7OEVBQ2IsUUFBQ0Q7b0VBQUlDLFdBQVU7Ozs7Ozs4RUFDZixRQUFDRDtvRUFBSUMsV0FBVTs7Ozs7Ozs7Ozs7Ozs7Ozs7a0VBS25CLFFBQUNEO3dEQUFJQyxXQUFVOzswRUFDYixRQUFDWTtnRUFBS1osV0FBVTswRUFDYmlCLE9BQU9mLFFBQVEsR0FBR2dCLFFBQVEsQ0FBQyxHQUFHOzs7Ozs7MEVBRWpDLFFBQUNOO2dFQUFLWixXQUFVOzBFQUNiWCxJQUFJckIsTUFBTTs7Ozs7Ozs7Ozs7O2tFQUtmLFFBQUMrQjt3REFBSUMsV0FBVTtrRUFDYixjQUFBLFFBQUNEOzREQUFJQyxXQUFVOzs4RUFDYixRQUFDRDtvRUFBSUMsV0FBVTs4RUFDYixjQUFBLFFBQUNZO3dFQUFLWixXQUFVOzs0RUFDYmlCLE9BQU9mLFFBQVEsR0FBR2dCLFFBQVEsQ0FBQyxHQUFHOzRFQUFLOzRFQUFJN0IsSUFBSXJCLE1BQU07Ozs7Ozs7Ozs7Ozs4RUFJdEQsUUFBQ21EO29FQUFHbkIsV0FBVTs4RUFDWFgsSUFBSXhCLElBQUk7Ozs7Ozs4RUFFWCxRQUFDa0M7b0VBQUlDLFdBQVU7O3NGQUNiLFFBQUNEOzRFQUFJQyxXQUFVOzs4RkFDYixRQUFDdkQ7b0ZBQVN1RCxXQUFVOzs7Ozs7OEZBQ3BCLFFBQUNZOzhGQUFNdkIsSUFBSXZCLE9BQU87Ozs7Ozs7Ozs7OztzRkFFcEIsUUFBQ2lDOzRFQUFJQyxXQUFVOzs4RkFDYixRQUFDdEQ7b0ZBQU9zRCxXQUFVOzs7Ozs7OEZBQ2xCLFFBQUNZOzhGQUFNdkIsSUFBSXRCLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs4RUFJdkIsUUFBQzhDO29FQUFFYixXQUFVOzhFQUNWWCxJQUFJaEIsV0FBVzs7Ozs7OzhFQUdsQixRQUFDMEI7b0VBQUlDLFdBQVU7O3NGQUNiLFFBQUNvQjs0RUFBR3BCLFdBQVU7OzhGQUNaLFFBQUN4RDtvRkFBTXdELFdBQVU7Ozs7OztnRkFBc0I7Ozs7Ozs7c0ZBR3pDLFFBQUNxQjs0RUFBR3JCLFdBQVU7c0ZBQ1hYLElBQUlmLFlBQVksQ0FBQ2MsR0FBRyxDQUFDLENBQUNrQyxhQUFhQyxrQkFDbEMsUUFBQ0M7b0ZBRUN4QixXQUFVOztzR0FFVixRQUFDRDs0RkFBSUMsV0FBVTs7Ozs7O3NHQUNmLFFBQUNZO3NHQUFNVTs7Ozs7OzttRkFKRkM7Ozs7Ozs7Ozs7Ozs7Ozs7OEVBVWIsUUFBQ3hCO29FQUFJQyxXQUFVOztzRkFDYixRQUFDb0I7NEVBQUdwQixXQUFVOzs4RkFDWixRQUFDckQ7b0ZBQVdxRCxXQUFVOzs7Ozs7Z0ZBQXNCOzs7Ozs7O3NGQUc5QyxRQUFDRDs0RUFBSUMsV0FBVTtzRkFDWnlCLE9BQU9mLE9BQU8sQ0FBQ3JCLElBQUliLE1BQU0sRUFBRVksR0FBRyxDQUFDLENBQUMsQ0FBQ3NDLEtBQUtDLE1BQU0saUJBQzNDLFFBQUM1QjtvRkFFQ0MsV0FBVTs7c0dBRVYsUUFBQ0Q7NEZBQUlDLFdBQVU7c0dBQ1oyQjs7Ozs7O3NHQUVILFFBQUM1Qjs0RkFBSUMsV0FBVTtzR0FDWjBCOzs7Ozs7O21GQVBFQTs7Ozs7Ozs7Ozs7Ozs7Ozs4RUFjYixRQUFDM0I7b0VBQUlDLFdBQVU7O3NGQUNiLFFBQUNvQjs0RUFBR3BCLFdBQVU7c0ZBQTZCOzs7Ozs7c0ZBRzNDLFFBQUNEOzRFQUFJQyxXQUFVO3NGQUNaWCxJQUFJZCxZQUFZLENBQUNhLEdBQUcsQ0FBQ3dDLENBQUFBLHFCQUNwQixRQUFDaEI7b0ZBRUNaLFdBQVU7OEZBRVQ0QjttRkFISUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7K0NBbEdaLEdBQUd2QyxJQUFJdkIsT0FBTyxDQUFDLENBQUMsRUFBRXVCLElBQUlyQixNQUFNLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7MENBa0gzQyxRQUFDMUIsT0FBT3lELEdBQUc7Z0NBQ1RLLFNBQVM7b0NBQUVDLFNBQVM7b0NBQUdDLEdBQUc7Z0NBQUc7Z0NBQzdCQyxTQUFTOUMsU0FBUztvQ0FBRTRDLFNBQVM7b0NBQUdDLEdBQUc7Z0NBQUUsSUFBSSxDQUFDO2dDQUMxQ0UsWUFBWTtvQ0FBRVEsT0FBTztvQ0FBS1AsVUFBVTtnQ0FBSTtnQ0FDeENULFdBQVU7O2tEQUVWLFFBQUNEO3dDQUFJQyxXQUFVOzswREFDYixRQUFDWTtnREFBS1osV0FBVTswREFBK0M7Ozs7OzswREFHL0QsUUFBQzZCO2dEQUFHN0IsV0FBVTswREFBa0U7Ozs7Ozs7Ozs7OztvQ0FJakZqQixVQUFVSyxHQUFHLENBQUMsQ0FBQzBDLEtBQUs1QixzQkFDbkIsUUFBQ0g7NENBRUNDLFdBQVU7OzhEQUVWLFFBQUNEO29EQUFJQyxXQUFVOztzRUFDYixRQUFDRDs7OEVBQ0MsUUFBQ29CO29FQUFHbkIsV0FBVTs4RUFDWDhCLElBQUk5QyxNQUFNOzs7Ozs7OEVBRWIsUUFBQzZCO29FQUFFYixXQUFVOzhFQUErQjhCLElBQUk3QyxNQUFNOzs7Ozs7Ozs7Ozs7c0VBRXhELFFBQUNjOzREQUFJQyxXQUFVOzs4RUFDYixRQUFDWTtvRUFBS1osV0FBVTs4RUFDYjhCLElBQUk5RCxNQUFNOzs7Ozs7OEVBRWIsUUFBQzRDO29FQUFLWixXQUFVOzt3RUFBMkU7d0VBQ25GOEIsSUFBSTVDLEdBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OERBSW5CLFFBQUNtQztvREFBR3JCLFdBQVU7OERBQ1g4QixJQUFJeEQsWUFBWSxDQUFDYyxHQUFHLENBQUMsQ0FBQ2tDLGFBQWFDLGtCQUNsQyxRQUFDQzs0REFFQ3hCLFdBQVU7OzhFQUVWLFFBQUNEO29FQUFJQyxXQUFVOzs7Ozs7OEVBQ2YsUUFBQ1k7OEVBQU1VOzs7Ozs7OzJEQUpGQzs7Ozs7Ozs7Ozs7MkNBdEJOckI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBCQW1DZixRQUFDckQ7Ozs7Ozs7Ozs7O0FBR1A7R0FsV01ROztRQUNhSDtRQUNZQztRQUVQWjs7O0tBSmxCYztBQW9XTixlQUFlQSxXQUFXIn0=