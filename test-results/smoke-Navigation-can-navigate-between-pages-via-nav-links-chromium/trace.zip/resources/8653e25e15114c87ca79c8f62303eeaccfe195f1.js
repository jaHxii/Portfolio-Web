import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/tech-marquee.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
const LAYERS = [
    {
        code: 'SYS',
        items: [
            'IT Support',
            'Systems Administration',
            'Troubleshooting'
        ]
    },
    {
        code: 'NET',
        items: [
            'Networking',
            'Hardware',
            'Windows',
            'Linux'
        ]
    },
    {
        code: 'DEV',
        items: [
            'Python',
            'React',
            'SQL'
        ]
    },
    {
        code: 'ML',
        items: [
            'AI/ML',
            'Cloud'
        ]
    }
];
const STATUS = [
    'ON TIME',
    'CRUISING',
    'STABLE',
    'NOMINAL'
];
const buildStrip = (dup)=>{
    const nodes = [];
    LAYERS.forEach((layer, layerIndex)=>{
        nodes.push(/*#__PURE__*/ _jsxDEV("div", {
            className: "flex items-center gap-3 px-2 shrink-0",
            children: [
                /*#__PURE__*/ _jsxDEV("span", {
                    className: "h-px w-6 bg-gold/40"
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("span", {
                    className: "font-mono text-[10px] tracking-[0.3em] text-gold/70",
                    children: layer.code
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ _jsxDEV("span", {
                    className: "h-px w-6 bg-gold/40"
                }, void 0, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this)
            ]
        }, `sep-${dup}-${layer.code}`, true, {
            fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
            lineNumber: 21,
            columnNumber: 7
        }, this));
        layer.items.forEach((tech, i)=>{
            const number = layerIndex * 10 + i + 1;
            const status = STATUS[(layerIndex + i) % STATUS.length] ?? 'ON TIME';
            nodes.push(/*#__PURE__*/ _jsxDEV("span", {
                className: "glass inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full font-mono text-sm text-mist-soft whitespace-nowrap",
                children: [
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "w-1 h-1 rounded-full bg-gold/70"
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                        lineNumber: 41,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "text-[11px] text-gold/80",
                        children: [
                            "T-",
                            String(number).padStart(3, '0')
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                        lineNumber: 42,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV("span", {
                        children: tech
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ _jsxDEV("span", {
                        className: "text-[10px] tracking-[0.15em] text-mist-soft/50",
                        children: status
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                        lineNumber: 46,
                        columnNumber: 11
                    }, this)
                ]
            }, `${dup}-${layer.code}-${tech}`, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                lineNumber: 37,
                columnNumber: 9
            }, this));
        });
    });
    return nodes;
};
const TechMarquee = ()=>{
    const items = [
        ...buildStrip(0),
        ...buildStrip(1)
    ];
    return /*#__PURE__*/ _jsxDEV(motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        transition: {
            delay: 1.4,
            duration: 0.8
        },
        className: "group mt-14 overflow-hidden relative w-full",
        "aria-hidden": "true",
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                className: "absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-background to-transparent z-10"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-background to-transparent z-10"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                lineNumber: 69,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "flex w-max animate-marquee [animation-duration:70s] group-hover:[animation-play-state:paused] gap-3",
                children: items
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
                lineNumber: 70,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
};
_c = TechMarquee;
export { TechMarquee };
var _c;
$RefreshReg$(_c, "TechMarquee");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/ui/tech-marquee.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlY2gtbWFycXVlZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuXG5jb25zdCBMQVlFUlMgPSBbXG4gIHtcbiAgICBjb2RlOiAnU1lTJyxcbiAgICBpdGVtczogWydJVCBTdXBwb3J0JywgJ1N5c3RlbXMgQWRtaW5pc3RyYXRpb24nLCAnVHJvdWJsZXNob290aW5nJ10sXG4gIH0sXG4gIHsgY29kZTogJ05FVCcsIGl0ZW1zOiBbJ05ldHdvcmtpbmcnLCAnSGFyZHdhcmUnLCAnV2luZG93cycsICdMaW51eCddIH0sXG4gIHsgY29kZTogJ0RFVicsIGl0ZW1zOiBbJ1B5dGhvbicsICdSZWFjdCcsICdTUUwnXSB9LFxuICB7IGNvZGU6ICdNTCcsIGl0ZW1zOiBbJ0FJL01MJywgJ0Nsb3VkJ10gfSxcbl07XG5cbmNvbnN0IFNUQVRVUyA9IFsnT04gVElNRScsICdDUlVJU0lORycsICdTVEFCTEUnLCAnTk9NSU5BTCddO1xuXG5jb25zdCBidWlsZFN0cmlwID0gKGR1cDogbnVtYmVyKTogUmVhY3QuUmVhY3ROb2RlW10gPT4ge1xuICBjb25zdCBub2RlczogUmVhY3QuUmVhY3ROb2RlW10gPSBbXTtcblxuICBMQVlFUlMuZm9yRWFjaCgobGF5ZXIsIGxheWVySW5kZXgpID0+IHtcbiAgICBub2Rlcy5wdXNoKFxuICAgICAgPGRpdlxuICAgICAgICBrZXk9e2BzZXAtJHtkdXB9LSR7bGF5ZXIuY29kZX1gfVxuICAgICAgICBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTIgc2hyaW5rLTAnXG4gICAgICA+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT0naC1weCB3LTYgYmctZ29sZC80MCcgLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdmb250LW1vbm8gdGV4dC1bMTBweF0gdHJhY2tpbmctWzAuM2VtXSB0ZXh0LWdvbGQvNzAnPlxuICAgICAgICAgIHtsYXllci5jb2RlfVxuICAgICAgICA8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT0naC1weCB3LTYgYmctZ29sZC80MCcgLz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG5cbiAgICBsYXllci5pdGVtcy5mb3JFYWNoKCh0ZWNoLCBpKSA9PiB7XG4gICAgICBjb25zdCBudW1iZXIgPSBsYXllckluZGV4ICogMTAgKyBpICsgMTtcbiAgICAgIGNvbnN0IHN0YXR1cyA9IFNUQVRVU1sobGF5ZXJJbmRleCArIGkpICUgU1RBVFVTLmxlbmd0aF0gPz8gJ09OIFRJTUUnO1xuICAgICAgbm9kZXMucHVzaChcbiAgICAgICAgPHNwYW5cbiAgICAgICAgICBrZXk9e2Ake2R1cH0tJHtsYXllci5jb2RlfS0ke3RlY2h9YH1cbiAgICAgICAgICBjbGFzc05hbWU9J2dsYXNzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTUgcHktMi41IHJvdW5kZWQtZnVsbCBmb250LW1vbm8gdGV4dC1zbSB0ZXh0LW1pc3Qtc29mdCB3aGl0ZXNwYWNlLW5vd3JhcCdcbiAgICAgICAgPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0ndy0xIGgtMSByb3VuZGVkLWZ1bGwgYmctZ29sZC83MCcgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J3RleHQtWzExcHhdIHRleHQtZ29sZC84MCc+XG4gICAgICAgICAgICBULXtTdHJpbmcobnVtYmVyKS5wYWRTdGFydCgzLCAnMCcpfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj57dGVjaH08L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSd0ZXh0LVsxMHB4XSB0cmFja2luZy1bMC4xNWVtXSB0ZXh0LW1pc3Qtc29mdC81MCc+XG4gICAgICAgICAgICB7c3RhdHVzfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgcmV0dXJuIG5vZGVzO1xufTtcblxuY29uc3QgVGVjaE1hcnF1ZWUgPSAoKSA9PiB7XG4gIGNvbnN0IGl0ZW1zID0gWy4uLmJ1aWxkU3RyaXAoMCksIC4uLmJ1aWxkU3RyaXAoMSldO1xuXG4gIHJldHVybiAoXG4gICAgPG1vdGlvbi5kaXZcbiAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCB9fVxuICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XG4gICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAxLjQsIGR1cmF0aW9uOiAwLjggfX1cbiAgICAgIGNsYXNzTmFtZT0nZ3JvdXAgbXQtMTQgb3ZlcmZsb3ctaGlkZGVuIHJlbGF0aXZlIHctZnVsbCdcbiAgICAgIGFyaWEtaGlkZGVuPSd0cnVlJ1xuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdhYnNvbHV0ZSBsZWZ0LTAgdG9wLTAgYm90dG9tLTAgdy0yNCBiZy1ncmFkaWVudC10by1yIGZyb20tYmFja2dyb3VuZCB0by10cmFuc3BhcmVudCB6LTEwJyAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9J2Fic29sdXRlIHJpZ2h0LTAgdG9wLTAgYm90dG9tLTAgdy0yNCBiZy1ncmFkaWVudC10by1sIGZyb20tYmFja2dyb3VuZCB0by10cmFuc3BhcmVudCB6LTEwJyAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggdy1tYXggYW5pbWF0ZS1tYXJxdWVlIFthbmltYXRpb24tZHVyYXRpb246NzBzXSBncm91cC1ob3ZlcjpbYW5pbWF0aW9uLXBsYXktc3RhdGU6cGF1c2VkXSBnYXAtMyc+XG4gICAgICAgIHtpdGVtc31cbiAgICAgIDwvZGl2PlxuICAgIDwvbW90aW9uLmRpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCB7IFRlY2hNYXJxdWVlIH07XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJtb3Rpb24iLCJMQVlFUlMiLCJjb2RlIiwiaXRlbXMiLCJTVEFUVVMiLCJidWlsZFN0cmlwIiwiZHVwIiwibm9kZXMiLCJmb3JFYWNoIiwibGF5ZXIiLCJsYXllckluZGV4IiwicHVzaCIsImRpdiIsImNsYXNzTmFtZSIsInNwYW4iLCJ0ZWNoIiwiaSIsIm51bWJlciIsInN0YXR1cyIsImxlbmd0aCIsIlN0cmluZyIsInBhZFN0YXJ0IiwiVGVjaE1hcnF1ZWUiLCJpbml0aWFsIiwib3BhY2l0eSIsImFuaW1hdGUiLCJ0cmFuc2l0aW9uIiwiZGVsYXkiLCJkdXJhdGlvbiIsImFyaWEtaGlkZGVuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxPQUFPQSxXQUFXLFFBQVE7QUFDMUIsU0FBU0MsTUFBTSxRQUFRLGdCQUFnQjtBQUV2QyxNQUFNQyxTQUFTO0lBQ2I7UUFDRUMsTUFBTTtRQUNOQyxPQUFPO1lBQUM7WUFBYztZQUEwQjtTQUFrQjtJQUNwRTtJQUNBO1FBQUVELE1BQU07UUFBT0MsT0FBTztZQUFDO1lBQWM7WUFBWTtZQUFXO1NBQVE7SUFBQztJQUNyRTtRQUFFRCxNQUFNO1FBQU9DLE9BQU87WUFBQztZQUFVO1lBQVM7U0FBTTtJQUFDO0lBQ2pEO1FBQUVELE1BQU07UUFBTUMsT0FBTztZQUFDO1lBQVM7U0FBUTtJQUFDO0NBQ3pDO0FBRUQsTUFBTUMsU0FBUztJQUFDO0lBQVc7SUFBWTtJQUFVO0NBQVU7QUFFM0QsTUFBTUMsYUFBYSxDQUFDQztJQUNsQixNQUFNQyxRQUEyQixFQUFFO0lBRW5DTixPQUFPTyxPQUFPLENBQUMsQ0FBQ0MsT0FBT0M7UUFDckJILE1BQU1JLElBQUksZUFDUixRQUFDQztZQUVDQyxXQUFVOzs4QkFFVixRQUFDQztvQkFBS0QsV0FBVTs7Ozs7OzhCQUNoQixRQUFDQztvQkFBS0QsV0FBVTs4QkFDYkosTUFBTVAsSUFBSTs7Ozs7OzhCQUViLFFBQUNZO29CQUFLRCxXQUFVOzs7Ozs7O1dBUFgsQ0FBQyxJQUFJLEVBQUVQLElBQUksQ0FBQyxFQUFFRyxNQUFNUCxJQUFJLEVBQUU7Ozs7O1FBV25DTyxNQUFNTixLQUFLLENBQUNLLE9BQU8sQ0FBQyxDQUFDTyxNQUFNQztZQUN6QixNQUFNQyxTQUFTUCxhQUFhLEtBQUtNLElBQUk7WUFDckMsTUFBTUUsU0FBU2QsTUFBTSxDQUFDLEFBQUNNLENBQUFBLGFBQWFNLENBQUFBLElBQUtaLE9BQU9lLE1BQU0sQ0FBQyxJQUFJO1lBQzNEWixNQUFNSSxJQUFJLGVBQ1IsUUFBQ0c7Z0JBRUNELFdBQVU7O2tDQUVWLFFBQUNDO3dCQUFLRCxXQUFVOzs7Ozs7a0NBQ2hCLFFBQUNDO3dCQUFLRCxXQUFVOzs0QkFBMkI7NEJBQ3RDTyxPQUFPSCxRQUFRSSxRQUFRLENBQUMsR0FBRzs7Ozs7OztrQ0FFaEMsUUFBQ1A7a0NBQU1DOzs7Ozs7a0NBQ1AsUUFBQ0Q7d0JBQUtELFdBQVU7a0NBQ2JLOzs7Ozs7O2VBVEUsR0FBR1osSUFBSSxDQUFDLEVBQUVHLE1BQU1QLElBQUksQ0FBQyxDQUFDLEVBQUVhLE1BQU07Ozs7O1FBYXpDO0lBQ0Y7SUFFQSxPQUFPUjtBQUNUO0FBRUEsTUFBTWUsY0FBYztJQUNsQixNQUFNbkIsUUFBUTtXQUFJRSxXQUFXO1dBQU9BLFdBQVc7S0FBRztJQUVsRCxxQkFDRSxRQUFDTCxPQUFPWSxHQUFHO1FBQ1RXLFNBQVM7WUFBRUMsU0FBUztRQUFFO1FBQ3RCQyxTQUFTO1lBQUVELFNBQVM7UUFBRTtRQUN0QkUsWUFBWTtZQUFFQyxPQUFPO1lBQUtDLFVBQVU7UUFBSTtRQUN4Q2YsV0FBVTtRQUNWZ0IsZUFBWTs7MEJBRVosUUFBQ2pCO2dCQUFJQyxXQUFVOzs7Ozs7MEJBQ2YsUUFBQ0Q7Z0JBQUlDLFdBQVU7Ozs7OzswQkFDZixRQUFDRDtnQkFBSUMsV0FBVTswQkFDWlY7Ozs7Ozs7Ozs7OztBQUlUO0tBbEJNbUI7QUFvQk4sU0FBU0EsV0FBVyxHQUFHIn0=