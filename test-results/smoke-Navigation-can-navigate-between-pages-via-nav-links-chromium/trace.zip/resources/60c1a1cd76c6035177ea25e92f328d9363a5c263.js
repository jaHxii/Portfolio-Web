import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Index.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/pages/Index.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react;
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import Navigation from "/src/components/layout/Navigation.tsx";
import Footer from "/src/components/layout/Footer.tsx";
import Hero from "/src/components/sections/Hero.tsx";
import About from "/src/components/sections/About.tsx";
import ProjectCarousel from "/src/components/sections/ProjectCarousel.tsx";
import { TechMarquee } from "/src/components/ui/tech-marquee.tsx";
import Atmosphere from "/src/components/atmosphere/Atmosphere.tsx";
import PreloadLink from "/src/components/ui/preload-link.tsx";
import SEO from "/src/components/seo/SEO.tsx";
import StructuredData from "/src/components/seo/StructuredData.tsx";
import { useSEO } from "/src/hooks/use-seo.ts";
import { useStructuredData } from "/src/hooks/use-structured-data.ts";
const Index = ()=>{
    _s();
    const seoProps = useSEO();
    const { personSchema, websiteSchema, breadcrumbSchema } = useStructuredData();
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "min-h-screen bg-background",
        children: [
            /*#__PURE__*/ _jsxDEV(SEO, {
                ...seoProps
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(StructuredData, {
                schema: personSchema
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(StructuredData, {
                schema: websiteSchema
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(StructuredData, {
                schema: breadcrumbSchema
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(Navigation, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("main", {
                children: [
                    /*#__PURE__*/ _jsxDEV(Hero, {}, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV(About, {}, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("section", {
                        className: "relative py-12 border-y border-white/5 bg-surface/30 overflow-hidden",
                        children: [
                            /*#__PURE__*/ _jsxDEV(Atmosphere, {
                                variant: "mist",
                                className: "opacity-60"
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                lineNumber: 33,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "relative z-10 container mx-auto px-4",
                                children: /*#__PURE__*/ _jsxDEV(TechMarquee, {}, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                    lineNumber: 35,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                lineNumber: 34,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                        lineNumber: 32,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("section", {
                        id: "projects-preview",
                        className: "relative py-28 overflow-hidden",
                        children: [
                            /*#__PURE__*/ _jsxDEV(Atmosphere, {}, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ _jsxDEV("div", {
                                className: "relative z-10 container mx-auto px-4",
                                children: /*#__PURE__*/ _jsxDEV("div", {
                                    className: "text-center mb-14",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                opacity: 0,
                                                y: 20
                                            },
                                            whileInView: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            viewport: {
                                                once: true
                                            },
                                            transition: {
                                                duration: 0.6
                                            },
                                            className: "flex items-center justify-center gap-4 mb-5",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "font-mono text-xs tracking-[0.3em] gold-text",
                                                    children: "02 /"
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                                    lineNumber: 54,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("h2", {
                                                    className: "text-3xl md:text-4xl font-bold font-heading tracking-tight",
                                                    children: [
                                                        "Featured ",
                                                        /*#__PURE__*/ _jsxDEV("span", {
                                                            className: "gold-text",
                                                            children: "Work"
                                                        }, void 0, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                                            lineNumber: 58,
                                                            columnNumber: 28
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                                    lineNumber: 57,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("div", {
                                                    className: "hidden md:block h-px w-40 alt-rule"
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                                    lineNumber: 60,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                            lineNumber: 47,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV(motion.p, {
                                            initial: {
                                                opacity: 0,
                                                y: 20
                                            },
                                            whileInView: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            viewport: {
                                                once: true
                                            },
                                            transition: {
                                                delay: 0.15,
                                                duration: 0.6
                                            },
                                            className: "text-lg text-mist-soft mb-10 max-w-2xl mx-auto font-light",
                                            children: "A rotating showcase of systems, dashboards, and websites built across infrastructure and software."
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                            lineNumber: 62,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                opacity: 0,
                                                y: 30
                                            },
                                            whileInView: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            viewport: {
                                                once: true
                                            },
                                            transition: {
                                                delay: 0.3,
                                                duration: 0.6
                                            },
                                            className: "max-w-4xl mx-auto text-left",
                                            children: /*#__PURE__*/ _jsxDEV(ProjectCarousel, {}, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                                lineNumber: 80,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                            lineNumber: 73,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                opacity: 0,
                                                y: 20
                                            },
                                            whileInView: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            viewport: {
                                                once: true
                                            },
                                            transition: {
                                                delay: 0.4,
                                                duration: 0.6
                                            },
                                            className: "mt-12",
                                            children: /*#__PURE__*/ _jsxDEV(PreloadLink, {
                                                to: "/projects",
                                                className: "inline-flex items-center px-8 py-3.5 rounded-lg bg-mist text-storm-deep text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 hover:shadow-glow-strong",
                                                children: "View All Projects →"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                                lineNumber: 90,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                            lineNumber: 83,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                    lineNumber: 46,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                                lineNumber: 45,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(Footer, {}, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/pages/Index.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
};
_s(Index, "Jk2465otN7mnS9aGUeXCI9v4F0I=", false, function() {
    return [
        useSEO,
        useStructuredData
    ];
});
_c = Index;
export default Index;
var _c;
$RefreshReg$(_c, "Index");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/pages/Index.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/pages/Index.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uIH0gZnJvbSAnZnJhbWVyLW1vdGlvbic7XG5pbXBvcnQgTmF2aWdhdGlvbiBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L05hdmlnYXRpb24nO1xuaW1wb3J0IEZvb3RlciBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L0Zvb3Rlcic7XG5pbXBvcnQgSGVybyBmcm9tICdAL2NvbXBvbmVudHMvc2VjdGlvbnMvSGVybyc7XG5pbXBvcnQgQWJvdXQgZnJvbSAnQC9jb21wb25lbnRzL3NlY3Rpb25zL0Fib3V0JztcbmltcG9ydCBQcm9qZWN0Q2Fyb3VzZWwgZnJvbSAnQC9jb21wb25lbnRzL3NlY3Rpb25zL1Byb2plY3RDYXJvdXNlbCc7XG5pbXBvcnQgeyBUZWNoTWFycXVlZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS90ZWNoLW1hcnF1ZWUnO1xuaW1wb3J0IEF0bW9zcGhlcmUgZnJvbSAnQC9jb21wb25lbnRzL2F0bW9zcGhlcmUvQXRtb3NwaGVyZSc7XG5pbXBvcnQgUHJlbG9hZExpbmsgZnJvbSAnQC9jb21wb25lbnRzL3VpL3ByZWxvYWQtbGluayc7XG5pbXBvcnQgU0VPIGZyb20gJ0AvY29tcG9uZW50cy9zZW8vU0VPJztcbmltcG9ydCBTdHJ1Y3R1cmVkRGF0YSBmcm9tICdAL2NvbXBvbmVudHMvc2VvL1N0cnVjdHVyZWREYXRhJztcbmltcG9ydCB7IHVzZVNFTyB9IGZyb20gJ0AvaG9va3MvdXNlLXNlbyc7XG5pbXBvcnQgeyB1c2VTdHJ1Y3R1cmVkRGF0YSB9IGZyb20gJ0AvaG9va3MvdXNlLXN0cnVjdHVyZWQtZGF0YSc7XG5cbmNvbnN0IEluZGV4ID0gKCkgPT4ge1xuICBjb25zdCBzZW9Qcm9wcyA9IHVzZVNFTygpO1xuICBjb25zdCB7IHBlcnNvblNjaGVtYSwgd2Vic2l0ZVNjaGVtYSwgYnJlYWRjcnVtYlNjaGVtYSB9ID0gdXNlU3RydWN0dXJlZERhdGEoKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPSdtaW4taC1zY3JlZW4gYmctYmFja2dyb3VuZCc+XG4gICAgICA8U0VPIHsuLi5zZW9Qcm9wc30gLz5cbiAgICAgIDxTdHJ1Y3R1cmVkRGF0YSBzY2hlbWE9e3BlcnNvblNjaGVtYX0gLz5cbiAgICAgIDxTdHJ1Y3R1cmVkRGF0YSBzY2hlbWE9e3dlYnNpdGVTY2hlbWF9IC8+XG4gICAgICA8U3RydWN0dXJlZERhdGEgc2NoZW1hPXticmVhZGNydW1iU2NoZW1hfSAvPlxuICAgICAgPE5hdmlnYXRpb24gLz5cbiAgICAgIDxtYWluPlxuICAgICAgICA8SGVybyAvPlxuICAgICAgICA8QWJvdXQgLz5cblxuICAgICAgICB7LyogU2tpbGxzIE1hcnF1ZWUgKi99XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT0ncmVsYXRpdmUgcHktMTIgYm9yZGVyLXkgYm9yZGVyLXdoaXRlLzUgYmctc3VyZmFjZS8zMCBvdmVyZmxvdy1oaWRkZW4nPlxuICAgICAgICAgIDxBdG1vc3BoZXJlIHZhcmlhbnQ9J21pc3QnIGNsYXNzTmFtZT0nb3BhY2l0eS02MCcgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncmVsYXRpdmUgei0xMCBjb250YWluZXIgbXgtYXV0byBweC00Jz5cbiAgICAgICAgICAgIDxUZWNoTWFycXVlZSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgey8qIEZlYXR1cmVkIFdvcmsgKi99XG4gICAgICAgIDxzZWN0aW9uXG4gICAgICAgICAgaWQ9J3Byb2plY3RzLXByZXZpZXcnXG4gICAgICAgICAgY2xhc3NOYW1lPSdyZWxhdGl2ZSBweS0yOCBvdmVyZmxvdy1oaWRkZW4nXG4gICAgICAgID5cbiAgICAgICAgICA8QXRtb3NwaGVyZSAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdyZWxhdGl2ZSB6LTEwIGNvbnRhaW5lciBteC1hdXRvIHB4LTQnPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3RleHQtY2VudGVyIG1iLTE0Jz5cbiAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgICAgICAgICAgd2hpbGVJblZpZXc9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgICAgIHZpZXdwb3J0PXt7IG9uY2U6IHRydWUgfX1cbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjYgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC00IG1iLTUnXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIHRyYWNraW5nLVswLjNlbV0gZ29sZC10ZXh0Jz5cbiAgICAgICAgICAgICAgICAgIDAyIC9cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT0ndGV4dC0zeGwgbWQ6dGV4dC00eGwgZm9udC1ib2xkIGZvbnQtaGVhZGluZyB0cmFja2luZy10aWdodCc+XG4gICAgICAgICAgICAgICAgICBGZWF0dXJlZCA8c3BhbiBjbGFzc05hbWU9J2dvbGQtdGV4dCc+V29yazwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdoaWRkZW4gbWQ6YmxvY2sgaC1weCB3LTQwIGFsdC1ydWxlJyAvPlxuICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICAgIDxtb3Rpb24ucFxuICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMjAgfX1cbiAgICAgICAgICAgICAgICB3aGlsZUluVmlldz17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICAgICAgdmlld3BvcnQ9e3sgb25jZTogdHJ1ZSB9fVxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuMTUsIGR1cmF0aW9uOiAwLjYgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9J3RleHQtbGcgdGV4dC1taXN0LXNvZnQgbWItMTAgbWF4LXctMnhsIG14LWF1dG8gZm9udC1saWdodCdcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEEgcm90YXRpbmcgc2hvd2Nhc2Ugb2Ygc3lzdGVtcywgZGFzaGJvYXJkcywgYW5kIHdlYnNpdGVzIGJ1aWx0XG4gICAgICAgICAgICAgICAgYWNyb3NzIGluZnJhc3RydWN0dXJlIGFuZCBzb2Z0d2FyZS5cbiAgICAgICAgICAgICAgPC9tb3Rpb24ucD5cblxuICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMzAgfX1cbiAgICAgICAgICAgICAgICB3aGlsZUluVmlldz17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICAgICAgdmlld3BvcnQ9e3sgb25jZTogdHJ1ZSB9fVxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuMywgZHVyYXRpb246IDAuNiB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nbWF4LXctNHhsIG14LWF1dG8gdGV4dC1sZWZ0J1xuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFByb2plY3RDYXJvdXNlbCAvPlxuICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG5cbiAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgICAgICAgICAgd2hpbGVJblZpZXc9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgICAgIHZpZXdwb3J0PXt7IG9uY2U6IHRydWUgfX1cbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjQsIGR1cmF0aW9uOiAwLjYgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9J210LTEyJ1xuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFByZWxvYWRMaW5rXG4gICAgICAgICAgICAgICAgICB0bz0nL3Byb2plY3RzJ1xuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtOCBweS0zLjUgcm91bmRlZC1sZyBiZy1taXN0IHRleHQtc3Rvcm0tZGVlcCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6c2hhZG93LWdsb3ctc3Ryb25nJ1xuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFZpZXcgQWxsIFByb2plY3RzIOKGklxuICAgICAgICAgICAgICAgIDwvUHJlbG9hZExpbms+XG4gICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG4gICAgICA8L21haW4+XG4gICAgICA8Rm9vdGVyIC8+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBJbmRleDtcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIm1vdGlvbiIsIk5hdmlnYXRpb24iLCJGb290ZXIiLCJIZXJvIiwiQWJvdXQiLCJQcm9qZWN0Q2Fyb3VzZWwiLCJUZWNoTWFycXVlZSIsIkF0bW9zcGhlcmUiLCJQcmVsb2FkTGluayIsIlNFTyIsIlN0cnVjdHVyZWREYXRhIiwidXNlU0VPIiwidXNlU3RydWN0dXJlZERhdGEiLCJJbmRleCIsInNlb1Byb3BzIiwicGVyc29uU2NoZW1hIiwid2Vic2l0ZVNjaGVtYSIsImJyZWFkY3J1bWJTY2hlbWEiLCJkaXYiLCJjbGFzc05hbWUiLCJzY2hlbWEiLCJtYWluIiwic2VjdGlvbiIsInZhcmlhbnQiLCJpZCIsImluaXRpYWwiLCJvcGFjaXR5IiwieSIsIndoaWxlSW5WaWV3Iiwidmlld3BvcnQiLCJvbmNlIiwidHJhbnNpdGlvbiIsImR1cmF0aW9uIiwic3BhbiIsImgyIiwicCIsImRlbGF5IiwidG8iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxPQUFPQSxXQUFXLFFBQVE7QUFDMUIsU0FBU0MsTUFBTSxRQUFRLGdCQUFnQjtBQUN2QyxPQUFPQyxnQkFBZ0IsaUNBQWlDO0FBQ3hELE9BQU9DLFlBQVksNkJBQTZCO0FBQ2hELE9BQU9DLFVBQVUsNkJBQTZCO0FBQzlDLE9BQU9DLFdBQVcsOEJBQThCO0FBQ2hELE9BQU9DLHFCQUFxQix3Q0FBd0M7QUFDcEUsU0FBU0MsV0FBVyxRQUFRLCtCQUErQjtBQUMzRCxPQUFPQyxnQkFBZ0IscUNBQXFDO0FBQzVELE9BQU9DLGlCQUFpQiwrQkFBK0I7QUFDdkQsT0FBT0MsU0FBUyx1QkFBdUI7QUFDdkMsT0FBT0Msb0JBQW9CLGtDQUFrQztBQUM3RCxTQUFTQyxNQUFNLFFBQVEsa0JBQWtCO0FBQ3pDLFNBQVNDLGlCQUFpQixRQUFRLDhCQUE4QjtBQUVoRSxNQUFNQyxRQUFROztJQUNaLE1BQU1DLFdBQVdIO0lBQ2pCLE1BQU0sRUFBRUksWUFBWSxFQUFFQyxhQUFhLEVBQUVDLGdCQUFnQixFQUFFLEdBQUdMO0lBRTFELHFCQUNFLFFBQUNNO1FBQUlDLFdBQVU7OzBCQUNiLFFBQUNWO2dCQUFLLEdBQUdLLFFBQVE7Ozs7OzswQkFDakIsUUFBQ0o7Z0JBQWVVLFFBQVFMOzs7Ozs7MEJBQ3hCLFFBQUNMO2dCQUFlVSxRQUFRSjs7Ozs7OzBCQUN4QixRQUFDTjtnQkFBZVUsUUFBUUg7Ozs7OzswQkFDeEIsUUFBQ2hCOzs7OzswQkFDRCxRQUFDb0I7O2tDQUNDLFFBQUNsQjs7Ozs7a0NBQ0QsUUFBQ0M7Ozs7O2tDQUdELFFBQUNrQjt3QkFBUUgsV0FBVTs7MENBQ2pCLFFBQUNaO2dDQUFXZ0IsU0FBUTtnQ0FBT0osV0FBVTs7Ozs7OzBDQUNyQyxRQUFDRDtnQ0FBSUMsV0FBVTswQ0FDYixjQUFBLFFBQUNiOzs7Ozs7Ozs7Ozs7Ozs7O2tDQUtMLFFBQUNnQjt3QkFDQ0UsSUFBRzt3QkFDSEwsV0FBVTs7MENBRVYsUUFBQ1o7Ozs7OzBDQUNELFFBQUNXO2dDQUFJQyxXQUFVOzBDQUNiLGNBQUEsUUFBQ0Q7b0NBQUlDLFdBQVU7O3NEQUNiLFFBQUNuQixPQUFPa0IsR0FBRzs0Q0FDVE8sU0FBUztnREFBRUMsU0FBUztnREFBR0MsR0FBRzs0Q0FBRzs0Q0FDN0JDLGFBQWE7Z0RBQUVGLFNBQVM7Z0RBQUdDLEdBQUc7NENBQUU7NENBQ2hDRSxVQUFVO2dEQUFFQyxNQUFNOzRDQUFLOzRDQUN2QkMsWUFBWTtnREFBRUMsVUFBVTs0Q0FBSTs0Q0FDNUJiLFdBQVU7OzhEQUVWLFFBQUNjO29EQUFLZCxXQUFVOzhEQUErQzs7Ozs7OzhEQUcvRCxRQUFDZTtvREFBR2YsV0FBVTs7d0RBQTZEO3NFQUNoRSxRQUFDYzs0REFBS2QsV0FBVTtzRUFBWTs7Ozs7Ozs7Ozs7OzhEQUV2QyxRQUFDRDtvREFBSUMsV0FBVTs7Ozs7Ozs7Ozs7O3NEQUVqQixRQUFDbkIsT0FBT21DLENBQUM7NENBQ1BWLFNBQVM7Z0RBQUVDLFNBQVM7Z0RBQUdDLEdBQUc7NENBQUc7NENBQzdCQyxhQUFhO2dEQUFFRixTQUFTO2dEQUFHQyxHQUFHOzRDQUFFOzRDQUNoQ0UsVUFBVTtnREFBRUMsTUFBTTs0Q0FBSzs0Q0FDdkJDLFlBQVk7Z0RBQUVLLE9BQU87Z0RBQU1KLFVBQVU7NENBQUk7NENBQ3pDYixXQUFVO3NEQUNYOzs7Ozs7c0RBS0QsUUFBQ25CLE9BQU9rQixHQUFHOzRDQUNUTyxTQUFTO2dEQUFFQyxTQUFTO2dEQUFHQyxHQUFHOzRDQUFHOzRDQUM3QkMsYUFBYTtnREFBRUYsU0FBUztnREFBR0MsR0FBRzs0Q0FBRTs0Q0FDaENFLFVBQVU7Z0RBQUVDLE1BQU07NENBQUs7NENBQ3ZCQyxZQUFZO2dEQUFFSyxPQUFPO2dEQUFLSixVQUFVOzRDQUFJOzRDQUN4Q2IsV0FBVTtzREFFVixjQUFBLFFBQUNkOzs7Ozs7Ozs7O3NEQUdILFFBQUNMLE9BQU9rQixHQUFHOzRDQUNUTyxTQUFTO2dEQUFFQyxTQUFTO2dEQUFHQyxHQUFHOzRDQUFHOzRDQUM3QkMsYUFBYTtnREFBRUYsU0FBUztnREFBR0MsR0FBRzs0Q0FBRTs0Q0FDaENFLFVBQVU7Z0RBQUVDLE1BQU07NENBQUs7NENBQ3ZCQyxZQUFZO2dEQUFFSyxPQUFPO2dEQUFLSixVQUFVOzRDQUFJOzRDQUN4Q2IsV0FBVTtzREFFVixjQUFBLFFBQUNYO2dEQUNDNkIsSUFBRztnREFDSGxCLFdBQVU7MERBQ1g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBUVgsUUFBQ2pCOzs7Ozs7Ozs7OztBQUdQO0dBeEZNVzs7UUFDYUY7UUFDeUNDOzs7S0FGdERDO0FBMEZOLGVBQWVBLE1BQU0ifQ==