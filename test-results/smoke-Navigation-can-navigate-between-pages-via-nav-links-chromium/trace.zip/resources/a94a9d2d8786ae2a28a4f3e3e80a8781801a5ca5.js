import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/ProjectCarousel.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useEffect = __vite__cjsImport2_react["useEffect"]; const useState = __vite__cjsImport2_react["useState"];
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { ExternalLink, ChevronLeft, ChevronRight } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import { Button } from "/src/components/ui/button.tsx";
import ConfirmCodeLink from "/src/components/ui/confirm-code-link.tsx";
import DemoGallery from "/src/components/sections/DemoGallery.tsx";
import { ALL_PROJECTS } from "/src/lib/projects-data.ts";
const FEATURED = ALL_PROJECTS;
const ProjectCarousel = ()=>{
    _s();
    const [index, setIndex] = useState(0);
    const [paused, setPaused] = useState(false);
    const [demoOpen, setDemoOpen] = useState(false);
    useEffect(()=>{
        if (paused) return;
        const timer = setInterval(()=>{
            setIndex((prev)=>(prev + 1) % FEATURED.length);
        }, 5000);
        return ()=>clearInterval(timer);
    }, [
        paused
    ]);
    const { [index % FEATURED.length]: current } = FEATURED;
    const project = current ?? FEATURED[0];
    const go = (dir)=>{
        setIndex((prev)=>(prev + dir + FEATURED.length) % FEATURED.length);
    };
    const handleKeyDown = (e)=>{
        if (e.key === 'ArrowLeft') {
            e.preventDefault();
            go(-1);
        } else if (e.key === 'ArrowRight') {
            e.preventDefault();
            go(1);
        }
    };
    return /*#__PURE__*/ _jsxDEV("div", {
        className: "relative",
        role: "region",
        "aria-label": "Featured projects carousel",
        "aria-roledescription": "carousel",
        tabIndex: 0,
        onKeyDown: handleKeyDown,
        onMouseEnter: ()=>setPaused(true),
        onMouseLeave: ()=>setPaused(false),
        onFocus: ()=>setPaused(true),
        onBlur: ()=>setPaused(false),
        children: [
            /*#__PURE__*/ _jsxDEV(AnimatePresence, {
                mode: "wait",
                children: /*#__PURE__*/ _jsxDEV(motion.div, {
                    initial: {
                        opacity: 0,
                        x: 40
                    },
                    animate: {
                        opacity: 1,
                        x: 0
                    },
                    exit: {
                        opacity: 0,
                        x: -40
                    },
                    transition: {
                        duration: 0.5,
                        ease: 'easeOut'
                    },
                    children: /*#__PURE__*/ _jsxDEV("div", {
                        className: "glass-cloud rounded-2xl overflow-hidden",
                        children: /*#__PURE__*/ _jsxDEV("div", {
                            className: "grid md:grid-cols-2",
                            children: [
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "relative overflow-hidden min-h-56",
                                    children: [
                                        project.image ? /*#__PURE__*/ _jsxDEV("img", {
                                            src: project.image,
                                            alt: project.title,
                                            className: "w-full h-56 md:h-full object-cover"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                            lineNumber: 67,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ _jsxDEV("div", {
                                            className: "w-full h-56 md:h-full bg-gradient-to-br from-storm via-background to-background flex items-center justify-center",
                                            children: /*#__PURE__*/ _jsxDEV("span", {
                                                className: "text-6xl font-heading font-bold gold-text/70",
                                                children: project.title.charAt(0)
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                lineNumber: 74,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                            lineNumber: 73,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "absolute top-4 left-4 flex items-center gap-2",
                                            children: /*#__PURE__*/ _jsxDEV("span", {
                                                className: "px-3 py-1 rounded-md border border-gold/40 bg-background/70 backdrop-blur-sm text-xs font-mono text-gold",
                                                children: project.category
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                lineNumber: 80,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                            lineNumber: 79,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                    lineNumber: 65,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "p-8 md:p-10 flex flex-col justify-center text-left",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "flex items-center gap-3 mb-4",
                                            children: [
                                                "          ",
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "font-mono text-xs tracking-[0.3em] gold-text",
                                                    "aria-live": "polite",
                                                    "aria-atomic": "true",
                                                    children: [
                                                        String(index + 1).padStart(2, '0'),
                                                        " /",
                                                        ' ',
                                                        String(FEATURED.length).padStart(2, '0')
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                    lineNumber: 88,
                                                    columnNumber: 73
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "h-px flex-1 bg-border"
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                    lineNumber: 92,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                            lineNumber: 88,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("h3", {
                                            className: "text-2xl font-heading font-bold mb-3 tracking-tight",
                                            children: project.title
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                            lineNumber: 94,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("p", {
                                            className: "text-mist-soft leading-relaxed mb-6 font-light",
                                            children: project.description
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                            lineNumber: 97,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "flex flex-wrap gap-2 mb-8",
                                            children: project.tech.map((tech)=>/*#__PURE__*/ _jsxDEV("span", {
                                                    className: "glass rounded-md px-3 py-1.5 font-mono text-xs text-mist-soft",
                                                    children: tech
                                                }, tech, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                    lineNumber: 102,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                            lineNumber: 100,
                                            columnNumber: 17
                                        }, this),
                                        (project.github || project.demo || project.demoImages) && /*#__PURE__*/ _jsxDEV("div", {
                                            className: "flex gap-3",
                                            children: [
                                                project.github && /*#__PURE__*/ _jsxDEV(ConfirmCodeLink, {
                                                    href: project.github,
                                                    projectName: project.title,
                                                    className: "glass text-mist-soft hover:border-gold/60"
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                    lineNumber: 113,
                                                    columnNumber: 23
                                                }, this),
                                                project.demoImages ? /*#__PURE__*/ _jsxDEV(Button, {
                                                    size: "sm",
                                                    onClick: ()=>setDemoOpen(true),
                                                    children: [
                                                        /*#__PURE__*/ _jsxDEV(ExternalLink, {
                                                            className: "h-4 w-4 mr-2"
                                                        }, void 0, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                            lineNumber: 121,
                                                            columnNumber: 25
                                                        }, this),
                                                        "Demo"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                    lineNumber: 120,
                                                    columnNumber: 23
                                                }, this) : project.demo && /*#__PURE__*/ _jsxDEV(Button, {
                                                    size: "sm",
                                                    asChild: true,
                                                    children: /*#__PURE__*/ _jsxDEV("a", {
                                                        href: project.demo,
                                                        target: "_blank",
                                                        rel: "noopener noreferrer",
                                                        children: [
                                                            /*#__PURE__*/ _jsxDEV(ExternalLink, {
                                                                className: "h-4 w-4 mr-2"
                                                            }, void 0, false, {
                                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                                lineNumber: 132,
                                                                columnNumber: 29
                                                            }, this),
                                                            "Demo"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                        lineNumber: 127,
                                                        columnNumber: 27
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                                    lineNumber: 126,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                            lineNumber: 111,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                    lineNumber: 87,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                            lineNumber: 63,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                        lineNumber: 62,
                        columnNumber: 11
                    }, this)
                }, index, false, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                    lineNumber: 55,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "flex items-center justify-center gap-6 mt-7",
                children: [
                    /*#__PURE__*/ _jsxDEV("button", {
                        onClick: ()=>go(-1),
                        "aria-label": "Previous project",
                        className: "glass p-2.5 rounded-full text-mist-soft hover:text-gold hover:border-gold/50 transition-all duration-300",
                        children: /*#__PURE__*/ _jsxDEV(ChevronLeft, {
                            className: "h-4 w-4"
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                            lineNumber: 153,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                        lineNumber: 148,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "flex gap-2",
                        children: FEATURED.map((_, i)=>/*#__PURE__*/ _jsxDEV("button", {
                                onClick: ()=>setIndex(i),
                                "aria-label": `Go to project ${i + 1}`,
                                className: `h-1.5 rounded-full transition-all duration-300 ${i === index ? 'w-6 bg-gradient-gold' : 'w-1.5 bg-storm hover:bg-mist-soft/60'}`
                            }, i, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                                lineNumber: 157,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                        lineNumber: 155,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ _jsxDEV("button", {
                        onClick: ()=>go(1),
                        "aria-label": "Next project",
                        className: "glass p-2.5 rounded-full text-mist-soft hover:text-gold hover:border-gold/50 transition-all duration-300",
                        children: /*#__PURE__*/ _jsxDEV(ChevronRight, {
                            className: "h-4 w-4"
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                            lineNumber: 174,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                        lineNumber: 169,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                lineNumber: 147,
                columnNumber: 7
            }, this),
            project.demoImages && /*#__PURE__*/ _jsxDEV(DemoGallery, {
                open: demoOpen,
                onOpenChange: setDemoOpen,
                title: project.title,
                images: project.demoImages
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
                lineNumber: 179,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
};
_s(ProjectCarousel, "xOSkATavHIVZUcdZtIqd8FDfXj0=");
_c = ProjectCarousel;
export default ProjectCarousel;
var _c;
$RefreshReg$(_c, "ProjectCarousel");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/sections/ProjectCarousel.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlByb2plY3RDYXJvdXNlbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24sIEFuaW1hdGVQcmVzZW5jZSB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgRXh0ZXJuYWxMaW5rLCBDaGV2cm9uTGVmdCwgQ2hldnJvblJpZ2h0IH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IENvbmZpcm1Db2RlTGluayBmcm9tICdAL2NvbXBvbmVudHMvdWkvY29uZmlybS1jb2RlLWxpbmsnO1xuaW1wb3J0IERlbW9HYWxsZXJ5IGZyb20gJ0AvY29tcG9uZW50cy9zZWN0aW9ucy9EZW1vR2FsbGVyeSc7XG5pbXBvcnQgeyBBTExfUFJPSkVDVFMgfSBmcm9tICdAL2xpYi9wcm9qZWN0cy1kYXRhJztcblxuY29uc3QgRkVBVFVSRUQgPSBBTExfUFJPSkVDVFM7XG5cbmNvbnN0IFByb2plY3RDYXJvdXNlbCA9ICgpID0+IHtcbiAgY29uc3QgW2luZGV4LCBzZXRJbmRleF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3BhdXNlZCwgc2V0UGF1c2VkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2RlbW9PcGVuLCBzZXREZW1vT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAocGF1c2VkKSByZXR1cm47XG4gICAgY29uc3QgdGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBzZXRJbmRleChwcmV2ID0+IChwcmV2ICsgMSkgJSBGRUFUVVJFRC5sZW5ndGgpO1xuICAgIH0sIDUwMDApO1xuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKHRpbWVyKTtcbiAgfSwgW3BhdXNlZF0pO1xuXG4gIGNvbnN0IHsgW2luZGV4ICUgRkVBVFVSRUQubGVuZ3RoXTogY3VycmVudCB9ID0gRkVBVFVSRUQ7XG4gIGNvbnN0IHByb2plY3QgPSBjdXJyZW50ID8/IEZFQVRVUkVEWzBdO1xuXG4gIGNvbnN0IGdvID0gKGRpcjogbnVtYmVyKSA9PiB7XG4gICAgc2V0SW5kZXgocHJldiA9PiAocHJldiArIGRpciArIEZFQVRVUkVELmxlbmd0aCkgJSBGRUFUVVJFRC5sZW5ndGgpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZTogUmVhY3QuS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgIGlmIChlLmtleSA9PT0gJ0Fycm93TGVmdCcpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGdvKC0xKTtcbiAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnQXJyb3dSaWdodCcpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGdvKDEpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT0ncmVsYXRpdmUnXG4gICAgICByb2xlPSdyZWdpb24nXG4gICAgICBhcmlhLWxhYmVsPSdGZWF0dXJlZCBwcm9qZWN0cyBjYXJvdXNlbCdcbiAgICAgIGFyaWEtcm9sZWRlc2NyaXB0aW9uPSdjYXJvdXNlbCdcbiAgICAgIHRhYkluZGV4PXswfVxuICAgICAgb25LZXlEb3duPXtoYW5kbGVLZXlEb3dufVxuICAgICAgb25Nb3VzZUVudGVyPXsoKSA9PiBzZXRQYXVzZWQodHJ1ZSl9XG4gICAgICBvbk1vdXNlTGVhdmU9eygpID0+IHNldFBhdXNlZChmYWxzZSl9XG4gICAgICBvbkZvY3VzPXsoKSA9PiBzZXRQYXVzZWQodHJ1ZSl9XG4gICAgICBvbkJsdXI9eygpID0+IHNldFBhdXNlZChmYWxzZSl9XG4gICAgPlxuICAgICAgPEFuaW1hdGVQcmVzZW5jZSBtb2RlPSd3YWl0Jz5cbiAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICBrZXk9e2luZGV4fVxuICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeDogNDAgfX1cbiAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHg6IDAgfX1cbiAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHg6IC00MCB9fVxuICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuNSwgZWFzZTogJ2Vhc2VPdXQnIH19XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZ2xhc3MtY2xvdWQgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuJz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdncmlkIG1kOmdyaWQtY29scy0yJz5cbiAgICAgICAgICAgICAgey8qIEltYWdlICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIG1pbi1oLTU2Jz5cbiAgICAgICAgICAgICAgICB7cHJvamVjdC5pbWFnZSA/IChcbiAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgc3JjPXtwcm9qZWN0LmltYWdlfVxuICAgICAgICAgICAgICAgICAgICBhbHQ9e3Byb2plY3QudGl0bGV9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0ndy1mdWxsIGgtNTYgbWQ6aC1mdWxsIG9iamVjdC1jb3ZlcidcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd3LWZ1bGwgaC01NiBtZDpoLWZ1bGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zdG9ybSB2aWEtYmFja2dyb3VuZCB0by1iYWNrZ3JvdW5kIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyJz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSd0ZXh0LTZ4bCBmb250LWhlYWRpbmcgZm9udC1ib2xkIGdvbGQtdGV4dC83MCc+XG4gICAgICAgICAgICAgICAgICAgICAge3Byb2plY3QudGl0bGUuY2hhckF0KDApfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdhYnNvbHV0ZSB0b3AtNCBsZWZ0LTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTInPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdweC0zIHB5LTEgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdvbGQvNDAgYmctYmFja2dyb3VuZC83MCBiYWNrZHJvcC1ibHVyLXNtIHRleHQteHMgZm9udC1tb25vIHRleHQtZ29sZCc+XG4gICAgICAgICAgICAgICAgICAgIHtwcm9qZWN0LmNhdGVnb3J5fVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQ29udGVudCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J3AtOCBtZDpwLTEwIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgdGV4dC1sZWZ0Jz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItNCc+ICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQteHMgdHJhY2tpbmctWzAuM2VtXSBnb2xkLXRleHQnIGFyaWEtbGl2ZT0ncG9saXRlJyBhcmlhLWF0b21pYz0ndHJ1ZSc+XG4gICAgICAgICAgICAgICAgICAgIHtTdHJpbmcoaW5kZXggKyAxKS5wYWRTdGFydCgyLCAnMCcpfSAvXG4gICAgICAgICAgICAgICAgICAgIHsnICd9e1N0cmluZyhGRUFUVVJFRC5sZW5ndGgpLnBhZFN0YXJ0KDIsICcwJyl9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2gtcHggZmxleC0xIGJnLWJvcmRlcicgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPSd0ZXh0LTJ4bCBmb250LWhlYWRpbmcgZm9udC1ib2xkIG1iLTMgdHJhY2tpbmctdGlnaHQnPlxuICAgICAgICAgICAgICAgICAge3Byb2plY3QudGl0bGV9XG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtbWlzdC1zb2Z0IGxlYWRpbmctcmVsYXhlZCBtYi02IGZvbnQtbGlnaHQnPlxuICAgICAgICAgICAgICAgICAge3Byb2plY3QuZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGZsZXgtd3JhcCBnYXAtMiBtYi04Jz5cbiAgICAgICAgICAgICAgICAgIHtwcm9qZWN0LnRlY2gubWFwKHRlY2ggPT4gKFxuICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgIGtleT17dGVjaH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2dsYXNzIHJvdW5kZWQtbWQgcHgtMyBweS0xLjUgZm9udC1tb25vIHRleHQteHMgdGV4dC1taXN0LXNvZnQnXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7dGVjaH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgeyhwcm9qZWN0LmdpdGh1YiB8fCBwcm9qZWN0LmRlbW8gfHwgcHJvamVjdC5kZW1vSW1hZ2VzKSAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZmxleCBnYXAtMyc+XG4gICAgICAgICAgICAgICAgICAgIHtwcm9qZWN0LmdpdGh1YiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPENvbmZpcm1Db2RlTGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17cHJvamVjdC5naXRodWJ9XG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9qZWN0TmFtZT17cHJvamVjdC50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZ2xhc3MgdGV4dC1taXN0LXNvZnQgaG92ZXI6Ym9yZGVyLWdvbGQvNjAnXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge3Byb2plY3QuZGVtb0ltYWdlcyA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9J3NtJyBvbkNsaWNrPXsoKSA9PiBzZXREZW1vT3Blbih0cnVlKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT0naC00IHctNCBtci0yJyAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgRGVtb1xuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIHByb2plY3QuZGVtbyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9J3NtJyBhc0NoaWxkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e3Byb2plY3QuZGVtb31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9J19ibGFuaydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9J25vb3BlbmVyIG5vcmVmZXJyZXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT0naC00IHctNCBtci0yJyAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlbW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG5cbiAgICAgIHsvKiBDb250cm9scyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNiBtdC03Jz5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGdvKC0xKX1cbiAgICAgICAgICBhcmlhLWxhYmVsPSdQcmV2aW91cyBwcm9qZWN0J1xuICAgICAgICAgIGNsYXNzTmFtZT0nZ2xhc3MgcC0yLjUgcm91bmRlZC1mdWxsIHRleHQtbWlzdC1zb2Z0IGhvdmVyOnRleHQtZ29sZCBob3Zlcjpib3JkZXItZ29sZC81MCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAnXG4gICAgICAgID5cbiAgICAgICAgICA8Q2hldnJvbkxlZnQgY2xhc3NOYW1lPSdoLTQgdy00JyAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggZ2FwLTInPlxuICAgICAgICAgIHtGRUFUVVJFRC5tYXAoKF8sIGkpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtpfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJbmRleChpKX1cbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YEdvIHRvIHByb2plY3QgJHtpICsgMX1gfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLTEuNSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwICR7XG4gICAgICAgICAgICAgICAgaSA9PT0gaW5kZXhcbiAgICAgICAgICAgICAgICAgID8gJ3ctNiBiZy1ncmFkaWVudC1nb2xkJ1xuICAgICAgICAgICAgICAgICAgOiAndy0xLjUgYmctc3Rvcm0gaG92ZXI6YmctbWlzdC1zb2Z0LzYwJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gZ28oMSl9XG4gICAgICAgICAgYXJpYS1sYWJlbD0nTmV4dCBwcm9qZWN0J1xuICAgICAgICAgIGNsYXNzTmFtZT0nZ2xhc3MgcC0yLjUgcm91bmRlZC1mdWxsIHRleHQtbWlzdC1zb2Z0IGhvdmVyOnRleHQtZ29sZCBob3Zlcjpib3JkZXItZ29sZC81MCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAnXG4gICAgICAgID5cbiAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT0naC00IHctNCcgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAge3Byb2plY3QuZGVtb0ltYWdlcyAmJiAoXG4gICAgICAgIDxEZW1vR2FsbGVyeVxuICAgICAgICAgIG9wZW49e2RlbW9PcGVufVxuICAgICAgICAgIG9uT3BlbkNoYW5nZT17c2V0RGVtb09wZW59XG4gICAgICAgICAgdGl0bGU9e3Byb2plY3QudGl0bGV9XG4gICAgICAgICAgaW1hZ2VzPXtwcm9qZWN0LmRlbW9JbWFnZXN9XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUHJvamVjdENhcm91c2VsO1xuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJtb3Rpb24iLCJBbmltYXRlUHJlc2VuY2UiLCJFeHRlcm5hbExpbmsiLCJDaGV2cm9uTGVmdCIsIkNoZXZyb25SaWdodCIsIkJ1dHRvbiIsIkNvbmZpcm1Db2RlTGluayIsIkRlbW9HYWxsZXJ5IiwiQUxMX1BST0pFQ1RTIiwiRkVBVFVSRUQiLCJQcm9qZWN0Q2Fyb3VzZWwiLCJpbmRleCIsInNldEluZGV4IiwicGF1c2VkIiwic2V0UGF1c2VkIiwiZGVtb09wZW4iLCJzZXREZW1vT3BlbiIsInRpbWVyIiwic2V0SW50ZXJ2YWwiLCJwcmV2IiwibGVuZ3RoIiwiY2xlYXJJbnRlcnZhbCIsImN1cnJlbnQiLCJwcm9qZWN0IiwiZ28iLCJkaXIiLCJoYW5kbGVLZXlEb3duIiwiZSIsImtleSIsInByZXZlbnREZWZhdWx0IiwiZGl2IiwiY2xhc3NOYW1lIiwicm9sZSIsImFyaWEtbGFiZWwiLCJhcmlhLXJvbGVkZXNjcmlwdGlvbiIsInRhYkluZGV4Iiwib25LZXlEb3duIiwib25Nb3VzZUVudGVyIiwib25Nb3VzZUxlYXZlIiwib25Gb2N1cyIsIm9uQmx1ciIsIm1vZGUiLCJpbml0aWFsIiwib3BhY2l0eSIsIngiLCJhbmltYXRlIiwiZXhpdCIsInRyYW5zaXRpb24iLCJkdXJhdGlvbiIsImVhc2UiLCJpbWFnZSIsImltZyIsInNyYyIsImFsdCIsInRpdGxlIiwic3BhbiIsImNoYXJBdCIsImNhdGVnb3J5IiwiYXJpYS1saXZlIiwiYXJpYS1hdG9taWMiLCJTdHJpbmciLCJwYWRTdGFydCIsImgzIiwicCIsImRlc2NyaXB0aW9uIiwidGVjaCIsIm1hcCIsImdpdGh1YiIsImRlbW8iLCJkZW1vSW1hZ2VzIiwiaHJlZiIsInByb2plY3ROYW1lIiwic2l6ZSIsIm9uQ2xpY2siLCJhc0NoaWxkIiwiYSIsInRhcmdldCIsInJlbCIsImJ1dHRvbiIsIl8iLCJpIiwib3BlbiIsIm9uT3BlbkNoYW5nZSIsImltYWdlcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLE9BQU9BLFNBQVNDLFNBQVMsRUFBRUMsUUFBUSxRQUFRLFFBQVE7QUFDbkQsU0FBU0MsTUFBTSxFQUFFQyxlQUFlLFFBQVEsZ0JBQWdCO0FBQ3hELFNBQVNDLFlBQVksRUFBRUMsV0FBVyxFQUFFQyxZQUFZLFFBQVEsZUFBZTtBQUN2RSxTQUFTQyxNQUFNLFFBQVEseUJBQXlCO0FBQ2hELE9BQU9DLHFCQUFxQixvQ0FBb0M7QUFDaEUsT0FBT0MsaUJBQWlCLG9DQUFvQztBQUM1RCxTQUFTQyxZQUFZLFFBQVEsc0JBQXNCO0FBRW5ELE1BQU1DLFdBQVdEO0FBRWpCLE1BQU1FLGtCQUFrQjs7SUFDdEIsTUFBTSxDQUFDQyxPQUFPQyxTQUFTLEdBQUdiLFNBQVM7SUFDbkMsTUFBTSxDQUFDYyxRQUFRQyxVQUFVLEdBQUdmLFNBQVM7SUFDckMsTUFBTSxDQUFDZ0IsVUFBVUMsWUFBWSxHQUFHakIsU0FBUztJQUV6Q0QsVUFBVTtRQUNSLElBQUllLFFBQVE7UUFDWixNQUFNSSxRQUFRQyxZQUFZO1lBQ3hCTixTQUFTTyxDQUFBQSxPQUFRLEFBQUNBLENBQUFBLE9BQU8sQ0FBQSxJQUFLVixTQUFTVyxNQUFNO1FBQy9DLEdBQUc7UUFDSCxPQUFPLElBQU1DLGNBQWNKO0lBQzdCLEdBQUc7UUFBQ0o7S0FBTztJQUVYLE1BQU0sRUFBRSxDQUFDRixRQUFRRixTQUFTVyxNQUFNLENBQUMsRUFBRUUsT0FBTyxFQUFFLEdBQUdiO0lBQy9DLE1BQU1jLFVBQVVELFdBQVdiLFFBQVEsQ0FBQyxFQUFFO0lBRXRDLE1BQU1lLEtBQUssQ0FBQ0M7UUFDVmIsU0FBU08sQ0FBQUEsT0FBUSxBQUFDQSxDQUFBQSxPQUFPTSxNQUFNaEIsU0FBU1csTUFBTSxBQUFELElBQUtYLFNBQVNXLE1BQU07SUFDbkU7SUFFQSxNQUFNTSxnQkFBZ0IsQ0FBQ0M7UUFDckIsSUFBSUEsRUFBRUMsR0FBRyxLQUFLLGFBQWE7WUFDekJELEVBQUVFLGNBQWM7WUFDaEJMLEdBQUcsQ0FBQztRQUNOLE9BQU8sSUFBSUcsRUFBRUMsR0FBRyxLQUFLLGNBQWM7WUFDakNELEVBQUVFLGNBQWM7WUFDaEJMLEdBQUc7UUFDTDtJQUNGO0lBRUEscUJBQ0UsUUFBQ007UUFDQ0MsV0FBVTtRQUNWQyxNQUFLO1FBQ0xDLGNBQVc7UUFDWEMsd0JBQXFCO1FBQ3JCQyxVQUFVO1FBQ1ZDLFdBQVdWO1FBQ1hXLGNBQWMsSUFBTXZCLFVBQVU7UUFDOUJ3QixjQUFjLElBQU14QixVQUFVO1FBQzlCeUIsU0FBUyxJQUFNekIsVUFBVTtRQUN6QjBCLFFBQVEsSUFBTTFCLFVBQVU7OzBCQUV4QixRQUFDYjtnQkFBZ0J3QyxNQUFLOzBCQUNwQixjQUFBLFFBQUN6QyxPQUFPOEIsR0FBRztvQkFFVFksU0FBUzt3QkFBRUMsU0FBUzt3QkFBR0MsR0FBRztvQkFBRztvQkFDN0JDLFNBQVM7d0JBQUVGLFNBQVM7d0JBQUdDLEdBQUc7b0JBQUU7b0JBQzVCRSxNQUFNO3dCQUFFSCxTQUFTO3dCQUFHQyxHQUFHLENBQUM7b0JBQUc7b0JBQzNCRyxZQUFZO3dCQUFFQyxVQUFVO3dCQUFLQyxNQUFNO29CQUFVOzhCQUU3QyxjQUFBLFFBQUNuQjt3QkFBSUMsV0FBVTtrQ0FDYixjQUFBLFFBQUNEOzRCQUFJQyxXQUFVOzs4Q0FFYixRQUFDRDtvQ0FBSUMsV0FBVTs7d0NBQ1pSLFFBQVEyQixLQUFLLGlCQUNaLFFBQUNDOzRDQUNDQyxLQUFLN0IsUUFBUTJCLEtBQUs7NENBQ2xCRyxLQUFLOUIsUUFBUStCLEtBQUs7NENBQ2xCdkIsV0FBVTs7Ozs7aUVBR1osUUFBQ0Q7NENBQUlDLFdBQVU7c0RBQ2IsY0FBQSxRQUFDd0I7Z0RBQUt4QixXQUFVOzBEQUNiUixRQUFRK0IsS0FBSyxDQUFDRSxNQUFNLENBQUM7Ozs7Ozs7Ozs7O3NEQUk1QixRQUFDMUI7NENBQUlDLFdBQVU7c0RBQ2IsY0FBQSxRQUFDd0I7Z0RBQUt4QixXQUFVOzBEQUNiUixRQUFRa0MsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7OENBTXZCLFFBQUMzQjtvQ0FBSUMsV0FBVTs7c0RBQ2IsUUFBQ0Q7NENBQUlDLFdBQVU7O2dEQUErQjs4REFBVSxRQUFDd0I7b0RBQUt4QixXQUFVO29EQUErQzJCLGFBQVU7b0RBQVNDLGVBQVk7O3dEQUNqSkMsT0FBT2pELFFBQVEsR0FBR2tELFFBQVEsQ0FBQyxHQUFHO3dEQUFLO3dEQUNuQzt3REFBS0QsT0FBT25ELFNBQVNXLE1BQU0sRUFBRXlDLFFBQVEsQ0FBQyxHQUFHOzs7Ozs7OzhEQUU1QyxRQUFDTjtvREFBS3hCLFdBQVU7Ozs7Ozs7Ozs7OztzREFFbEIsUUFBQytCOzRDQUFHL0IsV0FBVTtzREFDWFIsUUFBUStCLEtBQUs7Ozs7OztzREFFaEIsUUFBQ1M7NENBQUVoQyxXQUFVO3NEQUNWUixRQUFReUMsV0FBVzs7Ozs7O3NEQUV0QixRQUFDbEM7NENBQUlDLFdBQVU7c0RBQ1pSLFFBQVEwQyxJQUFJLENBQUNDLEdBQUcsQ0FBQ0QsQ0FBQUEscUJBQ2hCLFFBQUNWO29EQUVDeEIsV0FBVTs4REFFVGtDO21EQUhJQTs7Ozs7Ozs7Ozt3Q0FPVDFDLENBQUFBLFFBQVE0QyxNQUFNLElBQUk1QyxRQUFRNkMsSUFBSSxJQUFJN0MsUUFBUThDLFVBQVUsQUFBRCxtQkFDbkQsUUFBQ3ZDOzRDQUFJQyxXQUFVOztnREFDWlIsUUFBUTRDLE1BQU0sa0JBQ2IsUUFBQzdEO29EQUNDZ0UsTUFBTS9DLFFBQVE0QyxNQUFNO29EQUNwQkksYUFBYWhELFFBQVErQixLQUFLO29EQUMxQnZCLFdBQVU7Ozs7OztnREFHYlIsUUFBUThDLFVBQVUsaUJBQ2pCLFFBQUNoRTtvREFBT21FLE1BQUs7b0RBQUtDLFNBQVMsSUFBTXpELFlBQVk7O3NFQUMzQyxRQUFDZDs0REFBYTZCLFdBQVU7Ozs7Ozt3REFBaUI7Ozs7OzsyREFJM0NSLFFBQVE2QyxJQUFJLGtCQUNWLFFBQUMvRDtvREFBT21FLE1BQUs7b0RBQUtFLE9BQU87OERBQ3ZCLGNBQUEsUUFBQ0M7d0RBQ0NMLE1BQU0vQyxRQUFRNkMsSUFBSTt3REFDbEJRLFFBQU87d0RBQ1BDLEtBQUk7OzBFQUVKLFFBQUMzRTtnRUFBYTZCLFdBQVU7Ozs7Ozs0REFBaUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O21CQTVFdERwQjs7Ozs7Ozs7OzswQkEyRlQsUUFBQ21CO2dCQUFJQyxXQUFVOztrQ0FDYixRQUFDK0M7d0JBQ0NMLFNBQVMsSUFBTWpELEdBQUcsQ0FBQzt3QkFDbkJTLGNBQVc7d0JBQ1hGLFdBQVU7a0NBRVYsY0FBQSxRQUFDNUI7NEJBQVk0QixXQUFVOzs7Ozs7Ozs7OztrQ0FFekIsUUFBQ0Q7d0JBQUlDLFdBQVU7a0NBQ1p0QixTQUFTeUQsR0FBRyxDQUFDLENBQUNhLEdBQUdDLGtCQUNoQixRQUFDRjtnQ0FFQ0wsU0FBUyxJQUFNN0QsU0FBU29FO2dDQUN4Qi9DLGNBQVksQ0FBQyxjQUFjLEVBQUUrQyxJQUFJLEdBQUc7Z0NBQ3BDakQsV0FBVyxDQUFDLCtDQUErQyxFQUN6RGlELE1BQU1yRSxRQUNGLHlCQUNBLHdDQUNKOytCQVBHcUU7Ozs7Ozs7Ozs7a0NBV1gsUUFBQ0Y7d0JBQ0NMLFNBQVMsSUFBTWpELEdBQUc7d0JBQ2xCUyxjQUFXO3dCQUNYRixXQUFVO2tDQUVWLGNBQUEsUUFBQzNCOzRCQUFhMkIsV0FBVTs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFJM0JSLFFBQVE4QyxVQUFVLGtCQUNqQixRQUFDOUQ7Z0JBQ0MwRSxNQUFNbEU7Z0JBQ05tRSxjQUFjbEU7Z0JBQ2RzQyxPQUFPL0IsUUFBUStCLEtBQUs7Z0JBQ3BCNkIsUUFBUTVELFFBQVE4QyxVQUFVOzs7Ozs7Ozs7Ozs7QUFLcEM7R0FqTE0zRDtLQUFBQTtBQW1MTixlQUFlQSxnQkFBZ0IifQ==