import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/Hero.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s1 = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useEffect = __vite__cjsImport2_react["useEffect"]; const useState = __vite__cjsImport2_react["useState"];
import { motion, useScroll, useTransform } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { ArrowRight, Download, Github, Mail, Plane, Send } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
const ROLES = [
    'IT Systems Engineer',
    'Systems & Network Specialist',
    'Computer Engineer',
    'Technology Builder'
];
const prefersReducedMotion = ()=>typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const Typewriter = ({ roles })=>{
    _s();
    const [roleIndex, setRoleIndex] = useState(0);
    const [text, setText] = useState('');
    const [deleting, setDeleting] = useState(false);
    useEffect(()=>{
        if (prefersReducedMotion()) {
            setText(roles[0] ?? '');
            return;
        }
        const { [roleIndex]: role } = roles;
        const current = role ?? '';
        const speed = deleting ? 30 : 70;
        let pauseTimer = null;
        const timeout = setTimeout(()=>{
            if (!deleting) {
                const next = current.slice(0, text.length + 1);
                setText(next);
                if (next === current) {
                    pauseTimer = setTimeout(()=>setDeleting(true), 1500);
                }
            } else {
                const next = current.slice(0, text.length - 1);
                setText(next);
                if (next === '') {
                    setDeleting(false);
                    setRoleIndex((prev)=>(prev + 1) % roles.length);
                }
            }
        }, speed);
        return ()=>{
            clearTimeout(timeout);
            if (pauseTimer) clearTimeout(pauseTimer);
        };
    }, [
        text,
        deleting,
        roleIndex,
        roles
    ]);
    return /*#__PURE__*/ _jsxDEV("span", {
        className: "inline-flex items-center",
        children: [
            /*#__PURE__*/ _jsxDEV("span", {
                className: "gold-text",
                children: text
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("span", {
                className: "ml-1 w-0.5 h-6 md:h-7 bg-gold/70 animate-pulse"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
};
_s(Typewriter, "anIlIwnY/tljakhx52RULX3RIiQ=");
_c = Typewriter;
const MISSION_LINES = [
    'Holding altitude above the cloud layer - keeping systems reliable.',
    'Engineering calm above the storm - infrastructure, networks, code.',
    'Systems online. Altitude steady. Building what lasts.',
    'Climbing through the clouds, one reliable system at a time.'
];
const Hero = ()=>{
    _s1();
    const { scrollY } = useScroll();
    // Mission line chosen once per visit
    const [mission] = useState(()=>MISSION_LINES[Math.floor(Math.random() * MISSION_LINES.length)] ?? MISSION_LINES[0] ?? '');
    // Content lifts and fades as you leave the hero (clouds are global — CloudField)
    const contentY = useTransform(scrollY, [
        0,
        600
    ], [
        0,
        -60
    ]);
    const contentOpacity = useTransform(scrollY, [
        0,
        500
    ], [
        1,
        0.2
    ]);
    const scrollToProjects = ()=>{
        const element = document.getElementById('projects-preview');
        element?.scrollIntoView({
            behavior: 'smooth'
        });
    };
    const socialLinks = [
        {
            icon: Github,
            href: 'https://github.com/jaHxii',
            label: 'GitHub'
        },
        {
            icon: Send,
            href: 'https://t.me/cloudx69',
            label: 'Telegram'
        },
        {
            icon: Mail,
            href: 'mailto:ermias.xii@gmail.com',
            label: 'Email'
        }
    ];
    return /*#__PURE__*/ _jsxDEV("section", {
        className: "relative min-h-screen flex items-center justify-center overflow-hidden bg-atmo-hero",
        children: [
            /*#__PURE__*/ _jsxDEV("div", {
                "aria-hidden": "true",
                className: "hero-vignette pointer-events-none absolute inset-0"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(motion.div, {
                style: {
                    y: contentY,
                    opacity: contentOpacity
                },
                className: "container mx-auto px-4 relative z-10 py-32",
                children: /*#__PURE__*/ _jsxDEV("div", {
                    className: "max-w-4xl mx-auto text-center",
                    children: [
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 14
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.1,
                                duration: 0.7
                            },
                            className: "glass inline-flex items-center gap-2.5 rounded-full px-5 py-2 font-mono text-[11px] tracking-[0.25em] text-mist-soft",
                            children: [
                                /*#__PURE__*/ _jsxDEV("span", {
                                    className: "relative flex h-2 w-2",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "absolute inline-flex h-full w-full rounded-full bg-gold/60 motion-safe:animate-ping"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                            lineNumber: 119,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "relative inline-flex h-2 w-2 rounded-full bg-gold"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                            lineNumber: 120,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 118,
                                    columnNumber: 13
                                }, this),
                                "ERMIAS.LEMESA / SYSTEMS ONLINE"
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                            lineNumber: 112,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.h1, {
                            initial: {
                                opacity: 0,
                                y: 24
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.3,
                                duration: 0.9
                            },
                            className: "relative mt-8 text-5xl sm:text-6xl md:text-8xl font-bold font-heading tracking-tight leading-[1.05]",
                            children: [
                                /*#__PURE__*/ _jsxDEV("span", {
                                    className: "name-gradient",
                                    children: "Ermias"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 132,
                                    columnNumber: 13
                                }, this),
                                ' ',
                                /*#__PURE__*/ _jsxDEV("span", {
                                    className: "name-gradient",
                                    children: "Lemesa"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 133,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("span", {
                                    "aria-hidden": "true",
                                    className: "absolute -right-6 top-1/4 h-1/2 w-24 rounded-full opacity-40 blur-2xl",
                                    style: {
                                        background: 'hsl(42 58% 64% / 0.5)'
                                    }
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 135,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                            lineNumber: 126,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.h2, {
                            initial: {
                                opacity: 0,
                                y: 16
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.5,
                                duration: 0.7
                            },
                            className: "mt-6 text-lg md:text-2xl font-mono text-mist-soft h-8 leading-relaxed",
                            children: /*#__PURE__*/ _jsxDEV(Typewriter, {
                                roles: ROLES
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                lineNumber: 149,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                            lineNumber: 143,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.p, {
                            initial: {
                                opacity: 0,
                                y: 16
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.65,
                                duration: 0.7
                            },
                            className: "mt-6 text-lg text-foreground/80 max-w-2xl mx-auto leading-relaxed font-heading font-normal",
                            children: "Keeping systems reliable, solving complex technical problems, and building practical software across infrastructure, networks, web, and AI."
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                            lineNumber: 153,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.p, {
                            initial: {
                                opacity: 0,
                                y: 12
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.75,
                                duration: 0.7
                            },
                            className: "mt-6 inline-flex items-center gap-2 font-mono text-[11px] md:text-xs tracking-[0.18em] text-gold/70",
                            children: [
                                /*#__PURE__*/ _jsxDEV(Plane, {
                                    className: "h-3.5 w-3.5",
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 171,
                                    columnNumber: 13
                                }, this),
                                mission
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                            lineNumber: 165,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 16
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.8,
                                duration: 0.7
                            },
                            className: "flex flex-col sm:flex-row items-center justify-center gap-4 mt-10",
                            children: [
                                /*#__PURE__*/ _jsxDEV("button", {
                                    onClick: scrollToProjects,
                                    className: "group inline-flex items-center justify-center gap-2 rounded-lg bg-mist px-8 py-3.5 text-sm font-semibold text-storm-deep transition-all duration-300 hover:-translate-y-0.5 hover:shadow-glow-strong",
                                    children: [
                                        "Explore My Work",
                                        /*#__PURE__*/ _jsxDEV(ArrowRight, {
                                            className: "h-4 w-4 group-hover:translate-x-1 transition-transform duration-300"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                            lineNumber: 187,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 182,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("a", {
                                    href: "/Ermias.L_cv.pdf",
                                    download: true,
                                    className: "glass inline-flex items-center justify-center gap-2 rounded-lg px-8 py-3.5 text-sm font-medium text-mist transition-all duration-300 hover:-translate-y-0.5 hover:border-gold/70",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV(Download, {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                            lineNumber: 195,
                                            columnNumber: 15
                                        }, this),
                                        "Download CV"
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 190,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                            lineNumber: 176,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 16
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.95,
                                duration: 0.7
                            },
                            className: "flex items-center justify-center gap-5 pt-10",
                            children: socialLinks.map((social, index)=>/*#__PURE__*/ _jsxDEV(motion.a, {
                                    href: social.href,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "glass flex h-11 w-11 items-center justify-center rounded-full text-mist-soft transition-all duration-300 hover:border-gold/60 hover:text-gold hover:shadow-glow",
                                    initial: {
                                        opacity: 0,
                                        scale: 0.8
                                    },
                                    animate: {
                                        opacity: 1,
                                        scale: 1
                                    },
                                    transition: {
                                        delay: 0.95 + index * 0.08,
                                        duration: 0.5
                                    },
                                    whileHover: {
                                        y: -3
                                    },
                                    whileTap: {
                                        scale: 0.95
                                    },
                                    "aria-label": social.label,
                                    children: /*#__PURE__*/ _jsxDEV(social.icon, {
                                        className: "h-5 w-5"
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                        lineNumber: 221,
                                        columnNumber: 17
                                    }, this)
                                }, social.label, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 208,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                            lineNumber: 201,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                    lineNumber: 110,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV(motion.div, {
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                transition: {
                    delay: 1.6,
                    duration: 1
                },
                className: "absolute bottom-7 left-1/2 -translate-x-1/2 z-10",
                children: /*#__PURE__*/ _jsxDEV(motion.div, {
                    animate: prefersReducedMotion() ? undefined : {
                        y: [
                            0,
                            10,
                            0
                        ]
                    },
                    transition: {
                        duration: 2.4,
                        repeat: Infinity,
                        ease: 'easeInOut'
                    },
                    className: "flex flex-col items-center gap-2.5 text-mist-soft",
                    children: [
                        /*#__PURE__*/ _jsxDEV("span", {
                            className: "text-[11px] font-mono tracking-[0.3em] uppercase",
                            children: "descend to explore"
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                            lineNumber: 241,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "absolute left-1/2 -top-16 h-14 w-10 -translate-x-1/2 bg-gradient-to-t from-mist/15 to-transparent blur-[6px] rounded-full"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 246,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV("div", {
                                    className: "h-9 w-px bg-gradient-to-b from-gold/70 to-transparent rounded-full"
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                                    lineNumber: 247,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                            lineNumber: 245,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                    lineNumber: 236,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
                lineNumber: 230,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx",
        lineNumber: 98,
        columnNumber: 5
    }, this);
};
_s1(Hero, "iLSMaWy9PWqHsxx6xavnzfAdzvw=", false, function() {
    return [
        useScroll,
        useTransform,
        useTransform
    ];
});
_c1 = Hero;
export default Hero;
var _c, _c1;
$RefreshReg$(_c, "Typewriter");
$RefreshReg$(_c1, "Hero");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/sections/Hero.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkhlcm8udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uLCB1c2VTY3JvbGwsIHVzZVRyYW5zZm9ybSB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgQXJyb3dSaWdodCwgRG93bmxvYWQsIEdpdGh1YiwgTWFpbCwgUGxhbmUsIFNlbmQgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5jb25zdCBST0xFUyA9IFtcbiAgJ0lUIFN5c3RlbXMgRW5naW5lZXInLFxuICAnU3lzdGVtcyAmIE5ldHdvcmsgU3BlY2lhbGlzdCcsXG4gICdDb21wdXRlciBFbmdpbmVlcicsXG4gICdUZWNobm9sb2d5IEJ1aWxkZXInLFxuXTtcblxuY29uc3QgcHJlZmVyc1JlZHVjZWRNb3Rpb24gPSAoKSA9PlxuICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJlxuICB3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSknKS5tYXRjaGVzO1xuXG5jb25zdCBUeXBld3JpdGVyID0gKHsgcm9sZXMgfTogeyByb2xlczogc3RyaW5nW10gfSkgPT4ge1xuICBjb25zdCBbcm9sZUluZGV4LCBzZXRSb2xlSW5kZXhdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFt0ZXh0LCBzZXRUZXh0XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2RlbGV0aW5nLCBzZXREZWxldGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAocHJlZmVyc1JlZHVjZWRNb3Rpb24oKSkge1xuICAgICAgc2V0VGV4dChyb2xlc1swXSA/PyAnJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgeyBbcm9sZUluZGV4XTogcm9sZSB9ID0gcm9sZXM7XG4gICAgY29uc3QgY3VycmVudCA9IHJvbGUgPz8gJyc7XG4gICAgY29uc3Qgc3BlZWQgPSBkZWxldGluZyA/IDMwIDogNzA7XG5cbiAgICBsZXQgcGF1c2VUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCBudWxsID0gbnVsbDtcblxuICAgIGNvbnN0IHRpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGlmICghZGVsZXRpbmcpIHtcbiAgICAgICAgY29uc3QgbmV4dCA9IGN1cnJlbnQuc2xpY2UoMCwgdGV4dC5sZW5ndGggKyAxKTtcbiAgICAgICAgc2V0VGV4dChuZXh0KTtcbiAgICAgICAgaWYgKG5leHQgPT09IGN1cnJlbnQpIHtcbiAgICAgICAgICBwYXVzZVRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBzZXREZWxldGluZyh0cnVlKSwgMTUwMCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IG5leHQgPSBjdXJyZW50LnNsaWNlKDAsIHRleHQubGVuZ3RoIC0gMSk7XG4gICAgICAgIHNldFRleHQobmV4dCk7XG4gICAgICAgIGlmIChuZXh0ID09PSAnJykge1xuICAgICAgICAgIHNldERlbGV0aW5nKGZhbHNlKTtcbiAgICAgICAgICBzZXRSb2xlSW5kZXgocHJldiA9PiAocHJldiArIDEpICUgcm9sZXMubGVuZ3RoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sIHNwZWVkKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dCk7XG4gICAgICBpZiAocGF1c2VUaW1lcikgY2xlYXJUaW1lb3V0KHBhdXNlVGltZXIpO1xuICAgIH07XG4gIH0sIFt0ZXh0LCBkZWxldGluZywgcm9sZUluZGV4LCByb2xlc10pO1xuXG4gIHJldHVybiAoXG4gICAgPHNwYW4gY2xhc3NOYW1lPSdpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXInPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPSdnb2xkLXRleHQnPnt0ZXh0fTwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT0nbWwtMSB3LTAuNSBoLTYgbWQ6aC03IGJnLWdvbGQvNzAgYW5pbWF0ZS1wdWxzZScgLz5cbiAgICA8L3NwYW4+XG4gICk7XG59O1xuXG5jb25zdCBNSVNTSU9OX0xJTkVTID0gW1xuICAnSG9sZGluZyBhbHRpdHVkZSBhYm92ZSB0aGUgY2xvdWQgbGF5ZXIgLSBrZWVwaW5nIHN5c3RlbXMgcmVsaWFibGUuJyxcbiAgJ0VuZ2luZWVyaW5nIGNhbG0gYWJvdmUgdGhlIHN0b3JtIC0gaW5mcmFzdHJ1Y3R1cmUsIG5ldHdvcmtzLCBjb2RlLicsXG4gICdTeXN0ZW1zIG9ubGluZS4gQWx0aXR1ZGUgc3RlYWR5LiBCdWlsZGluZyB3aGF0IGxhc3RzLicsXG4gICdDbGltYmluZyB0aHJvdWdoIHRoZSBjbG91ZHMsIG9uZSByZWxpYWJsZSBzeXN0ZW0gYXQgYSB0aW1lLicsXG5dO1xuXG5jb25zdCBIZXJvID0gKCkgPT4ge1xuICBjb25zdCB7IHNjcm9sbFkgfSA9IHVzZVNjcm9sbCgpO1xuXG4gIC8vIE1pc3Npb24gbGluZSBjaG9zZW4gb25jZSBwZXIgdmlzaXRcbiAgY29uc3QgW21pc3Npb25dID0gdXNlU3RhdGUoXG4gICAgKCkgPT5cbiAgICAgIE1JU1NJT05fTElORVNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogTUlTU0lPTl9MSU5FUy5sZW5ndGgpXSA/P1xuICAgICAgTUlTU0lPTl9MSU5FU1swXSA/P1xuICAgICAgJydcbiAgKTtcblxuICAvLyBDb250ZW50IGxpZnRzIGFuZCBmYWRlcyBhcyB5b3UgbGVhdmUgdGhlIGhlcm8gKGNsb3VkcyBhcmUgZ2xvYmFsIOKAlCBDbG91ZEZpZWxkKVxuICBjb25zdCBjb250ZW50WSA9IHVzZVRyYW5zZm9ybShzY3JvbGxZLCBbMCwgNjAwXSwgWzAsIC02MF0pO1xuICBjb25zdCBjb250ZW50T3BhY2l0eSA9IHVzZVRyYW5zZm9ybShzY3JvbGxZLCBbMCwgNTAwXSwgWzEsIDAuMl0pO1xuXG4gIGNvbnN0IHNjcm9sbFRvUHJvamVjdHMgPSAoKSA9PiB7XG4gICAgY29uc3QgZWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwcm9qZWN0cy1wcmV2aWV3Jyk7XG4gICAgZWxlbWVudD8uc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gIH07XG5cbiAgY29uc3Qgc29jaWFsTGlua3MgPSBbXG4gICAgeyBpY29uOiBHaXRodWIsIGhyZWY6ICdodHRwczovL2dpdGh1Yi5jb20vamFIeGlpJywgbGFiZWw6ICdHaXRIdWInIH0sXG4gICAgeyBpY29uOiBTZW5kLCBocmVmOiAnaHR0cHM6Ly90Lm1lL2Nsb3VkeDY5JywgbGFiZWw6ICdUZWxlZ3JhbScgfSxcbiAgICB7IGljb246IE1haWwsIGhyZWY6ICdtYWlsdG86ZXJtaWFzLnhpaUBnbWFpbC5jb20nLCBsYWJlbDogJ0VtYWlsJyB9LFxuICBdO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPSdyZWxhdGl2ZSBtaW4taC1zY3JlZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuIGJnLWF0bW8taGVybyc+XG4gICAgICB7LyogQWlyY3JhZnQtd2luZG93IHZpZ25ldHRlICovfVxuICAgICAgPGRpdlxuICAgICAgICBhcmlhLWhpZGRlbj0ndHJ1ZSdcbiAgICAgICAgY2xhc3NOYW1lPSdoZXJvLXZpZ25ldHRlIHBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgaW5zZXQtMCdcbiAgICAgIC8+XG5cbiAgICAgIHsvKiDilIDilIAgQ29udGVudCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi99XG4gICAgICA8bW90aW9uLmRpdlxuICAgICAgICBzdHlsZT17eyB5OiBjb250ZW50WSwgb3BhY2l0eTogY29udGVudE9wYWNpdHkgfX1cbiAgICAgICAgY2xhc3NOYW1lPSdjb250YWluZXIgbXgtYXV0byBweC00IHJlbGF0aXZlIHotMTAgcHktMzInXG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPSdtYXgtdy00eGwgbXgtYXV0byB0ZXh0LWNlbnRlcic+XG4gICAgICAgICAgey8qIEF2aWF0aW9uIHN0YXR1cyBpbmRpY2F0b3IgKi99XG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMTQgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC4xLCBkdXJhdGlvbjogMC43IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J2dsYXNzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHJvdW5kZWQtZnVsbCBweC01IHB5LTIgZm9udC1tb25vIHRleHQtWzExcHhdIHRyYWNraW5nLVswLjI1ZW1dIHRleHQtbWlzdC1zb2Z0J1xuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0ncmVsYXRpdmUgZmxleCBoLTIgdy0yJz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdhYnNvbHV0ZSBpbmxpbmUtZmxleCBoLWZ1bGwgdy1mdWxsIHJvdW5kZWQtZnVsbCBiZy1nb2xkLzYwIG1vdGlvbi1zYWZlOmFuaW1hdGUtcGluZycgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdyZWxhdGl2ZSBpbmxpbmUtZmxleCBoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1nb2xkJyAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgRVJNSUFTLkxFTUVTQSAvIFNZU1RFTVMgT05MSU5FXG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICAgICAgey8qIE5hbWUgKi99XG4gICAgICAgICAgPG1vdGlvbi5oMVxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAyNCB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjMsIGR1cmF0aW9uOiAwLjkgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT0ncmVsYXRpdmUgbXQtOCB0ZXh0LTV4bCBzbTp0ZXh0LTZ4bCBtZDp0ZXh0LTh4bCBmb250LWJvbGQgZm9udC1oZWFkaW5nIHRyYWNraW5nLXRpZ2h0IGxlYWRpbmctWzEuMDVdJ1xuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nbmFtZS1ncmFkaWVudCc+RXJtaWFzPC9zcGFuPnsnICd9XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J25hbWUtZ3JhZGllbnQnPkxlbWVzYTwvc3Bhbj5cbiAgICAgICAgICAgIHsvKiBzdWJ0bGUgZ29sZGVuIGxpZ2h0IGJsZWVkaW5nIGFjcm9zcyBvbmUgZWRnZSAqL31cbiAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgIGFyaWEtaGlkZGVuPSd0cnVlJ1xuICAgICAgICAgICAgICBjbGFzc05hbWU9J2Fic29sdXRlIC1yaWdodC02IHRvcC0xLzQgaC0xLzIgdy0yNCByb3VuZGVkLWZ1bGwgb3BhY2l0eS00MCBibHVyLTJ4bCdcbiAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogJ2hzbCg0MiA1OCUgNjQlIC8gMC41KScgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9tb3Rpb24uaDE+XG5cbiAgICAgICAgICB7LyogUm90YXRpbmcgdGl0bGUgKi99XG4gICAgICAgICAgPG1vdGlvbi5oMlxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAxNiB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjUsIGR1cmF0aW9uOiAwLjcgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT0nbXQtNiB0ZXh0LWxnIG1kOnRleHQtMnhsIGZvbnQtbW9ubyB0ZXh0LW1pc3Qtc29mdCBoLTggbGVhZGluZy1yZWxheGVkJ1xuICAgICAgICAgID5cbiAgICAgICAgICAgIDxUeXBld3JpdGVyIHJvbGVzPXtST0xFU30gLz5cbiAgICAgICAgICA8L21vdGlvbi5oMj5cblxuICAgICAgICAgIHsvKiBQb3NpdGlvbmluZyBzdGF0ZW1lbnQgKi99XG4gICAgICAgICAgPG1vdGlvbi5wXG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDE2IH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuNjUsIGR1cmF0aW9uOiAwLjcgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT0nbXQtNiB0ZXh0LWxnIHRleHQtZm9yZWdyb3VuZC84MCBtYXgtdy0yeGwgbXgtYXV0byBsZWFkaW5nLXJlbGF4ZWQgZm9udC1oZWFkaW5nIGZvbnQtbm9ybWFsJ1xuICAgICAgICAgID5cbiAgICAgICAgICAgIEtlZXBpbmcgc3lzdGVtcyByZWxpYWJsZSwgc29sdmluZyBjb21wbGV4IHRlY2huaWNhbCBwcm9ibGVtcywgYW5kXG4gICAgICAgICAgICBidWlsZGluZyBwcmFjdGljYWwgc29mdHdhcmUgYWNyb3NzIGluZnJhc3RydWN0dXJlLCBuZXR3b3Jrcywgd2ViLFxuICAgICAgICAgICAgYW5kIEFJLlxuICAgICAgICAgIDwvbW90aW9uLnA+XG5cbiAgICAgICAgICB7LyogTWlzc2lvbiBsaW5lIOKAlCBvbmUgcGVyIHZpc2l0ICovfVxuICAgICAgICAgIDxtb3Rpb24ucFxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAxMiB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjc1LCBkdXJhdGlvbjogMC43IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J210LTYgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XSBtZDp0ZXh0LXhzIHRyYWNraW5nLVswLjE4ZW1dIHRleHQtZ29sZC83MCdcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8UGxhbmUgY2xhc3NOYW1lPSdoLTMuNSB3LTMuNScgYXJpYS1oaWRkZW49J3RydWUnIC8+XG4gICAgICAgICAgICB7bWlzc2lvbn1cbiAgICAgICAgICA8L21vdGlvbi5wPlxuXG4gICAgICAgICAgey8qIENUQXMgKi99XG4gICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMTYgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC44LCBkdXJhdGlvbjogMC43IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J2ZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC00IG10LTEwJ1xuICAgICAgICAgID5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17c2Nyb2xsVG9Qcm9qZWN0c31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSdncm91cCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcm91bmRlZC1sZyBiZy1taXN0IHB4LTggcHktMy41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXN0b3JtLWRlZXAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6c2hhZG93LWdsb3ctc3Ryb25nJ1xuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBFeHBsb3JlIE15IFdvcmtcbiAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPSdoLTQgdy00IGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwJyAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9Jy9Fcm1pYXMuTF9jdi5wZGYnXG4gICAgICAgICAgICAgIGRvd25sb2FkXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT0nZ2xhc3MgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJvdW5kZWQtbGcgcHgtOCBweS0zLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LW1pc3QgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6Ym9yZGVyLWdvbGQvNzAnXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9J2gtNCB3LTQnIC8+XG4gICAgICAgICAgICAgIERvd25sb2FkIENWXG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICAgICAgey8qIFNvY2lhbCBsaW5rcyAqL31cbiAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAxNiB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjk1LCBkdXJhdGlvbjogMC43IH19XG4gICAgICAgICAgICBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC01IHB0LTEwJ1xuICAgICAgICAgID5cbiAgICAgICAgICAgIHtzb2NpYWxMaW5rcy5tYXAoKHNvY2lhbCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgPG1vdGlvbi5hXG4gICAgICAgICAgICAgICAga2V5PXtzb2NpYWwubGFiZWx9XG4gICAgICAgICAgICAgICAgaHJlZj17c29jaWFsLmhyZWZ9XG4gICAgICAgICAgICAgICAgdGFyZ2V0PSdfYmxhbmsnXG4gICAgICAgICAgICAgICAgcmVsPSdub29wZW5lciBub3JlZmVycmVyJ1xuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT0nZ2xhc3MgZmxleCBoLTExIHctMTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCB0ZXh0LW1pc3Qtc29mdCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgaG92ZXI6Ym9yZGVyLWdvbGQvNjAgaG92ZXI6dGV4dC1nb2xkIGhvdmVyOnNoYWRvdy1nbG93J1xuICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgc2NhbGU6IDAuOCB9fVxuICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgc2NhbGU6IDEgfX1cbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjk1ICsgaW5kZXggKiAwLjA4LCBkdXJhdGlvbjogMC41IH19XG4gICAgICAgICAgICAgICAgd2hpbGVIb3Zlcj17eyB5OiAtMyB9fVxuICAgICAgICAgICAgICAgIHdoaWxlVGFwPXt7IHNjYWxlOiAwLjk1IH19XG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17c29jaWFsLmxhYmVsfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNvY2lhbC5pY29uIGNsYXNzTmFtZT0naC01IHctNScgLz5cbiAgICAgICAgICAgICAgPC9tb3Rpb24uYT5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgey8qIFNjcm9sbCBpbmRpY2F0b3IgKi99XG4gICAgICA8bW90aW9uLmRpdlxuICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAgfX1cbiAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxIH19XG4gICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDEuNiwgZHVyYXRpb246IDEgfX1cbiAgICAgICAgY2xhc3NOYW1lPSdhYnNvbHV0ZSBib3R0b20tNyBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIHotMTAnXG4gICAgICA+XG4gICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgYW5pbWF0ZT17cHJlZmVyc1JlZHVjZWRNb3Rpb24oKSA/IHVuZGVmaW5lZCA6IHsgeTogWzAsIDEwLCAwXSB9fVxuICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDIuNCwgcmVwZWF0OiBJbmZpbml0eSwgZWFzZTogJ2Vhc2VJbk91dCcgfX1cbiAgICAgICAgICBjbGFzc05hbWU9J2ZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0yLjUgdGV4dC1taXN0LXNvZnQnXG4gICAgICAgID5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J3RleHQtWzExcHhdIGZvbnQtbW9ubyB0cmFja2luZy1bMC4zZW1dIHVwcGVyY2FzZSc+XG4gICAgICAgICAgICBkZXNjZW5kIHRvIGV4cGxvcmVcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgey8qIENvbnRyYWlsZWQgYmVhbSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncmVsYXRpdmUnPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Fic29sdXRlIGxlZnQtMS8yIC10b3AtMTYgaC0xNCB3LTEwIC10cmFuc2xhdGUteC0xLzIgYmctZ3JhZGllbnQtdG8tdCBmcm9tLW1pc3QvMTUgdG8tdHJhbnNwYXJlbnQgYmx1ci1bNnB4XSByb3VuZGVkLWZ1bGwnIC8+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0naC05IHctcHggYmctZ3JhZGllbnQtdG8tYiBmcm9tLWdvbGQvNzAgdG8tdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsJyAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICA8L21vdGlvbi5kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgSGVybztcbiJdLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwibW90aW9uIiwidXNlU2Nyb2xsIiwidXNlVHJhbnNmb3JtIiwiQXJyb3dSaWdodCIsIkRvd25sb2FkIiwiR2l0aHViIiwiTWFpbCIsIlBsYW5lIiwiU2VuZCIsIlJPTEVTIiwicHJlZmVyc1JlZHVjZWRNb3Rpb24iLCJ3aW5kb3ciLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsIlR5cGV3cml0ZXIiLCJyb2xlcyIsInJvbGVJbmRleCIsInNldFJvbGVJbmRleCIsInRleHQiLCJzZXRUZXh0IiwiZGVsZXRpbmciLCJzZXREZWxldGluZyIsInJvbGUiLCJjdXJyZW50Iiwic3BlZWQiLCJwYXVzZVRpbWVyIiwidGltZW91dCIsInNldFRpbWVvdXQiLCJuZXh0Iiwic2xpY2UiLCJsZW5ndGgiLCJwcmV2IiwiY2xlYXJUaW1lb3V0Iiwic3BhbiIsImNsYXNzTmFtZSIsIk1JU1NJT05fTElORVMiLCJIZXJvIiwic2Nyb2xsWSIsIm1pc3Npb24iLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJjb250ZW50WSIsImNvbnRlbnRPcGFjaXR5Iiwic2Nyb2xsVG9Qcm9qZWN0cyIsImVsZW1lbnQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwic2Nyb2xsSW50b1ZpZXciLCJiZWhhdmlvciIsInNvY2lhbExpbmtzIiwiaWNvbiIsImhyZWYiLCJsYWJlbCIsInNlY3Rpb24iLCJkaXYiLCJhcmlhLWhpZGRlbiIsInN0eWxlIiwieSIsIm9wYWNpdHkiLCJpbml0aWFsIiwiYW5pbWF0ZSIsInRyYW5zaXRpb24iLCJkZWxheSIsImR1cmF0aW9uIiwiaDEiLCJiYWNrZ3JvdW5kIiwiaDIiLCJwIiwiYnV0dG9uIiwib25DbGljayIsImEiLCJkb3dubG9hZCIsIm1hcCIsInNvY2lhbCIsImluZGV4IiwidGFyZ2V0IiwicmVsIiwic2NhbGUiLCJ3aGlsZUhvdmVyIiwid2hpbGVUYXAiLCJhcmlhLWxhYmVsIiwidW5kZWZpbmVkIiwicmVwZWF0IiwiSW5maW5pdHkiLCJlYXNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsU0FBU0MsU0FBUyxFQUFFQyxRQUFRLFFBQVEsUUFBUTtBQUNuRCxTQUFTQyxNQUFNLEVBQUVDLFNBQVMsRUFBRUMsWUFBWSxRQUFRLGdCQUFnQjtBQUNoRSxTQUFTQyxVQUFVLEVBQUVDLFFBQVEsRUFBRUMsTUFBTSxFQUFFQyxJQUFJLEVBQUVDLEtBQUssRUFBRUMsSUFBSSxRQUFRLGVBQWU7QUFFL0UsTUFBTUMsUUFBUTtJQUNaO0lBQ0E7SUFDQTtJQUNBO0NBQ0Q7QUFFRCxNQUFNQyx1QkFBdUIsSUFDM0IsT0FBT0MsV0FBVyxlQUNsQkEsT0FBT0MsVUFBVSxDQUFDLG9DQUFvQ0MsT0FBTztBQUUvRCxNQUFNQyxhQUFhLENBQUMsRUFBRUMsS0FBSyxFQUF1Qjs7SUFDaEQsTUFBTSxDQUFDQyxXQUFXQyxhQUFhLEdBQUdsQixTQUFTO0lBQzNDLE1BQU0sQ0FBQ21CLE1BQU1DLFFBQVEsR0FBR3BCLFNBQVM7SUFDakMsTUFBTSxDQUFDcUIsVUFBVUMsWUFBWSxHQUFHdEIsU0FBUztJQUV6Q0QsVUFBVTtRQUNSLElBQUlZLHdCQUF3QjtZQUMxQlMsUUFBUUosS0FBSyxDQUFDLEVBQUUsSUFBSTtZQUNwQjtRQUNGO1FBRUEsTUFBTSxFQUFFLENBQUNDLFVBQVUsRUFBRU0sSUFBSSxFQUFFLEdBQUdQO1FBQzlCLE1BQU1RLFVBQVVELFFBQVE7UUFDeEIsTUFBTUUsUUFBUUosV0FBVyxLQUFLO1FBRTlCLElBQUlLLGFBQW1EO1FBRXZELE1BQU1DLFVBQVVDLFdBQVc7WUFDekIsSUFBSSxDQUFDUCxVQUFVO2dCQUNiLE1BQU1RLE9BQU9MLFFBQVFNLEtBQUssQ0FBQyxHQUFHWCxLQUFLWSxNQUFNLEdBQUc7Z0JBQzVDWCxRQUFRUztnQkFDUixJQUFJQSxTQUFTTCxTQUFTO29CQUNwQkUsYUFBYUUsV0FBVyxJQUFNTixZQUFZLE9BQU87Z0JBQ25EO1lBQ0YsT0FBTztnQkFDTCxNQUFNTyxPQUFPTCxRQUFRTSxLQUFLLENBQUMsR0FBR1gsS0FBS1ksTUFBTSxHQUFHO2dCQUM1Q1gsUUFBUVM7Z0JBQ1IsSUFBSUEsU0FBUyxJQUFJO29CQUNmUCxZQUFZO29CQUNaSixhQUFhYyxDQUFBQSxPQUFRLEFBQUNBLENBQUFBLE9BQU8sQ0FBQSxJQUFLaEIsTUFBTWUsTUFBTTtnQkFDaEQ7WUFDRjtRQUNGLEdBQUdOO1FBRUgsT0FBTztZQUNMUSxhQUFhTjtZQUNiLElBQUlELFlBQVlPLGFBQWFQO1FBQy9CO0lBQ0YsR0FBRztRQUFDUDtRQUFNRTtRQUFVSjtRQUFXRDtLQUFNO0lBRXJDLHFCQUNFLFFBQUNrQjtRQUFLQyxXQUFVOzswQkFDZCxRQUFDRDtnQkFBS0MsV0FBVTswQkFBYWhCOzs7Ozs7MEJBQzdCLFFBQUNlO2dCQUFLQyxXQUFVOzs7Ozs7Ozs7Ozs7QUFHdEI7R0E5Q01wQjtLQUFBQTtBQWdETixNQUFNcUIsZ0JBQWdCO0lBQ3BCO0lBQ0E7SUFDQTtJQUNBO0NBQ0Q7QUFFRCxNQUFNQyxPQUFPOztJQUNYLE1BQU0sRUFBRUMsT0FBTyxFQUFFLEdBQUdwQztJQUVwQixxQ0FBcUM7SUFDckMsTUFBTSxDQUFDcUMsUUFBUSxHQUFHdkMsU0FDaEIsSUFDRW9DLGFBQWEsQ0FBQ0ksS0FBS0MsS0FBSyxDQUFDRCxLQUFLRSxNQUFNLEtBQUtOLGNBQWNMLE1BQU0sRUFBRSxJQUMvREssYUFBYSxDQUFDLEVBQUUsSUFDaEI7SUFHSixpRkFBaUY7SUFDakYsTUFBTU8sV0FBV3hDLGFBQWFtQyxTQUFTO1FBQUM7UUFBRztLQUFJLEVBQUU7UUFBQztRQUFHLENBQUM7S0FBRztJQUN6RCxNQUFNTSxpQkFBaUJ6QyxhQUFhbUMsU0FBUztRQUFDO1FBQUc7S0FBSSxFQUFFO1FBQUM7UUFBRztLQUFJO0lBRS9ELE1BQU1PLG1CQUFtQjtRQUN2QixNQUFNQyxVQUFVQyxTQUFTQyxjQUFjLENBQUM7UUFDeENGLFNBQVNHLGVBQWU7WUFBRUMsVUFBVTtRQUFTO0lBQy9DO0lBRUEsTUFBTUMsY0FBYztRQUNsQjtZQUFFQyxNQUFNOUM7WUFBUStDLE1BQU07WUFBNkJDLE9BQU87UUFBUztRQUNuRTtZQUFFRixNQUFNM0M7WUFBTTRDLE1BQU07WUFBeUJDLE9BQU87UUFBVztRQUMvRDtZQUFFRixNQUFNN0M7WUFBTThDLE1BQU07WUFBK0JDLE9BQU87UUFBUTtLQUNuRTtJQUVELHFCQUNFLFFBQUNDO1FBQVFwQixXQUFVOzswQkFFakIsUUFBQ3FCO2dCQUNDQyxlQUFZO2dCQUNadEIsV0FBVTs7Ozs7OzBCQUlaLFFBQUNsQyxPQUFPdUQsR0FBRztnQkFDVEUsT0FBTztvQkFBRUMsR0FBR2hCO29CQUFVaUIsU0FBU2hCO2dCQUFlO2dCQUM5Q1QsV0FBVTswQkFFVixjQUFBLFFBQUNxQjtvQkFBSXJCLFdBQVU7O3NDQUViLFFBQUNsQyxPQUFPdUQsR0FBRzs0QkFDVEssU0FBUztnQ0FBRUQsU0FBUztnQ0FBR0QsR0FBRzs0QkFBRzs0QkFDN0JHLFNBQVM7Z0NBQUVGLFNBQVM7Z0NBQUdELEdBQUc7NEJBQUU7NEJBQzVCSSxZQUFZO2dDQUFFQyxPQUFPO2dDQUFLQyxVQUFVOzRCQUFJOzRCQUN4QzlCLFdBQVU7OzhDQUVWLFFBQUNEO29DQUFLQyxXQUFVOztzREFDZCxRQUFDRDs0Q0FBS0MsV0FBVTs7Ozs7O3NEQUNoQixRQUFDRDs0Q0FBS0MsV0FBVTs7Ozs7Ozs7Ozs7O2dDQUNYOzs7Ozs7O3NDQUtULFFBQUNsQyxPQUFPaUUsRUFBRTs0QkFDUkwsU0FBUztnQ0FBRUQsU0FBUztnQ0FBR0QsR0FBRzs0QkFBRzs0QkFDN0JHLFNBQVM7Z0NBQUVGLFNBQVM7Z0NBQUdELEdBQUc7NEJBQUU7NEJBQzVCSSxZQUFZO2dDQUFFQyxPQUFPO2dDQUFLQyxVQUFVOzRCQUFJOzRCQUN4QzlCLFdBQVU7OzhDQUVWLFFBQUNEO29DQUFLQyxXQUFVOzhDQUFnQjs7Ozs7O2dDQUFjOzhDQUM5QyxRQUFDRDtvQ0FBS0MsV0FBVTs4Q0FBZ0I7Ozs7Ozs4Q0FFaEMsUUFBQ0Q7b0NBQ0N1QixlQUFZO29DQUNadEIsV0FBVTtvQ0FDVnVCLE9BQU87d0NBQUVTLFlBQVk7b0NBQXdCOzs7Ozs7Ozs7Ozs7c0NBS2pELFFBQUNsRSxPQUFPbUUsRUFBRTs0QkFDUlAsU0FBUztnQ0FBRUQsU0FBUztnQ0FBR0QsR0FBRzs0QkFBRzs0QkFDN0JHLFNBQVM7Z0NBQUVGLFNBQVM7Z0NBQUdELEdBQUc7NEJBQUU7NEJBQzVCSSxZQUFZO2dDQUFFQyxPQUFPO2dDQUFLQyxVQUFVOzRCQUFJOzRCQUN4QzlCLFdBQVU7c0NBRVYsY0FBQSxRQUFDcEI7Z0NBQVdDLE9BQU9OOzs7Ozs7Ozs7OztzQ0FJckIsUUFBQ1QsT0FBT29FLENBQUM7NEJBQ1BSLFNBQVM7Z0NBQUVELFNBQVM7Z0NBQUdELEdBQUc7NEJBQUc7NEJBQzdCRyxTQUFTO2dDQUFFRixTQUFTO2dDQUFHRCxHQUFHOzRCQUFFOzRCQUM1QkksWUFBWTtnQ0FBRUMsT0FBTztnQ0FBTUMsVUFBVTs0QkFBSTs0QkFDekM5QixXQUFVO3NDQUNYOzs7Ozs7c0NBT0QsUUFBQ2xDLE9BQU9vRSxDQUFDOzRCQUNQUixTQUFTO2dDQUFFRCxTQUFTO2dDQUFHRCxHQUFHOzRCQUFHOzRCQUM3QkcsU0FBUztnQ0FBRUYsU0FBUztnQ0FBR0QsR0FBRzs0QkFBRTs0QkFDNUJJLFlBQVk7Z0NBQUVDLE9BQU87Z0NBQU1DLFVBQVU7NEJBQUk7NEJBQ3pDOUIsV0FBVTs7OENBRVYsUUFBQzNCO29DQUFNMkIsV0FBVTtvQ0FBY3NCLGVBQVk7Ozs7OztnQ0FDMUNsQjs7Ozs7OztzQ0FJSCxRQUFDdEMsT0FBT3VELEdBQUc7NEJBQ1RLLFNBQVM7Z0NBQUVELFNBQVM7Z0NBQUdELEdBQUc7NEJBQUc7NEJBQzdCRyxTQUFTO2dDQUFFRixTQUFTO2dDQUFHRCxHQUFHOzRCQUFFOzRCQUM1QkksWUFBWTtnQ0FBRUMsT0FBTztnQ0FBS0MsVUFBVTs0QkFBSTs0QkFDeEM5QixXQUFVOzs4Q0FFVixRQUFDbUM7b0NBQ0NDLFNBQVMxQjtvQ0FDVFYsV0FBVTs7d0NBQ1g7c0RBRUMsUUFBQy9COzRDQUFXK0IsV0FBVTs7Ozs7Ozs7Ozs7OzhDQUd4QixRQUFDcUM7b0NBQ0NuQixNQUFLO29DQUNMb0IsUUFBUTtvQ0FDUnRDLFdBQVU7O3NEQUVWLFFBQUM5Qjs0Q0FBUzhCLFdBQVU7Ozs7Ozt3Q0FBWTs7Ozs7Ozs7Ozs7OztzQ0FNcEMsUUFBQ2xDLE9BQU91RCxHQUFHOzRCQUNUSyxTQUFTO2dDQUFFRCxTQUFTO2dDQUFHRCxHQUFHOzRCQUFHOzRCQUM3QkcsU0FBUztnQ0FBRUYsU0FBUztnQ0FBR0QsR0FBRzs0QkFBRTs0QkFDNUJJLFlBQVk7Z0NBQUVDLE9BQU87Z0NBQU1DLFVBQVU7NEJBQUk7NEJBQ3pDOUIsV0FBVTtzQ0FFVGdCLFlBQVl1QixHQUFHLENBQUMsQ0FBQ0MsUUFBUUMsc0JBQ3hCLFFBQUMzRSxPQUFPdUUsQ0FBQztvQ0FFUG5CLE1BQU1zQixPQUFPdEIsSUFBSTtvQ0FDakJ3QixRQUFPO29DQUNQQyxLQUFJO29DQUNKM0MsV0FBVTtvQ0FDVjBCLFNBQVM7d0NBQUVELFNBQVM7d0NBQUdtQixPQUFPO29DQUFJO29DQUNsQ2pCLFNBQVM7d0NBQUVGLFNBQVM7d0NBQUdtQixPQUFPO29DQUFFO29DQUNoQ2hCLFlBQVk7d0NBQUVDLE9BQU8sT0FBT1ksUUFBUTt3Q0FBTVgsVUFBVTtvQ0FBSTtvQ0FDeERlLFlBQVk7d0NBQUVyQixHQUFHLENBQUM7b0NBQUU7b0NBQ3BCc0IsVUFBVTt3Q0FBRUYsT0FBTztvQ0FBSztvQ0FDeEJHLGNBQVlQLE9BQU9yQixLQUFLOzhDQUV4QixjQUFBLFFBQUNxQixPQUFPdkIsSUFBSTt3Q0FBQ2pCLFdBQVU7Ozs7OzttQ0FabEJ3QyxPQUFPckIsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBCQXFCM0IsUUFBQ3JELE9BQU91RCxHQUFHO2dCQUNUSyxTQUFTO29CQUFFRCxTQUFTO2dCQUFFO2dCQUN0QkUsU0FBUztvQkFBRUYsU0FBUztnQkFBRTtnQkFDdEJHLFlBQVk7b0JBQUVDLE9BQU87b0JBQUtDLFVBQVU7Z0JBQUU7Z0JBQ3RDOUIsV0FBVTswQkFFVixjQUFBLFFBQUNsQyxPQUFPdUQsR0FBRztvQkFDVE0sU0FBU25ELHlCQUF5QndFLFlBQVk7d0JBQUV4QixHQUFHOzRCQUFDOzRCQUFHOzRCQUFJO3lCQUFFO29CQUFDO29CQUM5REksWUFBWTt3QkFBRUUsVUFBVTt3QkFBS21CLFFBQVFDO3dCQUFVQyxNQUFNO29CQUFZO29CQUNqRW5ELFdBQVU7O3NDQUVWLFFBQUNEOzRCQUFLQyxXQUFVO3NDQUFtRDs7Ozs7O3NDQUluRSxRQUFDcUI7NEJBQUlyQixXQUFVOzs4Q0FDYixRQUFDcUI7b0NBQUlyQixXQUFVOzs7Ozs7OENBQ2YsUUFBQ3FCO29DQUFJckIsV0FBVTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFNM0I7SUF0TE1FOztRQUNnQm5DO1FBV0hDO1FBQ01BOzs7TUFibkJrQztBQXdMTixlQUFlQSxLQUFLIn0=