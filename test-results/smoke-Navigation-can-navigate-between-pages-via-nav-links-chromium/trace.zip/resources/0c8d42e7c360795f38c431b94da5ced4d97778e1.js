import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sections/About.tsx");if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/Projects/Portfolio-Web/src/components/sections/About.tsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import * as RefreshRuntime from "/@react-refresh";

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e72f996b"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s1 = $RefreshSig$();
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=e72f996b"; const React = __vite__cjsImport2_react.__esModule ? __vite__cjsImport2_react.default : __vite__cjsImport2_react; const useEffect = __vite__cjsImport2_react["useEffect"]; const useState = __vite__cjsImport2_react["useState"];
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=e72f996b";
import { useInView } from "/node_modules/.vite/deps/react-intersection-observer.js?v=e72f996b";
import { GraduationCap, Award, MapPin } from "/node_modules/.vite/deps/lucide-react.js?v=e72f996b";
import Atmosphere from "/src/components/atmosphere/Atmosphere.tsx";
import { cn } from "/src/lib/utils.ts";
const CountUp = ({ target, suffix = '' })=>{
    _s();
    const [value, setValue] = useState(0);
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.5
    });
    useEffect(()=>{
        if (!inView) return;
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            setValue(target);
            return;
        }
        const duration = 1200;
        const start = performance.now();
        let raf = 0;
        const tick = (now)=>{
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setValue(Math.round(eased * target));
            if (progress < 1) raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
        return ()=>cancelAnimationFrame(raf);
    }, [
        inView,
        target
    ]);
    return /*#__PURE__*/ _jsxDEV("span", {
        ref: ref,
        className: "text-3xl md:text-4xl font-bold font-heading gold-text",
        children: [
            value,
            suffix
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
};
_s(CountUp, "OmC1TI7/vIN/URCt8T0SztszC1c=", false, function() {
    return [
        useInView
    ];
});
_c = CountUp;
const stats = [
    {
        label: 'Systems Kept Running',
        target: 500,
        suffix: '+'
    },
    {
        label: 'Tickets Resolved',
        target: 1000,
        suffix: '+'
    },
    {
        label: 'Projects Built',
        target: 6,
        suffix: ''
    },
    {
        label: 'Years in IT',
        target: 3,
        suffix: '+'
    }
];
const disciplines = [
    {
        code: 'SYS',
        title: 'Systems',
        description: 'Windows & Linux administration, hardware, troubleshooting.'
    },
    {
        code: 'NET',
        title: 'Network',
        description: 'VPN, Wi-Fi, sharing, and multi-floor network diagnostics.'
    },
    {
        code: 'DEV',
        title: 'Development',
        description: 'Python, React, TypeScript, SQL, and automation tooling.'
    },
    {
        code: 'ML',
        title: 'AI/ML',
        description: 'Data pipelines, model training, and chatbot deployment.'
    }
];
const achievements = [
    {
        icon: GraduationCap,
        text: 'B.Sc Computer Engineering - University of Gondar (CGPA: 3.42/4.0)'
    },
    {
        icon: Award,
        text: 'AI/ML Intern at Ethiopian Artificial Intelligence Institute (EAII)'
    },
    {
        icon: MapPin,
        text: 'Senior IT Support at ROTECH Information Technology, Addis Ababa'
    }
];
const About = ()=>{
    _s1();
    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1
    });
    return /*#__PURE__*/ _jsxDEV("section", {
        id: "about",
        className: "relative py-28 overflow-hidden",
        children: [
            /*#__PURE__*/ _jsxDEV(Atmosphere, {
                variant: "mist"
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                lineNumber: 103,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "relative z-10 container mx-auto px-4",
                children: /*#__PURE__*/ _jsxDEV(motion.div, {
                    ref: ref,
                    initial: {
                        opacity: 0,
                        y: 40
                    },
                    animate: inView ? {
                        opacity: 1,
                        y: 0
                    } : {},
                    transition: {
                        duration: 0.8
                    },
                    className: "max-w-6xl mx-auto",
                    children: [
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "mb-16",
                            children: [
                                /*#__PURE__*/ _jsxDEV(motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 20
                                    },
                                    animate: inView ? {
                                        opacity: 1,
                                        y: 0
                                    } : {},
                                    transition: {
                                        delay: 0.2,
                                        duration: 0.6
                                    },
                                    className: "flex items-center gap-4 mb-5",
                                    children: [
                                        /*#__PURE__*/ _jsxDEV("span", {
                                            className: "font-mono text-xs tracking-[0.3em] gold-text",
                                            children: "01 /"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                            lineNumber: 120,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("h2", {
                                            className: "text-3xl md:text-4xl font-bold font-heading tracking-tight",
                                            children: [
                                                "About ",
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "gold-text",
                                                    children: "Me"
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                    lineNumber: 124,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                            lineNumber: 123,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ _jsxDEV("div", {
                                            className: "hidden md:block h-px flex-1 alt-rule"
                                        }, void 0, false, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                            lineNumber: 126,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                    lineNumber: 114,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV(motion.p, {
                                    initial: {
                                        opacity: 0,
                                        y: 20
                                    },
                                    animate: inView ? {
                                        opacity: 1,
                                        y: 0
                                    } : {},
                                    transition: {
                                        delay: 0.3,
                                        duration: 0.6
                                    },
                                    className: "max-w-2xl text-lg text-mist-soft leading-relaxed font-light",
                                    children: "Computer Engineering graduate and Senior IT Support specialist, keeping enterprise systems reliable from hardware and networking to helpdesk automation."
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                    lineNumber: 128,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                            lineNumber: 113,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "grid lg:grid-cols-5 gap-6 mb-10",
                            children: [
                                /*#__PURE__*/ _jsxDEV(motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: inView ? {
                                        opacity: 1,
                                        y: 0
                                    } : {},
                                    transition: {
                                        delay: 0.35,
                                        duration: 0.6
                                    },
                                    className: "lg:col-span-3",
                                    children: /*#__PURE__*/ _jsxDEV("div", {
                                        className: "glass-cloud rounded-xl p-8 h-full space-y-5",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                className: "text-lg text-foreground/90 leading-relaxed font-heading font-normal",
                                                children: "I combine practical IT infrastructure skills with software development - building tools like the MESOB helpdesk ticketing system and rental management platforms that solve real operational problems."
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                lineNumber: 150,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                className: "text-lg text-foreground/80 leading-relaxed font-heading font-normal",
                                                children: "From diagnosing network faults in multi-floor offices to training machine learning models, I work across the full technology stack with a calm, engineering mindset."
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                lineNumber: 156,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("div", {
                                                className: "flex items-center gap-3 pt-2",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                        className: "font-mono text-xs tracking-[0.25em] text-mist-soft/70",
                                                        children: "STATUS"
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                        lineNumber: 162,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                        className: "h-px flex-1 bg-border"
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                        lineNumber: 165,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                        className: "font-mono text-xs text-gold",
                                                        children: "OPEN TO OPPORTUNITIES"
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                        lineNumber: 166,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                lineNumber: 161,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                        lineNumber: 149,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                    lineNumber: 143,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ _jsxDEV(motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: inView ? {
                                        opacity: 1,
                                        y: 0
                                    } : {},
                                    transition: {
                                        delay: 0.45,
                                        duration: 0.6
                                    },
                                    className: "lg:col-span-2 grid gap-4",
                                    children: disciplines.map((d, index)=>/*#__PURE__*/ _jsxDEV(motion.div, {
                                            initial: {
                                                opacity: 0,
                                                x: 20
                                            },
                                            animate: inView ? {
                                                opacity: 1,
                                                x: 0
                                            } : {},
                                            transition: {
                                                delay: 0.5 + index * 0.1,
                                                duration: 0.5
                                            },
                                            className: "glass rounded-xl p-5 flex items-start gap-4",
                                            children: [
                                                /*#__PURE__*/ _jsxDEV("span", {
                                                    className: "font-mono text-xs gold-text pt-0.5",
                                                    children: d.code
                                                }, void 0, false, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                    lineNumber: 188,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ _jsxDEV("div", {
                                                    children: [
                                                        /*#__PURE__*/ _jsxDEV("h3", {
                                                            className: "font-heading font-semibold text-sm uppercase tracking-wider text-foreground",
                                                            children: d.title
                                                        }, void 0, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                            lineNumber: 192,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ _jsxDEV("p", {
                                                            className: "text-sm text-mist-soft mt-1 leading-relaxed",
                                                            children: d.description
                                                        }, void 0, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                            lineNumber: 195,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                    lineNumber: 191,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, d.code, true, {
                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                            lineNumber: 181,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                    lineNumber: 174,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                            lineNumber: 141,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: inView ? {
                                opacity: 1,
                                y: 0
                            } : {},
                            transition: {
                                delay: 0.7,
                                duration: 0.6
                            },
                            className: "mb-10",
                            children: /*#__PURE__*/ _jsxDEV("div", {
                                className: "glass-cloud rounded-xl p-8",
                                children: [
                                    /*#__PURE__*/ _jsxDEV("h3", {
                                        className: "font-heading font-semibold text-lg mb-6 flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ _jsxDEV("span", {
                                                className: "font-mono text-xs tracking-[0.3em] gold-text",
                                                children: "LOG"
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                lineNumber: 213,
                                                columnNumber: 17
                                            }, this),
                                            "Key Achievements"
                                        ]
                                    }, void 0, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                        lineNumber: 212,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("div", {
                                        className: "grid md:grid-cols-3 gap-4",
                                        children: achievements.map((achievement, index)=>/*#__PURE__*/ _jsxDEV(motion.div, {
                                                initial: {
                                                    opacity: 0,
                                                    y: 20
                                                },
                                                animate: inView ? {
                                                    opacity: 1,
                                                    y: 0
                                                } : {},
                                                transition: {
                                                    delay: 0.8 + index * 0.1,
                                                    duration: 0.5
                                                },
                                                className: "flex items-start gap-3 p-4 rounded-lg border border-border/70 hover:border-gold/40 transition-colors duration-300",
                                                children: [
                                                    /*#__PURE__*/ _jsxDEV("div", {
                                                        className: "p-2 bg-gold/10 rounded-lg shrink-0",
                                                        children: /*#__PURE__*/ _jsxDEV(achievement.icon, {
                                                            className: "h-5 w-5 gold-text"
                                                        }, void 0, false, {
                                                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                            lineNumber: 228,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                        lineNumber: 227,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ _jsxDEV("span", {
                                                        className: "text-sm text-foreground/85 leading-relaxed",
                                                        children: achievement.text
                                                    }, void 0, false, {
                                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                        lineNumber: 230,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, achievement.text, true, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                lineNumber: 220,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                        lineNumber: 218,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                lineNumber: 211,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                            lineNumber: 205,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ _jsxDEV(motion.div, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: inView ? {
                                opacity: 1,
                                y: 0
                            } : {},
                            transition: {
                                delay: 0.9,
                                duration: 0.6
                            },
                            children: /*#__PURE__*/ _jsxDEV("div", {
                                className: "grid grid-cols-2 md:grid-cols-4 gap-4",
                                children: stats.map((stat, index)=>/*#__PURE__*/ _jsxDEV(motion.div, {
                                        initial: {
                                            opacity: 0,
                                            y: 20
                                        },
                                        animate: inView ? {
                                            opacity: 1,
                                            y: 0
                                        } : {},
                                        transition: {
                                            delay: 1.0 + index * 0.08,
                                            duration: 0.5
                                        },
                                        className: cn('glass rounded-xl p-7 text-center transition-all duration-300 hover:border-gold/40'),
                                        children: [
                                            /*#__PURE__*/ _jsxDEV(CountUp, {
                                                target: stat.target,
                                                suffix: stat.suffix
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                lineNumber: 256,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ _jsxDEV("p", {
                                                className: "mt-2 text-sm text-mist-soft",
                                                children: stat.label
                                            }, void 0, false, {
                                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                                lineNumber: 257,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, stat.label, true, {
                                        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                        lineNumber: 247,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                                lineNumber: 245,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                            lineNumber: 240,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                    lineNumber: 105,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "D:/Projects/Portfolio-Web/src/components/sections/About.tsx",
        lineNumber: 102,
        columnNumber: 5
    }, this);
};
_s1(About, "GpcLnEGLCRT/LcXgsVwPMCbjDPg=", false, function() {
    return [
        useInView
    ];
});
_c1 = About;
export default About;
var _c, _c1;
$RefreshReg$(_c, "CountUp");
$RefreshReg$(_c1, "About");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("D:/Projects/Portfolio-Web/src/components/sections/About.tsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects/Portfolio-Web/src/components/sections/About.tsx", currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkFib3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgdXNlSW5WaWV3IH0gZnJvbSAncmVhY3QtaW50ZXJzZWN0aW9uLW9ic2VydmVyJztcbmltcG9ydCB7IEdyYWR1YXRpb25DYXAsIEF3YXJkLCBNYXBQaW4gfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IEF0bW9zcGhlcmUgZnJvbSAnQC9jb21wb25lbnRzL2F0bW9zcGhlcmUvQXRtb3NwaGVyZSc7XG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJztcblxuY29uc3QgQ291bnRVcCA9ICh7XG4gIHRhcmdldCxcbiAgc3VmZml4ID0gJycsXG59OiB7XG4gIHRhcmdldDogbnVtYmVyO1xuICBzdWZmaXg/OiBzdHJpbmc7XG59KSA9PiB7XG4gIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtyZWYsIGluVmlld10gPSB1c2VJblZpZXcoeyB0cmlnZ2VyT25jZTogdHJ1ZSwgdGhyZXNob2xkOiAwLjUgfSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWluVmlldykgcmV0dXJuO1xuICAgIGlmICh3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSknKS5tYXRjaGVzKSB7XG4gICAgICBzZXRWYWx1ZSh0YXJnZXQpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBkdXJhdGlvbiA9IDEyMDA7XG4gICAgY29uc3Qgc3RhcnQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICBsZXQgcmFmID0gMDtcblxuICAgIGNvbnN0IHRpY2sgPSAobm93OiBudW1iZXIpID0+IHtcbiAgICAgIGNvbnN0IHByb2dyZXNzID0gTWF0aC5taW4oKG5vdyAtIHN0YXJ0KSAvIGR1cmF0aW9uLCAxKTtcbiAgICAgIGNvbnN0IGVhc2VkID0gMSAtIE1hdGgucG93KDEgLSBwcm9ncmVzcywgMyk7XG4gICAgICBzZXRWYWx1ZShNYXRoLnJvdW5kKGVhc2VkICogdGFyZ2V0KSk7XG4gICAgICBpZiAocHJvZ3Jlc3MgPCAxKSByYWYgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGljayk7XG4gICAgfTtcblxuICAgIHJhZiA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh0aWNrKTtcbiAgICByZXR1cm4gKCkgPT4gY2FuY2VsQW5pbWF0aW9uRnJhbWUocmFmKTtcbiAgfSwgW2luVmlldywgdGFyZ2V0XSk7XG5cbiAgcmV0dXJuIChcbiAgICA8c3BhblxuICAgICAgcmVmPXtyZWZ9XG4gICAgICBjbGFzc05hbWU9J3RleHQtM3hsIG1kOnRleHQtNHhsIGZvbnQtYm9sZCBmb250LWhlYWRpbmcgZ29sZC10ZXh0J1xuICAgID5cbiAgICAgIHt2YWx1ZX1cbiAgICAgIHtzdWZmaXh9XG4gICAgPC9zcGFuPlxuICApO1xufTtcblxuY29uc3Qgc3RhdHMgPSBbXG4gIHsgbGFiZWw6ICdTeXN0ZW1zIEtlcHQgUnVubmluZycsIHRhcmdldDogNTAwLCBzdWZmaXg6ICcrJyB9LFxuICB7IGxhYmVsOiAnVGlja2V0cyBSZXNvbHZlZCcsIHRhcmdldDogMTAwMCwgc3VmZml4OiAnKycgfSxcbiAgeyBsYWJlbDogJ1Byb2plY3RzIEJ1aWx0JywgdGFyZ2V0OiA2LCBzdWZmaXg6ICcnIH0sXG4gIHsgbGFiZWw6ICdZZWFycyBpbiBJVCcsIHRhcmdldDogMywgc3VmZml4OiAnKycgfSxcbl07XG5cbmNvbnN0IGRpc2NpcGxpbmVzID0gW1xuICB7XG4gICAgY29kZTogJ1NZUycsXG4gICAgdGl0bGU6ICdTeXN0ZW1zJyxcbiAgICBkZXNjcmlwdGlvbjogJ1dpbmRvd3MgJiBMaW51eCBhZG1pbmlzdHJhdGlvbiwgaGFyZHdhcmUsIHRyb3VibGVzaG9vdGluZy4nLFxuICB9LFxuICB7XG4gICAgY29kZTogJ05FVCcsXG4gICAgdGl0bGU6ICdOZXR3b3JrJyxcbiAgICBkZXNjcmlwdGlvbjogJ1ZQTiwgV2ktRmksIHNoYXJpbmcsIGFuZCBtdWx0aS1mbG9vciBuZXR3b3JrIGRpYWdub3N0aWNzLicsXG4gIH0sXG4gIHtcbiAgICBjb2RlOiAnREVWJyxcbiAgICB0aXRsZTogJ0RldmVsb3BtZW50JyxcbiAgICBkZXNjcmlwdGlvbjogJ1B5dGhvbiwgUmVhY3QsIFR5cGVTY3JpcHQsIFNRTCwgYW5kIGF1dG9tYXRpb24gdG9vbGluZy4nLFxuICB9LFxuICB7XG4gICAgY29kZTogJ01MJyxcbiAgICB0aXRsZTogJ0FJL01MJyxcbiAgICBkZXNjcmlwdGlvbjogJ0RhdGEgcGlwZWxpbmVzLCBtb2RlbCB0cmFpbmluZywgYW5kIGNoYXRib3QgZGVwbG95bWVudC4nLFxuICB9LFxuXTtcblxuY29uc3QgYWNoaWV2ZW1lbnRzID0gW1xuICB7XG4gICAgaWNvbjogR3JhZHVhdGlvbkNhcCxcbiAgICB0ZXh0OiAnQi5TYyBDb21wdXRlciBFbmdpbmVlcmluZyAtIFVuaXZlcnNpdHkgb2YgR29uZGFyIChDR1BBOiAzLjQyLzQuMCknLFxuICB9LFxuICB7XG4gICAgaWNvbjogQXdhcmQsXG4gICAgdGV4dDogJ0FJL01MIEludGVybiBhdCBFdGhpb3BpYW4gQXJ0aWZpY2lhbCBJbnRlbGxpZ2VuY2UgSW5zdGl0dXRlIChFQUlJKScsXG4gIH0sXG4gIHtcbiAgICBpY29uOiBNYXBQaW4sXG4gICAgdGV4dDogJ1NlbmlvciBJVCBTdXBwb3J0IGF0IFJPVEVDSCBJbmZvcm1hdGlvbiBUZWNobm9sb2d5LCBBZGRpcyBBYmFiYScsXG4gIH0sXG5dO1xuXG5jb25zdCBBYm91dCA9ICgpID0+IHtcbiAgY29uc3QgW3JlZiwgaW5WaWV3XSA9IHVzZUluVmlldyh7XG4gICAgdHJpZ2dlck9uY2U6IHRydWUsXG4gICAgdGhyZXNob2xkOiAwLjEsXG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gaWQ9J2Fib3V0JyBjbGFzc05hbWU9J3JlbGF0aXZlIHB5LTI4IG92ZXJmbG93LWhpZGRlbic+XG4gICAgICA8QXRtb3NwaGVyZSB2YXJpYW50PSdtaXN0JyAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9J3JlbGF0aXZlIHotMTAgY29udGFpbmVyIG14LWF1dG8gcHgtNCc+XG4gICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgcmVmPXtyZWZ9XG4gICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiA0MCB9fVxuICAgICAgICAgIGFuaW1hdGU9e2luVmlldyA/IHsgb3BhY2l0eTogMSwgeTogMCB9IDoge319XG4gICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC44IH19XG4gICAgICAgICAgY2xhc3NOYW1lPSdtYXgtdy02eGwgbXgtYXV0bydcbiAgICAgICAgPlxuICAgICAgICAgIHsvKiBTZWN0aW9uIGhlYWRlciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nbWItMTYnPlxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAyMCB9fVxuICAgICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHk6IDAgfSA6IHt9fVxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjIsIGR1cmF0aW9uOiAwLjYgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPSdmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBtYi01J1xuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIHRyYWNraW5nLVswLjNlbV0gZ29sZC10ZXh0Jz5cbiAgICAgICAgICAgICAgICAwMSAvXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT0ndGV4dC0zeGwgbWQ6dGV4dC00eGwgZm9udC1ib2xkIGZvbnQtaGVhZGluZyB0cmFja2luZy10aWdodCc+XG4gICAgICAgICAgICAgICAgQWJvdXQgPHNwYW4gY2xhc3NOYW1lPSdnb2xkLXRleHQnPk1lPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0naGlkZGVuIG1kOmJsb2NrIGgtcHggZmxleC0xIGFsdC1ydWxlJyAvPlxuICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgPG1vdGlvbi5wXG4gICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMjAgfX1cbiAgICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB5OiAwIH0gOiB7fX1cbiAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkZWxheTogMC4zLCBkdXJhdGlvbjogMC42IH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT0nbWF4LXctMnhsIHRleHQtbGcgdGV4dC1taXN0LXNvZnQgbGVhZGluZy1yZWxheGVkIGZvbnQtbGlnaHQnXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIENvbXB1dGVyIEVuZ2luZWVyaW5nIGdyYWR1YXRlIGFuZCBTZW5pb3IgSVQgU3VwcG9ydCBzcGVjaWFsaXN0LFxuICAgICAgICAgICAgICBrZWVwaW5nIGVudGVycHJpc2Ugc3lzdGVtcyByZWxpYWJsZSBmcm9tIGhhcmR3YXJlIGFuZCBuZXR3b3JraW5nXG4gICAgICAgICAgICAgIHRvIGhlbHBkZXNrIGF1dG9tYXRpb24uXG4gICAgICAgICAgICA8L21vdGlvbi5wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEVkaXRvcmlhbCBiaW8gKyBkaXNjaXBsaW5lcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZ3JpZCBsZzpncmlkLWNvbHMtNSBnYXAtNiBtYi0xMCc+XG4gICAgICAgICAgICB7LyogQmlvICovfVxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAzMCB9fVxuICAgICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHk6IDAgfSA6IHt9fVxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjM1LCBkdXJhdGlvbjogMC42IH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT0nbGc6Y29sLXNwYW4tMydcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2dsYXNzLWNsb3VkIHJvdW5kZWQteGwgcC04IGgtZnVsbCBzcGFjZS15LTUnPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0ndGV4dC1sZyB0ZXh0LWZvcmVncm91bmQvOTAgbGVhZGluZy1yZWxheGVkIGZvbnQtaGVhZGluZyBmb250LW5vcm1hbCc+XG4gICAgICAgICAgICAgICAgICBJIGNvbWJpbmUgcHJhY3RpY2FsIElUIGluZnJhc3RydWN0dXJlIHNraWxscyB3aXRoIHNvZnR3YXJlXG4gICAgICAgICAgICAgICAgICBkZXZlbG9wbWVudCAtIGJ1aWxkaW5nIHRvb2xzIGxpa2UgdGhlIE1FU09CIGhlbHBkZXNrIHRpY2tldGluZ1xuICAgICAgICAgICAgICAgICAgc3lzdGVtIGFuZCByZW50YWwgbWFuYWdlbWVudCBwbGF0Zm9ybXMgdGhhdCBzb2x2ZSByZWFsXG4gICAgICAgICAgICAgICAgICBvcGVyYXRpb25hbCBwcm9ibGVtcy5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPSd0ZXh0LWxnIHRleHQtZm9yZWdyb3VuZC84MCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1oZWFkaW5nIGZvbnQtbm9ybWFsJz5cbiAgICAgICAgICAgICAgICAgIEZyb20gZGlhZ25vc2luZyBuZXR3b3JrIGZhdWx0cyBpbiBtdWx0aS1mbG9vciBvZmZpY2VzIHRvXG4gICAgICAgICAgICAgICAgICB0cmFpbmluZyBtYWNoaW5lIGxlYXJuaW5nIG1vZGVscywgSSB3b3JrIGFjcm9zcyB0aGUgZnVsbFxuICAgICAgICAgICAgICAgICAgdGVjaG5vbG9neSBzdGFjayB3aXRoIGEgY2FsbSwgZW5naW5lZXJpbmcgbWluZHNldC5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2ZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB0LTInPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdmb250LW1vbm8gdGV4dC14cyB0cmFja2luZy1bMC4yNWVtXSB0ZXh0LW1pc3Qtc29mdC83MCc+XG4gICAgICAgICAgICAgICAgICAgIFNUQVRVU1xuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdoLXB4IGZsZXgtMSBiZy1ib3JkZXInIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtZ29sZCc+XG4gICAgICAgICAgICAgICAgICAgIE9QRU4gVE8gT1BQT1JUVU5JVElFU1xuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgICAgICAgey8qIERpc2NpcGxpbmVzICovfVxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAzMCB9fVxuICAgICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHk6IDAgfSA6IHt9fVxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjQ1LCBkdXJhdGlvbjogMC42IH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT0nbGc6Y29sLXNwYW4tMiBncmlkIGdhcC00J1xuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7ZGlzY2lwbGluZXMubWFwKChkLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e2QuY29kZX1cbiAgICAgICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeDogMjAgfX1cbiAgICAgICAgICAgICAgICAgIGFuaW1hdGU9e2luVmlldyA/IHsgb3BhY2l0eTogMSwgeDogMCB9IDoge319XG4gICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjUgKyBpbmRleCAqIDAuMSwgZHVyYXRpb246IDAuNSB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPSdnbGFzcyByb3VuZGVkLXhsIHAtNSBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC00J1xuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQteHMgZ29sZC10ZXh0IHB0LTAuNSc+XG4gICAgICAgICAgICAgICAgICAgIHtkLmNvZGV9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPSdmb250LWhlYWRpbmcgZm9udC1zZW1pYm9sZCB0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWZvcmVncm91bmQnPlxuICAgICAgICAgICAgICAgICAgICAgIHtkLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3RleHQtc20gdGV4dC1taXN0LXNvZnQgbXQtMSBsZWFkaW5nLXJlbGF4ZWQnPlxuICAgICAgICAgICAgICAgICAgICAgIHtkLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEFjaGlldmVtZW50cyAqL31cbiAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAzMCB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB5OiAwIH0gOiB7fX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuNywgZHVyYXRpb246IDAuNiB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPSdtYi0xMCdcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nZ2xhc3MtY2xvdWQgcm91bmRlZC14bCBwLTgnPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPSdmb250LWhlYWRpbmcgZm9udC1zZW1pYm9sZCB0ZXh0LWxnIG1iLTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMnPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nZm9udC1tb25vIHRleHQteHMgdHJhY2tpbmctWzAuM2VtXSBnb2xkLXRleHQnPlxuICAgICAgICAgICAgICAgICAgTE9HXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIEtleSBBY2hpZXZlbWVudHNcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2dyaWQgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQnPlxuICAgICAgICAgICAgICAgIHthY2hpZXZlbWVudHMubWFwKChhY2hpZXZlbWVudCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT17YWNoaWV2ZW1lbnQudGV4dH1cbiAgICAgICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAyMCB9fVxuICAgICAgICAgICAgICAgICAgICBhbmltYXRlPXtpblZpZXcgPyB7IG9wYWNpdHk6IDEsIHk6IDAgfSA6IHt9fVxuICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGRlbGF5OiAwLjggKyBpbmRleCAqIDAuMSwgZHVyYXRpb246IDAuNSB9fVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9J2ZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIvNzAgaG92ZXI6Ym9yZGVyLWdvbGQvNDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwJ1xuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ncC0yIGJnLWdvbGQvMTAgcm91bmRlZC1sZyBzaHJpbmstMCc+XG4gICAgICAgICAgICAgICAgICAgICAgPGFjaGlldmVtZW50Lmljb24gY2xhc3NOYW1lPSdoLTUgdy01IGdvbGQtdGV4dCcgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0ndGV4dC1zbSB0ZXh0LWZvcmVncm91bmQvODUgbGVhZGluZy1yZWxheGVkJz5cbiAgICAgICAgICAgICAgICAgICAgICB7YWNoaWV2ZW1lbnQudGV4dH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgICAgIHsvKiBTdGF0cyAqL31cbiAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAzMCB9fVxuICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB5OiAwIH0gOiB7fX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDAuOSwgZHVyYXRpb246IDAuNiB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy00IGdhcC00Jz5cbiAgICAgICAgICAgICAge3N0YXRzLm1hcCgoc3RhdCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgICAga2V5PXtzdGF0LmxhYmVsfVxuICAgICAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAyMCB9fVxuICAgICAgICAgICAgICAgICAgYW5pbWF0ZT17aW5WaWV3ID8geyBvcGFjaXR5OiAxLCB5OiAwIH0gOiB7fX1cbiAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZGVsYXk6IDEuMCArIGluZGV4ICogMC4wOCwgZHVyYXRpb246IDAuNSB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgJ2dsYXNzIHJvdW5kZWQteGwgcC03IHRleHQtY2VudGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBob3Zlcjpib3JkZXItZ29sZC80MCdcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENvdW50VXAgdGFyZ2V0PXtzdGF0LnRhcmdldH0gc3VmZml4PXtzdGF0LnN1ZmZpeH0gLz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0nbXQtMiB0ZXh0LXNtIHRleHQtbWlzdC1zb2Z0Jz57c3RhdC5sYWJlbH08L3A+XG4gICAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQWJvdXQ7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIm1vdGlvbiIsInVzZUluVmlldyIsIkdyYWR1YXRpb25DYXAiLCJBd2FyZCIsIk1hcFBpbiIsIkF0bW9zcGhlcmUiLCJjbiIsIkNvdW50VXAiLCJ0YXJnZXQiLCJzdWZmaXgiLCJ2YWx1ZSIsInNldFZhbHVlIiwicmVmIiwiaW5WaWV3IiwidHJpZ2dlck9uY2UiLCJ0aHJlc2hvbGQiLCJ3aW5kb3ciLCJtYXRjaE1lZGlhIiwibWF0Y2hlcyIsImR1cmF0aW9uIiwic3RhcnQiLCJwZXJmb3JtYW5jZSIsIm5vdyIsInJhZiIsInRpY2siLCJwcm9ncmVzcyIsIk1hdGgiLCJtaW4iLCJlYXNlZCIsInBvdyIsInJvdW5kIiwicmVxdWVzdEFuaW1hdGlvbkZyYW1lIiwiY2FuY2VsQW5pbWF0aW9uRnJhbWUiLCJzcGFuIiwiY2xhc3NOYW1lIiwic3RhdHMiLCJsYWJlbCIsImRpc2NpcGxpbmVzIiwiY29kZSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJhY2hpZXZlbWVudHMiLCJpY29uIiwidGV4dCIsIkFib3V0Iiwic2VjdGlvbiIsImlkIiwidmFyaWFudCIsImRpdiIsImluaXRpYWwiLCJvcGFjaXR5IiwieSIsImFuaW1hdGUiLCJ0cmFuc2l0aW9uIiwiZGVsYXkiLCJoMiIsInAiLCJtYXAiLCJkIiwiaW5kZXgiLCJ4IiwiaDMiLCJhY2hpZXZlbWVudCIsInN0YXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSxPQUFPQSxTQUFTQyxTQUFTLEVBQUVDLFFBQVEsUUFBUSxRQUFRO0FBQ25ELFNBQVNDLE1BQU0sUUFBUSxnQkFBZ0I7QUFDdkMsU0FBU0MsU0FBUyxRQUFRLDhCQUE4QjtBQUN4RCxTQUFTQyxhQUFhLEVBQUVDLEtBQUssRUFBRUMsTUFBTSxRQUFRLGVBQWU7QUFDNUQsT0FBT0MsZ0JBQWdCLHFDQUFxQztBQUM1RCxTQUFTQyxFQUFFLFFBQVEsY0FBYztBQUVqQyxNQUFNQyxVQUFVLENBQUMsRUFDZkMsTUFBTSxFQUNOQyxTQUFTLEVBQUUsRUFJWjs7SUFDQyxNQUFNLENBQUNDLE9BQU9DLFNBQVMsR0FBR1osU0FBUztJQUNuQyxNQUFNLENBQUNhLEtBQUtDLE9BQU8sR0FBR1osVUFBVTtRQUFFYSxhQUFhO1FBQU1DLFdBQVc7SUFBSTtJQUVwRWpCLFVBQVU7UUFDUixJQUFJLENBQUNlLFFBQVE7UUFDYixJQUFJRyxPQUFPQyxVQUFVLENBQUMsb0NBQW9DQyxPQUFPLEVBQUU7WUFDakVQLFNBQVNIO1lBQ1Q7UUFDRjtRQUNBLE1BQU1XLFdBQVc7UUFDakIsTUFBTUMsUUFBUUMsWUFBWUMsR0FBRztRQUM3QixJQUFJQyxNQUFNO1FBRVYsTUFBTUMsT0FBTyxDQUFDRjtZQUNaLE1BQU1HLFdBQVdDLEtBQUtDLEdBQUcsQ0FBQyxBQUFDTCxDQUFBQSxNQUFNRixLQUFJLElBQUtELFVBQVU7WUFDcEQsTUFBTVMsUUFBUSxJQUFJRixLQUFLRyxHQUFHLENBQUMsSUFBSUosVUFBVTtZQUN6Q2QsU0FBU2UsS0FBS0ksS0FBSyxDQUFDRixRQUFRcEI7WUFDNUIsSUFBSWlCLFdBQVcsR0FBR0YsTUFBTVEsc0JBQXNCUDtRQUNoRDtRQUVBRCxNQUFNUSxzQkFBc0JQO1FBQzVCLE9BQU8sSUFBTVEscUJBQXFCVDtJQUNwQyxHQUFHO1FBQUNWO1FBQVFMO0tBQU87SUFFbkIscUJBQ0UsUUFBQ3lCO1FBQ0NyQixLQUFLQTtRQUNMc0IsV0FBVTs7WUFFVHhCO1lBQ0FEOzs7Ozs7O0FBR1A7R0F4Q01GOztRQVFrQk47OztLQVJsQk07QUEwQ04sTUFBTTRCLFFBQVE7SUFDWjtRQUFFQyxPQUFPO1FBQXdCNUIsUUFBUTtRQUFLQyxRQUFRO0lBQUk7SUFDMUQ7UUFBRTJCLE9BQU87UUFBb0I1QixRQUFRO1FBQU1DLFFBQVE7SUFBSTtJQUN2RDtRQUFFMkIsT0FBTztRQUFrQjVCLFFBQVE7UUFBR0MsUUFBUTtJQUFHO0lBQ2pEO1FBQUUyQixPQUFPO1FBQWU1QixRQUFRO1FBQUdDLFFBQVE7SUFBSTtDQUNoRDtBQUVELE1BQU00QixjQUFjO0lBQ2xCO1FBQ0VDLE1BQU07UUFDTkMsT0FBTztRQUNQQyxhQUFhO0lBQ2Y7SUFDQTtRQUNFRixNQUFNO1FBQ05DLE9BQU87UUFDUEMsYUFBYTtJQUNmO0lBQ0E7UUFDRUYsTUFBTTtRQUNOQyxPQUFPO1FBQ1BDLGFBQWE7SUFDZjtJQUNBO1FBQ0VGLE1BQU07UUFDTkMsT0FBTztRQUNQQyxhQUFhO0lBQ2Y7Q0FDRDtBQUVELE1BQU1DLGVBQWU7SUFDbkI7UUFDRUMsTUFBTXhDO1FBQ055QyxNQUFNO0lBQ1I7SUFDQTtRQUNFRCxNQUFNdkM7UUFDTndDLE1BQU07SUFDUjtJQUNBO1FBQ0VELE1BQU10QztRQUNOdUMsTUFBTTtJQUNSO0NBQ0Q7QUFFRCxNQUFNQyxRQUFROztJQUNaLE1BQU0sQ0FBQ2hDLEtBQUtDLE9BQU8sR0FBR1osVUFBVTtRQUM5QmEsYUFBYTtRQUNiQyxXQUFXO0lBQ2I7SUFFQSxxQkFDRSxRQUFDOEI7UUFBUUMsSUFBRztRQUFRWixXQUFVOzswQkFDNUIsUUFBQzdCO2dCQUFXMEMsU0FBUTs7Ozs7OzBCQUNwQixRQUFDQztnQkFBSWQsV0FBVTswQkFDYixjQUFBLFFBQUNsQyxPQUFPZ0QsR0FBRztvQkFDVHBDLEtBQUtBO29CQUNMcUMsU0FBUzt3QkFBRUMsU0FBUzt3QkFBR0MsR0FBRztvQkFBRztvQkFDN0JDLFNBQVN2QyxTQUFTO3dCQUFFcUMsU0FBUzt3QkFBR0MsR0FBRztvQkFBRSxJQUFJLENBQUM7b0JBQzFDRSxZQUFZO3dCQUFFbEMsVUFBVTtvQkFBSTtvQkFDNUJlLFdBQVU7O3NDQUdWLFFBQUNjOzRCQUFJZCxXQUFVOzs4Q0FDYixRQUFDbEMsT0FBT2dELEdBQUc7b0NBQ1RDLFNBQVM7d0NBQUVDLFNBQVM7d0NBQUdDLEdBQUc7b0NBQUc7b0NBQzdCQyxTQUFTdkMsU0FBUzt3Q0FBRXFDLFNBQVM7d0NBQUdDLEdBQUc7b0NBQUUsSUFBSSxDQUFDO29DQUMxQ0UsWUFBWTt3Q0FBRUMsT0FBTzt3Q0FBS25DLFVBQVU7b0NBQUk7b0NBQ3hDZSxXQUFVOztzREFFVixRQUFDRDs0Q0FBS0MsV0FBVTtzREFBK0M7Ozs7OztzREFHL0QsUUFBQ3FCOzRDQUFHckIsV0FBVTs7Z0RBQTZEOzhEQUNuRSxRQUFDRDtvREFBS0MsV0FBVTs4REFBWTs7Ozs7Ozs7Ozs7O3NEQUVwQyxRQUFDYzs0Q0FBSWQsV0FBVTs7Ozs7Ozs7Ozs7OzhDQUVqQixRQUFDbEMsT0FBT3dELENBQUM7b0NBQ1BQLFNBQVM7d0NBQUVDLFNBQVM7d0NBQUdDLEdBQUc7b0NBQUc7b0NBQzdCQyxTQUFTdkMsU0FBUzt3Q0FBRXFDLFNBQVM7d0NBQUdDLEdBQUc7b0NBQUUsSUFBSSxDQUFDO29DQUMxQ0UsWUFBWTt3Q0FBRUMsT0FBTzt3Q0FBS25DLFVBQVU7b0NBQUk7b0NBQ3hDZSxXQUFVOzhDQUNYOzs7Ozs7Ozs7Ozs7c0NBUUgsUUFBQ2M7NEJBQUlkLFdBQVU7OzhDQUViLFFBQUNsQyxPQUFPZ0QsR0FBRztvQ0FDVEMsU0FBUzt3Q0FBRUMsU0FBUzt3Q0FBR0MsR0FBRztvQ0FBRztvQ0FDN0JDLFNBQVN2QyxTQUFTO3dDQUFFcUMsU0FBUzt3Q0FBR0MsR0FBRztvQ0FBRSxJQUFJLENBQUM7b0NBQzFDRSxZQUFZO3dDQUFFQyxPQUFPO3dDQUFNbkMsVUFBVTtvQ0FBSTtvQ0FDekNlLFdBQVU7OENBRVYsY0FBQSxRQUFDYzt3Q0FBSWQsV0FBVTs7MERBQ2IsUUFBQ3NCO2dEQUFFdEIsV0FBVTswREFBc0U7Ozs7OzswREFNbkYsUUFBQ3NCO2dEQUFFdEIsV0FBVTswREFBc0U7Ozs7OzswREFLbkYsUUFBQ2M7Z0RBQUlkLFdBQVU7O2tFQUNiLFFBQUNEO3dEQUFLQyxXQUFVO2tFQUF3RDs7Ozs7O2tFQUd4RSxRQUFDRDt3REFBS0MsV0FBVTs7Ozs7O2tFQUNoQixRQUFDRDt3REFBS0MsV0FBVTtrRUFBOEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzhDQVFwRCxRQUFDbEMsT0FBT2dELEdBQUc7b0NBQ1RDLFNBQVM7d0NBQUVDLFNBQVM7d0NBQUdDLEdBQUc7b0NBQUc7b0NBQzdCQyxTQUFTdkMsU0FBUzt3Q0FBRXFDLFNBQVM7d0NBQUdDLEdBQUc7b0NBQUUsSUFBSSxDQUFDO29DQUMxQ0UsWUFBWTt3Q0FBRUMsT0FBTzt3Q0FBTW5DLFVBQVU7b0NBQUk7b0NBQ3pDZSxXQUFVOzhDQUVURyxZQUFZb0IsR0FBRyxDQUFDLENBQUNDLEdBQUdDLHNCQUNuQixRQUFDM0QsT0FBT2dELEdBQUc7NENBRVRDLFNBQVM7Z0RBQUVDLFNBQVM7Z0RBQUdVLEdBQUc7NENBQUc7NENBQzdCUixTQUFTdkMsU0FBUztnREFBRXFDLFNBQVM7Z0RBQUdVLEdBQUc7NENBQUUsSUFBSSxDQUFDOzRDQUMxQ1AsWUFBWTtnREFBRUMsT0FBTyxNQUFNSyxRQUFRO2dEQUFLeEMsVUFBVTs0Q0FBSTs0Q0FDdERlLFdBQVU7OzhEQUVWLFFBQUNEO29EQUFLQyxXQUFVOzhEQUNid0IsRUFBRXBCLElBQUk7Ozs7Ozs4REFFVCxRQUFDVTs7c0VBQ0MsUUFBQ2E7NERBQUczQixXQUFVO3NFQUNYd0IsRUFBRW5CLEtBQUs7Ozs7OztzRUFFVixRQUFDaUI7NERBQUV0QixXQUFVO3NFQUNWd0IsRUFBRWxCLFdBQVc7Ozs7Ozs7Ozs7Ozs7MkNBZGJrQixFQUFFcEIsSUFBSTs7Ozs7Ozs7Ozs7Ozs7OztzQ0F1Qm5CLFFBQUN0QyxPQUFPZ0QsR0FBRzs0QkFDVEMsU0FBUztnQ0FBRUMsU0FBUztnQ0FBR0MsR0FBRzs0QkFBRzs0QkFDN0JDLFNBQVN2QyxTQUFTO2dDQUFFcUMsU0FBUztnQ0FBR0MsR0FBRzs0QkFBRSxJQUFJLENBQUM7NEJBQzFDRSxZQUFZO2dDQUFFQyxPQUFPO2dDQUFLbkMsVUFBVTs0QkFBSTs0QkFDeENlLFdBQVU7c0NBRVYsY0FBQSxRQUFDYztnQ0FBSWQsV0FBVTs7a0RBQ2IsUUFBQzJCO3dDQUFHM0IsV0FBVTs7MERBQ1osUUFBQ0Q7Z0RBQUtDLFdBQVU7MERBQStDOzs7Ozs7NENBRXhEOzs7Ozs7O2tEQUdULFFBQUNjO3dDQUFJZCxXQUFVO2tEQUNaTyxhQUFhZ0IsR0FBRyxDQUFDLENBQUNLLGFBQWFILHNCQUM5QixRQUFDM0QsT0FBT2dELEdBQUc7Z0RBRVRDLFNBQVM7b0RBQUVDLFNBQVM7b0RBQUdDLEdBQUc7Z0RBQUc7Z0RBQzdCQyxTQUFTdkMsU0FBUztvREFBRXFDLFNBQVM7b0RBQUdDLEdBQUc7Z0RBQUUsSUFBSSxDQUFDO2dEQUMxQ0UsWUFBWTtvREFBRUMsT0FBTyxNQUFNSyxRQUFRO29EQUFLeEMsVUFBVTtnREFBSTtnREFDdERlLFdBQVU7O2tFQUVWLFFBQUNjO3dEQUFJZCxXQUFVO2tFQUNiLGNBQUEsUUFBQzRCLFlBQVlwQixJQUFJOzREQUFDUixXQUFVOzs7Ozs7Ozs7OztrRUFFOUIsUUFBQ0Q7d0RBQUtDLFdBQVU7a0VBQ2I0QixZQUFZbkIsSUFBSTs7Ozs7OzsrQ0FWZG1CLFlBQVluQixJQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0NBbUIvQixRQUFDM0MsT0FBT2dELEdBQUc7NEJBQ1RDLFNBQVM7Z0NBQUVDLFNBQVM7Z0NBQUdDLEdBQUc7NEJBQUc7NEJBQzdCQyxTQUFTdkMsU0FBUztnQ0FBRXFDLFNBQVM7Z0NBQUdDLEdBQUc7NEJBQUUsSUFBSSxDQUFDOzRCQUMxQ0UsWUFBWTtnQ0FBRUMsT0FBTztnQ0FBS25DLFVBQVU7NEJBQUk7c0NBRXhDLGNBQUEsUUFBQzZCO2dDQUFJZCxXQUFVOzBDQUNaQyxNQUFNc0IsR0FBRyxDQUFDLENBQUNNLE1BQU1KLHNCQUNoQixRQUFDM0QsT0FBT2dELEdBQUc7d0NBRVRDLFNBQVM7NENBQUVDLFNBQVM7NENBQUdDLEdBQUc7d0NBQUc7d0NBQzdCQyxTQUFTdkMsU0FBUzs0Q0FBRXFDLFNBQVM7NENBQUdDLEdBQUc7d0NBQUUsSUFBSSxDQUFDO3dDQUMxQ0UsWUFBWTs0Q0FBRUMsT0FBTyxNQUFNSyxRQUFROzRDQUFNeEMsVUFBVTt3Q0FBSTt3Q0FDdkRlLFdBQVc1QixHQUNUOzswREFHRixRQUFDQztnREFBUUMsUUFBUXVELEtBQUt2RCxNQUFNO2dEQUFFQyxRQUFRc0QsS0FBS3RELE1BQU07Ozs7OzswREFDakQsUUFBQytDO2dEQUFFdEIsV0FBVTswREFBK0I2QixLQUFLM0IsS0FBSzs7Ozs7Ozt1Q0FUakQyQixLQUFLM0IsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQmpDO0lBM0tNUTs7UUFDa0IzQzs7O01BRGxCMkM7QUE2S04sZUFBZUEsTUFBTSJ9